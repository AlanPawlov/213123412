# Unity MCP

Локальный MCP для открытого Unity Editor на Windows x64. Go-сервер запускается клиентом по `stdio` и выбирает проект по явно заданному пути. C#-мост устанавливается как Editor-only пакет. Помощник Windows Graphics Capture возвращает кадр главного окна Unity.

Целевой релизный Editor — Unity **6000.3.28f1**. При сборке используется Go **1.27.4** и Visual Studio Build Tools с компонентом Desktop development with C++ и Windows SDK **10.0.26100.0**.

## Сборка и установка

```powershell
go test ./...
.\build.ps1
```

В `dist` появятся папка комплекта, ZIP и SHA-256. В Unity выберите **Window → Package Manager → Add package from disk** и укажите `package.json` из папки `com.unity-mcp.bridge`. Храните папку пакета вместе с закреплённой версией поставки. Сохраните оба EXE рядом.

```powershell
& 'C:\Tools\UnityMCP\unity-mcp.exe' doctor --project 'C:\Projects\MyGame'
```

В рабочем столе текущего пользователя появляется `UnityMCP\<instance-id>.json`. Секрет защищён DPAPI текущего пользователя. Go проверяет совпадение проекта, поколение, процесс и доказательство владения секретом. Проект стартует в режиме чтения. Для редактирования сцены и C# включите соответствующие разрешения в **Tools → Unity MCP**. Разрешение C# сохраняется локально и используется при восстановлении из Safe Mode.

## Клиенты

Подставьте полный путь к EXE и к корню Unity-проекта. Добавляйте запись в существующую конфигурацию, сохраняя остальные настройки.

**Codex**

```powershell
codex mcp add unity -- 'C:\Tools\UnityMCP\unity-mcp.exe' serve --project 'C:\Projects\MyGame'
```

**Claude Desktop** в `%APPDATA%\Claude\claude_desktop_config.json` и **GigaCode CLI** в `.gigacode/settings.json` проекта

```json
{
  "mcpServers": {
    "unity": {
      "command": "C:\\Tools\\UnityMCP\\unity-mcp.exe",
      "args": ["serve", "--project", "C:\\Projects\\MyGame"]
    }
  }
}
```

## Рабочий сценарий

1. Вызовите `unity_status`, затем `scene_list` и `scene_hierarchy`. Идентификаторы сцены, объектов и компонентов нужно перечитать после смены поколения моста.
2. Для C# вызовите `script_read`, затем `script_write` с текущим `expected_sha256`. Для создания передайте `expected_absent: true`. `job_get` показывает состояние файла и результат наблюдаемой компиляции. `script_restore` использует резервную копию и проверяет текущий хеш. Ошибка компиляции оставляет файл доступным для исправления.
3. Добавьте скомпилированный скрипт через `component_add` с его GUID. Для правок используйте `serialized_inspect` и `serialized_patch` с возвращённой ревизией. Операции патча включают `set`, `resize`, `managed_new` и `managed_link`. Сохранение сцены выполняет `scene_save`. Вызов сохраняет также ручные изменения выбранной сцены.
4. Запустите `tests_run` и опрашивайте `job_get`. Если команда записи вернула `outcome_unknown`, сначала перечитайте состояние. `unity_screenshot` отдаёт PNG непосредственно клиенту. Основное окно Unity должно быть развёрнуто в интерактивном сеансе Windows.

Для отката обновления верните предыдущий комплект из Go-бинарника, помощника захвата и UPM-пакета. Проект с Unity 2023.2 мигрируйте в отдельной копии или ветке с проверкой тестов, сцен и целевой сборки до и после обновления.
