[CmdletBinding()]
param(
    [string] $OutputDirectory = (Join-Path $PSScriptRoot '.build')
)

$ErrorActionPreference = 'Stop'
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
if (-not (Test-Path -LiteralPath $vswhere)) {
    throw 'Install Visual Studio Build Tools with the Desktop development with C++ workload and Windows SDK 10.0.26100.0.'
}

$installation = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $installation) {
    throw 'Visual Studio with the x64 C++ build tools was not found.'
}

$msbuild = Join-Path $installation 'MSBuild/Current/Bin/amd64/MSBuild.exe'
$project = Join-Path $PSScriptRoot 'unity-mcp-capture.vcxproj'
$output = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputDirectory).Replace('\', '/').TrimEnd('/') + '/'
$intermediate = $output + 'obj/'
& $msbuild $project /nologo /m /nr:false /verbosity:minimal /p:Configuration=Release /p:Platform=x64 "/p:OutDir=$output" "/p:IntDir=$intermediate"
if ($LASTEXITCODE -ne 0) {
    throw "Capture helper build failed with MSBuild exit code $LASTEXITCODE."
}
