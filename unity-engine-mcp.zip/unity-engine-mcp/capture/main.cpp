#include <windows.h>
#include <d3d11.h>
#include <dwmapi.h>
#include <windows.graphics.capture.interop.h>
#include <windows.graphics.directx.direct3d11.interop.h>
#include <wincodec.h>

#include <winrt/Windows.Foundation.Metadata.h>
#include <winrt/Windows.Graphics.Capture.h>
#include <winrt/Windows.Graphics.DirectX.Direct3D11.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string_view>
#include <thread>
#include <vector>

namespace capture = winrt::Windows::Graphics::Capture;
namespace directx = winrt::Windows::Graphics::DirectX;
using winrt::Windows::Foundation::Metadata::ApiInformation;
using winrt::Windows::Graphics::SizeInt32;

namespace {
constexpr UINT defaultEdge = 1600;
constexpr UINT minEdge = 128;
constexpr UINT maxEdge = 2048;
constexpr UINT maxSourceEdge = 8192;
constexpr uint64_t maxSourcePixels = 32 * 1024 * 1024;
constexpr size_t maxPngBytes = 2 * 1024 * 1024;
constexpr auto frameTimeout = std::chrono::seconds(3);
constexpr auto framePollInterval = std::chrono::milliseconds(10);

struct Failure : std::runtime_error {
    char const* code;
    Failure(char const* code, char const* message) : std::runtime_error(message), code(code) {}
};

struct ProcessHandle {
    HANDLE value;
    explicit ProcessHandle(HANDLE handle) : value(handle) {}
    ProcessHandle(ProcessHandle const&) = delete;
    ProcessHandle& operator=(ProcessHandle const&) = delete;
    ~ProcessHandle() { if (value) CloseHandle(value); }
};

struct Options {
    HWND window = nullptr;
    DWORD pid = 0;
    uint64_t startTime = 0;
    UINT edge = defaultEdge;
};

struct Pixels {
    UINT width;
    UINT height;
    std::vector<BYTE> bgra;
};

uint64_t parseDecimal(std::wstring_view input, uint64_t limit) {
    if (input.empty()) throw Failure("invalid_arguments", "Expected an unsigned decimal number.");
    uint64_t value = 0;
    for (wchar_t digit : input) {
        if (digit < L'0' || digit > L'9' || value > (limit - (digit - L'0')) / 10) {
            throw Failure("invalid_arguments", "Unsigned decimal number is out of range.");
        }
        value = value * 10 + (digit - L'0');
    }
    return value;
}

Options parseOptions(int argc, wchar_t* argv[]) {
    Options options;
    bool edgeSet = false;
    for (int index = 1; index + 1 < argc; index += 2) {
        std::wstring_view flag = argv[index];
        std::wstring_view value = argv[index + 1];
        if (flag == L"--hwnd" && !options.window) {
            auto handle = parseDecimal(value, std::numeric_limits<uintptr_t>::max());
            options.window = reinterpret_cast<HWND>(static_cast<uintptr_t>(handle));
            if (!options.window) throw Failure("invalid_arguments", "HWND must be nonzero.");
        } else if (flag == L"--pid" && !options.pid) {
            options.pid = static_cast<DWORD>(parseDecimal(value, std::numeric_limits<DWORD>::max()));
            if (!options.pid) throw Failure("invalid_arguments", "PID must be nonzero.");
        } else if (flag == L"--start-time" && !options.startTime) {
            options.startTime = parseDecimal(value, std::numeric_limits<uint64_t>::max());
            if (!options.startTime) throw Failure("invalid_arguments", "Start time must be nonzero.");
        } else if (flag == L"--max-edge" && !edgeSet) {
            options.edge = static_cast<UINT>(parseDecimal(value, maxEdge));
            if (options.edge < minEdge) throw Failure("invalid_arguments", "Maximum edge must be at least 128 pixels.");
            edgeSet = true;
        } else {
            throw Failure("invalid_arguments", "Unexpected or duplicate capture option.");
        }
    }
    if (argc % 2 == 0 || !options.window || !options.pid || !options.startTime) {
        throw Failure("invalid_arguments", "Expected --hwnd N --pid N --start-time N [--max-edge N].");
    }
    return options;
}

uint64_t ticks(FILETIME time) {
    return (static_cast<uint64_t>(time.dwHighDateTime) << 32) | time.dwLowDateTime;
}

void verifyWindow(Options const& options, HANDLE process) {
    FILETIME created{}, exited{}, kernel{}, user{};
    DWORD owner = 0;
    GetWindowThreadProcessId(options.window, &owner);
    if (owner != options.pid ||
        WaitForSingleObject(process, 0) != WAIT_TIMEOUT ||
        !GetProcessTimes(process, &created, &exited, &kernel, &user) ||
        ticks(created) != options.startTime ||
        GetAncestor(options.window, GA_ROOT) != options.window ||
        GetWindow(options.window, GW_OWNER) ||
        !IsWindowVisible(options.window) ||
        IsIconic(options.window)) {
        throw Failure("capture_unavailable", "The target Unity Editor window is unavailable.");
    }
    DWORD cloaked = 0;
    if (SUCCEEDED(DwmGetWindowAttribute(options.window, DWMWA_CLOAKED, &cloaked, sizeof cloaked)) && cloaked) {
        throw Failure("capture_unavailable", "The target Unity Editor window is cloaked.");
    }
}

void verifyInteractiveDesktop() {
    HDESK desktop = OpenInputDesktop(0, FALSE, DESKTOP_READOBJECTS);
    if (!desktop) throw Failure("capture_unavailable", "The Windows input desktop is unavailable.");

    wchar_t name[256]{};
    BOOL read = GetUserObjectInformationW(desktop, UOI_NAME, name, sizeof name, nullptr);
    CloseDesktop(desktop);
    if (!read || CompareStringOrdinal(name, -1, L"Default", -1, TRUE) != CSTR_EQUAL) {
        throw Failure("capture_unavailable", "The Windows session is locked or on a noninteractive desktop.");
    }
}

void verifySize(SizeInt32 size) {
    if (size.Width <= 0 || size.Height <= 0) {
        throw Failure("capture_unavailable", "The Editor window has no drawable area.");
    }
    if (size.Width > static_cast<int32_t>(maxSourceEdge) ||
        size.Height > static_cast<int32_t>(maxSourceEdge) ||
        static_cast<uint64_t>(size.Width) * size.Height > maxSourcePixels) {
        throw Failure("capture_limit", "The source window exceeds the capture size limit.");
    }
}

Pixels readPixels(ID3D11Device* device, ID3D11DeviceContext* context, ID3D11Texture2D* source, SizeInt32 size) {
    UINT width = static_cast<UINT>(size.Width);
    UINT height = static_cast<UINT>(size.Height);
    D3D11_TEXTURE2D_DESC description{};
    description.Width = width;
    description.Height = height;
    description.MipLevels = 1;
    description.ArraySize = 1;
    description.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    description.SampleDesc.Count = 1;
    description.Usage = D3D11_USAGE_STAGING;
    description.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    winrt::com_ptr<ID3D11Texture2D> staging;
    winrt::check_hresult(device->CreateTexture2D(&description, nullptr, staging.put()));

    Pixels pixels{width, height, std::vector<BYTE>(static_cast<size_t>(width) * height * 4)};
    D3D11_BOX box{0, 0, 0, width, height, 1};
    context->CopySubresourceRegion(staging.get(), 0, 0, 0, 0, source, 0, &box);
    D3D11_MAPPED_SUBRESOURCE mapped{};
    winrt::check_hresult(context->Map(staging.get(), 0, D3D11_MAP_READ, 0, &mapped));
    auto sourceBytes = static_cast<BYTE const*>(mapped.pData);
    size_t rowBytes = static_cast<size_t>(width) * 4;
    for (UINT y = 0; y < height; ++y) {
        std::memcpy(pixels.bgra.data() + y * rowBytes, sourceBytes + y * static_cast<size_t>(mapped.RowPitch), rowBytes);
    }
    context->Unmap(staging.get(), 0);
    return pixels;
}

Pixels captureWindow(Options const& options, HANDLE process, char const*& step) {
    verifyInteractiveDesktop();
    verifyWindow(options, process);
    step = "check Windows Graphics Capture support";
    if (!capture::GraphicsCaptureSession::IsSupported()) {
        throw Failure("capture_unavailable", "Windows Graphics Capture is unavailable in this session.");
    }

    step = "create a capture item for the window";
    auto interop = winrt::get_activation_factory<capture::GraphicsCaptureItem, IGraphicsCaptureItemInterop>();
    capture::GraphicsCaptureItem item{nullptr};
    winrt::check_hresult(interop->CreateForWindow(options.window, winrt::guid_of<capture::IGraphicsCaptureItem>(), winrt::put_abi(item)));
    auto size = item.Size();
    verifySize(size);

    step = "create the Direct3D capture device";
    winrt::com_ptr<ID3D11Device> device;
    winrt::com_ptr<ID3D11DeviceContext> context;
    winrt::check_hresult(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
        nullptr, 0, D3D11_SDK_VERSION, device.put(), nullptr, context.put()));
    auto dxgiDevice = device.as<IDXGIDevice>();
    winrt::com_ptr<::IInspectable> inspectable;
    winrt::check_hresult(CreateDirect3D11DeviceFromDXGIDevice(dxgiDevice.get(), inspectable.put()));
    auto captureDevice = inspectable.as<directx::Direct3D11::IDirect3DDevice>();
    constexpr auto format = directx::DirectXPixelFormat::B8G8R8A8UIntNormalized;
    step = "configure the Windows capture session";
    auto pool = capture::Direct3D11CaptureFramePool::CreateFreeThreaded(captureDevice, format, 2, size);
    auto session = pool.CreateCaptureSession(item);
    constexpr auto sessionType = L"Windows.Graphics.Capture.GraphicsCaptureSession";
    if (ApiInformation::IsPropertyPresent(sessionType, L"IsCursorCaptureEnabled")) {
        session.IsCursorCaptureEnabled(false);
    }
    if (ApiInformation::IsPropertyPresent(sessionType, L"IncludeSecondaryWindows")) {
        session.IncludeSecondaryWindows(false);
    }
    verifyWindow(options, process);
    step = "start the Windows capture session";
    session.StartCapture();

    auto deadline = std::chrono::steady_clock::now() + frameTimeout;
    step = "read the Windows capture frame";
    while (std::chrono::steady_clock::now() < deadline) {
        verifyWindow(options, process);
        auto frame = pool.TryGetNextFrame();
        if (!frame) {
            std::this_thread::sleep_for(framePollInterval);
            continue;
        }
        auto contentSize = frame.ContentSize();
        verifySize(contentSize);
        auto access = frame.Surface().as<::Windows::Graphics::DirectX::Direct3D11::IDirect3DDxgiInterfaceAccess>();
        winrt::com_ptr<ID3D11Texture2D> texture;
        winrt::check_hresult(access->GetInterface(__uuidof(ID3D11Texture2D), texture.put_void()));
        D3D11_TEXTURE2D_DESC textureDescription{};
        texture->GetDesc(&textureDescription);
        if (textureDescription.Width < static_cast<UINT>(contentSize.Width) ||
            textureDescription.Height < static_cast<UINT>(contentSize.Height)) {
            texture = nullptr;
            frame.Close();
            pool.Recreate(captureDevice, format, 2, contentSize);
            continue;
        }
        auto pixels = readPixels(device.get(), context.get(), texture.get(), contentSize);
        texture = nullptr;
        frame.Close();
        if (std::none_of(pixels.bgra.begin(), pixels.bgra.end(), [](BYTE value) { return value != 0; })) {
            continue;
        }
        session.Close();
        pool.Close();
        return pixels;
    }
    throw Failure("capture_timeout", "Windows Graphics Capture produced no usable frame within 3 seconds.");
}

std::vector<BYTE> encodePng(IWICImagingFactory* factory, IWICBitmapSource* original, UINT originalWidth, UINT originalHeight, UINT edge) {
    auto longest = std::max(originalWidth, originalHeight);
    UINT width = originalWidth;
    UINT height = originalHeight;
    IWICBitmapSource* source = original;
    winrt::com_ptr<IWICBitmapScaler> scaler;
    if (longest > edge) {
        width = std::max(1u, originalWidth * edge / longest);
        height = std::max(1u, originalHeight * edge / longest);
        winrt::check_hresult(factory->CreateBitmapScaler(scaler.put()));
        winrt::check_hresult(scaler->Initialize(original, width, height, WICBitmapInterpolationModeFant));
        source = scaler.get();
    }
    winrt::com_ptr<IWICFormatConverter> converter;
    winrt::check_hresult(factory->CreateFormatConverter(converter.put()));
    winrt::check_hresult(converter->Initialize(source, GUID_WICPixelFormat24bppBGR,
        WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom));

    winrt::com_ptr<IStream> stream;
    winrt::check_hresult(CreateStreamOnHGlobal(nullptr, TRUE, stream.put()));
    winrt::com_ptr<IWICBitmapEncoder> encoder;
    winrt::check_hresult(factory->CreateEncoder(GUID_ContainerFormatPng, nullptr, encoder.put()));
    winrt::check_hresult(encoder->Initialize(stream.get(), WICBitmapEncoderNoCache));
    winrt::com_ptr<IWICBitmapFrameEncode> frame;
    winrt::check_hresult(encoder->CreateNewFrame(frame.put(), nullptr));
    winrt::check_hresult(frame->Initialize(nullptr));
    winrt::check_hresult(frame->SetSize(width, height));
    auto pixelFormat = GUID_WICPixelFormat24bppBGR;
    winrt::check_hresult(frame->SetPixelFormat(&pixelFormat));
    winrt::check_hresult(frame->WriteSource(converter.get(), nullptr));
    winrt::check_hresult(frame->Commit());
    winrt::check_hresult(encoder->Commit());

    STATSTG stats{};
    winrt::check_hresult(stream->Stat(&stats, STATFLAG_NONAME));
    if (stats.cbSize.QuadPart > maxPngBytes) return {};
    if (stats.cbSize.QuadPart == 0) throw Failure("capture_failed", "The PNG encoder produced no image.");
    std::vector<BYTE> png(static_cast<size_t>(stats.cbSize.QuadPart));
    LARGE_INTEGER beginning{};
    winrt::check_hresult(stream->Seek(beginning, STREAM_SEEK_SET, nullptr));
    ULONG read = 0;
    winrt::check_hresult(stream->Read(png.data(), static_cast<ULONG>(png.size()), &read));
    if (read != png.size()) throw Failure("capture_failed", "The PNG encoder returned an incomplete image.");
    return png;
}

std::vector<BYTE> makePng(Pixels& pixels, UINT edge) {
    auto factory = winrt::create_instance<IWICImagingFactory>(CLSID_WICImagingFactory);
    winrt::com_ptr<IWICBitmap> bitmap;
    winrt::check_hresult(factory->CreateBitmapFromMemory(pixels.width, pixels.height, GUID_WICPixelFormat32bppBGRA,
        pixels.width * 4, static_cast<UINT>(pixels.bgra.size()), pixels.bgra.data(), bitmap.put()));
    UINT targetEdge = std::max(minEdge, std::min(edge, std::max(pixels.width, pixels.height)));
    for (;;) {
        auto png = encodePng(factory.get(), bitmap.get(), pixels.width, pixels.height, targetEdge);
        if (!png.empty()) return png;
        if (targetEdge <= minEdge) throw Failure("capture_limit", "The PNG exceeds 2 MiB at the minimum capture size.");
        targetEdge = std::max(minEdge, targetEdge * 3 / 4);
    }
}

void writeOutput(std::vector<BYTE> const& png) {
    HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
    size_t offset = 0;
    while (offset < png.size()) {
        DWORD written = 0;
        if (!WriteFile(output, png.data() + offset, static_cast<DWORD>(png.size() - offset), &written, nullptr) || !written) {
            throw Failure("capture_failed", "Unable to write PNG to stdout.");
        }
        offset += written;
    }
}
} // namespace

int wmain(int argc, wchar_t* argv[]) {
    char const* step = "initialize the Windows Runtime";
    try {
        auto options = parseOptions(argc, argv);
        winrt::init_apartment(winrt::apartment_type::multi_threaded);
        ProcessHandle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, FALSE, options.pid));
        if (!process.value) throw Failure("capture_unavailable", "The target Unity Editor process is unavailable.");
        auto pixels = captureWindow(options, process.value, step);
        step = "encode the PNG";
        auto png = makePng(pixels, options.edge);
        verifyWindow(options, process.value);
        verifyInteractiveDesktop();
        writeOutput(png);
        return 0;
    } catch (Failure const& error) {
        std::fprintf(stderr, "%s\n%s\n", error.code, error.what());
    } catch (winrt::hresult_error const& error) {
        auto code = error.code().value;
        std::fprintf(stderr, "%s\nUnable to %s (HRESULT 0x%08lX).\n",
            code == E_ACCESSDENIED ? "capture_unavailable" : "capture_failed", step, static_cast<unsigned long>(code));
    } catch (std::exception const& error) {
        std::fprintf(stderr, "capture_failed\n%s\n", error.what());
    }
    return 1;
}
