package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"syscall"
	"time"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

const maxPNG = 2 << 20

type limitedBuffer struct {
	bytes.Buffer
	limit int
}

func (buffer *limitedBuffer) Write(p []byte) (int, error) {
	if len(p) > buffer.limit-buffer.Len() {
		return 0, errors.New("capture output exceeded its limit")
	}
	return buffer.Buffer.Write(p)
}

var captureCode = regexp.MustCompile(`^capture_[a-z_]{1,40}$`)

func (p project) screenshot(ctx context.Context, _ *mcp.CallToolRequest, args arguments) (*mcp.CallToolResult, any, error) {
	release, err := p.acquireMutex(ctx, "capture", 0)
	if err != nil {
		return resultError(err)
	}
	defer release()
	ep, err := p.findEndpoint(ctx)
	if err != nil {
		return resultError(err)
	}
	response, err := ep.call(ctx, "unity_status", json.RawMessage("{}"), false)
	if err != nil {
		return resultError(err)
	}
	var status struct {
		Window string `json:"hwnd"`
	}
	if err := json.Unmarshal(response, &status); err != nil {
		return resultError(failure("invalid_bridge_response", "The Editor returned invalid window metadata."))
	}
	hwnd, err := strconv.ParseUint(status.Window, 10, 64)
	if err != nil || hwnd == 0 {
		return resultError(failure("capture_unavailable", "The main Unity window is unavailable. Open it in the interactive Windows session."))
	}

	maxEdge := 1600
	if args["max_edge"] != nil {
		json.Unmarshal(args["max_edge"], &maxEdge)
	}
	executable, err := os.Executable()
	if err != nil {
		return resultError(err)
	}
	ctx, cancel := context.WithTimeout(ctx, 8*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, filepath.Join(filepath.Dir(executable), "unity-mcp-capture.exe"),
		"--hwnd", strconv.FormatUint(hwnd, 10), "--pid", strconv.FormatUint(uint64(ep.PID), 10),
		"--start-time", ep.StartedAt, "--max-edge", strconv.Itoa(maxEdge))
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	cmd.WaitDelay = time.Second
	stdout := limitedBuffer{limit: maxPNG}
	stderr := limitedBuffer{limit: 4096}
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		if ctx.Err() != nil {
			return resultError(failure("capture_timeout", "Timed out waiting for a fresh Unity frame."))
		}
		if errors.Is(err, os.ErrNotExist) {
			return resultError(failure("capture_unavailable", "Install unity-mcp-capture.exe next to unity-mcp.exe."))
		}
		code, message, _ := strings.Cut(strings.TrimSpace(stderr.String()), "\n")
		code = strings.TrimSpace(code)
		if captureCode.MatchString(code) {
			return resultError(failure(code, strings.TrimSpace(message)))
		}
		return resultError(failure("capture_failed", "The window capture helper failed."))
	}
	data := stdout.Bytes()
	config, err := png.DecodeConfig(bytes.NewReader(data))
	if err != nil || config.Width < 1 || config.Height < 1 || max(config.Width, config.Height) > maxEdge {
		return resultError(failure("invalid_capture", "The capture helper did not return a PNG within the expected limits."))
	}
	received := time.Now().UTC()
	if _, err := png.Decode(bytes.NewReader(data)); err != nil {
		return resultError(failure("invalid_capture", "The capture helper returned an incomplete or corrupt PNG."))
	}
	return imageResult(data, fmt.Sprintf("Unity Editor, %d × %d, received at %s.", config.Width, config.Height, received.Format(time.RFC3339Nano))), nil, nil
}

func imageResult(data []byte, description string) *mcp.CallToolResult {
	return &mcp.CallToolResult{Content: []mcp.Content{
		&mcp.ImageContent{Data: data, MIMEType: "image/png"},
		&mcp.TextContent{Text: description},
	}}
}

func runVisionProbe(ctx context.Context) error {
	server := newServer("unity-mcp-vision-probe", "Call unity_vision_probe, then read the six digits and name the marker color shown in the returned image.")
	registerTool(server, unityTool{"unity_vision_probe", "Return a visual test card. Read the six digits and report the marker color.", true, "", nil},
		func(_ context.Context, _ *mcp.CallToolRequest, _ arguments) (*mcp.CallToolResult, any, error) {
			data, digits, label, err := createVisionCard()
			if err != nil {
				return resultError(err)
			}
			fmt.Fprintf(os.Stderr, "Vision probe answer for operator: %s %s\n", digits, label)
			return imageResult(data, "Visual test card. Read the six digits and name the color of the square."), nil, nil
		})
	return server.Run(ctx, &mcp.StdioTransport{MaxLineLength: 4 << 20})
}

func createVisionCard() ([]byte, string, string, error) {
	entropy := randomBytes(7)
	markers := []struct {
		label string
		color color.RGBA
	}{
		{"red", color.RGBA{220, 35, 35, 255}},
		{"blue", color.RGBA{30, 80, 230, 255}},
		{"green", color.RGBA{25, 150, 55, 255}},
		{"yellow", color.RGBA{245, 207, 30, 255}},
	}
	marker := markers[int(entropy[6])%len(markers)]
	card := image.NewRGBA(image.Rect(0, 600, 620, 770))
	draw.Draw(card, card.Bounds(), image.NewUniform(color.White), image.Point{}, draw.Src)
	segments := [7]image.Rectangle{
		image.Rect(10, 0, 48, 8), image.Rect(48, 8, 56, 43), image.Rect(48, 51, 56, 87),
		image.Rect(10, 87, 48, 95), image.Rect(2, 51, 10, 87), image.Rect(2, 8, 10, 43),
		image.Rect(10, 43, 48, 51),
	}
	patterns := [10]uint8{0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f}
	digits := make([]byte, 6)
	for i, value := range entropy[:6] {
		digit := value % 10
		digits[i] = '0' + digit
		for segment, rect := range segments {
			if patterns[digit]&(1<<segment) != 0 {
				draw.Draw(card, rect.Add(image.Pt(30+i*72, 635)), image.NewUniform(color.Black), image.Point{}, draw.Src)
			}
		}
	}
	draw.Draw(card, image.Rect(500, 642, 584, 726), image.NewUniform(marker.color), image.Point{}, draw.Src)
	var result bytes.Buffer
	err := png.Encode(&result, card)
	return result.Bytes(), string(digits), marker.label, err
}
