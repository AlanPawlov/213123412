package main

import (
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"golang.org/x/sys/windows"
)

func TestValidAssetPath(t *testing.T) {
	for _, path := range []string{"Assets", "Assets/Scripts/Player.cs", "Assets/Скрипты/Камера.cs", "Assets/a file.cs"} {
		if !validAssetPath(path) {
			t.Errorf("rejected valid path %q", path)
		}
	}
	for _, path := range []string{
		"Packages/Runtime.cs",
		"Assets/../Outside.cs",
		"Assets/./Runtime.cs",
		"Assets//Runtime.cs",
		"Assets/Scripts/",
		"Assets/Scripts /Runtime.cs",
		"Assets/NUL.cs",
		"Assets/COM¹.cs",
		"Assets/CON /Runtime.cs",
		"Assets/Runtime.cs:other",
		"Assets\\Scripts\\Runtime.cs",
		"Assets/Scripts\x00/Runtime.cs",
		"C:/Assets/Runtime.cs",
	} {
		if validAssetPath(path) {
			t.Errorf("accepted invalid path %q", path)
		}
	}
}

func TestScriptTargetValidatesProjectAndFileIdentity(t *testing.T) {
	project := makeScriptProject(t)
	const relative = "Assets/Scripts/Камера.cs"
	target, err := project.resolveScript(relative)
	if err != nil {
		t.Fatal(err)
	}
	path := target.path
	target.close()
	writeFixture(t, path, []byte("class CameraScript {}"))

	if _, err := project.resolveScript("Assets/Missing/Камера.cs"); err == nil {
		t.Error("resolved a missing parent")
	}
	if _, err := project.resolveScript("Assets/Scripts/Камера.cs.meta"); err == nil {
		t.Error("resolved a file without a .cs extension")
	}
	stale := project
	stale.id += "-stale"
	_, err = stale.resolveScript(relative)
	requireToolError(t, err, "invalid_path")

	hardlink := filepath.Join(filepath.Dir(path), "linked.cs")
	if err := os.Link(path, hardlink); err != nil {
		t.Fatal(err)
	}
	_, err = readScriptFile(path)
	requireToolError(t, err, "invalid_path")
}

func TestAtomicScriptReplacementKeepsBackupAndMeta(t *testing.T) {
	project := makeScriptProject(t)
	target, err := project.resolveScript("Assets/Scripts/Game.cs")
	if err != nil {
		t.Fatal(err)
	}
	defer target.close()
	dir := filepath.Dir(target.path)
	previous := []byte("// Original\n")
	updated := []byte("// Updated\n")
	meta := []byte("guid: e9069a157ae54851b5a91024581ba84f\n")
	writeFixture(t, target.path, previous)
	writeFixture(t, target.path+".meta", meta)

	temp, err := writeTemp(dir, updated)
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(temp)
	if err := moveFile(temp, target.path, windows.MOVEFILE_WRITE_THROUGH); !errors.Is(err, windows.ERROR_ALREADY_EXISTS) && !errors.Is(err, windows.ERROR_FILE_EXISTS) {
		t.Fatalf("create-only move did not refuse an existing script: %v", err)
	}
	checkFixture(t, target.path, previous)
	backup := filepath.Join(dir, ".game.cs.backup")
	if err := replaceScript(target.path, temp, backup); err != nil {
		t.Fatal(err)
	}
	checkFixture(t, target.path, updated)
	checkFixture(t, backup, previous)
	checkFixture(t, target.path+".meta", meta)

	journal := filepath.Join(dir, "journal.json")
	if err := atomicFile(journal, []byte(`{"file_status":"intent"}`)); err != nil {
		t.Fatal(err)
	}
	committed := []byte(`{"file_status":"committed"}`)
	if err := atomicFile(journal, committed); err != nil {
		t.Fatal(err)
	}
	checkFixture(t, journal, committed)
}

func TestRecoverPendingScriptWriteChecksArchivedBackup(t *testing.T) {
	project := makeScriptProject(t)
	path := filepath.Join(project.root, "Assets", "Scripts", "Game.cs")
	dir := t.TempDir()
	previous := []byte("// Original\n")
	updated := []byte("// Updated\n")
	writeFixture(t, path, updated)
	job := scriptJob{
		ID: "0123456789abcdef0123456789abcdef", Path: "Assets/Scripts/Game.cs",
		Previous: digest(previous), SHA256: digest(updated), FileStatus: "intent",
	}

	archive := filepath.Join(dir, "previous.cs")
	if got := project.inspectPendingJob(job, dir); got.FileStatus != "intent" {
		t.Errorf("recovered state without verified original = %q, want intent", got.FileStatus)
	}
	writeFixture(t, archive, []byte("// External save won the race before ReplaceFileW\n"))
	if got := project.inspectPendingJob(job, dir); got.FileStatus != "conflict" {
		t.Errorf("recovered state = %q, want conflict", got.FileStatus)
	}
	writeFixture(t, archive, previous)
	if got := project.inspectPendingJob(job, dir); got.FileStatus != "committed" {
		t.Errorf("recovered state = %q, want committed", got.FileStatus)
	}
	writeFixture(t, path, []byte("// No longer matches the intended write\n"))
	if got := project.inspectPendingJob(job, dir); got.FileStatus != "intent" {
		t.Errorf("recovered state = %q, want intent", got.FileStatus)
	}
}

func TestScriptFilesSupportLongNTFSPaths(t *testing.T) {
	project := makeScriptProject(t)
	folder := "Assets/Scripts/" + strings.Repeat("long-directory-", 10) + "/" + strings.Repeat("another-folder-", 10)
	if err := os.MkdirAll(filepath.Join(project.root, filepath.FromSlash(folder)), 0700); err != nil {
		t.Fatal(err)
	}
	target, err := project.resolveScript(folder + "/LongPath.cs")
	if err != nil {
		t.Fatal(err)
	}
	defer target.close()
	if len(target.path) <= 260 {
		t.Fatalf("test path does not exceed MAX_PATH: %d", len(target.path))
	}
	data := []byte("// Long path\n")
	if err := atomicFile(target.path, data); err != nil {
		t.Fatal(err)
	}
	got, err := readScriptFile(target.path)
	if err != nil || !bytes.Equal(got, data) {
		t.Fatalf("read after atomic move = %q, %v", got, err)
	}
}

func makeScriptProject(t *testing.T) project {
	t.Helper()
	root := filepath.Join(t.TempDir(), "Unity project Тест")
	for _, dir := range []string{"ProjectSettings", "Assets/Scripts"} {
		if err := os.MkdirAll(filepath.Join(root, filepath.FromSlash(dir)), 0o700); err != nil {
			t.Fatal(err)
		}
	}
	writeFixture(t, filepath.Join(root, "ProjectSettings", "ProjectVersion.txt"), []byte("m_EditorVersion: 6000.3.28f1\n"))
	project, err := openProject(root)
	if err != nil {
		t.Fatal(err)
	}
	return project
}

func writeFixture(t *testing.T, path string, content []byte) {
	t.Helper()
	if err := os.WriteFile(path, content, 0o600); err != nil {
		t.Fatal(err)
	}
}

func checkFixture(t *testing.T, path string, want []byte) {
	t.Helper()
	if content, err := os.ReadFile(path); err != nil || !bytes.Equal(content, want) {
		t.Errorf("%s = %q, %v, want %q", filepath.Base(path), content, err, want)
	}
}
