package main

import (
	"bytes"
	"context"
	"fmt"
	"image"
	"image/color"
	"image/png"
	"os"
	"os/exec"
	"regexp"
	"strings"
	"testing"
	"time"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

const visionProbeChild = "UNITY_MCP_VISION_PROBE_TEST_CHILD"

func TestVisionProbeChild(t *testing.T) {
	if os.Getenv(visionProbeChild) != "1" {
		return
	}
	if err := run(context.Background(), []string{"vision-probe"}); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	os.Exit(0)
}

func TestVisionProbeOverStdio(t *testing.T) {
	executable, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, executable, "-test.run=^TestVisionProbeChild$")
	cmd.Env = append(os.Environ(), visionProbeChild+"=1")
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	client := mcp.NewClient(&mcp.Implementation{Name: "unity-mcp-probe-test", Version: "1"}, nil)
	session, err := client.Connect(ctx, &mcp.CommandTransport{Command: cmd}, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer session.Close()
	list, err := session.ListTools(ctx, nil)
	if err != nil || len(list.Tools) != 1 || list.Tools[0].Name != "unity_vision_probe" {
		t.Fatalf("tools/list = %#v, %v", list, err)
	}
	result, err := session.CallTool(ctx, &mcp.CallToolParams{Name: "unity_vision_probe"})
	if err != nil {
		t.Fatal(err)
	}
	if result.IsError || result.StructuredContent != nil || len(result.Content) != 2 {
		t.Fatalf("unexpected result shape: error=%v, structured=%v, content items=%d",
			result.IsError, result.StructuredContent, len(result.Content))
	}
	picture, ok := result.Content[0].(*mcp.ImageContent)
	if !ok || picture.MIMEType != "image/png" || len(picture.Data) > maxPNG {
		t.Fatalf("first content is not a bounded PNG: %T", result.Content[0])
	}
	text, ok := result.Content[1].(*mcp.TextContent)
	if !ok {
		t.Fatalf("second content is not explanatory text: %T", result.Content[1])
	}
	if err := session.Close(); err != nil {
		t.Fatal(err)
	}

	match := regexp.MustCompile(`Vision probe answer for operator: ([0-9]{6}) (red|blue|green|yellow)`).FindStringSubmatch(stderr.String())
	if len(match) != 3 {
		t.Fatalf("operator did not receive a valid answer on stderr: %q", stderr.String())
	}
	digits, marker := match[1], match[2]
	if strings.Contains(text.Text, digits) || regexp.MustCompile(`\b(red|blue|green|yellow)\b`).MatchString(text.Text) {
		t.Fatalf("tool response leaks the answer outside the PNG: %q", text.Text)
	}
	checkVisionCard(t, picture.Data, digits, marker)
}

func checkVisionCard(t *testing.T, data []byte, digits, marker string) {
	t.Helper()
	card, err := png.Decode(bytes.NewReader(data))
	if err != nil {
		t.Fatalf("invalid probe PNG: %v", err)
	}
	if card.Bounds() != image.Rect(0, 0, 620, 170) {
		t.Fatalf("unexpected probe PNG bounds: %v", card.Bounds())
	}
	colorForMarker := map[string]color.RGBA{
		"red": {220, 35, 35, 255}, "blue": {30, 80, 230, 255},
		"green": {25, 150, 55, 255}, "yellow": {245, 207, 30, 255},
	}
	if pixel := color.RGBAModel.Convert(card.At(542, 84)); pixel != colorForMarker[marker] {
		t.Errorf("PNG marker = %v, operator reports %s", pixel, marker)
	}
	digitForSegments := map[byte]byte{
		0x3f: '0', 0x06: '1', 0x5b: '2', 0x4f: '3', 0x66: '4',
		0x6d: '5', 0x7d: '6', 0x07: '7', 0x7f: '8', 0x6f: '9',
	}
	points := []image.Point{{28, 4}, {52, 25}, {52, 66}, {28, 91}, {6, 66}, {6, 25}, {28, 47}}
	decoded := make([]byte, len(digits))
	for i := range decoded {
		var segments byte
		for segment, point := range points {
			r, g, b, _ := card.At(30+i*72+point.X, 35+point.Y).RGBA()
			if r == 0 && g == 0 && b == 0 {
				segments |= 1 << segment
			}
		}
		decoded[i] = digitForSegments[segments]
	}
	if string(decoded) != digits {
		t.Errorf("PNG challenge = %q, operator reports %q", decoded, digits)
	}
}

func TestCaptureOutputLimit(t *testing.T) {
	out := limitedBuffer{limit: 5}
	if n, err := out.Write([]byte("12345")); n != 5 || err != nil {
		t.Fatalf("write at limit = %d, %v", n, err)
	}
	if n, err := out.Write([]byte("6")); n != 0 || err == nil || out.String() != "12345" {
		t.Fatalf("write beyond limit = %d, %v, contents %q", n, err, out.String())
	}
}

func TestLiveUnityScreenshot(t *testing.T) {
	project, server := os.Getenv("UNITY_MCP_LIVE_TEST_PROJECT"), os.Getenv("UNITY_MCP_LIVE_TEST_SERVER")
	if project == "" || server == "" {
		t.Skip("set UNITY_MCP_LIVE_TEST_PROJECT and UNITY_MCP_LIVE_TEST_SERVER to exercise an open Unity Editor")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, server, "serve", "--project", project)
	cmd.Stderr = os.Stderr
	client := mcp.NewClient(&mcp.Implementation{Name: "unity-mcp-live-test", Version: "1"}, nil)
	session, err := client.Connect(ctx, &mcp.CommandTransport{Command: cmd}, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer session.Close()

	const edge = 1024
	result, err := session.CallTool(ctx, &mcp.CallToolParams{Name: "unity_screenshot", Arguments: map[string]any{"max_edge": edge}})
	if err != nil {
		t.Fatal(err)
	}
	if result.IsError {
		t.Fatalf("Unity screenshot failed: %v", result.Content)
	}
	if len(result.Content) != 2 {
		t.Fatalf("unexpected result length: %d", len(result.Content))
	}
	picture, ok := result.Content[0].(*mcp.ImageContent)
	if !ok || picture.MIMEType != "image/png" || len(picture.Data) > maxPNG {
		t.Fatalf("live Unity screenshot is not a bounded PNG: %T", result.Content[0])
	}
	decoded, err := png.Decode(bytes.NewReader(picture.Data))
	if err != nil {
		t.Fatal(err)
	}
	width, height := decoded.Bounds().Dx(), decoded.Bounds().Dy()
	if width < 1 || height < 1 || max(width, height) > edge {
		t.Fatalf("PNG dimensions %d x %d exceed the request limit %d", width, height, edge)
	}
	t.Logf("Unity screenshot arrived over MCP as a %d x %d PNG with %d bytes", width, height, len(picture.Data))
}
