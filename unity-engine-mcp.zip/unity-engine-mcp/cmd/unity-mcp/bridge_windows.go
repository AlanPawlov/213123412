package main

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"unsafe"

	"golang.org/x/sys/windows"
)

const (
	bridgeProtocol = 1
	maxFrame       = 4 << 20
	maxDescriptor  = 16 << 10
)

type toolError struct {
	Code    string `json:"code"`
	Message string `json:"message"`
	JobID   string `json:"job_id,omitempty"`
}

func (err *toolError) Error() string { return err.Code + ": " + err.Message }

func failure(code, message string) error { return &toolError{Code: code, Message: message} }

type project struct {
	root string
	id   string
}

func openProject(root string) (project, error) {
	if !filepath.IsAbs(root) {
		return project{}, errors.New("--project must be an absolute path")
	}
	root = filepath.Clean(root)
	info, err := os.Stat(filepath.Join(root, "ProjectSettings", "ProjectVersion.txt"))
	if err != nil || !info.Mode().IsRegular() {
		return project{}, errors.New("project must contain ProjectSettings/ProjectVersion.txt")
	}
	handle, err := openWindowsFile(root, windows.FILE_READ_ATTRIBUTES, windows.FILE_SHARE_READ|windows.FILE_SHARE_WRITE|windows.FILE_SHARE_DELETE, windows.FILE_FLAG_BACKUP_SEMANTICS)
	if err != nil {
		return project{}, err
	}
	defer windows.CloseHandle(handle)
	var identity windows.ByHandleFileInformation
	if err := windows.GetFileInformationByHandle(handle, &identity); err != nil {
		return project{}, err
	}
	index := uint64(identity.FileIndexHigh)<<32 | uint64(identity.FileIndexLow)
	return project{root, fmt.Sprintf("%08x-%016x", identity.VolumeSerialNumber, index)}, nil
}

func openWindowsFile(path string, access, share, flags uint32) (windows.Handle, error) {
	name, err := windows.UTF16PtrFromString(windowsPath(path))
	if err != nil {
		return windows.InvalidHandle, err
	}
	return windows.CreateFile(name, access, share, nil, windows.OPEN_EXISTING, flags, 0)
}

func windowsPath(path string) string {
	path = filepath.Clean(path)
	if !filepath.IsAbs(path) || strings.HasPrefix(path, `\\?\`) || strings.HasPrefix(path, `\\.\`) {
		return path
	}
	if strings.HasPrefix(path, `\\`) {
		return `\\?\UNC\` + path[2:]
	}
	return `\\?\` + path
}

type identity struct {
	InstanceID string `json:"instance_id"`
	ProjectID  string `json:"project_id"`
	Generation string `json:"generation"`
	Protocol   int    `json:"protocol"`
	Port       int    `json:"port"`
	PID        uint32 `json:"pid"`
	StartedAt  string `json:"started_at"`
}

type descriptor struct {
	identity
	Secret string `json:"secret"`
}

type protectedDescriptor struct {
	identity
	Key string `json:"key"`
}

type endpoint struct {
	identity
	key []byte
}

func descriptorDirectory() (string, error) {
	desktop, err := windows.KnownFolderPath(windows.FOLDERID_Desktop, 0)
	if err != nil {
		return "", err
	}
	return filepath.Join(desktop, "UnityMCP"), nil
}

func readWindowsFile(path string, limit int64) ([]byte, error) {
	handle, err := openWindowsFile(path, windows.GENERIC_READ, windows.FILE_SHARE_READ|windows.FILE_SHARE_WRITE|windows.FILE_SHARE_DELETE, windows.FILE_FLAG_OPEN_REPARSE_POINT)
	if err != nil {
		return nil, err
	}
	file := os.NewFile(uintptr(handle), path)
	defer file.Close()
	return readBounded(file, limit)
}

func readBounded(reader io.Reader, limit int64) ([]byte, error) {
	data, err := io.ReadAll(io.LimitReader(reader, limit+1))
	if err != nil {
		return nil, err
	}
	if int64(len(data)) > limit {
		return nil, errors.New("file or stream exceeds its size limit")
	}
	return data, nil
}

func unprotect(encoded string) (protectedDescriptor, error) {
	var protected protectedDescriptor
	ciphertext, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil || len(ciphertext) == 0 {
		return protected, errors.New("invalid DPAPI block")
	}
	input := windows.DataBlob{Size: uint32(len(ciphertext)), Data: &ciphertext[0]}
	var output windows.DataBlob
	if err := windows.CryptUnprotectData(&input, nil, nil, 0, nil, windows.CRYPTPROTECT_UI_FORBIDDEN, &output); err != nil {
		return protected, err
	}
	defer windows.LocalFree(windows.Handle(uintptr(unsafe.Pointer(output.Data))))
	if output.Size > maxDescriptor || output.Data == nil {
		return protected, errors.New("invalid protected descriptor size")
	}
	data := unsafe.Slice(output.Data, int(output.Size))
	defer clear(data)
	err = json.Unmarshal(data, &protected)
	return protected, err
}

func processStart(pid uint32) (string, error) {
	process, err := windows.OpenProcess(windows.PROCESS_QUERY_LIMITED_INFORMATION, false, pid)
	if err != nil {
		return "", err
	}
	defer windows.CloseHandle(process)
	var creation, exit, kernel, user windows.Filetime
	if err := windows.GetProcessTimes(process, &creation, &exit, &kernel, &user); err != nil {
		return "", err
	}
	if exit.HighDateTime != 0 || exit.LowDateTime != 0 {
		return "", errors.New("Unity process has exited")
	}
	return strconv.FormatUint(uint64(creation.HighDateTime)<<32|uint64(creation.LowDateTime), 10), nil
}

func (p project) findEndpoint(ctx context.Context) (endpoint, error) {
	dir, err := descriptorDirectory()
	if err != nil {
		return endpoint{}, failure("desktop_unavailable", "Cannot resolve the current Windows Desktop: "+err.Error())
	}
	entries, err := os.ReadDir(dir)
	if os.IsNotExist(err) {
		return endpoint{}, failure("editor_unavailable", "Open the project in Unity with the Editor Bridge package installed.")
	}
	if err != nil {
		return endpoint{}, failure("desktop_unavailable", "Cannot read the Desktop descriptor directory: "+err.Error())
	}
	var matches []endpoint
	var incompatible bool
	for _, entry := range entries {
		if ctx.Err() != nil {
			return endpoint{}, ctx.Err()
		}
		if entry.IsDir() || filepath.Ext(entry.Name()) != ".json" {
			continue
		}
		var desc descriptor
		data, err := readWindowsFile(filepath.Join(dir, entry.Name()), maxDescriptor)
		if err != nil || json.Unmarshal(data, &desc) != nil || desc.ProjectID != p.id ||
			desc.PID == 0 || desc.Port < 1 || desc.Port > 65535 ||
			!guidN.MatchString(desc.Generation) || !guidN.MatchString(desc.InstanceID) ||
			entry.Name() != desc.InstanceID+".json" {
			continue
		}
		protected, err := unprotect(desc.Secret)
		if err != nil || protected.identity != desc.identity {
			continue
		}
		started, err := processStart(desc.PID)
		if err != nil || started != desc.StartedAt {
			continue
		}
		if desc.Protocol != bridgeProtocol {
			incompatible = true
			continue
		}
		key, err := base64.StdEncoding.DecodeString(protected.Key)
		if err != nil || len(key) != 32 {
			continue
		}
		candidate := endpoint{desc.identity, key}
		probeCtx, cancel := context.WithTimeout(ctx, 750*time.Millisecond)
		conn, _, err := candidate.connect(probeCtx)
		if conn != nil {
			conn.Close()
		}
		cancel()
		if err == nil {
			matches = append(matches, candidate)
		}
	}
	switch len(matches) {
	case 0:
		if incompatible {
			return endpoint{}, failure("protocol_mismatch", "Install matching versions of unity-mcp and the Editor Bridge.")
		}
		return endpoint{}, failure("editor_unavailable", "No authenticated Editor Bridge is available for this project.")
	case 1:
		return matches[0], nil
	default:
		var ids []string
		for _, match := range matches {
			ids = append(ids, match.InstanceID)
		}
		return endpoint{}, failure("ambiguous_editor", "Multiple Editor instances for this project: "+strings.Join(ids, ", "))
	}
}

type exchange struct {
	clientNonce string
	serverNonce string
}

func (ep endpoint) proof(kind string, exchange exchange, payload string) []byte {
	mac := hmac.New(sha256.New, ep.key)
	io.WriteString(mac, strings.Join([]string{"unity-mcp-v1", kind, ep.Generation, exchange.clientNonce, exchange.serverNonce, payload}, "\n"))
	return mac.Sum(nil)
}

func (ep endpoint) verify(proof, kind string, exchange exchange, payload string) bool {
	expected, err := base64.StdEncoding.DecodeString(proof)
	return err == nil && hmac.Equal(expected, ep.proof(kind, exchange, payload))
}

func (ep endpoint) connect(ctx context.Context) (net.Conn, exchange, error) {
	var exchange exchange
	dialer := net.Dialer{Timeout: time.Second}
	conn, err := dialer.DialContext(ctx, "tcp4", net.JoinHostPort("127.0.0.1", strconv.Itoa(ep.Port)))
	if err != nil {
		return nil, exchange, err
	}
	deadline := time.Now().Add(time.Second)
	if end, ok := ctx.Deadline(); ok && end.Before(deadline) {
		deadline = end
	}
	err = conn.SetDeadline(deadline)
	if err != nil {
		conn.Close()
		return nil, exchange, err
	}
	stop := context.AfterFunc(ctx, func() { conn.Close() })
	defer stop()
	exchange.clientNonce = base64.StdEncoding.EncodeToString(randomBytes(32))
	err = writeFrame(conn, map[string]string{"client_nonce": exchange.clientNonce})
	if err != nil {
		conn.Close()
		return nil, exchange, err
	}
	var hello struct {
		Nonce string `json:"server_nonce"`
		Proof string `json:"proof"`
	}
	if err := readFrame(conn, &hello); err != nil {
		conn.Close()
		return nil, exchange, err
	}
	exchange.serverNonce = hello.Nonce
	nonce, err := base64.StdEncoding.DecodeString(hello.Nonce)
	if err != nil || len(nonce) != 32 || !ep.verify(hello.Proof, "server", exchange, "") {
		conn.Close()
		return nil, exchange, errors.New("bridge authentication failed")
	}
	return conn, exchange, nil
}

func randomBytes(count int) []byte {
	data := make([]byte, count)
	rand.Read(data)
	return data
}

func (ep endpoint) call(ctx context.Context, method string, args json.RawMessage, mutates bool) (json.RawMessage, error) {
	payload, err := json.Marshal(struct {
		Method string          `json:"method"`
		Params json.RawMessage `json:"params"`
	}{method, args})
	if err != nil {
		return nil, err
	}
	if len(payload) > maxFrame/2 {
		return nil, failure("request_limit", "Unity request is too large.")
	}
	conn, exchange, err := ep.connect(ctx)
	if err != nil {
		return nil, failure("editor_unavailable", "The Unity Editor disconnected before the request was sent.")
	}
	defer conn.Close()
	stop := context.AfterFunc(ctx, func() { conn.Close() })
	defer stop()
	deadline := time.Now().Add(10 * time.Second)
	if end, ok := ctx.Deadline(); ok && end.Before(deadline) {
		deadline = end
	}
	if err := conn.SetDeadline(deadline); err != nil {
		return nil, err
	}
	if ctx.Err() != nil {
		return nil, ctx.Err()
	}
	encoded := base64.StdEncoding.EncodeToString(payload)
	err = writeFrame(conn, map[string]string{"request": encoded, "proof": base64.StdEncoding.EncodeToString(ep.proof("request", exchange, encoded))})
	var reply struct {
		Response string `json:"response"`
		Proof    string `json:"proof"`
	}
	if err == nil {
		err = readFrame(conn, &reply)
	}
	if err != nil || !ep.verify(reply.Proof, "response", exchange, reply.Response) {
		if mutates {
			return nil, failure("outcome_unknown", "The Editor did not confirm the result. Read the affected state before issuing a new write.")
		}
		return nil, failure("editor_unavailable", "The Editor did not return an authenticated response. Check status and retry the read.")
	}
	decoded, err := base64.StdEncoding.DecodeString(reply.Response)
	var response struct {
		Result json.RawMessage `json:"result"`
		Error  *toolError      `json:"error"`
	}
	if err != nil || json.Unmarshal(decoded, &response) != nil || (response.Result == nil) == (response.Error == nil) {
		if mutates {
			return nil, failure("outcome_unknown", "The Editor returned an invalid response after the request was sent.")
		}
		return nil, failure("invalid_bridge_response", "The Editor returned an invalid response.")
	}
	if response.Error != nil {
		return nil, response.Error
	}
	return response.Result, nil
}

func writeFrame(writer io.Writer, value any) error {
	data, err := json.Marshal(value)
	if err != nil {
		return err
	}
	if len(data) == 0 || len(data) > maxFrame {
		return errors.New("bridge frame exceeds its size limit")
	}
	frame := binary.BigEndian.AppendUint32(make([]byte, 0, len(data)+4), uint32(len(data)))
	frame = append(frame, data...)
	for len(frame) != 0 {
		size, err := writer.Write(frame)
		if err != nil {
			return err
		}
		if size == 0 {
			return io.ErrShortWrite
		}
		frame = frame[size:]
	}
	return nil
}

func readFrame(reader io.Reader, value any) error {
	var header [4]byte
	if _, err := io.ReadFull(reader, header[:]); err != nil {
		return err
	}
	size := binary.BigEndian.Uint32(header[:])
	if size == 0 || size > maxFrame {
		return errors.New("invalid bridge frame size")
	}
	data := make([]byte, size)
	if _, err := io.ReadFull(reader, data); err != nil {
		return err
	}
	return json.Unmarshal(data, value)
}
