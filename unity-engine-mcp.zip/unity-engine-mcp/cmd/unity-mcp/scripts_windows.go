package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"time"
	"unicode/utf8"
	"unsafe"

	"github.com/modelcontextprotocol/go-sdk/mcp"
	"golang.org/x/sys/windows"
)

const maxScript = 512 << 10

type permissions struct {
	AllowScriptWrites bool     `json:"allow_script_writes"`
	ScriptFolders     []string `json:"script_folders"`
}

func stateDirectory() (string, error) {
	root, err := windows.KnownFolderPath(windows.FOLDERID_LocalAppData, 0)
	if err != nil {
		return "", err
	}
	return filepath.Join(root, "UnityMCP"), nil
}

func (p project) scriptPermissions(path string) error {
	root, err := stateDirectory()
	if err != nil {
		return err
	}
	data, err := readWindowsFile(filepath.Join(root, "permissions", p.id+".json"), maxDescriptor)
	var permissions permissions
	if err != nil || json.Unmarshal(data, &permissions) != nil || !permissions.AllowScriptWrites {
		return failure("permission_denied", "Enable script writes in Unity under Tools > Unity MCP for this project.")
	}
	for _, folder := range permissions.ScriptFolders {
		if validAssetPath(folder) && strings.HasPrefix(strings.ToLower(path), strings.ToLower(folder)+"/") {
			return nil
		}
	}
	return failure("permission_denied", "The script is outside the permitted project folders.")
}

var deviceName = regexp.MustCompile(`(?i)^(CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|(?:COM|LPT)[0-9¹²³])$`)

func validAssetPath(path string) bool {
	parts := strings.Split(path, "/")
	if len(parts) == 0 || parts[0] != "Assets" || len(path) > 768 {
		return false
	}
	for _, part := range parts {
		if part == "" || part == "." || part == ".." || strings.TrimRight(part, " .") != part ||
			strings.ContainsAny(part, "\\:*?<>|\x00\"") {
			return false
		}
		base, _, _ := strings.Cut(part, ".")
		if deviceName.MatchString(strings.TrimRight(base, " ")) {
			return false
		}
		for _, char := range part {
			if char < 32 {
				return false
			}
		}
	}
	return true
}

type scriptTarget struct {
	path    string
	parents []windows.Handle
}

func (target *scriptTarget) close() {
	for i := len(target.parents) - 1; i >= 0; i-- {
		windows.CloseHandle(target.parents[i])
	}
}

func (p project) resolveScript(path string) (scriptTarget, error) {
	if !validAssetPath(path) || !strings.HasPrefix(path, "Assets/") || !strings.EqualFold(filepath.Ext(path), ".cs") {
		return scriptTarget{}, failure("invalid_path", "Use an existing Assets directory and a .cs filename.")
	}
	volume := filepath.VolumeName(p.root)
	if len(volume) != 2 || volume[1] != ':' {
		return scriptTarget{}, failure("unsupported_volume", "Script file access requires a local NTFS drive.")
	}
	drive, err := windows.UTF16PtrFromString(volume + "\\")
	if err != nil || windows.GetDriveType(drive) != windows.DRIVE_FIXED {
		return scriptTarget{}, failure("unsupported_volume", "Script file access requires a local NTFS drive.")
	}
	target := scriptTarget{path: filepath.Join(p.root, filepath.FromSlash(path))}
	parent := volume + "\\"
	// Keep every parent open without share-delete until after the operation. It
	// prevents normal concurrent rename/replacement of a validated parent.
	for _, part := range strings.Split(strings.TrimPrefix(filepath.Dir(target.path), parent), "\\") {
		parent = filepath.Join(parent, part)
		handle, err := openWindowsFile(parent, windows.FILE_READ_ATTRIBUTES, windows.FILE_SHARE_READ|windows.FILE_SHARE_WRITE,
			windows.FILE_FLAG_BACKUP_SEMANTICS|windows.FILE_FLAG_OPEN_REPARSE_POINT)
		if err != nil {
			target.close()
			return scriptTarget{}, failure("invalid_path", "Cannot open script parent: "+err.Error())
		}
		target.parents = append(target.parents, handle)
		var info windows.ByHandleFileInformation
		if err := windows.GetFileInformationByHandle(handle, &info); err != nil ||
			info.FileAttributes&windows.FILE_ATTRIBUTE_DIRECTORY == 0 || info.FileAttributes&windows.FILE_ATTRIBUTE_REPARSE_POINT != 0 {
			target.close()
			return scriptTarget{}, failure("invalid_path", "Script paths must use normal directories without junctions or symlinks.")
		}
		if strings.EqualFold(parent, p.root) {
			index := uint64(info.FileIndexHigh)<<32 | uint64(info.FileIndexLow)
			if fmt.Sprintf("%08x-%016x", info.VolumeSerialNumber, index) != p.id {
				target.close()
				return scriptTarget{}, failure("invalid_path", "The project directory changed since the server started.")
			}
		}
	}
	var name [32]uint16
	if len(target.parents) == 0 ||
		windows.GetVolumeInformationByHandle(target.parents[len(target.parents)-1], nil, 0, nil, nil, nil, &name[0], uint32(len(name))) != nil ||
		windows.UTF16ToString(name[:]) != "NTFS" {
		target.close()
		return scriptTarget{}, failure("unsupported_volume", "Script file access requires a local NTFS drive.")
	}
	return target, nil
}

func readScriptFile(path string) ([]byte, error) {
	handle, err := openWindowsFile(path, windows.GENERIC_READ, windows.FILE_SHARE_READ|windows.FILE_SHARE_WRITE|windows.FILE_SHARE_DELETE, windows.FILE_FLAG_OPEN_REPARSE_POINT)
	if err != nil {
		return nil, err
	}
	file := os.NewFile(uintptr(handle), path)
	defer file.Close()
	var info windows.ByHandleFileInformation
	if err := windows.GetFileInformationByHandle(handle, &info); err != nil {
		return nil, err
	}
	if info.FileAttributes&(windows.FILE_ATTRIBUTE_DIRECTORY|windows.FILE_ATTRIBUTE_REPARSE_POINT) != 0 || info.NumberOfLinks != 1 {
		return nil, failure("invalid_path", "The script must be a regular file without symlinks or additional hard links.")
	}
	return readBounded(file, maxScript)
}

func digest(data []byte) string { return fmt.Sprintf("%x", sha256.Sum256(data)) }

func (p project) readScript(_ context.Context, _ *mcp.CallToolRequest, args arguments) (*mcp.CallToolResult, any, error) {
	path := stringArg(args, "path")
	target, err := p.resolveScript(path)
	if err != nil {
		return resultError(err)
	}
	defer target.close()
	data, err := readScriptFile(target.path)
	if err != nil {
		return resultError(err)
	}
	if !utf8.Valid(data) {
		return resultError(failure("invalid_encoding", "Only UTF-8 script files are supported."))
	}
	return nil, map[string]string{"path": path, "sha256": digest(data), "content": string(data)}, nil
}

type scriptJob struct {
	ID          string `json:"job_id"`
	Path        string `json:"path"`
	SHA256      string `json:"sha256"`
	Previous    string `json:"previous_sha256,omitempty"`
	FileStatus  string `json:"file_status"`
	Compile     string `json:"compilation_status"`
	Error       string `json:"error,omitempty"`
	CreatedAt   string `json:"created_at"`
	BackupReady bool   `json:"backup_available"`
	StagedFile  string `json:"staged_file,omitempty"`
}

var guidN = regexp.MustCompile(`^[a-f0-9]{32}$`)
var hashValue = regexp.MustCompile(`^[a-f0-9]{64}$`)

func (p project) jobDirectory(id string) (string, error) {
	if !guidN.MatchString(id) {
		return "", failure("job_not_found", "No script job matches the supplied ID.")
	}
	root, err := stateDirectory()
	if err != nil {
		return "", err
	}
	return filepath.Join(root, "jobs", p.id, id), nil
}

func (p project) loadJob(id string) (scriptJob, string, error) {
	dir, err := p.jobDirectory(id)
	if err != nil {
		return scriptJob{}, "", err
	}
	data, err := readWindowsFile(filepath.Join(dir, "job.json"), maxDescriptor)
	if os.IsNotExist(err) {
		return scriptJob{}, "", failure("job_not_found", "No script job matches the supplied ID.")
	}
	var job scriptJob
	if err != nil || json.Unmarshal(data, &job) != nil || job.ID != id || !validAssetPath(job.Path) {
		return scriptJob{}, "", failure("job_unavailable", "The script job journal could not be read.")
	}
	return job, dir, nil
}

func (job scriptJob) save(dir string) error {
	data, err := json.Marshal(job)
	if err != nil {
		return err
	}
	return atomicFile(filepath.Join(dir, "job.json"), data)
}

func atomicFile(path string, data []byte) error {
	temp, err := writeTemp(filepath.Dir(path), data)
	if err != nil {
		return err
	}
	defer os.Remove(temp)
	return moveFile(temp, path, windows.MOVEFILE_REPLACE_EXISTING|windows.MOVEFILE_WRITE_THROUGH)
}

func writeTemp(dir string, data []byte) (string, error) {
	file, err := os.CreateTemp(dir, ".unity-mcp-*.tmp")
	if err != nil {
		return "", err
	}
	name := file.Name()
	if _, err = file.Write(data); err == nil {
		err = file.Sync()
	}
	closeErr := file.Close()
	if err := errors.Join(err, closeErr); err != nil {
		os.Remove(name)
		return "", err
	}
	return name, nil
}

func moveFile(source, target string, flags uint32) error {
	return windows.MoveFileEx(windows.StringToUTF16Ptr(windowsPath(source)), windows.StringToUTF16Ptr(windowsPath(target)), flags)
}

var replaceFile = windows.NewLazySystemDLL("kernel32.dll").NewProc("ReplaceFileW")

func replaceScript(target, temp, backup string) error {
	targetName := windows.StringToUTF16Ptr(windowsPath(target))
	tempName := windows.StringToUTF16Ptr(windowsPath(temp))
	backupName := windows.StringToUTF16Ptr(windowsPath(backup))
	result, _, err := replaceFile.Call(uintptr(unsafe.Pointer(targetName)), uintptr(unsafe.Pointer(tempName)), uintptr(unsafe.Pointer(backupName)), 0, 0, 0)
	runtime.KeepAlive(targetName)
	runtime.KeepAlive(tempName)
	runtime.KeepAlive(backupName)
	if result == 0 {
		return err
	}
	return nil
}

func (p project) acquireMutex(ctx context.Context, operation string, timeout time.Duration) (func(), error) {
	// Windows mutex ownership belongs to the calling OS thread.
	runtime.LockOSThread()
	handle, err := windows.CreateMutex(nil, false, windows.StringToUTF16Ptr("Local\\UnityMCP-"+operation+"-"+p.id))
	if handle == 0 {
		runtime.UnlockOSThread()
		return nil, err
	}
	deadline := time.Now().Add(timeout)
	for ctx.Err() == nil {
		interval := max(0, min(100*time.Millisecond, time.Until(deadline)))
		wait, err := windows.WaitForSingleObject(handle, uint32(interval/time.Millisecond))
		if err != nil {
			windows.CloseHandle(handle)
			runtime.UnlockOSThread()
			return nil, err
		}
		if wait == windows.WAIT_OBJECT_0 || wait == windows.WAIT_ABANDONED {
			return func() {
				windows.ReleaseMutex(handle)
				windows.CloseHandle(handle)
				runtime.UnlockOSThread()
			}, nil
		}
		if !time.Now().Before(deadline) {
			break
		}
	}
	windows.CloseHandle(handle)
	runtime.UnlockOSThread()
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return nil, failure("busy", "Another client is already running this operation in the same project.")
}

func (p project) writeScript(ctx context.Context, _ *mcp.CallToolRequest, args arguments) (*mcp.CallToolResult, any, error) {
	path := stringArg(args, "path")
	expected, err := scriptPrecondition(args)
	if err != nil {
		return resultError(err)
	}
	data := []byte(stringArg(args, "content"))
	job, err := p.commitScript(ctx, path, expected, data)
	if err != nil {
		return resultError(err)
	}
	return nil, job, nil
}

func (p project) restoreScript(ctx context.Context, _ *mcp.CallToolRequest, args arguments) (*mcp.CallToolResult, any, error) {
	job, dir, err := p.loadJob(stringArg(args, "job_id"))
	if err != nil {
		return resultError(err)
	}
	expected, err := scriptPrecondition(args)
	if err != nil {
		return resultError(err)
	}
	data, err := p.readBackup(job, dir)
	if err != nil {
		return resultError(failure("restore_unavailable", "The previous script bytes could not be read."))
	}
	result, err := p.commitScript(ctx, job.Path, expected, data)
	if err != nil {
		return resultError(err)
	}
	return nil, result, nil
}

func scriptPrecondition(args arguments) (string, error) {
	expected := strings.ToLower(stringArg(args, "expected_sha256"))
	var absent bool
	json.Unmarshal(args["expected_absent"], &absent)
	if absent == (expected != "") || (!absent && !hashValue.MatchString(expected)) {
		return "", failure("invalid_precondition", "Supply either expected_absent: true or an expected SHA-256.")
	}
	return expected, nil
}

func (p project) commitScript(ctx context.Context, path, expected string, data []byte) (scriptJob, error) {
	if !utf8.Valid(data) || len(data) > maxScript {
		return scriptJob{}, failure("script_limit", "A script must be UTF-8 and no larger than 512 KiB.")
	}
	job, dir, err := p.writeScriptFile(ctx, path, expected, data)
	if err != nil || job.FileStatus != "committed" {
		return job, err
	}
	job.Compile = "awaiting_editor"
	ep, err := p.findEndpoint(ctx)
	if err == nil {
		request, _ := json.Marshal(map[string]string{"path": path, "job_id": job.ID, "expected_sha256": job.SHA256})
		_, err = ep.call(ctx, "compile_start", request, true)
		if err == nil {
			job.Compile = "scheduled"
		} else {
			job.Compile = "unconfirmed"
		}
	}
	if err != nil {
		job.Error = err.Error()
	}
	if err := job.save(dir); err != nil {
		job.Error = "The file was committed but the compilation status could not be saved."
	}
	return job, nil
}

func (p project) writeScriptFile(ctx context.Context, path, expected string, data []byte) (scriptJob, string, error) {
	var job scriptJob
	unlock, err := p.acquireMutex(ctx, "script", 5*time.Second)
	if err != nil {
		return job, "", err
	}
	defer unlock()
	if err := p.scriptPermissions(path); err != nil {
		return job, "", err
	}
	target, err := p.resolveScript(path)
	if err != nil {
		return job, "", err
	}
	defer target.close()
	existing, err := readScriptFile(target.path)
	if expected == "" {
		if err == nil {
			return job, "", failure("script_conflict", "The file already exists.")
		}
		if !os.IsNotExist(err) {
			return job, "", err
		}
	} else if err != nil || digest(existing) != expected || !utf8.Valid(existing) {
		return job, "", failure("script_conflict", "The current file differs from the expected UTF-8 script.")
	}
	job = scriptJob{ID: hex.EncodeToString(randomBytes(16)), Path: path, SHA256: digest(data), Previous: expected,
		FileStatus: "intent", Compile: "not_started", CreatedAt: time.Now().UTC().Format(time.RFC3339Nano)}
	dir, err := p.jobDirectory(job.ID)
	if err != nil {
		return job, "", err
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		return job, "", err
	}
	if err := job.save(dir); err != nil {
		return job, "", err
	}
	parent := filepath.Dir(target.path)
	temp, err := writeTemp(parent, data)
	if err != nil {
		return job, "", err
	}
	keepTemp := false
	defer func() {
		if !keepTemp {
			os.Remove(temp)
		}
	}()
	if ctx.Err() != nil {
		job.FileStatus = "cancelled"
		job.save(dir)
		return job, dir, ctx.Err()
	}
	if expected == "" {
		err = moveFile(temp, target.path, windows.MOVEFILE_WRITE_THROUGH)
	} else {
		latest, readErr := readScriptFile(target.path)
		if readErr != nil || digest(latest) != expected {
			job.FileStatus, job.Error = "conflict", "The script changed while the operation was being prepared."
			job.save(dir)
			return job, dir, nil
		}
		backup := siblingBackup(target.path, job.ID)
		err = replaceScript(target.path, temp, backup)
		if errors.Is(err, windows.Errno(1177)) {
			// ReplaceFileW may have moved the original to backup while leaving
			// the replacement at its temporary path and the target absent.
			keepTemp = true
			job.StagedFile = filepath.Base(temp)
		}
		if previous, readErr := readScriptFile(backup); readErr == nil {
			job.BackupReady = true
			if backupErr := atomicFile(filepath.Join(dir, "previous.cs"), previous); backupErr == nil {
				os.Remove(backup)
			} else {
				job.Error = "The replaced version remains in the sibling backup file."
			}
			if digest(previous) != expected {
				job.FileStatus = "conflict"
				job.Error = "An external save raced the replacement. Both versions were retained."
			}
		}
	}
	current, readErr := readScriptFile(target.path)
	if job.FileStatus != "conflict" {
		switch {
		case err == nil && readErr == nil && digest(current) == job.SHA256 && (expected == "" || job.BackupReady):
			job.FileStatus = "committed"
		case expected == "" && (errors.Is(err, windows.ERROR_ALREADY_EXISTS) || errors.Is(err, windows.ERROR_FILE_EXISTS)):
			job.FileStatus, job.Error = "conflict", "The file was created concurrently."
		default:
			job.FileStatus = "outcome_unknown"
			job.Error = "Windows did not confirm the intended file state. Inspect the script and journal before retrying."
			if job.StagedFile != "" {
				job.Error += " The replacement remains beside the script under staged_file."
			}
		}
	}
	if err := job.save(dir); err != nil {
		job.Error = "The final state could not be written to the journal. Inspect the target before retrying."
	}
	return job, dir, nil
}

func siblingBackup(path, id string) string {
	return filepath.Join(filepath.Dir(path), ".unity-mcp-"+id+".backup")
}

func (p project) getJob(ctx context.Context, _ *mcp.CallToolRequest, args arguments) (*mcp.CallToolResult, any, error) {
	id := stringArg(args, "job_id")
	diskJob, dir, diskErr := p.loadJob(id)
	var editorJob json.RawMessage
	ep, editorErr := p.findEndpoint(ctx)
	if editorErr == nil {
		editorJob, editorErr = ep.call(ctx, "job_get", marshalArguments(args), false)
	}
	if diskErr == nil {
		if diskJob.FileStatus == "intent" || diskJob.FileStatus == "outcome_unknown" {
			diskJob = p.inspectPendingJob(diskJob, dir)
		}
		if !diskJob.BackupReady && diskJob.Previous != "" {
			_, err := p.readBackup(diskJob, dir)
			diskJob.BackupReady = err == nil
		}
		response := map[string]any{"job_id": id, "script": diskJob}
		if editorErr == nil {
			if p.scriptMatchesJob(diskJob) {
				response["compilation"] = editorJob
			} else {
				diskJob.Compile = "superseded"
				response["script"] = diskJob
			}
		} else {
			var unavailable *toolError
			if errors.As(editorErr, &unavailable) {
				response["compilation_error"] = unavailable
				if unavailable.Code == "job_not_found" && diskJob.Compile == "scheduled" {
					diskJob.Compile = "unconfirmed"
					response["script"] = diskJob
				}
			}
		}
		return nil, response, nil
	}
	if editorErr != nil {
		return resultError(editorErr)
	}
	return nil, editorJob, nil
}

func (p project) readBackup(job scriptJob, dir string) ([]byte, error) {
	data, err := readScriptFile(filepath.Join(dir, "previous.cs"))
	if !os.IsNotExist(err) {
		return data, err
	}
	target, err := p.resolveScript(job.Path)
	if err != nil {
		return nil, err
	}
	defer target.close()
	return readScriptFile(siblingBackup(target.path, job.ID))
}

func (p project) inspectPendingJob(job scriptJob, dir string) scriptJob {
	if job.Previous != "" {
		prior, err := p.readBackup(job, dir)
		if err != nil {
			return job
		}
		if digest(prior) != job.Previous {
			job.FileStatus = "conflict"
			return job
		}
	}
	if p.scriptMatchesJob(job) {
		job.FileStatus = "committed"
	}
	return job
}

func (p project) scriptMatchesJob(job scriptJob) bool {
	target, err := p.resolveScript(job.Path)
	if err != nil {
		return false
	}
	defer target.close()
	current, err := readScriptFile(target.path)
	return err == nil && digest(current) == job.SHA256
}
