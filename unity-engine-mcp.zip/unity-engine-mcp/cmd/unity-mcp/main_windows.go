package main

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"os"
	"os/signal"
	"strings"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

var version = "0.1.0-dev"

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	if err := run(ctx, os.Args[1:]); err != nil && !errors.Is(err, context.Canceled) {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(ctx context.Context, args []string) error {
	if len(args) == 0 {
		return errors.New("usage: unity-mcp serve|doctor --project <absolute-path>, unity-mcp vision-probe, or unity-mcp version")
	}
	if args[0] == "version" {
		fmt.Println(version)
		return nil
	}
	if args[0] == "vision-probe" {
		if len(args) != 1 {
			return errors.New("usage: unity-mcp vision-probe")
		}
		return runVisionProbe(ctx)
	}
	if args[0] != "serve" && args[0] != "doctor" {
		return errors.New("unknown command: " + args[0])
	}
	flags := flag.NewFlagSet(args[0], flag.ContinueOnError)
	root := flags.String("project", "", "absolute path of the Unity project")
	if err := flags.Parse(args[1:]); err != nil {
		return err
	}
	if flags.NArg() != 0 {
		return errors.New("unexpected positional argument")
	}
	project, err := openProject(*root)
	if err != nil {
		return err
	}
	if args[0] == "doctor" {
		return doctor(ctx, project)
	}
	server := newServer("unity-mcp", "Work only in the configured Unity project. Inspect status before a write. Check job_get after starting compilation or tests. If a mutation returns outcome_unknown, inspect its result before issuing another write.")
	addUnityTools(server, project)
	return server.Run(ctx, &mcp.StdioTransport{MaxLineLength: 4 << 20})
}

func newServer(name, instructions string) *mcp.Server {
	return mcp.NewServer(&mcp.Implementation{Name: name, Version: version}, &mcp.ServerOptions{
		Instructions: instructions,
		Logger:       slog.New(slog.NewTextHandler(os.Stderr, nil)),
	})
}

func doctor(ctx context.Context, project project) error {
	path, _ := descriptorDirectory()
	report := map[string]any{"project": project.root, "project_id": project.id, "descriptor_directory": path, "version": version}
	ep, err := project.findEndpoint(ctx)
	if err == nil {
		var state json.RawMessage
		state, err = ep.call(ctx, "unity_status", json.RawMessage("{}"), false)
		if err == nil {
			report["editor"] = state
		}
	}
	if err != nil {
		report["error"] = err.Error()
	}
	encoder := json.NewEncoder(os.Stdout)
	encoder.SetIndent("", "  ")
	if encodeErr := encoder.Encode(report); encodeErr != nil {
		return encodeErr
	}
	return err
}

type schema = map[string]any
type arguments = map[string]json.RawMessage

func objectSchema(required string, properties schema) schema {
	if properties == nil {
		properties = schema{}
	}
	result := schema{"type": "object", "properties": properties, "additionalProperties": false}
	if required != "" {
		result["required"] = strings.Fields(required)
	}
	return result
}

func field(kind, description string) schema {
	return schema{"type": kind, "description": description}
}

type unityTool struct {
	name, description string
	readOnly          bool
	required          string
	properties        schema
}

func registerTool(server *mcp.Server, spec unityTool, handler mcp.ToolHandlerFor[arguments, any]) {
	closedWorld := false
	mcp.AddTool(server, &mcp.Tool{
		Name: spec.name, Description: spec.description, InputSchema: objectSchema(spec.required, spec.properties),
		Annotations: &mcp.ToolAnnotations{ReadOnlyHint: spec.readOnly, OpenWorldHint: &closedWorld},
	}, handler)
}

func resultError(err error) (*mcp.CallToolResult, any, error) {
	var typed *toolError
	if !errors.As(err, &typed) {
		typed = &toolError{Code: "operation_failed", Message: err.Error()}
	}
	result, _ := json.Marshal(typed)
	return &mcp.CallToolResult{
		IsError: true,
		Content: []mcp.Content{&mcp.TextContent{Text: string(result)}},
	}, nil, nil
}

func addUnityTools(server *mcp.Server, project project) {
	str := func(description string) schema { return field("string", description) }
	index := func(description string) schema {
		return schema{"type": "integer", "minimum": 0, "description": description}
	}
	vector := schema{"type": "array", "items": schema{"type": "number"}, "minItems": 3, "maxItems": 3}
	scene := str("Scene ID from scene_list. Refresh after a domain reload.")
	object := str("Object ID from scene_hierarchy or object_create.")
	component := str("Component ID from object_get or component_add.")
	asset := str("Unity asset GUID from asset_find.")
	parent := schema{"type": []string{"string", "null"}, "description": "Object ID in the same scene. Null detaches the object."}
	path := str("Project-relative path under Assets/ using forward slashes.")
	job := str("Job ID returned by a start or write tool.")
	ops := schema{"type": "array", "minItems": 1, "maxItems": 128, "items": objectSchema("op path", schema{
		"op":      schema{"type": "string", "enum": []string{"set", "resize", "managed_new", "managed_link"}},
		"path":    str("Full SerializedProperty path."),
		"value":   schema{"description": "Leaf value as shown by inspect, new array size, or managed reference ID/key. Null clears a reference."},
		"type_id": str("Compatible type ID from inspect for managed_new."),
		"key":     str("Optional patch-local reference key for managed_new."),
	})}

	for _, spec := range []unityTool{
		{"unity_status", "Read Unity editor status and capabilities.", true, "", nil},
		{"console_get", "Read recent Unity logs after a sequence number.", true, "", schema{"limit": index("Maximum number of entries."), "after": index("Last sequence number seen.")}},
		{"scene_list", "List loaded scenes and identify the active scene.", true, "", nil},
		{"scene_create", "Create an empty additive scene, optionally at a new Assets path.", false, "", schema{"path": path}},
		{"scene_open", "Open an existing scene additively.", false, "asset_guid", schema{"asset_guid": asset}},
		{"scene_set_active", "Make a loaded scene active.", false, "scene_id", schema{"scene_id": scene}},
		{"scene_close", "Close a clean loaded scene.", false, "scene_id", schema{"scene_id": scene}},
		{"scene_save", "Save the chosen scene, including manual changes. An unsaved scene needs a new path.", false, "scene_id", schema{"scene_id": scene, "path": path}},
		{"scene_hierarchy", "Read and search a scene hierarchy with pagination.", true, "scene_id", schema{"scene_id": scene, "query": str("Case-insensitive name substring."), "offset": index("Page offset."), "limit": index("Page size.")}},
		{"object_get", "Inspect one scene object and its component IDs.", true, "object_id", schema{"object_id": object}},
		{"object_create", "Create a GameObject with Unity Undo.", false, "scene_id name", schema{"scene_id": scene, "name": str("Object name."), "parent_id": parent}},
		{"object_update", "Update object name, active state, parent or local transform. Rotation is in Euler degrees.", false, "object_id", schema{"object_id": object, "name": str("Object name."), "active": field("boolean", "Whether the object is active."), "parent_id": parent, "position": vector, "rotation": vector, "scale": vector}},
		{"object_delete", "Delete a GameObject with Unity Undo.", false, "object_id", schema{"object_id": object}},
		{"component_add", "Add one built-in component or compiled MonoBehaviour. Specify exactly one type.", false, "object_id", schema{"object_id": object, "builtin_type": str("Built-in UnityEngine component type."), "script_guid": asset}},
		{"component_remove", "Remove a component with Unity Undo.", false, "component_id", schema{"component_id": component}},
		{"asset_find", "Search assets under Assets with optional Unity type and folder filters.", true, "", schema{"query": str("Name search."), "type": str("Unity asset type."), "folder": path, "offset": index("Page offset."), "limit": index("Page size.")}},
		{"asset_get", "Look up an asset by GUID.", true, "asset_guid", schema{"asset_guid": asset}},
		{"scriptable_create", "Create a ScriptableObject at a new .asset path.", false, "script_guid path", schema{"script_guid": asset, "path": path}},
		{"prefab_create", "Create a prefab from a scene object at a new .prefab path.", false, "object_id path", schema{"object_id": object, "path": path}},
		{"prefab_instantiate", "Instantiate a prefab in the specified scene, preserving its source link.", false, "asset_guid scene_id", schema{"asset_guid": asset, "scene_id": scene, "parent_id": parent}},
		{"serialized_inspect", "Inspect a component or asset branch, its Unity property types, and revision.", true, "target_id", schema{"target_id": str("Component or asset ID."), "path": str("Optional branch property path."), "offset": index("Page offset."), "limit": index("Page size.")}},
		{"serialized_patch", "Update serialized fields using an expected revision from serialized_inspect.", false, "target_id expected_revision operations", schema{"target_id": str("Component or asset ID."), "path": str("Same branch used in serialized_inspect."), "expected_revision": str("Revision returned by serialized_inspect."), "operations": ops}},
		{"compile_start", "Request Unity compilation, optionally importing one script. Poll job_get.", false, "", schema{"path": path}},
		{"play_start", "Request entry into Play Mode. Poll job_get.", false, "", nil},
		{"play_stop", "Request exit from Play Mode. Poll job_get.", false, "", nil},
		{"tests_run", "Start a Unity Test Framework run. Poll job_get for results.", false, "mode", schema{"mode": schema{"type": "string", "enum": []string{"EditMode", "PlayMode"}}, "filter": str("Optional test name filter.")}},
	} {
		registerTool(server, spec, func(ctx context.Context, _ *mcp.CallToolRequest, input arguments) (*mcp.CallToolResult, any, error) {
			return project.bridgeTool(ctx, spec.name, input, !spec.readOnly)
		})
	}

	registerTool(server, unityTool{"job_get", "Read the status of a compilation, Play Mode transition, or Unity test run.", true, "job_id", schema{"job_id": job}}, project.getJob)
	registerTool(server, unityTool{"script_read", "Read a UTF-8 .cs file under Assets and its SHA-256.", true, "path", schema{"path": path}}, project.readScript)
	registerTool(server, unityTool{"script_write", "Create or update one UTF-8 .cs file, preserving its Unity .meta. Supply expected_sha256 for an update or expected_absent for creation.", false, "path content", schema{"path": path, "content": str("Complete UTF-8 file contents."), "expected_sha256": str("SHA-256 from script_read."), "expected_absent": field("boolean", "Require the file to be absent.")}}, project.writeScript)
	registerTool(server, unityTool{"script_restore", "Restore backed-up bytes if the current SHA-256 matches or the file is still absent.", false, "job_id", schema{"job_id": job, "expected_sha256": str("Expected current file SHA-256."), "expected_absent": field("boolean", "Require the file to be absent.")}}, project.restoreScript)
	registerTool(server, unityTool{"unity_screenshot", "Return a fresh PNG of the main Unity editor window as an image.", true, "", schema{"max_edge": schema{"type": "integer", "minimum": 320, "maximum": 2048, "description": "Maximum longer edge, default 1600."}}}, project.screenshot)
}

func marshalArguments(input arguments) json.RawMessage {
	if input == nil {
		return json.RawMessage("{}")
	}
	data, _ := json.Marshal(input)
	return data
}

func (p project) bridgeTool(ctx context.Context, method string, args arguments, mutates bool) (*mcp.CallToolResult, any, error) {
	ep, err := p.findEndpoint(ctx)
	if err != nil {
		return resultError(err)
	}
	var job string
	switch method {
	case "compile_start", "play_start", "play_stop", "tests_run":
		job = hex.EncodeToString(randomBytes(16))
		if args == nil {
			args = make(arguments)
		}
		args["job_id"], _ = json.Marshal(job)
	}
	result, err := ep.call(ctx, method, marshalArguments(args), mutates)
	if err != nil {
		var typed *toolError
		if job != "" && errors.As(err, &typed) && typed.Code == "outcome_unknown" {
			return resultError(&toolError{Code: typed.Code, Message: typed.Message, JobID: job})
		}
		return resultError(err)
	}
	return nil, result, nil
}

func stringArg(args arguments, key string) string {
	var value string
	json.Unmarshal(args[key], &value)
	return value
}
