package main

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"testing"
	"time"
)

func TestBridgeRoundTripAndAuthentication(t *testing.T) {
	cases := []struct {
		name    string
		mode    string
		mutates bool
		code    string
	}{
		{name: "authenticated response"},
		{name: "wrong challenge proof", mode: "wrong challenge", mutates: true, code: "editor_unavailable"},
		{name: "forged read response", mode: "wrong response", code: "editor_unavailable"},
		{name: "dropped write after dispatch", mode: "drop", mutates: true, code: "outcome_unknown"},
		{name: "dropped read after dispatch", mode: "drop", code: "editor_unavailable"},
		{name: "authenticated domain error", mode: "rejected", mutates: true, code: "permission_denied"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			listener, err := net.ListenTCP("tcp4", &net.TCPAddr{IP: net.IPv4(127, 0, 0, 1)})
			if err != nil {
				t.Fatal(err)
			}
			defer listener.Close()
			if err := listener.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
				t.Fatal(err)
			}

			ep := endpoint{
				identity: identity{Port: listener.Addr().(*net.TCPAddr).Port, Generation: "test-generation"},
				key:      bytes.Repeat([]byte{0x37}, 32),
			}
			serverErr := make(chan error, 1)
			go func() {
				conn, err := listener.Accept()
				if err == nil {
					defer conn.Close()
					err = fakeBridgeExchange(conn, ep, tc.mode)
				}
				serverErr <- err
			}()

			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			result, err := ep.call(ctx, "object_create", json.RawMessage(`{"name":"Сцена"}`), tc.mutates)
			if tc.code != "" {
				requireToolError(t, err, tc.code)
			} else if err != nil || string(result) != `{"id":"created"}` {
				t.Errorf("call = %s, %v", result, err)
			}
			select {
			case err := <-serverErr:
				if err != nil {
					t.Fatal(err)
				}
			case <-ctx.Done():
				t.Fatal("fake Editor did not complete")
			}
		})
	}
}

func fakeBridgeExchange(conn net.Conn, ep endpoint, mode string) error {
	if err := conn.SetDeadline(time.Now().Add(3 * time.Second)); err != nil {
		return err
	}
	var hello map[string]string
	if err := readFrame(conn, &hello); err != nil {
		return err
	}
	clientNonce := hello["client_nonce"]
	if decoded, err := base64.StdEncoding.DecodeString(clientNonce); err != nil || len(decoded) != 32 {
		return fmt.Errorf("invalid client nonce %q", clientNonce)
	}
	serverNonce := base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{0x71}, 32))
	sign := func(kind, payload string) string {
		mac := hmac.New(sha256.New, ep.key)
		fmt.Fprintf(mac, "unity-mcp-v1\n%s\n%s\n%s\n%s\n%s", kind, ep.Generation, clientNonce, serverNonce, payload)
		return base64.StdEncoding.EncodeToString(mac.Sum(nil))
	}
	proof := sign("server", "")
	if mode == "wrong challenge" {
		proof = sign("server", "tampered")
	}
	if err := writeFrame(conn, map[string]string{"server_nonce": serverNonce, "proof": proof}); err != nil {
		return err
	}
	if mode == "wrong challenge" {
		if n, err := conn.Read(make([]byte, 1)); n != 0 || err != io.EOF {
			return fmt.Errorf("client did not close unauthenticated connection: %d, %v", n, err)
		}
		return nil
	}

	var request map[string]string
	if err := readFrame(conn, &request); err != nil {
		return err
	}
	if want := sign("request", request["request"]); request["proof"] != want {
		return errors.New("request proof does not cover the encoded request")
	}
	payload, err := base64.StdEncoding.DecodeString(request["request"])
	if err != nil || string(payload) != `{"method":"object_create","params":{"name":"Сцена"}}` {
		return fmt.Errorf("unexpected request %q: %v", payload, err)
	}
	if mode == "drop" {
		return nil
	}
	body := `{"result":{"id":"created"}}`
	if mode == "rejected" {
		body = `{"error":{"code":"permission_denied","message":"Read-only project"}}`
	}
	response := base64.StdEncoding.EncodeToString([]byte(body))
	proof = sign("response", response)
	if mode == "wrong response" {
		proof = sign("request", response)
	}
	return writeFrame(conn, map[string]string{"response": response, "proof": proof})
}

func TestBridgeFramingLimits(t *testing.T) {
	var output chunkedFrameWriter
	if err := writeFrame(&output, map[string]string{"value": "й"}); err != nil {
		t.Fatal(err)
	}
	const payload = `{"value":"й"}`
	want := append(binary.BigEndian.AppendUint32(nil, uint32(len(payload))), payload...)
	if !bytes.Equal(output.Bytes(), want) {
		t.Fatalf("encoded frame = %q, want %q", output.Bytes(), want)
	}
	var result map[string]string
	if err := readFrame(&output, &result); err != nil || result["value"] != "й" {
		t.Fatalf("decoded frame = %v, %v", result, err)
	}

	for _, size := range []uint32{0, maxFrame + 1} {
		if err := readFrame(bytes.NewReader(binary.BigEndian.AppendUint32(nil, size)), &result); err == nil {
			t.Errorf("readFrame accepted invalid length %d", size)
		}
	}
	truncated := binary.BigEndian.AppendUint32(nil, 12)
	truncated = append(truncated, '{')
	if err := readFrame(bytes.NewReader(truncated), &result); !errors.Is(err, io.ErrUnexpectedEOF) {
		t.Errorf("truncated frame = %v, want unexpected EOF", err)
	}
}

type chunkedFrameWriter struct{ bytes.Buffer }

func (output *chunkedFrameWriter) Write(p []byte) (int, error) {
	return output.Buffer.Write(p[:min(len(p), 3)])
}

func requireToolError(t *testing.T, err error, want string) {
	t.Helper()
	var typed *toolError
	if !errors.As(err, &typed) || typed.Code != want {
		t.Fatalf("error = %v, want tool error %s", err, want)
	}
}
