[CmdletBinding()]
param(
    [string] $Version = '0.1.0-dev',
    [switch] $SkipArchive
)

$ErrorActionPreference = 'Stop'
if ($Version -notmatch '^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$') {
    throw 'Use a version such as 0.1.0-dev.'
}

$previousGoOS = $env:GOOS
$previousGoArch = $env:GOARCH
$previousCGO = $env:CGO_ENABLED
Push-Location $PSScriptRoot
try {
    $env:GOOS = 'windows'
    $env:GOARCH = 'amd64'
    $env:CGO_ENABLED = '0'
    $output = Join-Path $PSScriptRoot 'dist'
    $stage = Join-Path $output "unity-mcp-$Version-windows-amd64"
    New-Item -ItemType Directory -Force -Path $output | Out-Null
    $outputInfo = Get-Item -LiteralPath $output
    if ($outputInfo.Attributes -band [IO.FileAttributes]::ReparsePoint) {
        throw 'Use a normal dist directory inside the project.'
    }
    if (Test-Path -LiteralPath $stage) {
        $previous = Get-Item -LiteralPath $stage
        if (-not $previous.PSIsContainer -or $previous.Parent.FullName -ne $outputInfo.FullName) {
            throw 'Refusing to replace a package outside the dist directory.'
        }
        if ($previous.Attributes -band [IO.FileAttributes]::ReparsePoint) {
            throw 'Refusing to replace a redirected package directory.'
        }
        Remove-Item -LiteralPath $previous.FullName -Recurse -Force
    }
    New-Item -ItemType Directory -Path $stage | Out-Null

    & go build -trimpath -mod=readonly -ldflags "-X main.version=$Version" -o (Join-Path $stage 'unity-mcp.exe') ./cmd/unity-mcp
    if ($LASTEXITCODE -ne 0) {
        throw 'Go build failed.'
    }
    & (Join-Path $PSScriptRoot 'capture/build.ps1') -OutputDirectory (Join-Path $output 'native')
    Copy-Item -LiteralPath (Join-Path $output 'native/unity-mcp-capture.exe') -Destination $stage -Force
    Copy-Item -LiteralPath 'README.md' -Destination $stage -Force
    $bridgeSource = Join-Path $PSScriptRoot 'unity/com.unity-mcp.bridge'
    $bridgeStage = Join-Path $stage 'com.unity-mcp.bridge'
    New-Item -ItemType Directory -Path $bridgeStage | Out-Null
    foreach ($entry in @('Editor', 'Editor.meta', 'package.json', 'package.json.meta')) {
        Copy-Item -LiteralPath (Join-Path $bridgeSource $entry) -Destination $bridgeStage -Recurse
    }
    $manifestPath = Join-Path $bridgeStage 'package.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    $manifest.version = $Version
    [IO.File]::WriteAllText($manifestPath, ($manifest | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))

    if (-not $SkipArchive) {
        $archive = "$stage.zip"
        Compress-Archive -LiteralPath $stage -DestinationPath $archive -Force
        $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $archive).Hash.ToLowerInvariant()
        "$hash  $(Split-Path -Leaf $archive)" | Set-Content -LiteralPath "$archive.sha256" -Encoding ascii
    }
    Write-Output $stage
}
finally {
    $env:GOOS = $previousGoOS
    $env:GOARCH = $previousGoArch
    $env:CGO_ENABLED = $previousCGO
    Pop-Location
}
