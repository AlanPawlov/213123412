using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

[assembly: InternalsVisibleTo("UnityMcp.Editor.Tests")]

namespace UnityMcp.Editor
{
    internal sealed class EditorToolException : Exception
    {
        internal string Code { get; }

        internal EditorToolException(string code, string message) : base(message)
        {
            Code = code;
        }
    }

    internal static class EditorTools
    {
        private const int LogCapacity = 256;
        private const int ObjectCapacity = 32768;
        private static readonly Dictionary<string, Object> objects = new Dictionary<string, Object>();
        private static readonly Dictionary<Object, string> objectIds = new Dictionary<Object, string>();
        private static readonly Queue<string> objectOrder = new Queue<string>();
        private static readonly Dictionary<Scene, string> scenes = new Dictionary<Scene, string>();
        private static readonly Queue<JObject> logs = new Queue<JObject>();
        private static readonly object logLock = new object();
        private static long logSequence;

        internal static string ProjectRoot => Bridge.ProjectRoot ?? Path.GetFullPath(Path.Combine(Application.dataPath, ".."));

        static EditorTools()
        {
            Application.logMessageReceivedThreaded += RecordLog;
            EditorSceneManager.sceneClosed += scene => scenes.Remove(scene);
        }

        internal static bool IsMutation(string tool)
        {
            switch (tool)
            {
                case "unity_status": case "console_get": case "scene_list": case "scene_hierarchy":
                case "object_get": case "asset_find": case "asset_get": case "serialized_inspect": case "job_get":
                    return false;
                default:
                    return true;
            }
        }

        internal static JToken Execute(string tool, JObject args)
        {
            if (IsMutation(tool) && tool != "play_stop")
            {
                if (Jobs.IsBusy)
                    throw new EditorToolException("editor_busy", "Wait for the current Editor job to finish.");
                if (EditorApplication.isPlayingOrWillChangePlaymode)
                    throw new EditorToolException("editor_busy", "Exit Play Mode before changing the project.");
                if (PrefabStageUtility.GetCurrentPrefabStage() != null)
                    throw new EditorToolException("editor_busy", "Exit Prefab Mode before changing the project.");
            }

            switch (tool)
            {
                case "unity_status": return Status();
                case "console_get": return ConsoleGet(args);
                case "scene_list": return SceneList();
                case "scene_create": return SceneCreate(args);
                case "scene_open": return SceneOpen(args);
                case "scene_set_active": return SceneSetActive(args);
                case "scene_save": return SceneSave(args);
                case "scene_close": return SceneClose(args);
                case "scene_hierarchy": return Hierarchy(args);
                case "object_get": return DescribeObject(Resolve<GameObject>(String(args, "object_id")), true);
                case "object_create": return ObjectCreate(args);
                case "object_update": return ObjectUpdate(args);
                case "object_delete": return ObjectDelete(args);
                case "component_add": return ComponentAdd(args);
                case "component_remove": return ComponentRemove(args);
                case "asset_find": return AssetFind(args);
                case "asset_get": return DescribeAsset(AssetPathFromGuid(String(args, "asset_guid")), true);
                case "scriptable_create": return ScriptableCreate(args);
                case "prefab_create": return PrefabCreate(args);
                case "prefab_instantiate": return PrefabInstantiate(args);
                case "serialized_inspect": return SerializedTools.Inspect(args);
                case "serialized_patch": return SerializedTools.Patch(args);
                case "compile_start": return Jobs.StartCompile(args);
                case "play_start": return Jobs.StartPlay(args, true);
                case "play_stop": return Jobs.StartPlay(args, false);
                case "tests_run": return Jobs.StartTests(args);
                case "job_get": return Jobs.Get(String(args, "job_id"));
                default: throw new EditorToolException("unknown_tool", "This Unity tool is not available.");
            }
        }

        private static JObject Status()
        {
            bool playing = EditorApplication.isPlaying;
            bool compiling = EditorApplication.isCompiling;
            bool updating = EditorApplication.isUpdating;
            bool transitioning = EditorApplication.isPlayingOrWillChangePlaymode != playing || Jobs.IsPlayTransition;
            return new JObject
            {
                ["unity_version"] = Application.unityVersion,
                ["is_compiling"] = compiling,
                ["is_updating"] = updating,
                ["is_playing"] = playing,
                ["is_paused"] = EditorApplication.isPaused,
                ["is_play_transition"] = transitioning,
                ["is_running_tests"] = Jobs.IsTesting,
                ["in_prefab_stage"] = PrefabStageUtility.GetCurrentPrefabStage() != null,
                ["ready"] = !compiling && !updating && !transitioning,
                ["active_scene"] = DescribeScene(SceneManager.GetActiveScene())
            };
        }

        private static void RecordLog(string condition, string stack, LogType type)
        {
            lock (logLock)
            {
                if (logs.Count == LogCapacity)
                    logs.Dequeue();
                logs.Enqueue(new JObject
                {
                    ["sequence"] = ++logSequence,
                    ["time_utc"] = DateTime.UtcNow.ToString("O"),
                    ["type"] = type.ToString(),
                    ["message"] = Truncate(condition, 2048),
                    ["stack"] = Truncate(stack, 2048)
                });
            }
        }

        private static JObject ConsoleGet(JObject args)
        {
            int limit = Number(args, "limit", 30, 1, 100);
            int after = Number(args, "after", 0, 0, int.MaxValue);
            lock (logLock)
            {
                return new JObject
                {
                    ["latest_sequence"] = logSequence,
                    ["oldest_sequence"] = logs.Count > 0 ? (long)logs.Peek()["sequence"] : 0,
                    ["items"] = new JArray(logs.Where(entry => (long)entry["sequence"] > after).Take(limit)
                        .Select(entry => entry.DeepClone()))
                };
            }
        }

        internal static string Truncate(string text, int limit)
        {
            return text == null || text.Length <= limit ? text : text.Substring(0, limit);
        }

        private static JObject SceneList()
        {
            return new JObject { ["items"] = new JArray(LoadedScenes().Select(DescribeScene)) };
        }

        private static IEnumerable<Scene> LoadedScenes()
        {
            for (int index = 0; index < SceneManager.sceneCount; index++)
            {
                var scene = SceneManager.GetSceneAt(index);
                if (scene.IsValid() && scene.isLoaded && !EditorSceneManager.IsPreviewScene(scene))
                    yield return scene;
            }
        }

        private static JObject DescribeScene(Scene scene)
        {
            if (!scene.IsValid() || !scene.isLoaded)
                return null;
            if (!scenes.TryGetValue(scene, out string id))
                scenes.Add(scene, id = Guid.NewGuid().ToString("N"));
            return new JObject
            {
                ["scene_id"] = id, ["name"] = scene.name, ["path"] = scene.path,
                ["dirty"] = scene.isDirty, ["active"] = scene == SceneManager.GetActiveScene(),
                ["asset_guid"] = string.IsNullOrEmpty(scene.path) ? null : AssetDatabase.AssetPathToGUID(scene.path)
            };
        }

        private static Scene ResolveScene(string id)
        {
            foreach (var scene in LoadedScenes())
                if (scenes.TryGetValue(scene, out string candidate) && candidate == id)
                    return scene;
            throw new EditorToolException("stale_id", "Scene ID is unknown or stale. List the loaded scenes again.");
        }

        private static JObject SceneCreate(JObject args)
        {
            string path = String(args, "path", false);
            if (path != null)
                ValidateAssetPath(path, ".unity", true);
            RequireSavedScenesForAdditiveLoad();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            if (path != null && !EditorSceneManager.SaveScene(scene, path))
            {
                EditorSceneManager.CloseScene(scene, true);
                throw new EditorToolException("save_failed", "Unity could not save the new scene.");
            }
            return DescribeScene(scene);
        }

        private static JObject SceneOpen(JObject args)
        {
            string path = AssetPathFromGuid(String(args, "asset_guid"));
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
                throw Invalid("asset_guid must refer to a scene asset.");
            var open = SceneManager.GetSceneByPath(path);
            if (open.IsValid() && open.isLoaded)
                return DescribeScene(open);
            RequireSavedScenesForAdditiveLoad();
            return DescribeScene(EditorSceneManager.OpenScene(path, OpenSceneMode.Additive));
        }

        private static void RequireSavedScenesForAdditiveLoad()
        {
            if (LoadedScenes().Any(scene => string.IsNullOrEmpty(scene.path)))
                throw new EditorToolException("unsaved_scene", "Save the untitled scene with scene_save and an explicit Assets path before loading another scene additively.");
        }

        private static JObject SceneSetActive(JObject args)
        {
            var scene = ResolveScene(String(args, "scene_id"));
            if (!SceneManager.SetActiveScene(scene))
                throw new EditorToolException("invalid_scene", "Unity could not activate this scene.");
            return DescribeScene(scene);
        }

        private static JObject SceneSave(JObject args)
        {
            var scene = ResolveScene(String(args, "scene_id"));
            string path = String(args, "path", false);
            if (string.IsNullOrEmpty(scene.path))
            {
                if (path == null)
                    throw Invalid("An explicit path under Assets is required for a new scene.");
                ValidateAssetPath(path, ".unity", true);
            }
            else
            {
                if (path != null && path != scene.path)
                    throw Invalid("Save an existing scene to its current path.");
                path = scene.path;
                ValidateAssetPath(path, ".unity", false);
            }
            if (!EditorSceneManager.SaveScene(scene, path))
                throw new EditorToolException("save_failed", "Unity could not save the scene.");
            return DescribeScene(scene);
        }

        private static JObject SceneClose(JObject args)
        {
            var scene = ResolveScene(String(args, "scene_id"));
            if (scene.isDirty)
                throw new EditorToolException("scene_dirty", "Save the scene explicitly before closing it.");
            if (LoadedScenes().Take(2).Count() < 2)
                throw new EditorToolException("last_scene", "Open another scene before closing this one.");
            if (!EditorSceneManager.CloseScene(scene, true))
                throw new EditorToolException("close_failed", "Unity could not close the scene.");
            scenes.Remove(scene);
            return new JObject { ["closed"] = true };
        }

        private static JObject Hierarchy(JObject args)
        {
            var scene = ResolveScene(String(args, "scene_id"));
            string query = String(args, "query", false);
            var entries = WalkHierarchy(scene).Where(transform => query == null ||
                transform.name.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0);
            return Page(entries, args, transform => DescribeObject(transform.gameObject, false));
        }

        private static IEnumerable<Transform> WalkHierarchy(Scene scene)
        {
            var pending = new Stack<Transform>();
            var roots = scene.GetRootGameObjects();
            for (int i = roots.Length - 1; i >= 0; --i)
                pending.Push(roots[i].transform);
            while (pending.Count > 0)
            {
                var transform = pending.Pop();
                yield return transform;
                for (int i = transform.childCount - 1; i >= 0; --i)
                    pending.Push(transform.GetChild(i));
            }
        }

        private static JObject DescribeObject(GameObject obj, bool includeComponents)
        {
            var transform = obj.transform;
            var result = new JObject
            {
                ["object_id"] = Id(obj), ["name"] = obj.name, ["active"] = obj.activeSelf,
                ["parent_id"] = transform.parent ? Id(transform.parent.gameObject) : null,
                ["position"] = Vector(transform.localPosition), ["rotation"] = Vector(transform.localEulerAngles),
                ["scale"] = Vector(transform.localScale), ["child_count"] = transform.childCount,
                ["scene_id"] = (string)DescribeScene(obj.scene)?["scene_id"]
            };
            if (includeComponents)
                result["components"] = new JArray(obj.GetComponents<Component>().Select(component => component
                    ? new JObject { ["component_id"] = Id(component), ["type"] = component.GetType().FullName }
                    : new JObject { ["missing_script"] = true }));
            return result;
        }

        private static JObject ObjectCreate(JObject args)
        {
            var scene = ResolveScene(String(args, "scene_id"));
            string name = String(args, "name");
            var parent = Parent(args, scene);
            return InUndoGroup("Create GameObject", () =>
            {
                var obj = new GameObject(name);
                Undo.RegisterCreatedObjectUndo(obj, "Create GameObject");
                if (obj.scene != scene)
                    Undo.MoveGameObjectToScene(obj, scene, "Move GameObject to scene");
                if (parent)
                    Undo.SetTransformParent(obj.transform, parent, false, "Parent GameObject");
                return DescribeObject(obj, true);
            });
        }

        private static JObject ObjectUpdate(JObject args)
        {
            var obj = Resolve<GameObject>(String(args, "object_id"));
            CheckSceneObject(obj);
            string name = String(args, "name", false);
            bool? active = OptionalBool(args, "active");
            Vector3? position = OptionalVector(args, "position");
            Vector3? rotation = OptionalVector(args, "rotation");
            Vector3? scale = OptionalVector(args, "scale");
            bool reparent = args.Property("parent_id") != null;
            var parent = reparent ? Parent(args, obj.scene) : obj.transform.parent;
            if (parent && (parent == obj.transform || parent.IsChildOf(obj.transform)))
                throw Invalid("A GameObject cannot be parented to itself or one of its descendants.");
            if (reparent && parent != obj.transform.parent && PrefabUtility.IsPartOfPrefabInstance(obj) &&
                !PrefabUtility.IsOutermostPrefabInstanceRoot(obj) && !PrefabUtility.IsAddedGameObjectOverride(obj))
                throw Invalid("Reparent the prefab instance root or edit the source prefab in Unity.");
            return InUndoGroup("Update GameObject", () =>
            {
                if (name != null || active != null)
                {
                    Undo.RecordObject(obj, "Update GameObject");
                    if (name != null) obj.name = name;
                    if (active != null) obj.SetActive(active.Value);
                    PrefabUtility.RecordPrefabInstancePropertyModifications(obj);
                }
                var transform = obj.transform;
                if (reparent && parent != transform.parent)
                    Undo.SetTransformParent(transform, parent, true, "Parent GameObject");
                if (position != null || rotation != null || scale != null)
                {
                    Undo.RecordObject(transform, "Update Transform");
                    if (position != null) transform.localPosition = position.Value;
                    if (rotation != null) transform.localEulerAngles = rotation.Value;
                    if (scale != null) transform.localScale = scale.Value;
                    PrefabUtility.RecordPrefabInstancePropertyModifications(transform);
                }
                return DescribeObject(obj, true);
            });
        }

        private static JObject ObjectDelete(JObject args)
        {
            var obj = Resolve<GameObject>(String(args, "object_id"));
            CheckSceneObject(obj);
            if (PrefabUtility.IsPartOfPrefabInstance(obj) && !PrefabUtility.IsOutermostPrefabInstanceRoot(obj) &&
                !PrefabUtility.IsAddedGameObjectOverride(obj))
                throw Invalid("Deleting a prefab source child requires editing its source prefab in Unity.");
            return InUndoGroup("Delete GameObject", () =>
            {
                Undo.DestroyObjectImmediate(obj);
                return new JObject { ["deleted"] = !obj };
            });
        }

        private static JObject ComponentAdd(JObject args)
        {
            var obj = Resolve<GameObject>(String(args, "object_id"));
            CheckSceneObject(obj);
            string script = String(args, "script_guid", false);
            string builtin = String(args, "builtin_type", false);
            if ((script == null) == (builtin == null))
                throw Invalid("Provide exactly one of script_guid or builtin_type.");
            Type type = script != null ? ScriptType(script, typeof(MonoBehaviour)) : BuiltinType(builtin);
            if (typeof(Transform).IsAssignableFrom(type))
                throw Invalid("Unity manages the Transform component of a GameObject.");
            return InUndoGroup("Add Component", () =>
            {
                var component = Undo.AddComponent(obj, type);
                if (component == null)
                    throw new EditorToolException("component_failed", "Unity could not add this component.");
                return new JObject { ["component_id"] = Id(component), ["type"] = type.FullName };
            });
        }

        private static Type BuiltinType(string name)
        {
            string qualified = name.Contains(".") ? name : "UnityEngine." + name;
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                string assemblyName = assembly.GetName().Name;
                if (assemblyName != "UnityEngine" && !assemblyName.StartsWith("UnityEngine.", StringComparison.Ordinal))
                    continue;
                Type type = assembly.GetType(qualified, false);
                if (type != null && type.IsPublic && !type.IsAbstract && typeof(Component).IsAssignableFrom(type))
                    return type;
            }
            throw Invalid("builtin_type must name a concrete UnityEngine component.");
        }

        private static JObject ComponentRemove(JObject args)
        {
            var component = Resolve<Component>(String(args, "component_id"));
            CheckSceneObject(component.gameObject);
            if (component is Transform)
                throw Invalid("Unity manages the Transform component of a GameObject.");
            return InUndoGroup("Remove Component", () =>
            {
                Undo.DestroyObjectImmediate(component);
                if (component)
                    throw new EditorToolException("component_failed", "Unity retained this component, possibly because another component requires it.");
                return new JObject { ["removed"] = true };
            });
        }

        private static JObject AssetFind(JObject args)
        {
            string query = String(args, "query", false) ?? string.Empty;
            string folder = String(args, "folder", false) ?? "Assets";
            string type = String(args, "type", false);
            if (folder != "Assets")
                ValidateAssetPath(folder, null, false);
            if (!AssetDatabase.IsValidFolder(folder))
                throw Invalid("folder must be an existing project asset folder.");
            if (type != null && type.Any(character => !char.IsLetterOrDigit(character) && character != '_' && character != '.'))
                throw Invalid("type must be a Unity asset type name.");
            string filter = type == null ? query : query + " t:" + type;
            var paths = AssetDatabase.FindAssets(filter, new[] { folder }).Select(AssetDatabase.GUIDToAssetPath)
                .Where(path => path.StartsWith("Assets/", StringComparison.Ordinal)).Distinct().OrderBy(path => path, StringComparer.Ordinal);
            return Page(paths, args, path => DescribeAsset(path, false));
        }

        private static JObject DescribeAsset(string path, bool includeId)
        {
            var result = new JObject
            {
                ["asset_guid"] = AssetDatabase.AssetPathToGUID(path), ["path"] = path,
                ["type"] = AssetDatabase.GetMainAssetTypeAtPath(path)?.FullName
            };
            if (includeId)
            {
                result["asset_id"] = Id(AssetDatabase.LoadMainAssetAtPath(path));
                result["objects"] = new JArray(AssetDatabase.LoadAllAssetsAtPath(path).Where(obj => obj).Take(100)
                    .Select(obj => new JObject { ["asset_id"] = Id(obj), ["name"] = obj.name, ["type"] = obj.GetType().FullName }));
            }
            return result;
        }

        private static JObject ScriptableCreate(JObject args)
        {
            Type type = ScriptType(String(args, "script_guid"), typeof(ScriptableObject));
            string path = String(args, "path");
            ValidateAssetPath(path, ".asset", true);
            var asset = ScriptableObject.CreateInstance(type);
            try
            {
                AssetDatabase.CreateAsset(asset, path);
                if (!EditorUtility.IsPersistent(asset))
                    throw new EditorToolException("save_failed", "Unity could not create the asset.");
                return DescribeAsset(path, true);
            }
            finally
            {
                if (asset && !EditorUtility.IsPersistent(asset))
                    Object.DestroyImmediate(asset);
            }
        }

        private static JObject PrefabCreate(JObject args)
        {
            var obj = Resolve<GameObject>(String(args, "object_id"));
            CheckSceneObject(obj);
            if (PrefabUtility.IsPartOfPrefabInstance(obj))
                throw Invalid("Create a prefab from a plain scene object.");
            string path = String(args, "path");
            ValidateAssetPath(path, ".prefab", true);
            PrefabUtility.SaveAsPrefabAsset(obj, path, out bool success);
            if (!success)
                throw new EditorToolException("save_failed", "Unity could not create the prefab.");
            return DescribeAsset(path, true);
        }

        private static JObject PrefabInstantiate(JObject args)
        {
            string path = AssetPathFromGuid(String(args, "asset_guid"));
            var asset = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (!asset || PrefabUtility.GetPrefabAssetType(asset) == PrefabAssetType.NotAPrefab)
                throw Invalid("asset_guid must refer to a prefab.");
            var scene = ResolveScene(String(args, "scene_id"));
            var parent = Parent(args, scene);
            return InUndoGroup("Instantiate Prefab", () =>
            {
                var obj = (GameObject)PrefabUtility.InstantiatePrefab(asset, scene);
                if (!obj)
                    throw new EditorToolException("prefab_failed", "Unity could not instantiate the prefab.");
                Undo.RegisterCreatedObjectUndo(obj, "Instantiate Prefab");
                if (parent)
                    Undo.SetTransformParent(obj.transform, parent, false, "Parent Prefab Instance");
                return DescribeObject(obj, true);
            });
        }

        internal static Type ScriptType(string guid, Type baseType)
        {
            var script = AssetDatabase.LoadAssetAtPath<MonoScript>(AssetPathFromGuid(guid));
            Type type = script ? script.GetClass() : null;
            if (type == null || !baseType.IsAssignableFrom(type) || type.IsAbstract || type.ContainsGenericParameters)
                throw Invalid("The script must define a compiled concrete " + baseType.Name + " class.");
            return type;
        }

        internal static void CheckSceneObject(GameObject obj)
        {
            if (EditorUtility.IsPersistent(obj) || !obj.scene.IsValid() || !obj.scene.isLoaded ||
                EditorSceneManager.IsPreviewScene(obj.scene) || (obj.hideFlags & HideFlags.NotEditable) != 0)
                throw Invalid("The target must be editable in a loaded project scene.");
        }

        private static Transform Parent(JObject args, Scene scene)
        {
            string parentId = String(args, "parent_id", false);
            if (parentId == null)
                return null;
            var parent = Resolve<GameObject>(parentId);
            CheckSceneObject(parent);
            if (parent.scene != scene)
                throw Invalid("Parent and child must belong to the same scene.");
            return parent.transform;
        }

        internal static string AssetPathFromGuid(string guid)
        {
            if (guid.Length != 32 || !Guid.TryParseExact(guid, "N", out _))
                throw Invalid("Expected a 32-character Unity asset GUID.");
            string path = AssetDatabase.GUIDToAssetPath(guid);
            ValidateAssetPath(path, null, false);
            return path;
        }

        internal static void ValidateAssetPath(string path, string extension, bool creating)
        {
            if (string.IsNullOrEmpty(path) || !path.StartsWith("Assets/", StringComparison.Ordinal) || path.Length > 500 ||
                path.Contains("\\") || (extension != null && !path.EndsWith(extension, StringComparison.OrdinalIgnoreCase)))
                throw Invalid("Expected a project-relative Assets path" + (extension != null ? " ending in " + extension : "") + ".");
            string full = ProjectRoot;
            string[] parts = path.Split('/');
            for (int i = 0; i < parts.Length; i++)
            {
                string part = parts[i];
                string stem = part.Split('.')[0].ToUpperInvariant();
                if (part.Length == 0 || part.EndsWith(".", StringComparison.Ordinal) || part.EndsWith(" ", StringComparison.Ordinal) ||
                    part.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || part.IndexOf(':') >= 0 ||
                    stem == "CON" || stem == "PRN" || stem == "AUX" || stem == "NUL" || stem == "CONIN$" || stem == "CONOUT$" ||
                    ((stem.StartsWith("COM", StringComparison.Ordinal) || stem.StartsWith("LPT", StringComparison.Ordinal)) &&
                     stem.Length == 4 && (char.IsDigit(stem[3]) || "¹²³".Contains(stem[3]))))
                    throw Invalid("The asset path contains an invalid Windows path component.");
                full = Path.Combine(full, part);
                try
                {
                    if ((File.GetAttributes(full) & FileAttributes.ReparsePoint) != 0)
                        throw Invalid("Asset paths cannot traverse a junction or symbolic link.");
                }
                catch (FileNotFoundException) when (i == parts.Length - 1) { }
                catch (DirectoryNotFoundException) { throw Invalid("The asset's parent directory must exist."); }
            }
            if (!Directory.Exists(Path.GetDirectoryName(full)))
                throw Invalid("The asset's parent directory must exist.");
            if (creating && (File.Exists(full) || Directory.Exists(full) || File.Exists(full + ".meta") ||
                AssetDatabase.LoadMainAssetAtPath(path) != null))
                throw new EditorToolException("asset_exists", "The asset path or its metadata is already in use.");
        }

        internal static string Id(Object obj)
        {
            if (!obj)
                return null;
            if (objectIds.TryGetValue(obj, out string id) && objects.TryGetValue(id, out var previous) && previous && previous == obj)
                return id;
            if (objectOrder.Count == ObjectCapacity)
            {
                string oldest = objectOrder.Dequeue();
                Object expired = objects[oldest];
                if (objectIds.TryGetValue(expired, out string oldId) && oldId == oldest)
                    objectIds.Remove(expired);
                objects.Remove(oldest);
            }
            id = Guid.NewGuid().ToString("N");
            objects[id] = obj;
            objectIds[obj] = id;
            objectOrder.Enqueue(id);
            return id;
        }

        internal static T Resolve<T>(string id) where T : Object
        {
            if (!objects.TryGetValue(id, out Object obj) || !obj || !(obj is T typed))
                throw new EditorToolException("stale_id", "Object ID is unknown, incompatible or stale. Read the scene or asset again.");
            return typed;
        }

        internal static T InUndoGroup<T>(string label, Func<T> operation)
        {
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName(label);
            try
            {
                T result = operation();
                Undo.FlushUndoRecordObjects();
                Undo.CollapseUndoOperations(group);
                return result;
            }
            catch
            {
                Undo.FlushUndoRecordObjects();
                Undo.RevertAllDownToGroup(group);
                throw;
            }
        }

        internal static JObject Page<T>(IEnumerable<T> entries, JObject args, Func<T, JToken> select)
        {
            int offset = Number(args, "offset", 0, 0, 1000000);
            int limit = Number(args, "limit", 50, 1, 200);
            var batch = entries.Skip(offset).Take(limit + 1).ToList();
            return new JObject
            {
                ["items"] = new JArray(batch.Take(limit).Select(select)),
                ["next_offset"] = batch.Count > limit ? new JValue(offset + limit) : JValue.CreateNull()
            };
        }

        internal static string String(JObject args, string key, bool required = true)
        {
            var value = args[key];
            if (!required && (value == null || value.Type == JTokenType.Null ||
                value.Type == JTokenType.String && (string)value == null))
                return null;
            if (value?.Type != JTokenType.String || string.IsNullOrWhiteSpace((string)value) || ((string)value).Length > 1024)
                throw Invalid(key + " must be a nonempty string of up to 1024 characters.");
            return (string)value;
        }

        internal static int Number(JObject args, string key, int fallback, int minimum, int maximum)
        {
            var value = args[key];
            if (value == null)
                return fallback;
            if (value.Type != JTokenType.Integer || !long.TryParse(value.ToString(), out long number) || number < minimum || number > maximum)
                throw Invalid(key + " must be an integer between " + minimum + " and " + maximum + ".");
            return (int)number;
        }

        private static bool? OptionalBool(JObject args, string key)
        {
            var value = args[key];
            if (value == null)
                return null;
            if (value.Type != JTokenType.Boolean)
                throw Invalid(key + " must be a boolean.");
            return (bool)value;
        }

        private static Vector3? OptionalVector(JObject args, string key)
        {
            var value = args[key];
            if (value == null)
                return null;
            if (!(value is JArray array) || array.Count != 3)
                throw Invalid(key + " must contain three finite numbers.");
            return new Vector3(Float(array[0]), Float(array[1]), Float(array[2]));
        }

        internal static float Float(JToken token)
        {
            if (token == null || token.Type != JTokenType.Float && token.Type != JTokenType.Integer)
                throw Invalid("Expected a finite number.");
            float value = (float)token;
            if (float.IsInfinity(value) || float.IsNaN(value))
                throw Invalid("Expected a finite number.");
            return value;
        }

        private static JArray Vector(Vector3 value) => new JArray(value.x, value.y, value.z);

        internal static EditorToolException Invalid(string message) => new EditorToolException("invalid_argument", message);
    }
}
