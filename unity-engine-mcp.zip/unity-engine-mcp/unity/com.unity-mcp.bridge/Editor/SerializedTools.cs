using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;
using Object = UnityEngine.Object;

namespace UnityMcp.Editor
{
    internal static class SerializedTools
    {
        private const int PropertyLimit = 8192;
        private const int ArrayLimit = 1024;
        private const int SnapshotByteLimit = 1024 * 1024;
        private static readonly HashSet<string> protectedPaths = new HashSet<string>(StringComparer.Ordinal)
        {
            "m_Script", "m_GameObject", "m_CorrespondingSourceObject", "m_PrefabInstance", "m_PrefabAsset",
            "m_ObjectHideFlags", "m_EditorHideFlags", "m_Father", "m_Children", "m_RootOrder"
        };
        private static readonly HashSet<SerializedPropertyType> writableLeaves = new HashSet<SerializedPropertyType>
        {
            SerializedPropertyType.Integer, SerializedPropertyType.Boolean, SerializedPropertyType.Float,
            SerializedPropertyType.String, SerializedPropertyType.Color, SerializedPropertyType.ObjectReference,
            SerializedPropertyType.LayerMask, SerializedPropertyType.Enum, SerializedPropertyType.Vector2,
            SerializedPropertyType.Vector3, SerializedPropertyType.Vector4, SerializedPropertyType.Rect,
            SerializedPropertyType.Character, SerializedPropertyType.AnimationCurve, SerializedPropertyType.Bounds,
            SerializedPropertyType.Gradient, SerializedPropertyType.Quaternion, SerializedPropertyType.ExposedReference,
            SerializedPropertyType.Vector2Int, SerializedPropertyType.Vector3Int, SerializedPropertyType.RectInt,
            SerializedPropertyType.BoundsInt, SerializedPropertyType.Hash128
        };
        private static HashSet<string> projectAssemblies;

        internal static JObject Inspect(JObject args)
        {
            string id = EditorTools.String(args, "target_id");
            string path = EditorTools.String(args, "path", false);
            var target = ResolveTarget(id, false);
            using (var serialized = new SerializedObject(target))
            {
                var rows = Snapshot(serialized, path);
                var page = EditorTools.Page(rows, args, row => row);
                page["target_id"] = id;
                page["type"] = target.GetType().FullName;
                page["path"] = path;
                page["revision"] = Revision(rows);
                if (path != null)
                {
                    using (var property = Find(serialized, path))
                        if (property.propertyType == SerializedPropertyType.ManagedReference)
                            page["managed_types"] = new JArray(ManagedTypes(property).Take(256).Select(TypeId));
                }
                return page;
            }
        }

        internal static JObject Patch(JObject args)
        {
            string id = EditorTools.String(args, "target_id");
            string branch = EditorTools.String(args, "path", false);
            string expected = EditorTools.String(args, "expected_revision");
            if (!(args["operations"] is JArray operations) || operations.Count < 1 || operations.Count > 256)
                throw EditorTools.Invalid("operations must contain between 1 and 256 property edits.");
            var target = ResolveTarget(id, true);
            using (var serialized = new SerializedObject(target))
            {
                string actual = Revision(Snapshot(serialized, branch));
                if (!string.Equals(expected, actual, StringComparison.OrdinalIgnoreCase))
                    throw new EditorToolException("revision_conflict", "The serialized branch changed. Inspect it again before patching.");

                var references = new Dictionary<string, object>(StringComparer.Ordinal);
                bool editsReferences = operations.Any(operation => operation.Type == JTokenType.Object &&
                    ((string)operation["op"] == "managed_new" || (string)operation["op"] == "managed_link"));
                if (editsReferences)
                    Walk(serialized, null, property =>
                    {
                        if (property.propertyType == SerializedPropertyType.ManagedReference && property.managedReferenceValue != null)
                            references[ReferenceId(property)] = property.managedReferenceValue;
                    });
                foreach (JToken token in operations)
                {
                    if (!(token is JObject operation))
                        throw EditorTools.Invalid("Each serialized edit must be an object.");
                    string path = EditorTools.String(operation, "path");
                    if (branch != null && path != branch && !path.StartsWith(branch + ".", StringComparison.Ordinal))
                        throw EditorTools.Invalid("Every edit must belong to the inspected property branch.");
                    using (var property = Find(serialized, path))
                    {
                        if (!Editable(property))
                            throw EditorTools.Invalid(path + " is not an editable serialized property.");
                        ApplyEdit(property, operation, references);
                    }
                }
                return EditorTools.InUndoGroup("Edit Serialized Properties", () =>
                {
                    bool changed = serialized.ApplyModifiedProperties();
                    if (changed && target is Component component)
                        PrefabUtility.RecordPrefabInstancePropertyModifications(component);
                    return new JObject { ["target_id"] = id, ["changed"] = changed, ["path"] = branch };
                });
            }
        }

        private static Object ResolveTarget(string id, bool writing)
        {
            var target = EditorTools.Resolve<Object>(id);
            if (target is Component component)
            {
                if (writing)
                    EditorTools.CheckSceneObject(component.gameObject);
            }
            else if (target is ScriptableObject && EditorUtility.IsPersistent(target))
            {
                string path = AssetDatabase.GetAssetPath(target);
                EditorTools.ValidateAssetPath(path, writing ? ".asset" : null, false);
                if (writing && !AssetDatabase.IsOpenForEdit(path))
                    throw new EditorToolException("asset_read_only", "Unity reports that the asset cannot be opened for editing.");
            }
            else
                throw EditorTools.Invalid("target_id must identify a component or a project ScriptableObject asset.");
            if (writing && (target.hideFlags & HideFlags.NotEditable) != 0)
                throw EditorTools.Invalid("The target is read-only in Unity.");
            return target;
        }

        private static List<JObject> Snapshot(SerializedObject serialized, string branch)
        {
            var rows = new List<JObject>();
            int bytes = 0;
            Walk(serialized, branch, property =>
            {
                var row = Describe(property);
                bytes += Encoding.UTF8.GetByteCount(row.ToString(Formatting.None));
                if (bytes > SnapshotByteLimit)
                    throw new EditorToolException("property_limit", "This branch is too large. Inspect a narrower property path.");
                rows.Add(row);
            });
            return rows;
        }

        private static void Walk(SerializedObject serialized, string branch, Action<SerializedProperty> visit)
        {
            using (var property = branch == null ? serialized.GetIterator() : Find(serialized, branch))
            {
                var seen = new HashSet<long>();
                bool more = branch != null || property.Next(true);
                int count = 0;
                while (more && (branch == null || property.propertyPath == branch ||
                    property.propertyPath.StartsWith(branch + ".", StringComparison.Ordinal)))
                {
                    if (++count > PropertyLimit)
                        throw new EditorToolException("property_limit", "This branch is too large. Inspect a narrower property path.");
                    if (!IsArrayContainer(property) && property.propertyType != SerializedPropertyType.ArraySize)
                        visit(property);
                    bool enter = property.propertyType == SerializedPropertyType.Generic ||
                        property.propertyType == SerializedPropertyType.ManagedReference &&
                        property.managedReferenceValue != null && seen.Add(property.managedReferenceId);
                    more = property.Next(enter);
                }
            }
        }

        private static SerializedProperty Find(SerializedObject serialized, string path)
        {
            return serialized.FindProperty(path) ?? throw EditorTools.Invalid("Unknown serialized property: " + path);
        }

        private static JObject Describe(SerializedProperty property)
        {
            var kind = property.propertyType;
            bool editable = Editable(property);
            var row = new JObject
            {
                ["path"] = property.propertyPath, ["type"] = kind.ToString(),
                ["unity_type"] = property.type, ["editable"] = editable
            };
            if (kind == SerializedPropertyType.ManagedReference)
            {
                object value = property.managedReferenceValue;
                row["value"] = value == null ? JValue.CreateNull() : new JValue(ReferenceId(property));
                row["managed_type"] = value == null ? null : TypeId(value.GetType());
                row["declared_type"] = property.managedReferenceFieldTypename;
            }
            else if (IsArray(property))
                row["size"] = property.arraySize;
            else if (writableLeaves.Contains(kind))
                row["value"] = ReadLeaf(property);
            else if (kind != SerializedPropertyType.Generic && kind != SerializedPropertyType.ArraySize)
                row["status"] = "unsupported_property_type";
            if (kind == SerializedPropertyType.Enum)
                row["enum_names"] = new JArray(property.enumNames);
            if (property.prefabOverride)
                row["prefab_override"] = true;
            return row;
        }

        private static bool Editable(SerializedProperty property)
        {
            string path = property.propertyPath;
            int delimiter = path.IndexOf('.');
            if (!property.editable || protectedPaths.Contains(delimiter < 0 ? path : path.Substring(0, delimiter)))
                return false;
            if (IsArrayContainer(property))
                return false;
            for (int split = delimiter; split >= 0; split = path.IndexOf('.', split + 1))
            {
                using (var parent = property.serializedObject.FindProperty(path.Substring(0, split)))
                    if (parent != null && parent.propertyType != SerializedPropertyType.Generic &&
                        parent.propertyType != SerializedPropertyType.ManagedReference)
                        return false;
            }
            return IsArray(property) ? !property.isFixedBuffer :
                property.propertyType == SerializedPropertyType.ManagedReference || writableLeaves.Contains(property.propertyType);
        }

        private static bool IsArray(SerializedProperty property)
        {
            return property.isArray && property.propertyType == SerializedPropertyType.Generic;
        }

        private static bool IsArrayContainer(SerializedProperty property)
        {
            return property.type == "Array" && property.propertyPath.EndsWith(".Array", StringComparison.Ordinal);
        }

        private static string Revision(List<JObject> rows)
        {
            using (var sha = SHA256.Create())
            {
                var encoded = Encoding.UTF8.GetBytes(new JArray(rows).ToString(Formatting.None));
                return BitConverter.ToString(sha.ComputeHash(encoded)).Replace("-", "").ToLowerInvariant();
            }
        }

        private static void ApplyEdit(SerializedProperty property, JObject edit, Dictionary<string, object> references)
        {
            string op = EditorTools.String(edit, "op");
            switch (op)
            {
                case "set" when writableLeaves.Contains(property.propertyType):
                    if (edit["value"] == null)
                        throw EditorTools.Invalid("A set edit requires a value.");
                    WriteLeaf(property, edit["value"]);
                    return;
                case "resize" when IsArray(property):
                    int size = EditorTools.Number(edit, "value", -1, 0, ArrayLimit);
                    if (size < 0)
                        throw EditorTools.Invalid("A resize edit requires the desired size.");
                    property.arraySize = size;
                    return;
                case "managed_new" when property.propertyType == SerializedPropertyType.ManagedReference:
                    NewManaged(property, edit, references);
                    return;
                case "managed_link" when property.propertyType == SerializedPropertyType.ManagedReference:
                    LinkManaged(property, edit, references);
                    return;
                default:
                    throw EditorTools.Invalid(op + " is unsupported for " + property.propertyPath + ".");
            }
        }

        private static void NewManaged(SerializedProperty property, JObject edit, Dictionary<string, object> references)
        {
            string typeId = EditorTools.String(edit, "type_id");
            string key = EditorTools.String(edit, "key", false);
            if (key != null && references.ContainsKey(key))
                throw EditorTools.Invalid("The managed reference key is already in use.");
            Type type = ManagedTypes(property).FirstOrDefault(candidate => TypeId(candidate) == typeId);
            if (type == null)
                throw EditorTools.Invalid("The managed type must be a concrete compatible project type from serialized_inspect.");
            object value = FormatterServices.GetUninitializedObject(type);
            property.managedReferenceValue = value;
            if (key != null)
                references.Add(key, value);
        }

        private static void LinkManaged(SerializedProperty property, JObject edit, Dictionary<string, object> references)
        {
            if (edit["value"]?.Type == JTokenType.Null)
            {
                property.managedReferenceValue = null;
                return;
            }
            string key = EditorTools.String(edit, "value");
            if (!references.TryGetValue(key, out object value) || !ManagedBase(property).IsInstanceOfType(value))
                throw EditorTools.Invalid("The managed reference ID is unknown or incompatible with the field.");
            property.managedReferenceValue = value;
        }

        private static string ReferenceId(SerializedProperty property)
        {
            return "ref:" + property.managedReferenceId.ToString(CultureInfo.InvariantCulture);
        }

        private static string TypeId(Type type) => type.Assembly.GetName().Name + " " + type.FullName;

        private static Type ManagedBase(SerializedProperty property)
        {
            string name = property.managedReferenceFieldTypename;
            int space = name.IndexOf(' ');
            if (space >= 0)
            {
                string assemblyName = name.Substring(0, space);
                string typeName = name.Substring(space + 1).Replace('/', '+');
                var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(candidate => candidate.GetName().Name == assemblyName);
                Type type = assembly?.GetType(typeName, false);
                if (type != null)
                    return type;
            }
            throw EditorTools.Invalid("Unity could not resolve the declared managed reference type.");
        }

        private static IEnumerable<Type> ManagedTypes(SerializedProperty property)
        {
            if (projectAssemblies == null)
                projectAssemblies = new HashSet<string>(CompilationPipeline.GetAssemblies().Where(assembly =>
                    assembly.sourceFiles.Any(file => file.Replace('\\', '/').StartsWith("Assets/", StringComparison.Ordinal) ||
                        file.Replace('\\', '/').StartsWith(Application.dataPath.Replace('\\', '/') + "/", StringComparison.OrdinalIgnoreCase)))
                    .Select(assembly => assembly.name), StringComparer.Ordinal);
            Type baseType = ManagedBase(property);
            return TypeCache.GetTypesDerivedFrom(baseType).Concat(new[] { baseType }).Where(type =>
                type.IsClass && !type.IsAbstract && !type.ContainsGenericParameters && type.IsSerializable &&
                !typeof(Object).IsAssignableFrom(type) && !typeof(Delegate).IsAssignableFrom(type) &&
                projectAssemblies.Contains(type.Assembly.GetName().Name)).OrderBy(TypeId, StringComparer.Ordinal);
        }

        private static JToken ReadLeaf(SerializedProperty property)
        {
            switch (property.propertyType)
            {
                case SerializedPropertyType.Integer:
                    object number = property.boxedValue;
                    return number is long || number is ulong ? new JValue(Convert.ToString(number, CultureInfo.InvariantCulture)) : JToken.FromObject(number);
                case SerializedPropertyType.Boolean: return new JValue(property.boolValue);
                case SerializedPropertyType.Float: return Number(property.doubleValue);
                case SerializedPropertyType.String: return new JValue(property.stringValue);
                case SerializedPropertyType.Color: return ColorValue(property.colorValue);
                case SerializedPropertyType.ObjectReference: return new JValue(EditorTools.Id(property.objectReferenceValue));
                case SerializedPropertyType.ExposedReference: return new JValue(EditorTools.Id(property.exposedReferenceValue));
                case SerializedPropertyType.LayerMask: case SerializedPropertyType.Character: return new JValue(property.intValue);
                case SerializedPropertyType.Enum: return new JValue(property.enumValueFlag);
                case SerializedPropertyType.Vector2:
                    Vector2 v2 = property.vector2Value;
                    return Tuple(v2.x, v2.y);
                case SerializedPropertyType.Vector3: return Vector(property.vector3Value);
                case SerializedPropertyType.Vector4:
                    Vector4 v4 = property.vector4Value;
                    return Tuple(v4.x, v4.y, v4.z, v4.w);
                case SerializedPropertyType.Rect:
                    Rect rect = property.rectValue;
                    return Tuple(rect.x, rect.y, rect.width, rect.height);
                case SerializedPropertyType.Bounds:
                    Bounds bounds = property.boundsValue;
                    return new JObject { ["center"] = Vector(bounds.center), ["size"] = Vector(bounds.size) };
                case SerializedPropertyType.Quaternion:
                    Quaternion q = property.quaternionValue;
                    return Tuple(q.x, q.y, q.z, q.w);
                case SerializedPropertyType.Vector2Int:
                    Vector2Int v2i = property.vector2IntValue;
                    return new JArray(v2i.x, v2i.y);
                case SerializedPropertyType.Vector3Int: return Vector(property.vector3IntValue);
                case SerializedPropertyType.RectInt:
                    RectInt ri = property.rectIntValue;
                    return new JArray(ri.x, ri.y, ri.width, ri.height);
                case SerializedPropertyType.BoundsInt:
                    BoundsInt bi = property.boundsIntValue;
                    return new JObject { ["position"] = Vector(bi.position), ["size"] = Vector(bi.size) };
                case SerializedPropertyType.Hash128: return new JValue(property.hash128Value.ToString());
                case SerializedPropertyType.AnimationCurve: return CurveValue(property.animationCurveValue);
                case SerializedPropertyType.Gradient: return GradientValue(property.gradientValue);
                default: throw EditorTools.Invalid("Unsupported property type: " + property.propertyType);
            }
        }

        private static void WriteLeaf(SerializedProperty property, JToken value)
        {
            JArray array;
            JObject obj;
            switch (property.propertyType)
            {
                case SerializedPropertyType.Integer:
                    property.boxedValue = Integer(value, property.boxedValue.GetType());
                    return;
                case SerializedPropertyType.Boolean:
                    if (value.Type != JTokenType.Boolean) throw EditorTools.Invalid("Expected a boolean.");
                    property.boolValue = (bool)value;
                    return;
                case SerializedPropertyType.Float:
                    if (property.numericType == SerializedPropertyNumericType.Double) property.doubleValue = Double(value);
                    else property.floatValue = Float(value);
                    return;
                case SerializedPropertyType.String:
                    if (value.Type != JTokenType.String || ((string)value).Length > 32768)
                        throw EditorTools.Invalid("Expected a string of up to 32768 characters.");
                    property.stringValue = (string)value;
                    return;
                case SerializedPropertyType.Color: property.colorValue = ColorFrom(value); return;
                case SerializedPropertyType.ObjectReference: SetReference(property, ObjectReference(property, value)); return;
                case SerializedPropertyType.ExposedReference:
                    using (var defaultValue = property.FindPropertyRelative("defaultValue"))
                    {
                        if (defaultValue == null)
                            throw EditorTools.Invalid("Unity did not expose a writable default reference.");
                        SetReference(defaultValue, ObjectReference(property, value));
                    }
                    return;
                case SerializedPropertyType.LayerMask: property.intValue = Int(value); return;
                case SerializedPropertyType.Character: property.intValue = (ushort)Integer(value, typeof(ushort)); return;
                case SerializedPropertyType.Enum: property.enumValueFlag = Int(value); return;
                case SerializedPropertyType.Vector2:
                    array = Array(value, 2);
                    property.vector2Value = new Vector2(Float(array[0]), Float(array[1]));
                    return;
                case SerializedPropertyType.Vector3: property.vector3Value = Vector3From(value); return;
                case SerializedPropertyType.Vector4:
                    array = Array(value, 4);
                    property.vector4Value = new Vector4(Float(array[0]), Float(array[1]), Float(array[2]), Float(array[3]));
                    return;
                case SerializedPropertyType.Rect:
                    array = Array(value, 4);
                    property.rectValue = new Rect(Float(array[0]), Float(array[1]), Float(array[2]), Float(array[3]));
                    return;
                case SerializedPropertyType.Bounds:
                    obj = ObjectValue(value);
                    property.boundsValue = new Bounds(Vector3From(obj["center"]), Vector3From(obj["size"]));
                    return;
                case SerializedPropertyType.Quaternion:
                    array = Array(value, 4);
                    property.quaternionValue = new Quaternion(Float(array[0]), Float(array[1]), Float(array[2]), Float(array[3]));
                    return;
                case SerializedPropertyType.Vector2Int:
                    array = Array(value, 2);
                    property.vector2IntValue = new Vector2Int(Int(array[0]), Int(array[1]));
                    return;
                case SerializedPropertyType.Vector3Int: property.vector3IntValue = Vector3IntFrom(value); return;
                case SerializedPropertyType.RectInt:
                    array = Array(value, 4);
                    property.rectIntValue = new RectInt(Int(array[0]), Int(array[1]), Int(array[2]), Int(array[3]));
                    return;
                case SerializedPropertyType.BoundsInt:
                    obj = ObjectValue(value);
                    property.boundsIntValue = new BoundsInt(Vector3IntFrom(obj["position"]), Vector3IntFrom(obj["size"]));
                    return;
                case SerializedPropertyType.Hash128:
                    if (value.Type != JTokenType.String || ((string)value).Length != 32 || ((string)value).Any(ch => !Uri.IsHexDigit(ch)))
                        throw EditorTools.Invalid("Expected a 32-character hexadecimal Hash128.");
                    property.hash128Value = Hash128.Parse((string)value);
                    return;
                case SerializedPropertyType.AnimationCurve: property.animationCurveValue = CurveFrom(value); return;
                case SerializedPropertyType.Gradient: property.gradientValue = GradientFrom(value); return;
                default: throw EditorTools.Invalid("Unsupported property type: " + property.propertyType);
            }
        }

        private static Object ObjectReference(SerializedProperty property, JToken value)
        {
            if (value.Type == JTokenType.Null)
                return null;
            if (value.Type != JTokenType.String || string.IsNullOrWhiteSpace((string)value))
                throw EditorTools.Invalid("Object references require an object, component or asset ID, or null.");
            var reference = EditorTools.Resolve<Object>((string)value);
            var target = property.serializedObject.targetObject;
            if (!EditorUtility.IsPersistent(reference))
            {
                var sceneObject = reference as GameObject ?? (reference as Component)?.gameObject;
                if (!(target is Component owner) || !sceneObject || owner.gameObject.scene != sceneObject.scene)
                    throw EditorTools.Invalid("Scene references must belong to the same scene as the target component.");
            }
            Type expected = DeclaredType(property);
            if (expected != null && property.propertyType == SerializedPropertyType.ExposedReference && expected.IsGenericType)
                expected = expected.GetGenericArguments()[0];
            if (expected != null && typeof(Object).IsAssignableFrom(expected) && !expected.IsInstanceOfType(reference))
                throw EditorTools.Invalid("Object reference is incompatible with the property's type.");
            if (expected == null && property.type.StartsWith("PPtr<$", StringComparison.Ordinal) && property.type.EndsWith(">", StringComparison.Ordinal))
            {
                string unityType = property.type.Substring(6, property.type.Length - 7);
                Type actual = reference.GetType();
                while (actual != null && actual.Name != unityType && actual.FullName != unityType)
                    actual = actual.BaseType;
                if (actual == null && unityType != "Object")
                    throw EditorTools.Invalid("Object reference is incompatible with the property's type.");
            }
            return reference;
        }

        private static void SetReference(SerializedProperty property, Object value)
        {
            property.objectReferenceValue = value;
            if (property.objectReferenceValue != value)
                throw EditorTools.Invalid("Unity rejected the object reference for this property.");
        }

        private static Type DeclaredType(SerializedProperty property)
        {
            Type type = property.serializedObject.targetObject.GetType();
            string[] segments = property.propertyPath.Split('.');
            string prefix = string.Empty;
            for (int i = 0; i < segments.Length; i++)
            {
                string segment = segments[i];
                prefix = prefix.Length == 0 ? segment : prefix + "." + segment;
                if (segment == "Array" && i + 1 < segments.Length && segments[i + 1].StartsWith("data[", StringComparison.Ordinal))
                {
                    type = type.IsArray ? type.GetElementType() : type.IsGenericType ? type.GetGenericArguments().FirstOrDefault() : null;
                    prefix += "." + segments[++i];
                }
                else
                {
                    FieldInfo field = null;
                    for (Type container = type; container != null && field == null; container = container.BaseType)
                        field = container.GetField(segment, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly);
                    type = field?.FieldType;
                }
                if (type == null || i == segments.Length - 1)
                    return type;
                using (var parent = property.serializedObject.FindProperty(prefix))
                    if (parent?.propertyType == SerializedPropertyType.ManagedReference && parent.managedReferenceValue != null)
                        type = parent.managedReferenceValue.GetType();
            }
            return type;
        }

        private static JToken Number(double number)
        {
            if (double.IsPositiveInfinity(number)) return new JValue("Infinity");
            if (double.IsNegativeInfinity(number)) return new JValue("-Infinity");
            if (double.IsNaN(number)) return new JValue("NaN");
            return new JValue(number);
        }

        private static double Double(JToken token)
        {
            if (token?.Type == JTokenType.Float || token?.Type == JTokenType.Integer)
                return (double)token;
            switch ((string)token)
            {
                case "Infinity": return double.PositiveInfinity;
                case "-Infinity": return double.NegativeInfinity;
                case "NaN": return double.NaN;
                default: throw EditorTools.Invalid("Expected a number or an explicitly named IEEE floating point value.");
            }
        }

        private static float Float(JToken token)
        {
            double value = Double(token);
            if (!double.IsInfinity(value) && (value > float.MaxValue || value < -float.MaxValue))
                throw EditorTools.Invalid("The number is outside the supported float range.");
            return (float)value;
        }

        private static object Integer(JToken value, Type type)
        {
            if (value == null || value.Type != JTokenType.Integer && value.Type != JTokenType.String)
                throw EditorTools.Invalid("Expected an integer or its decimal string representation.");
            try { return Convert.ChangeType(value.ToString(), type, CultureInfo.InvariantCulture); }
            catch (FormatException) { throw EditorTools.Invalid("Expected a decimal integer."); }
            catch (OverflowException) { throw EditorTools.Invalid("The integer is outside the property's supported range."); }
        }

        private static int Int(JToken value) => (int)Integer(value, typeof(int));
        private static JObject ObjectValue(JToken value) => value as JObject ?? throw EditorTools.Invalid("Expected an object value.");
        private static JArray Array(JToken value, int length) => value is JArray array && array.Count == length
            ? array : throw EditorTools.Invalid("Expected an array of length " + length + ".");
        private static JArray Tuple(params float[] values) => new JArray(values.Select(value => Number(value)));
        private static JArray Vector(Vector3 value) => Tuple(value.x, value.y, value.z);
        private static JArray Vector(Vector3Int value) => new JArray(value.x, value.y, value.z);
        private static JArray ColorValue(Color value) => Tuple(value.r, value.g, value.b, value.a);

        private static Color ColorFrom(JToken value)
        {
            var array = Array(value, 4);
            return new Color(Float(array[0]), Float(array[1]), Float(array[2]), Float(array[3]));
        }

        private static Vector3 Vector3From(JToken value)
        {
            var array = Array(value, 3);
            return new Vector3(Float(array[0]), Float(array[1]), Float(array[2]));
        }

        private static Vector3Int Vector3IntFrom(JToken value)
        {
            var array = Array(value, 3);
            return new Vector3Int(Int(array[0]), Int(array[1]), Int(array[2]));
        }

        private static JObject CurveValue(AnimationCurve curve) => new JObject
        {
            ["pre_wrap"] = curve.preWrapMode.ToString(), ["post_wrap"] = curve.postWrapMode.ToString(),
            ["keys"] = new JArray(curve.keys.Select(key => new JObject
            {
                ["values"] = Tuple(key.time, key.value, key.inTangent, key.outTangent, key.inWeight, key.outWeight),
                ["weighted_mode"] = key.weightedMode.ToString()
            }))
        };

        private static AnimationCurve CurveFrom(JToken value)
        {
            var obj = ObjectValue(value);
            if (!(obj["keys"] is JArray keys) || keys.Count > ArrayLimit)
                throw EditorTools.Invalid("Expected a bounded animation curve keys array.");
            var curve = new AnimationCurve(keys.Select(item =>
            {
                var key = ObjectValue(item);
                var values = Array(key["values"], 6);
                return new Keyframe(Float(values[0]), Float(values[1]), Float(values[2]), Float(values[3]), Float(values[4]), Float(values[5]))
                    { weightedMode = EnumValue<WeightedMode>(key, "weighted_mode") };
            }).ToArray());
            curve.preWrapMode = EnumValue<WrapMode>(obj, "pre_wrap");
            curve.postWrapMode = EnumValue<WrapMode>(obj, "post_wrap");
            return curve;
        }

        private static JObject GradientValue(Gradient gradient) => new JObject
        {
            ["mode"] = gradient.mode.ToString(), ["color_space"] = gradient.colorSpace.ToString(),
            ["colors"] = new JArray(gradient.colorKeys.Select(key => new JObject { ["color"] = ColorValue(key.color), ["time"] = Number(key.time) })),
            ["alpha"] = new JArray(gradient.alphaKeys.Select(key => Tuple(key.alpha, key.time)))
        };

        private static Gradient GradientFrom(JToken value)
        {
            var obj = ObjectValue(value);
            if (!(obj["colors"] is JArray colors) || colors.Count < 2 || colors.Count > 8 ||
                !(obj["alpha"] is JArray alpha) || alpha.Count < 2 || alpha.Count > 8)
                throw EditorTools.Invalid("Expected 2 to 8 gradient color and alpha keys.");
            var gradient = new Gradient { mode = EnumValue<GradientMode>(obj, "mode"), colorSpace = EnumValue<ColorSpace>(obj, "color_space") };
            gradient.SetKeys(colors.Select(item =>
            {
                var key = ObjectValue(item);
                return new GradientColorKey(ColorFrom(key["color"]), EditorTools.Float(key["time"]));
            }).ToArray(), alpha.Select(item =>
            {
                var key = Array(item, 2);
                return new GradientAlphaKey(EditorTools.Float(key[0]), EditorTools.Float(key[1]));
            }).ToArray());
            return gradient;
        }

        private static T EnumValue<T>(JObject obj, string field) where T : struct, Enum
        {
            if (Enum.TryParse(EditorTools.String(obj, field), out T value) && Enum.IsDefined(typeof(T), value))
                return value;
            throw EditorTools.Invalid(field + " must name a supported " + typeof(T).Name + " value.");
        }
    }
}
