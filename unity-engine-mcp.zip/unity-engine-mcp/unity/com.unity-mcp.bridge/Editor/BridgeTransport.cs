using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace UnityMcp.Editor
{
    internal sealed class BridgeTransport : IDisposable
    {
        internal const int Protocol = 1;
        internal const int MaximumFrameSize = 4 * 1024 * 1024;
        internal static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);

        private const int MaximumConnections = 12;
        private const int MaximumQueue = 8;
        private static readonly TimeSpan AuthTimeout = TimeSpan.FromSeconds(3);
        private static readonly TimeSpan CommandTimeout = TimeSpan.FromSeconds(15);
        private static readonly TimeSpan ReplyTimeout = TimeSpan.FromSeconds(3);

        private readonly string generation;
        private readonly byte[] key;
        private readonly TcpListener listener;
        private readonly CancellationTokenSource stopping = new CancellationTokenSource();
        private readonly ConcurrentDictionary<TcpClient, byte> connections = new ConcurrentDictionary<TcpClient, byte>();
        private readonly ConcurrentQueue<Command> pending = new ConcurrentQueue<Command>();
        private readonly Func<string, bool> isMutation;
        private readonly Func<JObject> getStatus;
        private int pendingCount;

        internal BridgeTransport(string generation, byte[] key, Func<string, bool> isMutation, Func<JObject> getStatus)
        {
            this.generation = generation;
            this.key = key;
            this.isMutation = isMutation;
            this.getStatus = getStatus;
            listener = new TcpListener(IPAddress.Loopback, 0);
            listener.Server.ExclusiveAddressUse = true;
            listener.Start(MaximumConnections);
        }

        internal int Port => ((IPEndPoint)listener.LocalEndpoint).Port;

        internal void StartAccepting() => _ = Task.Run(AcceptAsync);

        internal void Pump(Func<string, JObject, JToken> execute)
        {
            var time = Stopwatch.StartNew();
            for (var index = 0; index < 4 && time.ElapsedMilliseconds < 4 && pending.TryDequeue(out var command); index++)
            {
                Interlocked.Decrement(ref pendingCount);
                if (!command.TryStart())
                    continue;

                JObject response;
                try
                {
                    response = Success(execute(command.Method, command.Arguments));
                }
                catch (EditorToolException failure)
                {
                    response = Error(failure.Code, failure.Message);
                }
                catch (Exception failure)
                {
                    // Unexpected failures may occur after an editor mutation has already taken effect.
                    response = isMutation(command.Method)
                        ? Error("outcome_unknown", "Unity failed during the operation. Read the target state before retrying.")
                        : Error("editor_error", "Unity failed to complete the operation.");
                    UnityEngine.Debug.LogException(failure);
                }
                command.Complete(response);
            }
        }

        public void Dispose()
        {
            stopping.Cancel();
            listener.Stop();
            foreach (var connection in connections.Keys)
                connection.Dispose();
            while (pending.TryDequeue(out var command))
            {
                Interlocked.Decrement(ref pendingCount);
                command.CancelBeforeStart();
            }
        }

        private async Task AcceptAsync()
        {
            while (!stopping.IsCancellationRequested)
            {
                TcpClient client;
                try
                {
                    client = await listener.AcceptTcpClientAsync().ConfigureAwait(false);
                }
                catch (ObjectDisposedException)
                {
                    return;
                }
                catch (SocketException)
                {
                    if (stopping.IsCancellationRequested)
                        return;
                    await Task.Delay(100).ConfigureAwait(false);
                    continue;
                }

                if (stopping.IsCancellationRequested || connections.Count >= MaximumConnections)
                {
                    client.Dispose();
                    continue;
                }
                connections.TryAdd(client, 0);
                if (stopping.IsCancellationRequested)
                    client.Dispose();
                _ = HandleAsync(client);
            }
        }

        private async Task HandleAsync(TcpClient client)
        {
            try
            {
                client.NoDelay = true;
                using var stream = client.GetStream();
                using var authDeadline = CancellationTokenSource.CreateLinkedTokenSource(stopping.Token);
                authDeadline.CancelAfter(AuthTimeout);
                // Socket disposal bounds a stuck read even on Unity's Mono implementation.
                using var abortAuth = authDeadline.Token.Register(() => client.Dispose());

                var hello = await ReadFrameAsync(stream).ConfigureAwait(false);
                var clientNonce = ReadBase64String(hello, "client_nonce", 32);
                var serverNonce = Convert.ToBase64String(RandomBytes(32));
                await WriteFrameAsync(stream, new JObject
                {
                    ["server_nonce"] = serverNonce,
                    ["proof"] = Sign("server", clientNonce, serverNonce, "")
                }).ConfigureAwait(false);

                var envelope = await ReadFrameAsync(stream).ConfigureAwait(false);
                var request = RequiredString(envelope, "request");
                var proof = ReadBase64String(envelope, "proof", 32);
                if (!Verify(proof, Sign("request", clientNonce, serverNonce, request)))
                    return;
                abortAuth.Dispose();
                authDeadline.Token.ThrowIfCancellationRequested();

                var requestObject = ParseObject(Convert.FromBase64String(request));
                var method = RequiredString(requestObject, "method");
                var arguments = requestObject["params"] as JObject;
                JObject response;
                if (method.Length > 100 || arguments == null)
                    response = Error("invalid_request", "Expected a tool name and object parameters.");
                else if (method == "unity_status")
                    response = Success(getStatus());
                else
                    response = await DispatchAsync(stream, method, arguments).ConfigureAwait(false);
                if (response == null)
                    return;

                var output = SignedResponse(response, clientNonce, serverNonce);
                if (output.Length > MaximumFrameSize)
                    output = SignedResponse(Error("response_too_large", "Result exceeds the bridge frame limit."),
                        clientNonce, serverNonce);
                using var replyDeadline = CancellationTokenSource.CreateLinkedTokenSource(stopping.Token);
                replyDeadline.CancelAfter(ReplyTimeout);
                using var abortReply = replyDeadline.Token.Register(() => client.Dispose());
                await WriteFrameAsync(stream, output).ConfigureAwait(false);
            }
            catch (Exception failure) when (failure is IOException || failure is SocketException ||
                failure is ObjectDisposedException || failure is OperationCanceledException || failure is JsonException ||
                failure is FormatException || failure is ArgumentException || failure is InvalidOperationException)
            {
                // Disconnects and invalid frames are connection-scoped. Never log request bodies or auth material.
            }
            finally
            {
                client.Dispose();
                connections.TryRemove(client, out _);
            }
        }

        private async Task<JObject> DispatchAsync(NetworkStream stream, string method, JObject arguments)
        {
            if (stopping.IsCancellationRequested)
                return null;
            if (Interlocked.Increment(ref pendingCount) > MaximumQueue)
            {
                Interlocked.Decrement(ref pendingCount);
                return Error("bridge_busy", "The Unity command queue is full. Try again after pending calls complete.");
            }

            var command = new Command(method, arguments);
            var disconnected = WaitForPeerCloseAsync(stream, command);
            pending.Enqueue(command);
            if (stopping.IsCancellationRequested)
                command.CancelBeforeStart();

            using var deadline = CancellationTokenSource.CreateLinkedTokenSource(stopping.Token);
            var timeout = Task.Delay(CommandTimeout, deadline.Token);
            await Task.WhenAny(command.Reply.Task, disconnected, timeout).ConfigureAwait(false);
            deadline.Cancel();
            if (disconnected.IsCompleted || stopping.IsCancellationRequested)
                return null;
            if (command.Reply.Task.IsCompleted)
                return await command.Reply.Task.ConfigureAwait(false);
            if (command.CancelBeforeStart() || !isMutation(method))
                return Error("request_timeout", "Unity did not complete the request before the deadline.");
            return Error("outcome_unknown", "Unity started the operation before the deadline. Read the target state before retrying.");
        }

        private static async Task WaitForPeerCloseAsync(NetworkStream stream, Command command)
        {
            try
            {
                // There is exactly one request per connection. EOF and unexpected extra input both cancel pending work.
                await stream.ReadAsync(new byte[1], 0, 1).ConfigureAwait(false);
            }
            catch (Exception failure) when (failure is IOException || failure is SocketException || failure is ObjectDisposedException)
            {
            }
            finally
            {
                command.CancelBeforeStart();
            }
        }

        private byte[] SignedResponse(JObject value, string clientNonce, string serverNonce)
        {
            var response = Convert.ToBase64String(Utf8.GetBytes(value.ToString(Formatting.None)));
            var envelope = new JObject
            {
                ["response"] = response,
                ["proof"] = Sign("response", clientNonce, serverNonce, response)
            };
            return Utf8.GetBytes(envelope.ToString(Formatting.None));
        }

        private string Sign(string kind, string clientNonce, string serverNonce, string payload)
        {
            using var hmac = new HMACSHA256(key);
            return Convert.ToBase64String(hmac.ComputeHash(Utf8.GetBytes(
                $"unity-mcp-v1\n{kind}\n{generation}\n{clientNonce}\n{serverNonce}\n{payload}")));
        }

        private static bool Verify(string actual, string expected)
        {
            var left = Convert.FromBase64String(actual);
            var right = Convert.FromBase64String(expected);
            var difference = 0;
            for (var index = 0; index < right.Length; index++)
                difference |= left[index] ^ right[index];
            return difference == 0;
        }

        internal static byte[] RandomBytes(int count)
        {
            using var random = RandomNumberGenerator.Create();
            var bytes = new byte[count];
            random.GetBytes(bytes);
            return bytes;
        }

        private static string RequiredString(JObject obj, string key)
        {
            if (obj[key]?.Type != JTokenType.String)
                throw new FormatException("Expected a string field.");
            return obj[key].Value<string>();
        }

        private static string ReadBase64String(JObject obj, string key, int length)
        {
            var value = RequiredString(obj, key);
            if (value.Length != (length + 2) / 3 * 4 || Convert.FromBase64String(value).Length != length)
                throw new FormatException("Invalid authentication data.");
            return value;
        }

        internal static JObject ParseObject(byte[] bytes)
        {
            using var text = new StringReader(Utf8.GetString(bytes));
            using var json = new JsonTextReader(text) { DateParseHandling = DateParseHandling.None, MaxDepth = 64 };
            var result = JObject.Load(json, new JsonLoadSettings { DuplicatePropertyNameHandling = DuplicatePropertyNameHandling.Error });
            if (json.Read())
                throw new JsonReaderException("Unexpected data after a JSON object.");
            return result;
        }

        private static async Task<JObject> ReadFrameAsync(Stream stream)
        {
            var prefix = new byte[4];
            await ReadExactlyAsync(stream, prefix).ConfigureAwait(false);
            var length = prefix[0] << 24 | prefix[1] << 16 | prefix[2] << 8 | prefix[3];
            if (length <= 0 || length > MaximumFrameSize)
                throw new IOException("Invalid frame length.");
            var payload = new byte[length];
            await ReadExactlyAsync(stream, payload).ConfigureAwait(false);
            return ParseObject(payload);
        }

        private static async Task ReadExactlyAsync(Stream stream, byte[] buffer)
        {
            var position = 0;
            while (position < buffer.Length)
            {
                var count = await stream.ReadAsync(buffer, position, buffer.Length - position).ConfigureAwait(false);
                if (count == 0)
                    throw new EndOfStreamException();
                position += count;
            }
        }

        private static Task WriteFrameAsync(Stream stream, JObject value) =>
            WriteFrameAsync(stream, Utf8.GetBytes(value.ToString(Formatting.None)));

        private static async Task WriteFrameAsync(Stream stream, byte[] payload)
        {
            var size = payload.Length;
            var prefix = new[] { (byte)(size >> 24), (byte)(size >> 16), (byte)(size >> 8), (byte)size };
            await stream.WriteAsync(prefix, 0, prefix.Length).ConfigureAwait(false);
            await stream.WriteAsync(payload, 0, payload.Length).ConfigureAwait(false);
        }

        private static JObject Success(JToken value) => new JObject { ["result"] = value ?? JValue.CreateNull() };

        private static JObject Error(string code, string message) => new JObject
        {
            ["error"] = new JObject { ["code"] = code, ["message"] = message }
        };

        private sealed class Command
        {
            // A cancellation can remove queued work, but never interrupts a running editor mutation.
            private int state;
            internal readonly string Method;
            internal readonly JObject Arguments;
            internal readonly TaskCompletionSource<JObject> Reply =
                new TaskCompletionSource<JObject>(TaskCreationOptions.RunContinuationsAsynchronously);

            internal Command(string method, JObject arguments)
            {
                Method = method;
                Arguments = arguments;
            }

            internal bool TryStart() => Interlocked.CompareExchange(ref state, 1, 0) == 0;

            internal bool CancelBeforeStart()
            {
                if (Interlocked.CompareExchange(ref state, 2, 0) != 0)
                    return false;
                Reply.TrySetResult(null);
                return true;
            }

            internal void Complete(JObject response) => Reply.TrySetResult(response);
        }
    }
}
