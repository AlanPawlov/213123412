using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace UnityMcp.Editor
{
    [InitializeOnLoad]
    internal static class Bridge
    {
        private const string Menu = "Tools/Unity MCP/";
        private const string AllowEditorWrites = Menu + "Allow editor changes";
        private const string AllowScriptWrites = Menu + "Allow C# file writes";
        private const string InstanceKey = "UnityMcp.Bridge.Instance";
        private const int MaximumLocalFile = 16 * 1024;

        private static BridgeTransport server;
        private static JObject status = new JObject();
        private static string descriptorPath;
        private static string permissionPath;
        private static string instance;
        private static string projectId;
        private static string startedAt;
        private static int pid;
        private static IntPtr mainWindow;
        private static double nextStart;
        private static double nextStatus;
        private static bool playTransition;
        private static bool shuttingDown;
        private static Permission permissions = new Permission();

        internal static string ProjectRoot { get; private set; }
        internal static string Generation { get; private set; }

        static Bridge()
        {
            if (Application.platform != RuntimePlatform.WindowsEditor || Application.isBatchMode)
                return;

            ProjectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            Jobs.Initialize();
            EditorApplication.delayCall += Start;
            EditorApplication.update += Update;
            EditorApplication.playModeStateChanged += OnPlayModeChanged;
            EditorApplication.quitting += Shutdown;
            AssemblyReloadEvents.beforeAssemblyReload += Shutdown;
        }

        [MenuItem(Menu + "Restart bridge")]
        private static void Restart()
        {
            Stop();
            Start();
        }

        [MenuItem(AllowEditorWrites)]
        private static void ToggleEditorWrites() => SavePermissions(!permissions.Editor, permissions.Script);

        [MenuItem(AllowScriptWrites)]
        private static void ToggleScriptWrites() => SavePermissions(permissions.Editor, !permissions.Script);

        [MenuItem(AllowEditorWrites, true)]
        private static bool ValidateEditorWrites()
        {
            UnityEditor.Menu.SetChecked(AllowEditorWrites, permissions.Editor);
            return permissionPath != null;
        }

        [MenuItem(AllowScriptWrites, true)]
        private static bool ValidateScriptWrites()
        {
            UnityEditor.Menu.SetChecked(AllowScriptWrites, permissions.Script);
            return permissionPath != null;
        }

        private static void Start()
        {
            if (server != null || ProjectRoot == null || shuttingDown)
                return;

            try
            {
                projectId = BridgeWindows.DirectoryId(ProjectRoot);
                startedAt = BridgeWindows.CurrentProcessStart();
                using (var process = Process.GetCurrentProcess())
                    pid = process.Id;

                instance = SessionState.GetString(InstanceKey, "");
                if (!Guid.TryParseExact(instance, "N", out _))
                {
                    instance = Guid.NewGuid().ToString("N");
                    SessionState.SetString(InstanceKey, instance);
                }
                Generation = Guid.NewGuid().ToString("N");

                LoadPermissions();
                var directory = Path.Combine(BridgeWindows.DesktopDirectory, "UnityMCP");
                BridgeWindows.CreatePrivateDirectory(directory);
                descriptorPath = Path.Combine(directory, instance + ".json");

                var key = BridgeTransport.RandomBytes(32);
                server = new BridgeTransport(Generation, key, EditorTools.IsMutation,
                    () => (JObject)Volatile.Read(ref status).DeepClone());
                var descriptor = Identity();
                var protectedFields = (JObject)descriptor.DeepClone();
                protectedFields["key"] = Convert.ToBase64String(key);
                var plaintext = Encode(protectedFields);
                try
                {
                    descriptor["secret"] = Convert.ToBase64String(BridgeWindows.ProtectForCurrentUser(plaintext));
                }
                finally
                {
                    Array.Clear(plaintext, 0, plaintext.Length);
                }

                RefreshStatus();
                BridgeWindows.PublishPrivateFile(descriptorPath, Encode(descriptor));
                server.StartAccepting();
            }
            catch (Exception failure)
            {
                Stop();
                nextStart = EditorApplication.timeSinceStartup + 5;
                Debug.LogWarning($"Unity MCP could not start: {failure.Message}. Use Tools > Unity MCP > Restart bridge after resolving the issue.");
            }
        }

        private static void Shutdown()
        {
            shuttingDown = true;
            Stop();
        }

        private static void Stop()
        {
            var closing = server;
            server = null;
            closing?.Dispose();

            var path = descriptorPath;
            descriptorPath = null;
            if (path == null)
                return;

            try
            {
                var descriptor = ReadLocalObject(path);
                if (descriptor?.Value<string>("generation") == Generation)
                    File.Delete(path);
            }
            catch (Exception failure) when (failure is IOException || failure is UnauthorizedAccessException ||
                failure is JsonException || failure is ArgumentException)
            {
                // A leftover descriptor is harmless because peers must authenticate to a live listener.
            }
        }

        private static void Update()
        {
            if (shuttingDown)
                return;
            if (server == null)
            {
                // Domain reload can discard a delayCall queued while AssetDatabase is already importing.
                if (EditorApplication.timeSinceStartup >= nextStart && !EditorApplication.isUpdating && !EditorApplication.isCompiling)
                    Start();
                return;
            }

            if (EditorApplication.timeSinceStartup >= nextStatus)
            {
                nextStatus = EditorApplication.timeSinceStartup + 0.25;
                RefreshStatus();
            }
            server.Pump(Execute);
        }

        private static void OnPlayModeChanged(PlayModeStateChange change)
        {
            playTransition = change == PlayModeStateChange.ExitingEditMode || change == PlayModeStateChange.ExitingPlayMode;
            nextStatus = 0;
        }

        private static bool InPlayTransition => playTransition || Jobs.IsPlayTransition ||
            EditorApplication.isPlayingOrWillChangePlaymode != EditorApplication.isPlaying;

        private static JToken Execute(string method, JObject arguments)
        {
            var mutation = EditorTools.IsMutation(method);
            if (mutation && !permissions.Editor && !(method == "compile_start" && CanImportScript(arguments)))
                throw new EditorToolException("permission_denied", "Enable editor changes in Tools > Unity MCP to use this tool.");

            if (method != "job_get" && method != "console_get" &&
                (EditorApplication.isCompiling || EditorApplication.isUpdating || InPlayTransition))
                throw new EditorToolException("editor_busy", "Wait for Unity to finish compiling, importing, or changing Play Mode.");

            if (mutation && EditorApplication.isPlaying && method != "play_stop")
                throw new EditorToolException("editor_busy", "Stop Play Mode before changing the project or launching tests.");

            var result = EditorTools.Execute(method, arguments);
            if (mutation)
                nextStatus = 0;
            return result;
        }

        private static bool CanImportScript(JObject arguments)
        {
            if (!permissions.Script || arguments["path"]?.Type != JTokenType.String)
                return false;
            var path = arguments.Value<string>("path");
            foreach (var folder in permissions.Folders)
            {
                if (folder.Type == JTokenType.String &&
                    path.StartsWith(folder.Value<string>().TrimEnd('/') + "/", StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        private static void RefreshStatus()
        {
            try
            {
                var snapshot = (JObject)EditorTools.Execute("unity_status", new JObject());
                if (!Application.isBatchMode)
                    mainWindow = BridgeWindows.FindMainWindow(pid, EditorGUIUtility.GetMainWindowPosition(), mainWindow);
                foreach (var property in Identity().Properties())
                    snapshot[property.Name] = property.Value.DeepClone();
                snapshot["hwnd"] = WindowHandle;
                snapshot["allow_editor_writes"] = permissions.Editor;
                snapshot["allow_script_writes"] = permissions.Script;
                snapshot["script_folders"] = permissions.Folders.DeepClone();
                snapshot["observed_at"] = DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture);
                snapshot["is_compiling"] = EditorApplication.isCompiling;
                snapshot["is_updating"] = EditorApplication.isUpdating;
                snapshot["is_playing"] = EditorApplication.isPlaying;
                snapshot["is_play_transition"] = InPlayTransition;
                snapshot["ready"] = !EditorApplication.isCompiling && !EditorApplication.isUpdating && !InPlayTransition;
                Volatile.Write(ref status, snapshot);
            }
            catch (Exception failure)
            {
                var snapshot = Identity();
                snapshot["hwnd"] = WindowHandle;
                snapshot["ready"] = false;
                snapshot["status_error"] = failure.GetType().Name;
                Volatile.Write(ref status, snapshot);
            }
        }

        private static string WindowHandle => unchecked((ulong)mainWindow.ToInt64()).ToString(CultureInfo.InvariantCulture);

        private static JObject Identity() => new JObject
        {
            ["instance_id"] = instance,
            ["project_id"] = projectId,
            ["generation"] = Generation,
            ["protocol"] = BridgeTransport.Protocol,
            ["port"] = server?.Port ?? 0,
            ["pid"] = pid,
            ["started_at"] = startedAt
        };

        private static void LoadPermissions()
        {
            permissions = new Permission();
            permissionPath = null;
            try
            {
                permissionPath = Path.Combine(BridgeWindows.LocalAppDataDirectory, "UnityMCP", "permissions", projectId + ".json");
                var stored = ReadLocalObject(permissionPath);
                if (stored != null)
                {
                    permissions = new Permission
                    {
                        Editor = stored["allow_editor_writes"]?.Type == JTokenType.Boolean && stored.Value<bool>("allow_editor_writes"),
                        Script = stored["allow_script_writes"]?.Type == JTokenType.Boolean && stored.Value<bool>("allow_script_writes"),
                        Folders = stored["script_folders"] as JArray ?? new JArray("Assets")
                    };
                }
            }
            catch (Exception failure) when (failure is IOException || failure is UnauthorizedAccessException ||
                failure is JsonException || failure is System.Runtime.InteropServices.ExternalException || failure is ArgumentException)
            {
                Debug.LogWarning($"Unity MCP could not read the local permissions file. The bridge will use read-only mode. {failure.Message}");
            }
        }

        private static void SavePermissions(bool editor, bool script)
        {
            if (permissionPath == null)
                return;
            try
            {
                var directory = Path.GetDirectoryName(permissionPath);
                BridgeWindows.CreatePrivateDirectory(Path.GetDirectoryName(directory));
                BridgeWindows.CreatePrivateDirectory(directory);
                var value = new JObject
                {
                    ["allow_editor_writes"] = editor,
                    ["allow_script_writes"] = script,
                    ["script_folders"] = permissions.Folders.DeepClone()
                };
                BridgeWindows.PublishPrivateFile(permissionPath, Encode(value));
                permissions = new Permission { Editor = editor, Script = script, Folders = permissions.Folders };
                nextStatus = 0;
            }
            catch (Exception failure)
            {
                Debug.LogWarning($"Unity MCP could not save local permissions: {failure.Message}");
            }
        }

        private static JObject ReadLocalObject(string path)
        {
            try
            {
                using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
                var bytes = new byte[MaximumLocalFile + 1];
                var length = 0;
                while (length < bytes.Length)
                {
                    var count = stream.Read(bytes, length, bytes.Length - length);
                    if (count == 0)
                        break;
                    length += count;
                }
                if (length == bytes.Length)
                    throw new IOException("The Unity MCP file exceeds the local descriptor limit.");
                Array.Resize(ref bytes, length);
                return BridgeTransport.ParseObject(bytes);
            }
            catch (FileNotFoundException) { return null; }
            catch (DirectoryNotFoundException) { return null; }
        }

        private static byte[] Encode(JObject value) => BridgeTransport.Utf8.GetBytes(value.ToString(Formatting.None));

        private sealed class Permission
        {
            internal bool Editor;
            internal bool Script;
            internal JArray Folders = new JArray("Assets");
        }
    }
}
