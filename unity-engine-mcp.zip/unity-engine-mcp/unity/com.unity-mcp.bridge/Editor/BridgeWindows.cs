using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;
using UnityEngine;

namespace UnityMcp.Editor
{
    internal static class BridgeWindows
    {
        private static readonly Guid DesktopId = new Guid("B4BFCC3A-DB2C-424C-B029-7FE99A87C641");
        private static readonly Guid LocalAppDataId = new Guid("F1B32785-6FBA-4FCF-9D55-7B8E7F157091");

        internal static string DesktopDirectory => KnownFolder(DesktopId);
        internal static string LocalAppDataDirectory => KnownFolder(LocalAppDataId);

        internal static string DirectoryId(string path)
        {
            const uint shareReadWriteDelete = 7;
            const uint openExisting = 3;
            const uint backupSemantics = 0x02000000;
            using var handle = CreateFileWithoutSecurity(path, 0, shareReadWriteDelete, IntPtr.Zero, openExisting,
                backupSemantics, IntPtr.Zero);
            if (handle.IsInvalid || !GetFileInformationByHandle(handle, out var info))
                throw LastError("Cannot identify the Unity project directory");

            var fileId = ((ulong)info.FileIndexHigh << 32) | info.FileIndexLow;
            return FormattableString.Invariant($"{info.VolumeSerialNumber:x8}-{fileId:x16}");
        }

        internal static string CurrentProcessStart()
        {
            if (!GetProcessTimes(GetCurrentProcess(), out var start, out _, out _, out _))
                throw LastError("Cannot identify the Unity Editor process");
            return start.ToString(CultureInfo.InvariantCulture);
        }

        internal static byte[] ProtectForCurrentUser(byte[] input)
        {
            const uint uiForbidden = 1;
            var pinned = GCHandle.Alloc(input, GCHandleType.Pinned);
            try
            {
                var data = new DataBlob { Size = input.Length, Data = pinned.AddrOfPinnedObject() };
                if (!CryptProtectData(ref data, null, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, uiForbidden, out var result))
                    throw LastError("Windows could not protect the bridge descriptor");
                try
                {
                    var bytes = new byte[result.Size];
                    Marshal.Copy(result.Data, bytes, 0, bytes.Length);
                    return bytes;
                }
                finally
                {
                    LocalFree(result.Data);
                }
            }
            finally
            {
                pinned.Free();
            }
        }

        internal static void CreatePrivateDirectory(string path)
        {
            if (Directory.Exists(path))
                return;

            var security = GetSecurityAttributes("OICI");
            try
            {
                if (!CreateDirectory(path, ref security) && Marshal.GetLastWin32Error() != 183)
                    throw LastError("Cannot create the Unity MCP directory");
            }
            finally
            {
                LocalFree(security.Descriptor);
            }
        }

        internal static void PublishPrivateFile(string path, byte[] bytes)
        {
            const uint genericWrite = 0x40000000;
            const uint createNew = 1;
            const uint normal = 0x80;
            const uint replaceAndWriteThrough = 0x1 | 0x8;
            var temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            var security = GetSecurityAttributes("");
            try
            {
                using (var handle = CreateFileWithSecurity(temporary, genericWrite, 0, ref security,
                           createNew, normal, IntPtr.Zero))
                {
                    if (handle.IsInvalid)
                        throw LastError("Cannot create the Unity MCP temporary file");
                    using var stream = new FileStream(handle, FileAccess.Write);
                    stream.Write(bytes, 0, bytes.Length);
                    stream.Flush(true);
                }

                for (var attempt = 0; ; attempt++)
                {
                    if (MoveFileEx(temporary, path, replaceAndWriteThrough))
                        return;
                    var error = Marshal.GetLastWin32Error();
                    if (attempt == 3 || error != 32 && error != 33)
                        throw new Win32Exception(error, "Cannot publish the Unity MCP file");
                    System.Threading.Thread.Sleep(10 * (attempt + 1));
                }
            }
            finally
            {
                LocalFree(security.Descriptor);
                try { File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        internal static IntPtr FindMainWindow(int pid, Rect position, IntPtr previous)
        {
            if (previous != IntPtr.Zero && IsUnityContainer(previous, pid))
                return previous;

            var matches = new List<(IntPtr Window, double Score)>();
            EnumWindows((window, _) =>
            {
                if (!IsUnityContainer(window, pid) || !GetWindowRect(window, out var bounds))
                    return true;

                var dpi = GetDpiForWindow(window) / 96.0;
                if (dpi <= 0)
                    dpi = 1;
                var score = Math.Min(WindowDistance(bounds, position, 1, 1),
                    Math.Min(WindowDistance(bounds, position, 1, dpi), WindowDistance(bounds, position, dpi, dpi)));
                matches.Add((window, score));
                return true;
            }, IntPtr.Zero);

            matches.Sort((left, right) => left.Score.CompareTo(right.Score));
            if (matches.Count == 1 || matches.Count > 1 && matches[0].Score <= 80 && matches[1].Score - matches[0].Score >= 4)
                return matches[0].Window;

            // Editor coordinates can be in logical points on a scaled desktop. Use the process's
            // main window when Win32 confirms the actual editor container class.
            using var process = Process.GetCurrentProcess();
            var candidate = process.MainWindowHandle;
            return IsUnityContainer(candidate, pid) ? candidate : IntPtr.Zero;
        }

        private static double WindowDistance(WindowRect bounds, Rect position, double originScale, double sizeScale)
        {
            return Math.Abs(bounds.Left - position.x * originScale) +
                   Math.Abs(bounds.Top - position.y * originScale) +
                   Math.Abs(bounds.Right - bounds.Left - position.width * sizeScale) +
                   Math.Abs(bounds.Bottom - bounds.Top - position.height * sizeScale);
        }

        private static bool OwnsWindow(IntPtr window, int pid)
        {
            return GetWindowThreadProcessId(window, out var owner) != 0 && owner == (uint)pid;
        }

        private static bool IsUnityContainer(IntPtr window, int pid)
        {
            const uint owner = 4;
            if (window == IntPtr.Zero || !OwnsWindow(window, pid) || !IsWindowVisible(window) ||
                GetWindow(window, owner) != IntPtr.Zero)
                return false;
            var name = new StringBuilder(64);
            return GetClassName(window, name, name.Capacity) > 0 && name.ToString() == "UnityContainerWndClass";
        }

        private static string KnownFolder(Guid folder)
        {
            var result = SHGetKnownFolderPath(ref folder, 0, IntPtr.Zero, out var pointer);
            try
            {
                Marshal.ThrowExceptionForHR(result);
                return Marshal.PtrToStringUni(pointer) ?? throw new IOException("Windows did not return a folder path.");
            }
            finally
            {
                Marshal.FreeCoTaskMem(pointer);
            }
        }

        private static SecurityAttributes GetSecurityAttributes(string inheritance)
        {
            var sid = CurrentUserSid();
            var sddl = $"D:P(A;{inheritance};FA;;;SY)(A;{inheritance};FA;;;{sid})";
            if (!ConvertStringSecurityDescriptorToSecurityDescriptor(sddl, 1, out var descriptor, out _))
                throw LastError("Cannot create a private security descriptor");
            return new SecurityAttributes
            {
                Size = Marshal.SizeOf<SecurityAttributes>(),
                Descriptor = descriptor
            };
        }

        private static string CurrentUserSid()
        {
            const uint queryToken = 8;
            const int tokenUser = 1;
            const int insufficientBuffer = 122;
            if (!OpenProcessToken(GetCurrentProcess(), queryToken, out var token))
                throw LastError("Cannot open the current Windows access token");
            using (token)
            {
                GetTokenInformation(token, tokenUser, IntPtr.Zero, 0, out var size);
                if (Marshal.GetLastWin32Error() != insufficientBuffer || size <= 0)
                    throw LastError("Cannot query the current Windows user");

                var information = Marshal.AllocHGlobal(size);
                try
                {
                    if (!GetTokenInformation(token, tokenUser, information, size, out _) ||
                        !ConvertSidToStringSid(Marshal.ReadIntPtr(information), out var result))
                        throw LastError("Cannot identify the current Windows user");
                    try { return Marshal.PtrToStringUni(result) ?? throw new IOException("Windows returned an empty SID."); }
                    finally { LocalFree(result); }
                }
                finally
                {
                    Marshal.FreeHGlobal(information);
                }
            }
        }

        private static Win32Exception LastError(string message) => new Win32Exception(Marshal.GetLastWin32Error(), message);

        [StructLayout(LayoutKind.Sequential)]
        private struct FileInformation
        {
            internal uint Attributes;
            internal System.Runtime.InteropServices.ComTypes.FILETIME Created;
            internal System.Runtime.InteropServices.ComTypes.FILETIME Accessed;
            internal System.Runtime.InteropServices.ComTypes.FILETIME Modified;
            internal uint VolumeSerialNumber;
            internal uint FileSizeHigh;
            internal uint FileSizeLow;
            internal uint Links;
            internal uint FileIndexHigh;
            internal uint FileIndexLow;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DataBlob
        {
            internal int Size;
            internal IntPtr Data;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SecurityAttributes
        {
            internal int Size;
            internal IntPtr Descriptor;
            internal int InheritHandle;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct WindowRect
        {
            internal int Left;
            internal int Top;
            internal int Right;
            internal int Bottom;
        }

        private delegate bool WindowVisitor(IntPtr window, IntPtr parameter);

        [DllImport("shell32.dll")]
        private static extern int SHGetKnownFolderPath(ref Guid folder, uint flags, IntPtr token, out IntPtr result);

        [DllImport("kernel32.dll", EntryPoint = "CreateFileW", CharSet = CharSet.Unicode, SetLastError = true, ExactSpelling = true)]
        private static extern SafeFileHandle CreateFileWithoutSecurity(string path, uint access, uint share,
            IntPtr security, uint disposition, uint flags, IntPtr template);

        [DllImport("kernel32.dll", EntryPoint = "CreateFileW", CharSet = CharSet.Unicode, SetLastError = true, ExactSpelling = true)]
        private static extern SafeFileHandle CreateFileWithSecurity(string path, uint access, uint share,
            ref SecurityAttributes security, uint disposition, uint flags, IntPtr template);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetFileInformationByHandle(SafeFileHandle handle, out FileInformation information);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetCurrentProcess();

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetProcessTimes(IntPtr handle, out long created, out long exited, out long kernel, out long user);

        [DllImport("crypt32.dll", CharSet = CharSet.Unicode, SetLastError = true, ExactSpelling = true)]
        private static extern bool CryptProtectData(ref DataBlob input, string description, IntPtr entropy,
            IntPtr reserved, IntPtr prompt, uint flags, out DataBlob output);

        [DllImport("kernel32.dll")]
        private static extern IntPtr LocalFree(IntPtr memory);

        [DllImport("advapi32.dll", EntryPoint = "ConvertStringSecurityDescriptorToSecurityDescriptorW",
            CharSet = CharSet.Unicode, SetLastError = true, ExactSpelling = true)]
        private static extern bool ConvertStringSecurityDescriptorToSecurityDescriptor(string text, uint revision,
            out IntPtr descriptor, out uint length);

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool OpenProcessToken(IntPtr process, uint access, out SafeFileHandle token);

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool GetTokenInformation(SafeFileHandle token, int kind, IntPtr information, int size, out int length);

        [DllImport("advapi32.dll", EntryPoint = "ConvertSidToStringSidW", SetLastError = true, ExactSpelling = true)]
        private static extern bool ConvertSidToStringSid(IntPtr sid, out IntPtr text);

        [DllImport("kernel32.dll", EntryPoint = "CreateDirectoryW", CharSet = CharSet.Unicode, SetLastError = true, ExactSpelling = true)]
        private static extern bool CreateDirectory(string path, ref SecurityAttributes security);

        [DllImport("kernel32.dll", EntryPoint = "MoveFileExW", CharSet = CharSet.Unicode, SetLastError = true, ExactSpelling = true)]
        private static extern bool MoveFileEx(string current, string target, uint flags);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(WindowVisitor visitor, IntPtr parameter);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr window);

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindow(IntPtr window, uint command);

        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr window, out WindowRect rect);

        [DllImport("user32.dll")]
        private static extern uint GetDpiForWindow(IntPtr window);

        [DllImport("user32.dll", EntryPoint = "GetClassNameW", CharSet = CharSet.Unicode, ExactSpelling = true)]
        private static extern int GetClassName(IntPtr window, StringBuilder name, int capacity);
    }
}
