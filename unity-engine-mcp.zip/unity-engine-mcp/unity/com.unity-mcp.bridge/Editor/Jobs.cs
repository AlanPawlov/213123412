using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEditor.TestTools.TestRunner.Api;
using UnityEngine;

namespace UnityMcp.Editor
{
    internal static class Jobs
    {
        private const string SessionKey = "UnityMcp.Editor.JobSession";
        private static readonly JObject jobs = new JObject();
        private static TestRunnerApi testRunner;
        private static JObject active;
        private static string session;
        private static string statePath;
        private static int readyTicks;
        private static int testRuns;
        private static bool initialized;

        internal static bool IsBusy => active != null || testRuns != 0;
        internal static bool IsTesting => Kind == "tests" || testRuns != 0;
        internal static bool IsPlayTransition => Kind == "play_start" || Kind == "play_stop";
        private static string Kind => (string)active?["kind"];

        internal static void Initialize()
        {
            if (initialized)
                return;
            initialized = true;
            session = SessionState.GetString(SessionKey, string.Empty);
            if (session.Length == 0)
            {
                session = Guid.NewGuid().ToString("N");
                SessionState.SetString(SessionKey, session);
            }
            statePath = Path.Combine(Path.GetFullPath(Path.Combine(Application.dataPath, "..")), "Library", "UnityMCP", "editor-jobs.json");
            Restore();
            testRunner = ScriptableObject.CreateInstance<TestRunnerApi>();
            testRunner.hideFlags = HideFlags.HideAndDontSave;
            testRunner.RegisterCallbacks(new TestCallbacks());
            CompilationPipeline.compilationStarted += OnCompileStarted;
            CompilationPipeline.assemblyCompilationFinished += OnAssemblyFinished;
            CompilationPipeline.compilationFinished += OnCompileFinished;
            EditorApplication.playModeStateChanged += OnPlayModeChanged;
            EditorApplication.update += Tick;
            EditorApplication.quitting += OnQuit;
        }

        internal static JObject StartCompile(JObject args)
        {
            string path = EditorTools.String(args, "path", false);
            string expectedHash = EditorTools.String(args, "expected_sha256", false);
            string sourceHash = null;
            if (path != null)
            {
                EditorTools.ValidateAssetPath(path, ".cs", false);
                if (!File.Exists(Path.Combine(EditorTools.ProjectRoot, path)))
                    throw EditorTools.Invalid("The script does not exist.");
                sourceHash = ScriptHash(path);
                if (expectedHash != null && !string.Equals(expectedHash, sourceHash, StringComparison.OrdinalIgnoreCase))
                    throw new EditorToolException("source_changed", "The script changed before Unity could start compilation.");
            }
            else if (expectedHash != null)
                throw EditorTools.Invalid("expected_sha256 requires a script path.");
            return Start(args, "compile", job =>
            {
                job["path"] = path;
                job["source_sha256"] = sourceHash;
                job["diagnostics"] = new JArray();
                if (path != null)
                    AssetDatabase.ImportAsset(path, ImportAssetOptions.Default);
                CompilationPipeline.RequestScriptCompilation();
            });
        }

        internal static JObject StartPlay(JObject args, bool enter)
        {
            if (IsBusy)
                throw new EditorToolException("editor_busy", "A Unity job or test run is active.");
            if (EditorApplication.isPlayingOrWillChangePlaymode != EditorApplication.isPlaying)
                throw new EditorToolException("editor_busy", "Unity is already changing Play Mode.");
            return Start(args, enter ? "play_start" : "play_stop", job =>
            {
                if (EditorApplication.isPlaying == enter)
                    Complete("succeeded");
                else if (enter)
                    EditorApplication.EnterPlaymode();
                else
                    EditorApplication.ExitPlaymode();
            });
        }

        internal static JObject StartTests(JObject args)
        {
            string mode = EditorTools.String(args, "mode");
            var filter = new Filter();
            if (mode.Equals("editmode", StringComparison.OrdinalIgnoreCase))
                filter.testMode = TestMode.EditMode;
            else if (mode.Equals("playmode", StringComparison.OrdinalIgnoreCase))
                filter.testMode = TestMode.PlayMode;
            else
                throw EditorTools.Invalid("mode must be EditMode or PlayMode.");
            string pattern = EditorTools.String(args, "filter", false);
            if (pattern != null)
                filter.testNames = new[] { pattern };
            return Start(args, "tests", job =>
            {
                job["mode"] = filter.testMode.ToString();
                job["run_guid"] = testRunner.Execute(new ExecutionSettings(filter));
            });
        }

        private static JObject Start(JObject args, string kind, Action<JObject> invoke)
        {
            string id = EditorTools.String(args, "job_id", false) ?? Guid.NewGuid().ToString("N");
            if (!Guid.TryParseExact(id, "N", out _) && !Guid.TryParseExact(id, "D", out _))
                throw EditorTools.Invalid("job_id must be a UUID.");
            if (jobs[id] != null)
                throw new EditorToolException("job_exists", "A job with this ID is already recorded. Use job_get.");
            if (IsBusy)
                throw new EditorToolException("editor_busy", "A Unity job or test run is active.");
            var job = new JObject
            {
                ["job_id"] = id, ["kind"] = kind, ["status"] = "queued",
                ["started_at"] = DateTime.UtcNow.ToString("O"), ["session"] = session
            };
            jobs[id] = job;
            active = job;
            readyTicks = 0;
            try
            {
                Persist();
            }
            catch (Exception ex)
            {
                jobs.Remove(id);
                active = null;
                throw new EditorToolException("job_storage_failed", "Could not persist the Unity job: " + EditorTools.Truncate(ex.Message, 350));
            }
            try
            {
                invoke(job);
                Save();
            }
            catch (Exception ex)
            {
                Complete("failed", EditorTools.Truncate(ex.Message, 1000));
            }
            return Public(job);
        }

        internal static JObject Get(string id)
        {
            if (!(jobs[id] is JObject job))
                throw new EditorToolException("job_not_found", "This Unity job is unknown or its result has expired.");
            return Public(job);
        }

        private static JObject Public(JObject job)
        {
            var result = (JObject)job.DeepClone();
            result.Remove("session");
            return result;
        }

        private static void OnCompileStarted(object context)
        {
            if (Kind != "compile")
                return;
            active["status"] = "running";
            Save();
        }

        private static void OnAssemblyFinished(string assembly, CompilerMessage[] messages)
        {
            if (Kind != "compile")
                return;
            var diagnostics = (JArray)active["diagnostics"];
            int errors = (int?)active["error_count"] ?? 0;
            foreach (var message in messages)
            {
                if (message.type == CompilerMessageType.Error)
                    errors++;
                if (diagnostics.Count >= 48)
                    continue;
                diagnostics.Add(new JObject
                {
                    ["assembly"] = EditorTools.Truncate(assembly, 250), ["file"] = EditorTools.Truncate(message.file, 500),
                    ["line"] = message.line, ["column"] = message.column, ["type"] = message.type.ToString(),
                    ["message"] = EditorTools.Truncate(message.message, 650)
                });
            }
            active["error_count"] = errors;
        }

        private static void OnCompileFinished(object context)
        {
            if (Kind != "compile")
                return;
            if (!CompilationSourceMatches())
                Complete("superseded", "The requested script changed while Unity compiled the project.");
            else if ((int?)active["error_count"] > 0)
                Complete("failed", "Unity reported script compilation errors.");
            else
            {
                active["status"] = "waiting_for_editor";
                readyTicks = 0;
                Save();
            }
        }

        private static void OnPlayModeChanged(PlayModeStateChange state)
        {
            if (Kind == "play_start" && state == PlayModeStateChange.EnteredPlayMode ||
                Kind == "play_stop" && state == PlayModeStateChange.EnteredEditMode)
                Complete("succeeded");
        }

        private static void Tick()
        {
            if (active == null)
                return;
            if (Kind == "compile" && (string)active["status"] == "waiting_for_editor")
            {
                readyTicks = EditorApplication.isCompiling || EditorApplication.isUpdating ? 0 : readyTicks + 1;
                if (readyTicks >= 3)
                {
                    if (CompilationSourceMatches())
                        Complete("succeeded");
                    else
                        Complete("superseded", "The requested script changed before Unity became ready.");
                    return;
                }
            }
            if (IsPlayTransition && EditorApplication.isPlaying == (Kind == "play_start") &&
                EditorApplication.isPlayingOrWillChangePlaymode == EditorApplication.isPlaying)
            {
                Complete("succeeded");
                return;
            }
            if (DateTime.TryParse((string)active["started_at"], out DateTime started) &&
                DateTime.UtcNow - started.ToUniversalTime() > (Kind == "tests" ? TimeSpan.FromHours(2) : TimeSpan.FromMinutes(3)))
                Complete("interrupted", "Unity did not confirm completion within the observation period.");
        }

        private static void OnQuit()
        {
            if (active != null)
                Complete("interrupted", "The Unity Editor quit during the job.");
        }

        private static bool CompilationSourceMatches()
        {
            string path = (string)active?["path"];
            if (path == null)
                return true;
            try
            {
                EditorTools.ValidateAssetPath(path, ".cs", false);
                return ScriptHash(path) == (string)active["source_sha256"];
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is EditorToolException)
            {
                return false;
            }
        }

        private static string ScriptHash(string path)
        {
            using (var source = new FileStream(Path.Combine(EditorTools.ProjectRoot, path), FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Delete))
            using (var sha = SHA256.Create())
            {
                if (source.Length > 2 * 1024 * 1024)
                    throw EditorTools.Invalid("The script exceeds the 2 MiB compilation tracking limit.");
                return BitConverter.ToString(sha.ComputeHash(source)).Replace("-", "").ToLowerInvariant();
            }
        }

        private static void Complete(string status, string message = null)
        {
            if (active == null)
                return;
            active["status"] = status;
            active["finished_at"] = DateTime.UtcNow.ToString("O");
            if (message != null)
                active["message"] = message;
            active = null;
            Save();
        }

        private static void Restore()
        {
            try
            {
                if (!File.Exists(statePath) || new FileInfo(statePath).Length > 8 * 1024 * 1024)
                    return;
                var saved = JObject.Parse(File.ReadAllText(statePath));
                testRuns = (string)saved["session"] == session ? (int?)saved["test_runs"] ?? 0 : 0;
                if (!(saved["jobs"] is JObject previous))
                    return;
                bool changed = false;
                foreach (var entry in previous.Properties().Take(32))
                {
                    if (!(entry.Value is JObject savedJob))
                        continue;
                    var job = (JObject)savedJob.DeepClone();
                    jobs[entry.Name] = job;
                    if (job["finished_at"] != null)
                        continue;
                    if ((string)job["session"] == session && active == null)
                        active = job;
                    else
                    {
                        job["status"] = "interrupted";
                        job["finished_at"] = DateTime.UtcNow.ToString("O");
                        job["message"] = "The Unity Editor restarted before reporting the job result.";
                        changed = true;
                    }
                }
                if (changed)
                    Save();
            }
            catch (Exception ex)
            {
                Debug.LogWarning("Unity MCP could not read the Editor job journal: " + EditorTools.Truncate(ex.Message, 350));
            }
        }

        private static void Save()
        {
            try { Persist(); }
            catch (Exception ex) { Debug.LogWarning("Unity MCP could not persist an Editor job: " + EditorTools.Truncate(ex.Message, 350)); }
        }

        private static void Persist()
        {
            foreach (var old in jobs.Properties().Where(entry => entry.Value["finished_at"] != null)
                .Take(Math.Max(0, jobs.Count - 32)).ToArray())
                old.Remove();
            Directory.CreateDirectory(Path.GetDirectoryName(statePath));
            string stage = statePath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                var state = new JObject { ["session"] = session, ["test_runs"] = testRuns, ["jobs"] = jobs.DeepClone() };
                using (var stream = new FileStream(stage, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(state.ToString(Formatting.None));
                    stream.Write(bytes, 0, bytes.Length);
                    stream.Flush(true);
                }
                if (File.Exists(statePath)) File.Replace(stage, statePath, null);
                else File.Move(stage, statePath);
            }
            finally
            {
                if (File.Exists(stage)) File.Delete(stage);
            }
        }

        private sealed class TestCallbacks : IErrorCallbacks
        {
            public void RunStarted(ITestAdaptor testsToRun)
            {
                testRuns++;
                if (Kind == "tests")
                {
                    if (testRuns > 1 || (string)active["status"] == "running")
                        Complete("interrupted", "Unity reported overlapping test runs without enough information to attribute results.");
                    else
                        active["status"] = "running";
                }
                Save();
            }

            public void RunFinished(ITestResultAdaptor result)
            {
                testRuns = Math.Max(0, testRuns - 1);
                if (Kind != "tests")
                {
                    Save();
                    return;
                }
                if ((string)active["status"] != "running")
                {
                    Complete("interrupted", "Unity returned a test result without a matching start callback.");
                    return;
                }
                var failures = new JArray();
                var pending = new Stack<ITestResultAdaptor>();
                pending.Push(result);
                while (pending.Count > 0 && failures.Count < 24)
                {
                    var item = pending.Pop();
                    if (item.HasChildren)
                    {
                        foreach (var child in item.Children)
                            if (child.FailCount > 0 || child.TestStatus == TestStatus.Failed)
                                pending.Push(child);
                    }
                    else if (item.TestStatus == TestStatus.Failed)
                        failures.Add(new JObject
                        {
                            ["name"] = EditorTools.Truncate(item.FullName, 300),
                            ["message"] = EditorTools.Truncate(item.Message, 700),
                            ["stack"] = EditorTools.Truncate(item.StackTrace, 1200)
                        });
                }
                active["passed"] = result.PassCount;
                active["failed"] = result.FailCount;
                active["skipped"] = result.SkipCount;
                active["inconclusive"] = result.InconclusiveCount;
                active["duration_seconds"] = result.Duration;
                active["failures"] = failures;
                Complete(result.FailCount > 0 || result.TestStatus == TestStatus.Failed ? "failed" : "succeeded");
            }

            public void TestStarted(ITestAdaptor test) { }
            public void TestFinished(ITestResultAdaptor result) { }

            public void OnError(string message)
            {
                testRuns = Math.Max(0, testRuns - 1);
                if (Kind == "tests")
                    Complete("failed", EditorTools.Truncate(message, 1000));
                else
                    Save();
            }
        }
    }
}
