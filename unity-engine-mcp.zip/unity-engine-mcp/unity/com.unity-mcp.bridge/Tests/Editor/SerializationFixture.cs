using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace UnityMcp.Editor.Tests
{
    public sealed class SerializationFixture : ScriptableObject
    {
        [Serializable]
        public sealed class Node
        {
            public int number;
            [SerializeReference] public Node next;
        }

        public int number;
        public List<int> values = new List<int>();
        public SerializationFixture linked;
        [SerializeReference] public Node first;
        [SerializeReference] public Node second;
    }

    public sealed class SerializedToolsTests
    {
        private string path;
        private SerializationFixture target;
        private string targetId;

        [SetUp]
        public void CreateFixture()
        {
            path = "Assets/UnityMcpTest_" + Guid.NewGuid().ToString("N") + ".asset";
            target = ScriptableObject.CreateInstance<SerializationFixture>();
            target.number = 3;
            target.values.Add(12);
            target.first = new SerializationFixture.Node { number = 7 };
            target.first.next = target.first;
            AssetDatabase.CreateAsset(target, path);
            AssetDatabase.SaveAssetIfDirty(target);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate | ImportAssetOptions.ForceSynchronousImport);
            target = AssetDatabase.LoadAssetAtPath<SerializationFixture>(path);
            targetId = EditorTools.Id(target);
        }

        [TearDown]
        public void DeleteFixture()
        {
            if (target)
                Undo.ClearUndo(target);
            AssetDatabase.DeleteAsset(path);
        }

        [Test]
        public void InvalidEditDoesNotCommitAnEarlierChange()
        {
            var before = Inspect();
            Assert.Throws<EditorToolException>(() => Apply(before, Set("number", 5), Set("missing", 6)));
            Assert.That(target.number, Is.EqualTo(3));
            Assert.That((string)Inspect()["revision"], Is.EqualTo((string)before["revision"]));
        }

        [Test]
        public void ChangedRevisionRejectsLaterPatch()
        {
            var before = Inspect("number");
            Apply(before, Set("number", 5));
            var conflict = Assert.Throws<EditorToolException>(() => Apply(before, Set("number", 6)));
            Assert.That(conflict.Code, Is.EqualTo("revision_conflict"));
            Assert.That(target.number, Is.EqualTo(5));
        }

        [Test]
        public void CanResizeAnArrayAndSetAnElementInOnePatch()
        {
            var before = Inspect("values");
            Apply(before, new JObject { ["op"] = "resize", ["path"] = "values", ["value"] = 2 },
                Set("values.Array.data[1]", 17));
            Assert.That(target.values, Is.EqualTo(new[] { 12, 17 }));
            Undo.PerformUndo();
            Assert.That(target.values, Is.EqualTo(new[] { 12 }));
        }

        [Test]
        public void PreservesSharedAndCyclicManagedReferences()
        {
            var before = Inspect();
            string referenceId = null;
            foreach (JObject item in (JArray)before["items"])
                if ((string)item["path"] == "first") referenceId = (string)item["value"];
            Assert.That(referenceId, Does.StartWith("ref:"), before.ToString());
            Apply(before, new JObject { ["op"] = "managed_link", ["path"] = "second", ["value"] = referenceId });
            Assert.That(target.first, Is.SameAs(target.second));
            Assert.That(target.first.next, Is.SameAs(target.first));
        }

        [Test]
        public void AppliesTypedObjectReferenceById()
        {
            var before = Inspect("linked");
            Apply(before, new JObject { ["op"] = "set", ["path"] = "linked", ["value"] = targetId });
            Assert.That(target.linked, Is.SameAs(target));
        }

        private JObject Inspect(string branch = null) => SerializedTools.Inspect(new JObject { ["target_id"] = targetId, ["path"] = branch });

        private void Apply(JObject before, params JObject[] changes)
        {
            SerializedTools.Patch(new JObject
            {
                ["target_id"] = targetId, ["path"] = before["path"],
                ["expected_revision"] = before["revision"], ["operations"] = new JArray(changes)
            });
        }

        private static JObject Set(string property, int value) => new JObject { ["op"] = "set", ["path"] = property, ["value"] = value };
    }
}
