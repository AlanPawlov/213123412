(() => {
  "use strict";

  const canvas = document.getElementById("unity-canvas");
  const viewport = document.getElementById("unity-fullscreen-container");
  const fullscreenButton = document.getElementById("fullscreen-button");
  const fullscreenLabel = document.getElementById("fullscreen-label");
  const loadingScreen = document.getElementById("loading-screen");
  const errorScreen = document.getElementById("error-screen");
  const progressBar = document.getElementById("loading-progress");
  const progressFill = document.getElementById("loading-progress-fill");
  const percentage = document.getElementById("loading-percentage");
  const build = window.archiverseBuild;
  let unityInstance;

  // Decoration consists of immutable images and has no JavaScript update loop.

  function showError(message) {
    console.error("ARCHIVERSE:", message);
    loadingScreen.hidden = true;
    errorScreen.hidden = false;
    fullscreenButton.disabled = true;
  }

  function updateProgress(progress) {
    const value = Math.min(100, Math.max(0, Math.round(progress * 100)));
    progressFill.style.width = `${value}%`;
    percentage.textContent = `${value}%`;
    progressBar.setAttribute("aria-valuenow", String(value));
  }

  function isFullscreen() {
    return Boolean(document.fullscreenElement || document.webkitFullscreenElement);
  }

  function syncFullscreenButton() {
    const expanded = isFullscreen();
    document.documentElement.toggleAttribute("data-decoration-suspended", expanded);
    fullscreenButton.setAttribute("aria-pressed", String(expanded));
    fullscreenButton.setAttribute("aria-label", expanded ? "Вернуться к оконному режиму" : "Развернуть приложение на весь экран");
    fullscreenLabel.textContent = expanded ? "Свернуть" : "Развернуть";
  }

  function exitFullscreen() {
    if (unityInstance) unityInstance.SetFullscreen(0);
  }

  fullscreenButton.addEventListener("click", () => {
    if (!unityInstance) return;
    if (isFullscreen()) {
      exitFullscreen();
    } else {
      unityInstance.SetFullscreen(1);
      canvas.focus({ preventScroll: true });
    }
  });

  document.addEventListener("fullscreenchange", syncFullscreenButton);
  document.addEventListener("webkitfullscreenchange", syncFullscreenButton);
  document.addEventListener("fullscreenerror", () => { fullscreenButton.title = "Браузер не разрешил полноэкранный режим"; });
  document.getElementById("reload-button").addEventListener("click", () => window.location.reload());
  document.getElementById("fullscreen-return").addEventListener("click", exitFullscreen);

  if (!build) {
    showError("Build configuration is missing.");
    return;
  }

  build.config.showBanner = (message, type) => {
    if (type === "error") showError(message);
    else console.warn("ARCHIVERSE:", message);
  };

  const loader = document.createElement("script");
  loader.src = build.loaderUrl;
  loader.onerror = () => showError("Could not load the application loader.");
  loader.onload = () => {
    createUnityInstance(canvas, build.config, updateProgress)
      .then((instance) => {
        unityInstance = instance;
        updateProgress(1);
        loadingScreen.classList.add("is-complete");
        loadingScreen.setAttribute("aria-hidden", "true");
        fullscreenButton.disabled = false;
        viewport.setAttribute("data-ready", "true");
      })
      .catch(showError);
  };
  document.body.appendChild(loader);
})();
