using UnityEditor;
using UnityEditor.UIElements;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UIElements;

namespace Sbrt.Av.Gameplay
{
    [CustomEditor(typeof(KafoGenerator))]
    public sealed class KafoGeneratorEditor : UnityEditor.Editor
    {
        public override VisualElement CreateInspectorGUI()
        {
            var root=new VisualElement();
            var sheet=AssetDatabase.LoadAssetAtPath<StyleSheet>("Assets/Kafo/Editor/KafoInspector.uss");if(sheet!=null)root.styleSheets.Add(sheet);
            InspectorElement.FillDefaultInspector(root,serializedObject,this);
            var status=new Label();status.AddToClassList("kafo-status");root.Add(status);
            var warnings=new Foldout{text="Диагностика",value=false};root.Add(warnings);
            void UpdateStatus()
            {
                var generator=(KafoGenerator)target;status.text=generator.Summary;
                warnings.Clear();warnings.text="Диагностика ("+generator.Diagnostics.Count+")";
                foreach(var warning in generator.Diagnostics){var l=new Label(warning);l.AddToClassList("kafo-warning");warnings.Add(l);}
            }
            var buttons=new VisualElement();buttons.AddToClassList("kafo-actions");root.Add(buttons);
            buttons.Add(new Button(()=>{
                serializedObject.ApplyModifiedProperties();var g=(KafoGenerator)target;g.Generate();
                EditorUtility.SetDirty(g);if(g.gameObject.scene.IsValid())EditorSceneManager.MarkSceneDirty(g.gameObject.scene);UpdateStatus();SceneView.RepaintAll();
            }){text="Сгенерировать"});
            buttons.Add(new Button(()=>{var g=(KafoGenerator)target;g.Clear();EditorUtility.SetDirty(g);EditorSceneManager.MarkSceneDirty(g.gameObject.scene);UpdateStatus();}){text="Очистить"});
            var examplesBox=new Foldout{text="Тестовые наборы",value=false};root.Add(examplesBox);
            foreach(var example in KafoExamples.All)
                examplesBox.Add(new Button(()=>{serializedObject.FindProperty("Json").stringValue=example.Json;serializedObject.ApplyModifiedProperties();}){text=example.Name});
            UpdateStatus();return root;
        }
    }
}
