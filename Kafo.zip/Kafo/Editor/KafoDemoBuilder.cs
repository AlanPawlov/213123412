using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public static class KafoDemoBuilder
    {
        public const string AssetFolder="Assets/Kafo/Visuals";
        [MenuItem("KFO/Подготовить префабы и сцену")]
        public static void Setup()
        {
            Directory.CreateDirectory(AssetFolder);AssetDatabase.Refresh();
            var app=BuildPrefab(KafoVisualKind.Application,"AS");
            var segment=BuildPrefab(KafoVisualKind.Segment,"Segment");
            var group=BuildPrefab(KafoVisualKind.Group,"Group");
            var root=GameObject.Find("Root")??new GameObject("KFO");
            var generator=root.GetComponent<KafoGenerator>()??root.AddComponent<KafoGenerator>();
            var environment=AssetDatabase.LoadAssetAtPath<Material>(AssetFolder+"/Environment.mat");
            if(environment==null)
            {
                environment=new Material(Shader.Find("Universal Render Pipeline/Lit")){name="KFO Environment"};
                environment.color=new Color(.018f,.026f,.03f);environment.SetFloat("_Smoothness",.25f);
                AssetDatabase.CreateAsset(environment,AssetFolder+"/Environment.mat");
            }
            foreach(var renderer in root.GetComponentsInChildren<MeshRenderer>(true))
                if(renderer.name=="decor"||renderer.name=="plane_zone")renderer.sharedMaterial=environment;
            generator.AsPrefab=app;generator.SegmentPrefab=segment;generator.GroupPrefab=group;
            generator.LabelFont=KafoFontBuilder.Prepare();
            if(generator.MainZone==null)generator.MainZone=root.GetComponentsInChildren<Renderer>(true).FirstOrDefault(r=>r.name=="plane_zone");
            if(generator.MainZone!=null && generator.IslandZone==null)
            {
                var bounds=generator.MainZone.bounds;
                var island=Object.Instantiate(segment);island.name="as_without_segments_zone";island.transform.SetParent(root.transform,true);
                var shape=island.GetComponent<KafoMeshResizer>();shape.CaptureSource();
                shape.Resize(new Vector3(bounds.max.x+3,bounds.center.y-.08f,bounds.min.z+2),new Vector3(4,.16f,4),1);
                generator.IslandZone=island.GetComponent<Renderer>();
            }
            generator.Json=KafoExamples.Bridges;
            generator.Generate();Selection.activeGameObject=root;EditorUtility.SetDirty(generator);
            EditorSceneManager.MarkSceneDirty(root.scene);AssetDatabase.SaveAssets();
            EditorSceneManager.SaveScene(root.scene);
        }
        static GameObject BuildPrefab(KafoVisualKind kind,string name)
        {
            string path=AssetFolder+"/"+name+".prefab";
            var existing=AssetDatabase.LoadAssetAtPath<GameObject>(path);if(existing!=null)return existing;
            var go=KafoDefaultVisuals.Create(kind);go.name=name;
            var filter=go.GetComponent<MeshFilter>();var mesh=Object.Instantiate(filter.sharedMesh);mesh.name=name+" Rounded Mesh";mesh.hideFlags=HideFlags.None;
            AssetDatabase.CreateAsset(mesh,AssetFolder+"/"+name+".asset");filter.sharedMesh=mesh;
            var renderer=go.GetComponent<MeshRenderer>();var mats=renderer.sharedMaterials;
            for(int i=0;i<mats.Length;i++)
            {
                var mat=Object.Instantiate(mats[i]);mat.name=name+" "+i;mat.hideFlags=HideFlags.None;
                AssetDatabase.CreateAsset(mat,AssetFolder+"/"+name+"_"+i+".mat");mats[i]=mat;
            }
            renderer.sharedMaterials=mats;go.GetComponent<KafoMeshResizer>().CaptureSource(false);
            var prefab=PrefabUtility.SaveAsPrefabAsset(go,path);Object.DestroyImmediate(go);return prefab;
        }
        public static string VerifyExamples()
        {
            var generator=Object.FindAnyObjectByType<KafoGenerator>();
            var original=generator.Json;var report=new System.Collections.Generic.List<string>();
            foreach(var example in KafoExamples.All)
            {
                generator.Json=example.Json;
                var watch=System.Diagnostics.Stopwatch.StartNew();generator.Generate();watch.Stop();
                var errors=generator.LastResult.Validate(generator.LastData);errors.AddRange(generator.ValidatePhysicalBounds());
                report.Add(example.Name+": AS="+generator.LastResult.Systems.Count+", bridges="+generator.LastResult.BridgeCount+", ms="+watch.ElapsedMilliseconds+", errors="+string.Join(";",errors));
            }
            generator.Json=original;generator.Generate();EditorUtility.SetDirty(generator);EditorSceneManager.SaveScene(generator.gameObject.scene);
            string text=string.Join("\n",report);Directory.CreateDirectory("Temp/Kafo");File.WriteAllText("Temp/Kafo/examples-report.txt",text);return text;
        }
    }
}
