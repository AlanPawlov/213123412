using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public static class KafoExampleVerifier
    {
        public static string VerifyExamples()
        {
            var generator=Object.FindAnyObjectByType<KafoGenerator>();
            var original=generator.Json;var report=new List<string>();
            try
            {
                foreach(var example in KafoExamples.All)
                {
                    generator.Json=example.Json;
                    var watch=System.Diagnostics.Stopwatch.StartNew();generator.Generate(KafoDataLoader.ReadTestJson(example.Json));watch.Stop();
                    if(generator.LastResult==null)throw new System.InvalidOperationException(string.Join("; ",generator.Diagnostics));
                    var errors=generator.LastResult.Validate(generator.LastData);errors.AddRange(generator.ValidatePhysicalBounds());
                    report.Add(example.Name+": AS="+generator.LastResult.Systems.Count+", bridges="+generator.LastResult.BridgeCount+", ms="+watch.ElapsedMilliseconds+", errors="+string.Join(";",errors));
                }
            }
            finally
            {
                generator.Json=original;generator.Generate(KafoDataLoader.ReadTestJson(original));EditorUtility.SetDirty(generator);EditorSceneManager.SaveScene(generator.gameObject.scene);
            }
            string text=string.Join("\n",report);Directory.CreateDirectory("Temp/Kafo");File.WriteAllText("Temp/Kafo/examples-report.txt",text);return text;
        }
    }
}
