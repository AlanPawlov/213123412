using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.UIElements;
using UnityEngine.UIElements;

namespace Sbrt.Av.Gameplay
{
    [CustomEditor(typeof(KafoDemoController))]
    public sealed class KafoDemoControllerEditor : UnityEditor.Editor
    {
        public override VisualElement CreateInspectorGUI()
        {
            var root = new VisualElement();
            InspectorElement.FillDefaultInspector(root, serializedObject, this);
            var status = new Label(); root.Add(status);
            var warnings = new Foldout { text = "Диагностика" }; root.Add(warnings);
            void Refresh()
            {
                var demo = (KafoDemoController)target;
                status.text = demo.Summary; warnings.Clear();
                foreach (var message in demo.Diagnostics) warnings.Add(new HelpBox(message, HelpBoxMessageType.Warning));
            }
            void Execute(System.Action<KafoDemoController> action)
            {
                serializedObject.ApplyModifiedProperties();
                var demo = (KafoDemoController)target;
                action(demo); serializedObject.Update();
                EditorUtility.SetDirty(demo);
                if (demo.Kafo != null) EditorUtility.SetDirty(demo.Kafo);
                if (demo.Infoflows != null) EditorUtility.SetDirty(demo.Infoflows);
                if (demo.gameObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(demo.gameObject.scene);
                Refresh(); SceneView.RepaintAll();
            }
            root.Add(new Button(() => Execute(d => d.FullGenerate())) { text = "Сгенерировать KAFO и потоки" });
            root.Add(new Button(() => Execute(d => d.FlowsOnly())) { text = "Перегенерировать потоки" });
            root.Add(new Button(() => Execute(d => d.NextSeed())) { text = "Другой набор связей" });
            root.Add(new Button(() => Execute(d => d.Clear())) { text = "Очистить всё" });
            Refresh(); return root;
        }
    }
}
