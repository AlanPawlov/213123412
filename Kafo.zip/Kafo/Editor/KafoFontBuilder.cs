using System.Collections.Generic;
using System.IO;
using System.Linq;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.TextCore.LowLevel;

namespace Sbrt.Av.Gameplay
{
    public static class KafoFontBuilder
    {
        const string Folder="Assets/Kafo/Resources/KafoFonts";
        public static TMP_FontAsset Prepare()
        {
            var existing=AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(Folder+"/KFO Sans SDF.asset");
            if(existing!=null)return existing;
            var source=AssetDatabase.LoadAssetAtPath<Font>("Assets/TextMesh Pro/Fonts/LiberationSans.ttf");
            if(source==null)throw new System.InvalidOperationException("Импортируйте TMP Essential Resources: отсутствует LiberationSans.ttf.");
            Directory.CreateDirectory(Folder);AssetDatabase.Refresh();
            var main=Create(source,"KFO Sans SDF");
            string characters=string.Concat(Enumerable.Range(32,95).Concat(Enumerable.Range(0x410,64)).Select(c=>(char)c))+"Ёё№×«»–—…‑\u00a0„“”";
            main.TryAddCharacters(characters,out string missing);
            main.atlasPopulationMode=AtlasPopulationMode.Static;
            var fallback=Create(source,"KFO Sans Dynamic");
            main.fallbackFontAssetTable=new List<TMP_FontAsset>{fallback};
            Save(fallback);Save(main);AssetDatabase.SaveAssets();return main;
        }
        static TMP_FontAsset Create(Font source,string name)
        {
            var asset=TMP_FontAsset.CreateFontAsset(source,90,9,GlyphRenderMode.SDF16,1024,1024,AtlasPopulationMode.Dynamic,true);
            asset.name=name;
            var serialized=new SerializedObject(asset);serialized.FindProperty("m_ClearDynamicDataOnBuild").boolValue=true;serialized.ApplyModifiedPropertiesWithoutUndo();
            return asset;
        }
        static void Save(TMP_FontAsset asset)
        {
            string path=Folder+"/"+asset.name+".asset";AssetDatabase.CreateAsset(asset,path);
            asset.material.name=asset.name+" Material";AssetDatabase.AddObjectToAsset(asset.material,asset);
            foreach(var atlas in asset.atlasTextures)
            {
                atlas.name=asset.name+" Atlas";AssetDatabase.AddObjectToAsset(atlas,asset);
            }
            EditorUtility.SetDirty(asset);
        }
    }
}
