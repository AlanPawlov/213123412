using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.UIElements;
using UnityEngine.UIElements;

namespace Sbrt.Av.Gameplay
{
    [CustomEditor(typeof(InfoflowGenerator))]
    public sealed class InfoflowGeneratorEditor : UnityEditor.Editor
    {
        public override VisualElement CreateInspectorGUI()
        {
            var root = new VisualElement();
            var settings = serializedObject.FindProperty("Settings");
            var minWidth = new PropertyField(settings.FindPropertyRelative("MinWidth"), "Минимальная ширина потока");
            minWidth.tooltip = "Нижняя граница автосайза в мировых единицах. Ширина потока не уменьшается ниже неё.";
            var maxWidth = new PropertyField(settings.FindPropertyRelative("MaxWidth"), "Максимальная ширина потока");
            maxWidth.tooltip = "Верхняя граница автосайза в мировых единицах. При равных границах ширина фиксирована.";
            var gap = new PropertyField(settings.FindPropertyRelative("GapRatio"), "Зазор (доли ширины)");
            gap.tooltip = "Свободный зазор между краями лент: 0,5 — половина фактической ширины, 2 — две ширины. Одинаковый в портах и на магистралях.";
            root.Add(minWidth); root.Add(maxWidth); root.Add(gap);
            var invalidRange = new HelpBox("Задайте положительную максимальную ширину, минимальную ширину от 0 до максимальной и неотрицательный зазор.", HelpBoxMessageType.Error);
            root.Add(invalidRange);
            var batch = new PropertyField(serializedObject.FindProperty("UseBatchRendering"), "Пакетная отрисовка");
            root.Add(batch);
            root.Add(new PropertyField(serializedObject.FindProperty("FlowPlaneLocalY"), "Высота общей плоскости (Local Y)"));
            var advanced = new Foldout { text = "Дополнительные настройки", value = false };
            foreach (var field in new[] {
                ("RadiusInCells", "Радиус поворота (доли ячейки)"),
                ("StraightExit", "Прямой выход из АС"),
                ("Clearance", "Отступ от корпуса АС"),
                ("PrimaryPortCount", "Подключений на основной стороне"),
                ("PreferredSide", "Основная сторона подключения"),
                ("SearchBudget", "Бюджет поиска"),
                ("ArcSteps", "Отрезков на четверть дуги") })
                advanced.Add(new PropertyField(settings.FindPropertyRelative(field.Item1), field.Item2));
            advanced.Add(new PropertyField(serializedObject.FindProperty("Material"), "Материал потоков"));
            root.Add(advanced);
            var status = new Label(); root.Add(status);
            status.style.whiteSpace = WhiteSpace.Normal;
            var apply = new Button { text = "Применить настройки потоков" }; root.Add(apply);
            var hint = new HelpBox("После перезагрузки редактора создайте потоки через KafoDemoController или вызовите Generate() с исходными данными.", HelpBoxMessageType.Info);
            root.Add(hint);
            var warnings = new Foldout { text = "Диагностика" }; root.Add(warnings);
            void Refresh()
            {
                var generator = (InfoflowGenerator)target;
                status.text = generator.Summary; warnings.Clear();
                var sizes = generator.Settings;
                bool valid = sizes.MaxWidth > 0 && sizes.MinWidth >= 0 && sizes.MinWidth <= sizes.MaxWidth && sizes.GapRatio >= 0;
                invalidRange.style.display = valid ? DisplayStyle.None : DisplayStyle.Flex;
                apply.SetEnabled(generator.CanRegenerate && valid);
                hint.style.display = generator.CanRegenerate ? DisplayStyle.None : DisplayStyle.Flex;
                foreach (var message in generator.Diagnostics) warnings.Add(new HelpBox(message, HelpBoxMessageType.Warning));
            }
            void Change(System.Action<InfoflowGenerator> action)
            {
                serializedObject.ApplyModifiedProperties();
                var generator = (InfoflowGenerator)target; action(generator);
                EditorUtility.SetDirty(generator);
                if (generator.gameObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(generator.gameObject.scene);
                Refresh(); SceneView.RepaintAll();
            }
            // Режим отрисовки не пересчитывает пути; новые размеры требуют явного применения.
            batch.RegisterValueChangeCallback(_ => Change(g => g.RebuildVisuals()));
            apply.clicked += () => Change(g => g.Regenerate());
            root.Add(new Button(() => Change(g => g.Clear())) { text = "Очистить инфопотоки" });
            root.TrackSerializedObjectValue(serializedObject, _ => Refresh());
            Refresh(); return root;
        }
    }
}
