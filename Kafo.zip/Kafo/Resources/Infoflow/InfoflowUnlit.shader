Shader "Sbrt/AV/KAFO Infoflow"
{
    Properties { _Color ("Color", Color) = (0.12, 1, 0.32, 1) }
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        Cull Off
        Pass
        {
            Tags { "LightMode"="SRPDefaultUnlit" }
            CGPROGRAM
            #pragma vertex Vertex
            #pragma fragment Fragment
            #include "UnityCG.cginc"
            fixed4 _Color;
            float4 Vertex(float4 position : POSITION) : SV_POSITION
            {
                return UnityObjectToClipPos(position);
            }
            fixed4 Fragment() : SV_Target { return _Color; }
            ENDCG
        }
    }
}
