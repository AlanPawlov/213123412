using UnityEngine;
#if UNITY_EDITOR
using System.Collections.Generic;
using System.Diagnostics;
#endif

namespace Sbrt.Av.Gameplay
{
    [DisallowMultipleComponent]
    public sealed class KafoDemoController : MonoBehaviour
    {
        public KafoGenerator Kafo;
        public InfoflowGenerator Infoflows;
#if UNITY_EDITOR
        public int FlowSeed;
        [Min(0)] public int FlowCount = 100;
        public InfoflowTestPattern Pattern;
        [SerializeField, HideInInspector] string summary;
        [SerializeField, HideInInspector] List<string> diagnostics = new List<string>();
        public string Summary => summary;
        public IReadOnlyList<string> Diagnostics => diagnostics;
        public int LogicalFlowCount { get; private set; }
        public int ExpandedLineCount { get; private set; }
        public double KafoMilliseconds { get; private set; }
        public double FlowMilliseconds { get; private set; }
        public double TotalMilliseconds { get; private set; }

        public void FullGenerate() => Run(true);
        public void FlowsOnly() => Run(false);
        public void NextSeed()
        {
            FlowSeed = unchecked(FlowSeed + 1);
            Run(false);
        }

        public void Clear()
        {
            if (Infoflows != null) Infoflows.Clear();
            if (Kafo != null) Kafo.Clear();
            diagnostics.Clear(); summary = "";
            LogicalFlowCount = ExpandedLineCount = 0;
            KafoMilliseconds = FlowMilliseconds = TotalMilliseconds = 0;
        }

        void Run(bool full)
        {
            diagnostics.Clear();
            KafoMilliseconds = FlowMilliseconds = 0; LogicalFlowCount = ExpandedLineCount = 0;
            var timer = Stopwatch.StartNew();
            if (Kafo == null || Infoflows == null) { diagnostics.Add("Назначьте Kafo и Infoflows."); return; }
            if (full)
            {
                var model = KafoDataLoader.ReadTestJson(Kafo.Json);
                var previousRoot = Kafo.GeneratedRoot;
                Infoflows.Clear();
                var kafoTimer = Stopwatch.StartNew();
                Kafo.Generate(model);
                KafoMilliseconds = kafoTimer.Elapsed.TotalMilliseconds;
                // Предупреждения допустимы, но прежний корень после неудачной попытки не считается новой KAFO.
                if (!ReferenceEquals(Kafo.LastData, model) || Kafo.GeneratedRoot == null || Kafo.GeneratedRoot == previousRoot)
                {
                    diagnostics.AddRange(Kafo.Diagnostics);
                    diagnostics.Add("Новая KAFO не создана. Потоки к предыдущему результату не добавлены.");
                    summary = "Генерация KAFO не завершена."; return;
                }
            }
            // При пересоздании только потоков используем модель текущей раскладки, а не изменённый JSON Inspector.
            if (Kafo.LastData == null || Kafo.GeneratedRoot == null)
            {
                diagnostics.Add("Нажмите «Сгенерировать KAFO и потоки»: актуальная модель KAFO недоступна.");
                return;
            }
            var flowTimer = Stopwatch.StartNew();
            var scene = InfoflowSceneSnapshot.Capture(Kafo.LastData, Kafo.GeneratedRoot,
                new InfoflowPlane(Kafo.GeneratedRoot.transform, Infoflows.FlowPlaneLocalY));
            var flows = InfoflowTestDataFactory.Create(scene, FlowCount, FlowSeed, Pattern, diagnostics);
            LogicalFlowCount = flows.Count;
            Infoflows.Generate(Kafo.LastData, Kafo.GeneratedRoot, flows);
            ExpandedLineCount = Infoflows.LastResult?.Routes.Count ?? 0;
            FlowMilliseconds = flowTimer.Elapsed.TotalMilliseconds;
            TotalMilliseconds = timer.Elapsed.TotalMilliseconds;
            diagnostics.AddRange(Infoflows.Diagnostics);
            if (full) diagnostics.AddRange(Kafo.Diagnostics);
            summary = $"KAFO: {KafoMilliseconds:F1} мс · Потоки: {FlowMilliseconds:F1} мс · Всего: {TotalMilliseconds:F1} мс\n" +
                $"Записей: {LogicalFlowCount} · Линий: {ExpandedLineCount} · FlowSeed: {FlowSeed}";
        }
#endif
    }
}
