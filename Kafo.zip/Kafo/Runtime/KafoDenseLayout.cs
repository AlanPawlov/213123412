using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public static partial class KafoLayoutSolver
    {
        sealed class DensePlan
        {
            public Context C;
            public IList<NormalizedSegment> Order;
            public List<Bucket> Buckets;
            public List<Band> Bands;
            public Dictionary<string,int> Index;
            public Dictionary<string,Bucket> ByPlacement;
            public float StepX,StepY,HeaderOffset,GridTop;
            public readonly Dictionary<string,DenseFitCache> Fits=new Dictionary<string,DenseFitCache>();
        }
        sealed class DenseFitCache
        {
            public DenseSegment Layout;
            public float RequiredHeight,FailedHeight=float.NegativeInfinity;
        }
        sealed class DenseSegment
        {
            public float Width;
            public readonly List<GroupLayout> Groups=new List<GroupLayout>();
            public readonly List<AsLayout> Systems=new List<AsLayout>();
            public readonly Dictionary<Bridge,Rect> Portals=new Dictionary<Bridge,Rect>();
        }

        static Pack SnapPack(Context c,List<Item> items,float aspect)
        {
            var pack=PackGrid(items,c.Gap,aspect);if(items.Count==0)return pack;
            float sx=c.Metrics.AsSize.x+c.Gap.x,sy=c.Metrics.AsSize.z+c.Gap.y;
            var widths=new int[pack.Columns];var heights=new int[pack.Rows];
            foreach(var item in pack.Items)
            {
                widths[item.Column]=Mathf.Max(widths[item.Column],Mathf.CeilToInt((item.W+c.Gap.x)/sx-.00001f));
                heights[item.Row]=Mathf.Max(heights[item.Row],Mathf.CeilToInt((item.H+c.Gap.y)/sy-.00001f));
            }
            var x=new float[widths.Length];var y=new float[heights.Length];
            for(int i=1;i<x.Length;i++)x[i]=x[i-1]+widths[i-1]*sx;
            for(int i=1;i<y.Length;i++)y[i]=y[i-1]+heights[i-1]*sy;
            foreach(var item in pack.Items)item.Rect=new Rect(x[item.Column],y[item.Row],item.W,item.H);
            pack.W=pack.Items.Max(i=>i.Rect.xMax);pack.H=pack.Items.Max(i=>i.Rect.yMax);return pack;
        }
        static DensePlan DensePrepare(Context c,IList<NormalizedSegment> order,int variant)
        {
            var plan=new DensePlan {C=c,Order=order,StepX=c.Metrics.AsSize.x+c.Gap.x,StepY=c.Metrics.AsSize.z+c.Gap.y,
                Index=order.Select((s,i)=>new{s.Key,I=i}).ToDictionary(x=>x.Key,x=>x.I),Buckets=Buckets(c.Source.Placements.Where(p=>p.SegmentKey!=null))};
            plan.HeaderOffset=Mathf.Ceil((c.GroupPad+c.GroupHeader)/plan.StepY)*plan.StepY;
            plan.GridTop=c.Pad+c.Header;
            plan.ByPlacement=plan.Buckets.SelectMany(b=>b.Placements.Select(p=>new{p.Key,B=b})).ToDictionary(x=>x.Key,x=>x.B);
            var bands=plan.Buckets.Select(b=>{var band=new Band();band.Buckets.Add(b);return band;}).ToList();
            foreach(var records in c.Source.Placements.Where(p=>p.SegmentKey!=null).GroupBy(p=>p.SystemKey).OrderByDescending(g=>g.Count()).ThenBy(g=>g.Key,StringComparer.Ordinal))
            {
                var ps=records.ToList();if(ps.Count<2||ps.GroupBy(p=>p.SegmentKey).Any(g=>g.Count()>1))continue;
                int first=ps.Min(p=>plan.Index[p.SegmentKey]),last=ps.Max(p=>plan.Index[p.SegmentKey]);
                if(last-first+1!=ps.Count)continue;
                var joining=ps.Select(p=>bands.First(b=>b.Buckets.Contains(plan.ByPlacement[p.Key]))).Distinct().ToList();
                var buckets=joining.SelectMany(b=>b.Buckets).Distinct().ToList();
                if(buckets.GroupBy(b=>b.SegmentKey).Any(g=>g.Count()>1))continue;
                var merged=new Band();merged.Buckets.AddRange(buckets);merged.Bridges.AddRange(joining.SelectMany(b=>b.Bridges));
                merged.Bridges.Add(new Bridge{System=c.Systems[records.Key],Placements=ps,First=first,Last=last});
                foreach(var band in joining)bands.Remove(band);bands.Add(merged);
            }
            plan.Bands=bands.Where(b=>b.Bridges.Count>0).OrderByDescending(b=>b.Bridges.Max(a=>a.Last-a.First)).ThenBy(b=>b.Bridges.Min(a=>a.System.Key),StringComparer.Ordinal).ToList();
            var bridged=new HashSet<string>(plan.Bands.SelectMany(b=>b.Bridges).SelectMany(b=>b.Placements).Select(p=>p.Key));
            float aspect=new[]{.6f,1f,1.8f,3f}[variant];
            foreach(var bucket in plan.Buckets)
            {
                bucket.Rest=SnapPack(c,bucket.Placements.Where(p=>!bridged.Contains(p.Key)).Select(p=>{var size=c.Size(p);return new Item{Key=p.Key,W=size.x,H=size.y,Value=p};}).ToList(),aspect);
                bucket.W=bucket.Rest.W+(bucket.IsGroup?2*c.GroupPad:0);
                bucket.H=bucket.Rest.H+(bucket.IsGroup?plan.HeaderOffset+c.GroupPad:0);
            }
            var occupied=order.ToDictionary(s=>s.Key,s=>new List<Vector2>());
            foreach(var band in plan.Bands)
            {
                float y=band.Buckets.Any(b=>b.IsGroup)?plan.HeaderOffset:0;
                foreach(var bridge in band.Bridges.OrderBy(b=>b.System.Key,StringComparer.Ordinal))
                {
                    var cells=c.Cells(bridge.System);
                    float minimumLength=2*(c.Pad+c.Metrics.AsSize.x)+c.SegmentGap*(bridge.Last-bridge.First);
                    float thickness=Mathf.Max(c.Metrics.AsSize.z,cells.x*cells.y*c.Metrics.AsSize.x*c.Metrics.AsSize.z/minimumLength);
                    int rows=Mathf.Clamp(Mathf.CeilToInt((thickness+c.Gap.y)/plan.StepY-.00001f),1,cells.y);
                    bridge.Thickness=rows*c.Metrics.AsSize.z;bridge.Lane=y;
                    y+=rows*plan.StepY;
                }
                band.RestY=y;
                var heights=band.Buckets.ToDictionary(b=>b.SegmentKey,b=>BandHeight(c,band,b));
                float start=0;
                while(true)
                {
                    float next=start;
                    foreach(var b in band.Buckets)
                    foreach(var used in occupied[b.SegmentKey])
                        if(start<used.y-.00001f&&start+heights[b.SegmentKey]>used.x+.00001f)next=Mathf.Max(next,used.y);
                    if(next<=start+.00001f)break;start=Mathf.Ceil(next/plan.StepY)*plan.StepY;
                }
                band.Y=start;
                foreach(var b in band.Buckets)occupied[b.SegmentKey].Add(new Vector2(start,start+heights[b.SegmentKey]));
            }
            return plan;
        }
        static float BandHeight(Context c,Band band,Bucket bucket)
        {
            if(bucket.IsGroup)return band.RestY+bucket.Rest.H+c.GroupPad;
            return band.Bridges.Where(a=>a.Placements.Any(p=>p.SegmentKey==bucket.SegmentKey)).Max(a=>a.Lane+a.Thickness);
        }
        static KafoLayoutResult SearchDense(Context c,Rect main,IList<NormalizedSegment> order,bool transpose,int variant)
        {
            if(order.Count==0)return Build(c,main,order,transpose,false);
            var plan=DensePrepare(c,order,variant);
            float low=Build(c,main,order,transpose,false).CellScale*.9f;
            KafoLayoutResult best=null;
            for(int i=0;i<16;i++)
            {
                best=TryDense(plan,main,transpose,low,variant);if(best!=null)break;low*=.7f;
            }
            if(best==null)return null;
            float high=low*1.4f;
            for(int i=0;i<16;i++)
            {
                var next=TryDense(plan,main,transpose,high,variant);if(next==null)break;
                best=next;low=high;high*=1.4f;
            }
            for(int i=0;i<13;i++)
            {
                float middle=(low+high)*.5f;var next=TryDense(plan,main,transpose,middle,variant);
                if(next==null)high=middle;else{low=middle;best=next;}
            }
            return best;
        }
        static KafoLayoutResult TryDense(DensePlan plan,Rect main,bool transpose,float scale,int variant)
        {
            var c=plan.C;float totalWidth=(transpose?main.height:main.width)/scale;
            float height=(transpose?main.width:main.height)/scale-2*c.Outer;
            if(height<plan.GridTop+c.Metrics.AsSize.z+c.Pad)return null;
            foreach(var band in plan.Bands)
            foreach(var bucket in band.Buckets)
                if(plan.GridTop+band.Y+BandHeight(c,band,bucket)>height-c.Pad+.00001f)return null;
            foreach(var bucket in plan.Buckets.Where(b=>!plan.Bands.Any(band=>band.Buckets.Contains(b))))
                if(plan.GridTop+bucket.H>height-c.Pad+.00001f)return null;
            float available=totalWidth-2*c.Outer-c.SegmentGap*(plan.Order.Count-1);
            int maxColumns=Mathf.Min(512,Mathf.FloorToInt((available-2*(c.Pad+c.GroupPad)+c.Gap.x)/plan.StepX));
            if(maxColumns<1)return null;
            var segments=new List<DenseSegment>();
            foreach(var segment in plan.Order)
            {
                DenseSegment fitted=null;
                var buckets=plan.Buckets.Where(b=>b.SegmentKey==segment.Key).ToList();
                float required=buckets.Count==0?0:buckets.Max(b=>b.IsGroup?2*c.Pad+b.W:2*c.Pad+c.GroupPad+b.W);
                if(plan.Bands.SelectMany(b=>b.Bridges).Any(a=>a.Placements.Any(p=>p.SegmentKey==segment.Key)))required=Mathf.Max(required,c.Pad+c.Metrics.AsSize.x);
                int minimumColumns=Mathf.Max(1,Mathf.CeilToInt((required-2*(c.Pad+c.GroupPad)+c.Gap.x)/plan.StepX-.00001f));
                for(int columns=minimumColumns;columns<=maxColumns;columns++)
                {
                    float width=2*(c.Pad+c.GroupPad)+columns*plan.StepX-c.Gap.x;
                    if(width>available+.00001f)break;
                    fitted=CachedDenseSegment(plan,segment.Key,width,height,columns,variant);
                    if(fitted!=null)break;
                }
                if(fitted==null)return null;available-=fitted.Width;segments.Add(fitted);
            }
            // Refit wider strips on the same cell pitch. Do not stretch inter-object gaps.
            float leftover=totalWidth-2*c.Outer-c.SegmentGap*(segments.Count-1)-segments.Sum(s=>s.Width);
            if(leftover<-.0001f)return null;
            var result=new KafoLayoutResult{MainRect=main,CellScale=scale,BridgesAlongX=!transpose,
                CellSize=transpose?new Vector2(c.Metrics.AsSize.z,c.Metrics.AsSize.x)*scale:new Vector2(c.Metrics.AsSize.x,c.Metrics.AsSize.z)*scale};
            float x=c.Outer,extra=leftover/segments.Count;
            for(int i=0;i<segments.Count;i++)
            {
                float width=segments[i].Width+extra;
                int columns=Mathf.FloorToInt((width-2*(c.Pad+c.GroupPad)+c.Gap.x)/plan.StepX+.00001f);
                var fitted=FitDenseSegment(plan,plan.Order[i].Key,width,height,columns,variant);
                if(fitted==null)return null;segments[i]=fitted;
            }
            Rect Map(Rect rect)=>MapFromLogical(main,new Rect(rect.position*scale,rect.size*scale),transpose);
            var origins=new float[segments.Count];
            for(int i=0;i<segments.Count;i++)
            {
                var local=segments[i];origins[i]=x;
                var platform=new Rect(x,c.Outer,local.Width,height);
                result.Segments.Add(new SegmentLayout{Key=plan.Order[i].Key,Name=plan.Order[i].Name,Rect=Map(platform),
                    TitleRect=Map(DenseTitle(c,platform)),
                    HeaderRect=Map(new Rect(platform.x,platform.y,platform.width,plan.GridTop))});
                Rect Place(Rect r)=>Map(new Rect(r.position+new Vector2(origins[i],c.Outer),r.size));
                foreach(var group in local.Groups)
                {
                    result.Groups.Add(new GroupLayout{Key=group.Key,Name=group.Name,SegmentKey=group.SegmentKey,Rect=Place(group.Rect),TitleRect=Place(group.TitleRect)});
                }
                foreach(var a in local.Systems)
                {
                    var copy=new AsLayout{Key=a.Key,SystemKey=a.SystemKey,Name=a.Name,Rect=Place(a.Rect)};
                    copy.PlacementKeys.AddRange(a.PlacementKeys);copy.SegmentKeys.AddRange(a.SegmentKeys);copy.GroupKeys.AddRange(a.GroupKeys);result.Systems.Add(copy);
                }
                x+=local.Width+c.SegmentGap;
            }
            foreach(var band in plan.Bands)
            foreach(var bridge in band.Bridges)
            {
                var first=segments[bridge.First].Portals[bridge];var last=segments[bridge.Last].Portals[bridge];
                var rect=Rect.MinMaxRect(origins[bridge.First]+first.xMin,c.Outer+first.yMin,origins[bridge.Last]+last.xMax,c.Outer+first.yMax);
                var a=new AsLayout{Key="bridge:"+bridge.System.Key,SystemKey=bridge.System.Key,Name=bridge.System.Name,IsBridge=true,Rect=Map(rect)};
                foreach(var p in bridge.Placements){a.PlacementKeys.Add(p.Key);a.SegmentKeys.Add(p.SegmentKey);if(p.Group!=null)a.GroupKeys.Add(plan.ByPlacement[p.Key].Key);}
                result.Systems.Add(a);
            }
            return result;
        }
        static DenseSegment CachedDenseSegment(DensePlan plan,string segmentKey,float width,float height,int columns,int variant)
        {
            string key=segmentKey+":"+columns;
            if(!plan.Fits.TryGetValue(key,out var cache)){cache=new DenseFitCache();plan.Fits.Add(key,cache);}
            if(height<=cache.FailedHeight)return null;
            if(cache.Layout!=null&&height>=cache.RequiredHeight)return cache.Layout;
            var fit=FitDenseSegment(plan,segmentKey,width,height,columns,variant);
            if(fit==null)cache.FailedHeight=Mathf.Max(cache.FailedHeight,height);
            else
            {
                cache.Layout=fit;float bottom=0;
                foreach(var group in fit.Groups)bottom=Mathf.Max(bottom,group.Rect.yMax);
                foreach(var a in fit.Systems)bottom=Mathf.Max(bottom,a.Rect.yMax);
                foreach(var rect in fit.Portals.Values)bottom=Mathf.Max(bottom,rect.yMax);
                cache.RequiredHeight=bottom+plan.C.Pad+.00001f;
            }
            return fit;
        }
        static Rect DenseTitle(Context c,Rect platform)=>Title(platform,c.Pad,c.Header-c.TitleClearance);
        static DenseSegment FitDenseSegment(DensePlan plan,string segmentKey,float width,float height,int columns,int variant)
        {
            var c=plan.C;var result=new DenseSegment{Width=width};
            var bounds=new Rect(0,0,width,height);float originX=c.Pad+c.GroupPad;
            var occupied=new List<Rect>();var shadows=new List<Rect>();
            var segmentTitle=DenseTitle(c,bounds);
            shadows.Add(TitleShadow(segmentTitle,c.TitleClearance));
            void AddGroup(Bucket bucket,Rect rect)
            {
                var title=GroupTitle(c,rect);
                result.Groups.Add(new GroupLayout{Key=bucket.Key,Name=GroupName(bucket.Group),SegmentKey=segmentKey,Rect=rect,TitleRect=title});
                shadows.Add(TitleShadow(title,c.TitleClearance));
            }
            void Emit(Bucket bucket,Vector2 origin)
            {
                foreach(var item in bucket.Rest.Items)
                {
                    var p=(NormalizedPlacement)item.Value;var system=c.Systems[p.SystemKey];
                    var a=new AsLayout{Key="local:"+p.Key,SystemKey=system.Key,Name=system.Name,Rect=new Rect(origin+item.Rect.position,item.Rect.size)};
                    a.PlacementKeys.Add(p.Key);a.SegmentKeys.Add(segmentKey);if(bucket.IsGroup)a.GroupKeys.Add(bucket.Key);result.Systems.Add(a);
                }
            }
            foreach(var band in plan.Bands)
            {
                var bucket=band.Buckets.FirstOrDefault(b=>b.SegmentKey==segmentKey);if(bucket==null)continue;
                int index=plan.Index[segmentKey];var bridges=band.Bridges.Where(a=>a.Placements.Any(p=>p.SegmentKey==segmentKey)).ToList();
                foreach(var bridge in bridges)
                {
                    float endpoint=c.Pad+c.Metrics.AsSize.x;
                    var portal=new Rect(bridge.First==index?width-endpoint:0,plan.GridTop+band.Y+bridge.Lane,
                        bridge.First==index?endpoint:bridge.Last==index?endpoint:width,bridge.Thickness);
                    if(!KafoLayoutResult.Contains(bounds,portal)||portal.yMax>height-c.Pad)return null;
                    result.Portals.Add(bridge,portal);
                }
                if(!bucket.IsGroup){occupied.AddRange(bridges.Select(a=>result.Portals[a]));continue;}
                bool enters=bridges.Any(a=>a.First<index),exits=bridges.Any(a=>a.Last>index);
                float left=0,right=width,restX=originX;
                float required=c.Pad+c.Metrics.AsSize.x;
                if(enters&&!exits)right=Mathf.Max(required,originX+bucket.Rest.W+c.GroupPad);
                else if(exits&&!enters)
                {
                    float desired=width-Mathf.Max(required,bucket.W);
                    left=Mathf.Max(0,originX+Mathf.Floor((desired+c.GroupPad-originX)/plan.StepX)*plan.StepX-c.GroupPad);
                    restX=left+c.GroupPad;
                }
                var rect=new Rect(left,plan.GridTop+band.Y,right-left,BandHeight(c,band,bucket));
                if(!KafoLayoutResult.Contains(bounds,rect)||rect.yMax>height-c.Pad||restX+bucket.Rest.W+c.GroupPad>right+.00001f)return null;
                AddGroup(bucket,rect);occupied.Add(rect);Emit(bucket,new Vector2(restX,plan.GridTop+band.Y+band.RestY));
            }
            var local=plan.Buckets.Where(b=>b.SegmentKey==segmentKey&&!plan.Bands.Any(band=>band.Buckets.Contains(b))).ToList();
            local=local.OrderByDescending(b=>IsGateway(b.Group)&&c.GatewaySides[segmentKey]!=0)
                .ThenByDescending(b=>variant%2==0?b.W*b.H:b.H).ThenBy(b=>b.Key,StringComparer.Ordinal).ToList();
            int rows=Mathf.FloorToInt((height-c.Pad-plan.GridTop-c.Metrics.AsSize.z)/plan.StepY)+1;
            if(rows<0)return null;
            foreach(var bucket in local)
            {
                bool placed=false;
                int side=IsGateway(bucket.Group)?c.GatewaySides[segmentKey]:0;
                int edgeColumn=side>0?Mathf.FloorToInt((width-c.Pad-bucket.W+c.GroupPad-originX)/plan.StepX+.00001f):0;
                if(side!=0&&edgeColumn<0)return null;
                int firstColumn=side==0?0:edgeColumn,lastColumn=side==0?columns-1:edgeColumn;
                for(int row=0;row<rows&&!placed;row++)for(int column=firstColumn;column<=lastColumn;column++)
                {
                    var origin=new Vector2(originX+column*plan.StepX,plan.GridTop+row*plan.StepY);
                    var rect=new Rect(origin.x-(bucket.IsGroup?c.GroupPad:0),origin.y,bucket.W,bucket.H);
                    if(rect.xMax>width-c.Pad+.00001f||rect.yMax>height-c.Pad+.00001f)continue;
                    if(occupied.Any(o=>KafoLayoutResult.Overlap(rect,Expand(o,c.Gap*.5f)))||shadows.Any(o=>KafoLayoutResult.Overlap(rect,o)))continue;
                    if(bucket.IsGroup)
                    {
                        var title=GroupTitle(c,rect);
                        var shadow=TitleShadow(title,c.TitleClearance);
                        if(occupied.Any(o=>KafoLayoutResult.Overlap(shadow,o)))continue;
                        AddGroup(bucket,rect);
                    }
                    occupied.Add(rect);Emit(bucket,origin+(bucket.IsGroup?Vector2.up*plan.HeaderOffset:Vector2.zero));placed=true;break;
                }
                if(!placed)return null;
            }
            return result;
        }
    }
}
