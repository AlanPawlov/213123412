using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    // Группа подключений к одной грани АС и допустимый диапазон их расположения.
    internal sealed class FlowBank
    {
        public int Id, Endpoint;
        public InfoflowPortSide Side;
        public Vector2 Point, Normal;
        public float Low, High;
    }

    // Одна физическая линия после разворачивания экземпляров «все со всеми».
    internal sealed class FlowWire
    {
        public int Id;
        public InfoflowRoute Route;
        public FlowBank Provider, Consumer;
        public FlowFamily Family;
        public bool Reversed;
        public float[] Radii;
        public readonly List<int> CornerNodes = new List<int>();
    }

    // Линии между одинаковыми группами подключений используют один предварительный путь.
    internal sealed class FlowFamily
    {
        public int Id;
        public FlowBank Start, End;
        public List<Vector2> Path;
        public readonly List<FlowWire> Wires = new List<FlowWire>();
        public readonly List<FlowEdge> Edges = new List<FlowEdge>();
        public readonly List<int> Nodes = new List<int>();
        public readonly Dictionary<int, int> EdgeIndex = new Dictionary<int, int>();
    }

    internal sealed class FlowNode
    {
        public int Id;
        public Vector2 Point;
        public FlowBank Bank;
        public readonly List<FlowEdge> Edges = new List<FlowEdge>();
    }

    internal sealed class FlowEdge
    {
        public int Id, From, To, ArrowFrom = -1;
        public bool Horizontal;
        public Vector2 Direction;
        // Результат сравнения относится к конкретному ребру и стороне входа.
        // Раздельные кэши не повторяют эти данные в ключе каждой пары семейств.
        public readonly Dictionary<long, int>[] Divergence = new Dictionary<long, int>[2];
        // Итоговая координата дорожки: TrackOrigin + (TrackShift + Offsets[wireId]) * pitch.
        // Смещения хранятся в шагах дорожек, поэтому общее масштабирование не меняет порядок.
        public float Coordinate, TrackOrigin, TrackShift;
        public float MinOffset, MaxOffset;
        public readonly List<FlowFamily> Order = new List<FlowFamily>();
        public readonly Dictionary<int, int> OrderRanks = new Dictionary<int, int>();
        public readonly List<FlowWire> Lanes = new List<FlowWire>();
        public readonly Dictionary<int, float> Offsets = new Dictionary<int, float>();
        public int Other(int node) => node == From ? To : From;
    }

    internal sealed class InfoflowNetwork
    {
        public readonly List<FlowNode> Nodes = new List<FlowNode>();
        public readonly List<FlowEdge> Edges = new List<FlowEdge>();
        public readonly HashSet<int> CrossingNodes = new HashSet<int>();
        public bool CompactTracks;
        public bool SplitPassages;
        public bool CrossingFallback;
        readonly Dictionary<Vector2, int> nodeIds = new Dictionary<Vector2, int>();
        readonly Dictionary<(int, int), FlowEdge> edgeIds = new Dictionary<(int, int), FlowEdge>();
        readonly List<Dictionary<long, int>> comparedSections = new List<Dictionary<long, int>>();
        readonly long familyStride;

        sealed class Piece
        {
            public FlowFamily Family;
            public Vector2 A, B;
            public Rect Bounds;
            public HashSet<Vector2> Cuts;
        }

        public InfoflowNetwork(List<FlowFamily> families)
        {
            familyStride = families.Count == 0 ? 1 : (long)families.Max(f => f.Id) + 1;
            var pieces = new List<Piece>();
            var cutsBySegment = new Dictionary<(Vector2 Min, Vector2 Max), HashSet<Vector2>>();
            foreach (var family in families)
            for (int i = 1; i < family.Path.Count; i++)
            {
                var piece = new Piece { Family = family, A = family.Path[i - 1], B = family.Path[i] };
                piece.Bounds = Rect.MinMaxRect(Mathf.Min(piece.A.x, piece.B.x), Mathf.Min(piece.A.y, piece.B.y),
                    Mathf.Max(piece.A.x, piece.B.x), Mathf.Max(piece.A.y, piece.B.y));
                // Совпадающие осевые отрезки получают одни и те же точки разбиения.
                // Пересечения их геометрии достаточно найти один раз для всех семейств.
                var segment = (Vector2.Min(piece.A, piece.B), Vector2.Max(piece.A, piece.B));
                if (!cutsBySegment.TryGetValue(segment, out piece.Cuts))
                    cutsBySegment.Add(segment, piece.Cuts = new HashSet<Vector2>());
                piece.Cuts.Add(piece.A); piece.Cuts.Add(piece.B); pieces.Add(piece);
            }
            // Общие отрезки и пересечения становятся узлами сети до назначения координат дорожек.
            // Просматриваем только пары с общим диапазоном X. Множество Cuts не
            // накапливает одинаковые узлы при пересечении многих общих маршрутов.
            var byStart = pieces.GroupBy(p => p.Cuts).Select(g => g.First()).OrderBy(p => p.Bounds.xMin).ToArray();
            for (int i = 0; i < byStart.Length; i++)
            for (int j = i + 1; j < byStart.Length; j++)
            {
                var a = byStart[i]; var b = byStart[j];
                if (b.Bounds.xMin > a.Bounds.xMax) break;
                if (a.Bounds.xMax < b.Bounds.xMin || a.Bounds.xMin > b.Bounds.xMax ||
                    a.Bounds.yMax < b.Bounds.yMin || a.Bounds.yMin > b.Bounds.yMax) continue;
                // Пути здесь ортогональные. После проверки bounds параллельные
                // отрезки уже лежат на одной прямой; общий расчёт пересечения им не нужен.
                if ((a.Bounds.height == 0) == (b.Bounds.height == 0))
                {
                    Cut(a, b.A); Cut(a, b.B); Cut(b, a.A); Cut(b, a.B);
                }
                else if (InfoflowGeometry.Intersection(a.A, a.B, b.A, b.B, out var hit))
                { a.Cuts.Add(hit); b.Cuts.Add(hit); }
            }
            foreach (var piece in pieces)
            {
                var cuts = piece.Cuts.OrderBy(p => Vector2.Dot(p - piece.A, piece.B - piece.A)).ToList();
                for (int i = 1; i < cuts.Count; i++)
                {
                    int a = Node(cuts[i - 1]), b = Node(cuts[i]);
                    var key = (Math.Min(a, b), Math.Max(a, b));
                    if (!edgeIds.TryGetValue(key, out var edge))
                    {
                        edge = new FlowEdge { Id = Edges.Count, From = a, To = b, Horizontal = cuts[i - 1].y == cuts[i].y,
                            Direction = (Nodes[b].Point - Nodes[a].Point).normalized };
                        Edges.Add(edge);
                        edgeIds.Add(key, edge);
                        Nodes[a].Edges.Add(edge);
                        Nodes[b].Edges.Add(edge);
                    }
                    var family = piece.Family;
                    if (family.Nodes.Count == 0) family.Nodes.Add(a);
                    family.Edges.Add(edge);
                    family.EdgeIndex[edge.Id] = family.Edges.Count - 1;
                    family.Nodes.Add(b);
                }
            }
            foreach (var family in families)
            {
                Nodes[family.Nodes[0]].Bank = family.Start;
                Nodes[family.Nodes[family.Nodes.Count - 1]].Bank = family.End;
            }
        }

        static void Cut(Piece piece, Vector2 point)
        {
            if (point.x >= Mathf.Min(piece.A.x, piece.B.x) && point.x <= Mathf.Max(piece.A.x, piece.B.x) &&
                point.y >= Mathf.Min(piece.A.y, piece.B.y) && point.y <= Mathf.Max(piece.A.y, piece.B.y)) piece.Cuts.Add(point);
        }

        int Node(Vector2 point)
        {
            if (nodeIds.TryGetValue(point, out int id)) return id;
            id = Nodes.Count;
            nodeIds.Add(point, id);
            Nodes.Add(new FlowNode { Id = id, Point = point });
            return id;
        }

        public void OrderLanes(List<FlowFamily> families, bool compact = false, bool tightPacking = false, bool splitPassages = false)
        {
            CompactTracks = compact;
            SplitPassages = splitPassages;
            foreach (var family in families.OrderByDescending(f => f.Edges.Count).ThenBy(f => f.Id))
            {
                // Выбираем согласованное направление обхода, независимое от передачи данных.
                int direction = 1;
                var first = family.Edges.FirstOrDefault(e => e.ArrowFrom >= 0);
                if (first != null) direction = first.ArrowFrom == family.Nodes[family.EdgeIndex[first.Id]] ? 1 : -1;
                int index = direction > 0 ? 0 : family.Edges.Count - 1;
                FlowEdge previous = null;
                while (index >= 0 && index < family.Edges.Count)
                {
                    var edge = family.Edges[index];
                    int entry = direction > 0 ? family.Nodes[index] : family.Nodes[index + 1];
                    if (edge.ArrowFrom < 0) edge.ArrowFrom = entry;
                    Insert(family, edge, previous);
                    previous = edge; index += direction;
                }
            }
            foreach (var edge in Edges)
            {
                foreach (var family in edge.Order)
                {
                    bool forward = edge.ArrowFrom == family.Nodes[family.EdgeIndex[edge.Id]];
                    var wires = forward ? family.Wires : family.Wires.AsEnumerable().Reverse();
                    edge.Lanes.AddRange(wires);
                }
                var arrow = edge.ArrowFrom == edge.From ? edge.Direction : -edge.Direction;
                float coordinateSign = edge.Horizontal ? arrow.x : -arrow.y;
                for (int i = 0; i < edge.Lanes.Count; i++)
                    edge.Offsets[edge.Lanes[i].Id] =
                        coordinateSign * ((edge.Lanes.Count - 1) * .5f - i);
            }
            KeepStraightTracks(tightPacking);
            if (splitPassages)
                foreach (var edge in Edges)
                {
                    // Разделяем переполненный длинный проход на пучки между свободными узлами.
                    // Порядок сохраняется, но закончившиеся дорожки больше не оставляют пустот.
                    edge.Lanes.Sort((a, b) => edge.Offsets[a.Id].CompareTo(edge.Offsets[b.Id]));
                    for (int i = 0; i < edge.Lanes.Count; i++) edge.Offsets[edge.Lanes[i].Id] = i - (edge.Lanes.Count - 1) * .5f;
                    edge.MinOffset = -(edge.Lanes.Count - 1) * .5f; edge.MaxOffset = -edge.MinOffset;
                }
        }

        void KeepStraightTracks(bool tightPacking)
        {
            // Согласуем порядок на всём прямом проходе: после ответвления соседние линии не центрируются заново.
            var visited = new HashSet<int>();
            foreach (var seed in Edges)
            {
                if (!visited.Add(seed.Id)) continue;
                var component = new List<FlowEdge>();
                var queue = new Queue<FlowEdge>();
                queue.Enqueue(seed);
                while (queue.Count > 0)
                {
                    var edge = queue.Dequeue(); component.Add(edge);
                    foreach (int node in new[] { edge.From, edge.To })
                    foreach (var next in Nodes[node].Edges)
                        if (next.Horizontal == edge.Horizontal && !visited.Contains(next.Id) &&
                            edge.Lanes.Any(w => next.Offsets.ContainsKey(w.Id)))
                        { visited.Add(next.Id); queue.Enqueue(next); }
                }
                var wires = component.SelectMany(e => e.Lanes).Distinct().ToDictionary(w => w.Id);
                var following = wires.Keys.ToDictionary(id => id, _ => new HashSet<int>());
                var incoming = wires.Keys.ToDictionary(id => id, _ => 0);
                var preference = wires.Keys.ToDictionary(id => id, _ => 0f);
                var appearances = wires.Keys.ToDictionary(id => id, _ => 0);
                foreach (var edge in component)
                {
                    var order = edge.Lanes.OrderBy(w => edge.Offsets[w.Id]).ToList();
                    for (int i = 0; i < order.Count; i++)
                    {
                        int id = order[i].Id;
                        preference[id] += (i + .5f) / order.Count; appearances[id]++;
                        if (i + 1 < order.Count && following[id].Add(order[i + 1].Id)) incoming[order[i + 1].Id]++;
                    }
                }
                // Топологическая сортировка ограничений «эта дорожка раньше следующей».
                var pending = new HashSet<int>(wires.Keys); var ranks = new Dictionary<int, int>();
                var ready = new SortedSet<(float Preference, int Id)>();
                foreach (int id in pending)
                {
                    preference[id] /= appearances[id];
                    if (incoming[id] == 0) ready.Add((preference[id], id));
                }
                while (pending.Count > 0)
                {
                    int id;
                    if (ready.Count > 0) { id = ready.Min.Id; ready.Remove(ready.Min); }
                    else
                    {
                        // При цикле ограничений сохраняем детерминированный выбор и отмечаем конфликтный узел.
                        id = pending.OrderBy(p => incoming[p]).ThenBy(p => preference[p]).ThenBy(p => p).First();
                        var junction = component.SelectMany(e => new[] { e.From, e.To }).Distinct()
                            .FirstOrDefault(n => Nodes[n].Edges.Count > 2);
                        CrossingNodes.Add(junction);
                    }
                    if (!pending.Remove(id)) continue;
                    ranks.Add(id, ranks.Count);
                    foreach (int next in following[id])
                        if (--incoming[next] == 0 && pending.Contains(next)) ready.Add((preference[next], next));
                }
                // Линии без общего продольного участка могут занимать одну дорожку.
                // Отдельный ранг для каждой линии оставил бы пустоты и чрезмерно уменьшил весь пучок.
                var tracks = wires.Keys.ToDictionary(id => id, _ => 0);
                var separation = wires.Keys.ToDictionary(id => id, _ => new HashSet<int>());
                foreach (var edge in component)
                {
                    edge.Lanes.Sort((a, b) => ranks[a.Id].CompareTo(ranks[b.Id]));
                    for (int i = 1; i < edge.Lanes.Count; i++)
                        separation[edge.Lanes[i - 1].Id].Add(edge.Lanes[i].Id);
                }
                foreach (int id in ranks.Keys.OrderBy(id => ranks[id]))
                    foreach (int next in separation[id]) tracks[next] = Math.Max(tracks[next], tracks[id] + 1);
                // Этот расчёт уже переиспользует дорожки у не встречающихся линий.
                // В резервном режиме тоже сохраняем его результат: повторный выбор
                // первой свободной дорожки менял порядок перед ответвлениями.
                if (tightPacking) tracks = PackTracks(component, ranks);
                float center = tracks.Values.Max() * .5f;
                foreach (var edge in component)
                {
                    foreach (var wire in edge.Lanes) edge.Offsets[wire.Id] = tracks[wire.Id] - center;
                    if (CompactTracks) edge.Lanes.Sort((a, b) => tracks[a.Id].CompareTo(tracks[b.Id]));
                    edge.MinOffset = edge.Lanes.Min(w => edge.Offsets[w.Id]);
                    edge.MaxOffset = edge.Lanes.Max(w => edge.Offsets[w.Id]);
                }
            }
        }

        Dictionary<int, int> PackTracks(List<FlowEdge> component, Dictionary<int, int> ranks)
        {
            // В тесном проходе сначала переиспользуем дорожки непересекающихся
            // продольных интервалов, затем согласуем порядок полученных дорожек.
            var intervals = ranks.Keys.ToDictionary(id => id, _ => new Vector2(float.PositiveInfinity, float.NegativeInfinity));
            foreach (var edge in component)
            {
                var a = Nodes[edge.From].Point; var b = Nodes[edge.To].Point;
                float low = edge.Horizontal ? Mathf.Min(a.x, b.x) : Mathf.Min(a.y, b.y);
                float high = edge.Horizontal ? Mathf.Max(a.x, b.x) : Mathf.Max(a.y, b.y);
                foreach (var wire in edge.Lanes)
                    intervals[wire.Id] = new Vector2(Mathf.Min(intervals[wire.Id].x, low), Mathf.Max(intervals[wire.Id].y, high));
            }
            var ends = new List<float>(); var tracks = new Dictionary<int, int>();
            foreach (int id in ranks.Keys.OrderBy(id => intervals[id].x).ThenByDescending(id => intervals[id].y).ThenBy(id => ranks[id]))
            {
                int track = ends.FindIndex(end => end <= intervals[id].x);
                if (track < 0) { track = ends.Count; ends.Add(intervals[id].y); }
                else ends[track] = intervals[id].y;
                tracks[id] = track;
            }
            var following = Enumerable.Range(0, ends.Count).Select(_ => new HashSet<int>()).ToArray();
            var incoming = new int[ends.Count];
            foreach (var edge in component)
            for (int i = 1; i < edge.Lanes.Count; i++)
            {
                int before = tracks[edge.Lanes[i - 1].Id], after = tracks[edge.Lanes[i].Id];
                if (following[before].Add(after)) incoming[after]++;
            }
            var preference = tracks.GroupBy(p => p.Value).ToDictionary(g => g.Key, g => g.Average(p => (double)ranks[p.Key]));
            var pending = new HashSet<int>(Enumerable.Range(0, ends.Count));
            var ready = new SortedSet<(double Preference, int Id)>();
            foreach (int id in pending) if (incoming[id] == 0) ready.Add((preference[id], id));
            var order = new int[ends.Count];
            for (int position = 0; pending.Count > 0; position++)
            {
                int id = ready.Count > 0 ? ready.Min.Id : pending.OrderBy(t => incoming[t]).ThenBy(t => preference[t]).ThenBy(t => t).First();
                ready.Remove((preference[id], id)); pending.Remove(id); order[id] = position;
                foreach (int next in following[id])
                    if (--incoming[next] == 0 && pending.Contains(next)) ready.Add((preference[next], next));
            }
            foreach (int id in ranks.Keys) tracks[id] = order[tracks[id]];
            foreach (var edge in component)
            for (int i = 1; i < edge.Lanes.Count; i++)
                if (tracks[edge.Lanes[i - 1].Id] > tracks[edge.Lanes[i].Id])
                    CrossingNodes.Add(Nodes[edge.From].Edges.Count > 2 ? edge.From : edge.To);
            return tracks;
        }

        void Insert(FlowFamily family, FlowEdge edge, FlowEdge previous)
        {
            // Наследуем порядок предыдущего участка, затем выбираем место с учётом будущих ответвлений.
            int lower = 0, upper = edge.Order.Count;
            if (previous != null && previous.OrderRanks.TryGetValue(family.Id, out int ownRank))
            {
                bool reverse = (previous.ArrowFrom == family.Nodes[family.EdgeIndex[previous.Id]]) !=
                    (edge.ArrowFrom == family.Nodes[family.EdgeIndex[edge.Id]]);
                if (reverse) ownRank = previous.Order.Count - 1 - ownRank;
                for (int i = 0; i < edge.Order.Count; i++)
                {
                    if (!previous.OrderRanks.TryGetValue(edge.Order[i].Id, out int oldRank)) continue;
                    if (reverse) oldRank = previous.Order.Count - 1 - oldRank;
                    if (oldRank < ownRank) lower = Math.Max(lower, i + 1);
                    else upper = Math.Min(upper, i);
                }
            }
            if (lower > upper)
            {
                CrossingNodes.Add(edge.ArrowFrom);
                lower = 0;
                upper = edge.Order.Count;
            }
            // За пределами унаследованного диапазона стоимость одинакова для любого
            // допустимого места. Сначала сравниваем только тех соседей, между которыми
            // ещё можно выбирать, затем при необходимости проверяем наличие конфликта.
            var comparisons = new int[upper - lower];
            int cost = 0;
            for (int i = lower; i < upper; i++)
            {
                int compare = Compare(edge.Order[i]);
                comparisons[i - lower] = compare;
                if (compare > 0) cost++;
            }
            int best = lower, bestCost = int.MaxValue;
            for (int slot = lower; slot <= upper; slot++)
            {
                if (cost < bestCost) { best = slot; bestCost = cost; }
                if (slot < upper) cost += comparisons[slot - lower] < 0 ? 1 : -1;
            }
            if (Nodes[edge.ArrowFrom].Edges.Count > 2 && (bestCost > 0 ||
                edge.Order.Take(lower).Any(f => Compare(f) < 0) || edge.Order.Skip(upper).Any(f => Compare(f) > 0)))
                CrossingNodes.Add(edge.ArrowFrom);
            edge.Order.Insert(best, family);
            // Обновляем только сдвинутый хвост вместо повторных IndexOf в каждом сравнении.
            for (int i = best; i < edge.Order.Count; i++) edge.OrderRanks[edge.Order[i].Id] = i;

            int Compare(FlowFamily other)
            {
                int compare = CompareFuture(family, other, edge, edge.ArrowFrom);
                if (compare == 0) compare = -CompareFuture(family, other, edge, edge.Other(edge.ArrowFrom));
                return compare == 0 ? family.Id.CompareTo(other.Id) : compare;
            }
        }

        int CompareFuture(FlowFamily a, FlowFamily b, FlowEdge first, int entry)
        {
            // Сравниваем первое реальное расхождение, пропуская общие рёбра обоих маршрутов.
            bool reversed = a.Id > b.Id;
            if (reversed) (a, b) = (b, a);
            var edge = first;
            // Индекс пары, как индекс ячейки в таблице: уникален для номеров этой сети.
            long pair = a.Id * familyStride + b.Id;
            var cache = edge.Divergence[entry == edge.From ? 0 : 1];
            if (cache != null && cache.TryGetValue(pair, out int cached)) return reversed ? -cached : cached;
            comparedSections.Clear();
            int order = 0;
            for (int step = 0; step < Math.Min(a.Edges.Count, b.Edges.Count); step++)
            {
                int side = entry == edge.From ? 0 : 1;
                cache = edge.Divergence[side];
                if (cache != null && cache.TryGetValue(pair, out order)) break;
                int exit = edge.Other(entry);
                var nextA = Next(a, edge, exit); var nextB = Next(b, edge, exit);
                if (nextA == nextB)
                {
                    if (nextA == null) break;
                    // Запоминаем только продолжение общего прохода. На самом разветвлении
                    // эту пару сравнивают один раз; отдельная запись там не окупается.
                    if (cache == null) edge.Divergence[side] = cache = new Dictionary<long, int>();
                    comparedSections.Add(cache);
                    entry = exit; edge = nextA; continue;
                }
                var incoming = entry == edge.From ? edge.Direction : -edge.Direction;
                float turnA = nextA == null ? 0 : Vector3.Cross(incoming,
                    exit == nextA.From ? nextA.Direction : -nextA.Direction).z;
                float turnB = nextB == null ? 0 : Vector3.Cross(incoming,
                    exit == nextB.From ? nextB.Direction : -nextB.Direction).z;
                order = turnB.CompareTo(turnA); break;
            }
            foreach (var section in comparedSections) section[pair] = order;
            return reversed ? -order : order;
        }

        static FlowEdge Next(FlowFamily family, FlowEdge edge, int exit)
        {
            if (!family.EdgeIndex.TryGetValue(edge.Id, out int index)) return null;
            if (family.Nodes[index + 1] == exit) return index + 1 < family.Edges.Count ? family.Edges[index + 1] : null;
            return index > 0 ? family.Edges[index - 1] : null;
        }

        public List<Vector2> WirePath(FlowWire wire, float pitch)
        {
            // Сохраняем связь углов с узлами сети для последующего расчёта общих скруглений.
            var family = wire.Family; var points = new List<Vector2>();
            wire.CornerNodes.Clear();
            int key = wire.Id;
            for (int i = 0; i < family.Nodes.Count; i++)
            {
                var point = Nodes[family.Nodes[i]].Point;
                if (i > 0)
                {
                    var edge = family.Edges[i - 1];
                    if (edge.Horizontal) point.y = edge.TrackOrigin + (edge.TrackShift + edge.Offsets[key]) * pitch;
                    else point.x = edge.TrackOrigin + (edge.TrackShift + edge.Offsets[key]) * pitch;
                }
                if (i < family.Edges.Count)
                {
                    var edge = family.Edges[i];
                    if (edge.Horizontal) point.y = edge.TrackOrigin + (edge.TrackShift + edge.Offsets[key]) * pitch;
                    else point.x = edge.TrackOrigin + (edge.TrackShift + edge.Offsets[key]) * pitch;
                }
                if (i > 0 && i < family.Edges.Count && family.Edges[i - 1].Horizontal == family.Edges[i].Horizontal)
                {
                    var incoming = point;
                    var before = family.Edges[i - 1];
                    if (before.Horizontal) incoming.y = before.TrackOrigin + (before.TrackShift + before.Offsets[key]) * pitch;
                    else incoming.x = before.TrackOrigin + (before.TrackShift + before.Offsets[key]) * pitch;
                    Add(incoming, family.Nodes[i]);
                }
                Add(point, family.Nodes[i]);
            }
            return points;

            void Add(Vector2 p, int node)
            {
                if (points.Count > 0 && points[points.Count - 1].Equals(p)) return;
                while (points.Count > 1)
                {
                    var a = points[points.Count - 2]; var b = points[points.Count - 1];
                    // До скругления все звенья параллельны осям: промежуточную точку
                    // прямой узнаём по общей координате, без векторных преобразований.
                    if ((a.x != b.x || b.x != p.x) && (a.y != b.y || b.y != p.y)) break;
                    points.RemoveAt(points.Count - 1); wire.CornerNodes.RemoveAt(wire.CornerNodes.Count - 1);
                }
                points.Add(p); wire.CornerNodes.Add(node);
            }
        }
    }
}


