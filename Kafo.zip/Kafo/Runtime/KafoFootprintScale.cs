using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    /// <summary>Document-relative FP area, quantized to compact integer rectangles.</summary>
    sealed class KafoFootprintScale
    {
        readonly Dictionary<string,Vector2Int> footprints=new Dictionary<string,Vector2Int>();
        public readonly int MinFp,MaxFp,MaxLength,MaxWidth;

        public KafoFootprintScale(NormalizedKafo source,KafoLayoutSettings settings)
        {
            MaxWidth=Mathf.Clamp(settings.MaxAsWidthCells>0?settings.MaxAsWidthCells:4,1,16);
            MaxLength=Mathf.Clamp(settings.MaxAsLengthCells>0?settings.MaxAsLengthCells:4,1,16);
            var valid=source.Systems.Where(s=>!s.UseMinimumFpSize&&s.FpCount>0).ToList();
            MinFp=valid.Count==0?0:valid.Min(s=>s.FpCount);
            MaxFp=valid.Count==0?0:valid.Max(s=>s.FpCount);
            foreach(var system in source.Systems)
            {
                double t=system.UseMinimumFpSize||system.FpCount<=0||MaxFp==MinFp?0:
                    ((double)system.FpCount-MinFp)/((double)MaxFp-MinFp);
                double area=1+Math.Max(0,Math.Min(1,t))*(MaxLength*MaxWidth-1);
                footprints[system.Key]=NearestRectangle(area);
            }
        }
        public Vector2Int Cells(NormalizedSystem system)=>footprints[system.Key];

        Vector2Int NearestRectangle(double area)
        {
            var best=Vector2Int.one;double error=double.MaxValue,aspect=double.MaxValue;
            for(int length=1;length<=MaxLength;length++)
            for(int width=1;width<=MaxWidth;width++)
            {
                double nextError=Math.Abs(length*width-area);
                double nextAspect=Math.Max(length,width)/(double)Math.Min(length,width);
                if(nextError<error-1e-9||Math.Abs(nextError-error)<=1e-9&&
                    (nextAspect<aspect-1e-9||Math.Abs(nextAspect-aspect)<=1e-9&&width>best.y))
                {
                    best=new Vector2Int(length,width);error=nextError;aspect=nextAspect;
                }
            }
            return best;
        }
        public string Description=>MinFp==0?"Все АС имеют минимальный размер: корректных fpCount нет.":
            MinFp==MaxFp?"Все корректные fpCount равны "+MinFp+": используется базовый размер АС 1×1.":
            "Размеры АС по диапазону fpCount "+MinFp+"…"+MaxFp+": от 1×1 до "+MaxLength+"×"+MaxWidth+" ячеек; исходные значения сохранены.";
    }
}
