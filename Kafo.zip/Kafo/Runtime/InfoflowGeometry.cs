using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    // Пространственный индекс корпусов: выбираем ячейки в ограничивающем прямоугольнике отрезка.
    internal sealed class InfoflowObstacleLookup
    {
        readonly IReadOnlyList<Rect> obstacles;
        readonly Dictionary<Vector2Int, List<int>> buckets = new Dictionary<Vector2Int, List<int>>();
        readonly HashSet<int> found = new HashSet<int>();
        readonly List<Rect> matches = new List<Rect>();
        readonly float step;

        public InfoflowObstacleLookup(IReadOnlyList<Rect> obstacles, float cellSize)
        {
            this.obstacles = obstacles; step = cellSize * 2;
            for (int i = 0; i < obstacles.Count; i++)
            {
                var r = obstacles[i];
                for (int x = Mathf.FloorToInt(r.xMin / step); x <= Mathf.FloorToInt(r.xMax / step); x++)
                for (int y = Mathf.FloorToInt(r.yMin / step); y <= Mathf.FloorToInt(r.yMax / step); y++)
                {
                    var key = new Vector2Int(x, y);
                    if (!buckets.TryGetValue(key, out var list)) buckets.Add(key, list = new List<int>());
                    list.Add(i);
                }
            }
        }

        public List<Rect> Query(Vector2 a, Vector2 b, float padding)
        {
            // Список переиспользуется; результат нужно обработать до следующего запроса.
            found.Clear(); matches.Clear();
            for (int x = Mathf.FloorToInt((Mathf.Min(a.x, b.x) - padding) / step);
                x <= Mathf.FloorToInt((Mathf.Max(a.x, b.x) + padding) / step); x++)
            for (int y = Mathf.FloorToInt((Mathf.Min(a.y, b.y) - padding) / step);
                y <= Mathf.FloorToInt((Mathf.Max(a.y, b.y) + padding) / step); y++)
                if (buckets.TryGetValue(new Vector2Int(x, y), out var list))
                    foreach (int index in list) if (found.Add(index)) matches.Add(obstacles[index]);
            return matches;
        }
    }

    public static class InfoflowGeometry
    {
        public static bool SegmentHitsRect(Vector2 a, Vector2 b, Rect rect, float padding = 0)
        {
            // Расширение прямоугольника на половину ширины учитывает ленту, а не только её ось.
            // Касание границы допустимо; пересечением считается попадание внутрь.
            double low = 0, high = 1;
            double left = rect.xMin - padding, right = rect.xMax + padding;
            double bottom = rect.yMin - padding, top = rect.yMax + padding;
            var delta = b - a;
            if (!Clip(a.x, delta.x, left, right) || !Clip(a.y, delta.y, bottom, top) || high <= low) return false;
            double middle = (low + high) * .5;
            double x = a.x + middle * delta.x, y = a.y + middle * delta.y;
            return x > left && x < right && y > bottom && y < top;

            bool Clip(double origin, double direction, double min, double max)
            {
                if (direction == 0) return origin >= min && origin <= max;
                double p = (min - origin) / direction, q = (max - origin) / direction;
                if (p > q) { double swap = p; p = q; q = swap; }
                low = Math.Max(low, p); high = Math.Min(high, q);
                return high >= low;
            }
        }

        public static bool Intersection(Vector2 a, Vector2 b, Vector2 c, Vector2 d, out Vector2 point)
        {
            point = default;
            // Большинство пар заведомо далеко друг от друга; точный расчёт нужен
            // только при пересечении их ограничивающих прямоугольников.
            if (Mathf.Max(a.x, b.x) < Mathf.Min(c.x, d.x) || Mathf.Max(c.x, d.x) < Mathf.Min(a.x, b.x) ||
                Mathf.Max(a.y, b.y) < Mathf.Min(c.y, d.y) || Mathf.Max(c.y, d.y) < Mathf.Min(a.y, b.y)) return false;
            var ab = b - a; var cd = d - c;
            double denominator = Vector3.Cross(ab, cd).z;
            if (denominator == 0) return false;
            double t = Vector3.Cross(c - a, cd).z / denominator;
            double u = Vector3.Cross(c - a, ab).z / denominator;
            if (t < 0 || t > 1 || u < 0 || u > 1) return false;
            // Для ортогонального узла сохраняем точные координаты сетки без погрешности интерполяции.
            point = ab.x == 0 && cd.y == 0 ? new Vector2(a.x, c.y) :
                ab.y == 0 && cd.x == 0 ? new Vector2(c.x, a.y) : a + ab * (float)t;
            return true;
        }

        public static List<Vector2> Simplify(List<Vector2> input)
        {
            var result = new List<Vector2>();
            foreach (var point in input)
            {
                if (result.Count > 0 && result[result.Count - 1].Equals(point)) continue;
                while (result.Count > 1 && Vector3.Cross(result[result.Count - 1] - result[result.Count - 2],
                    point - result[result.Count - 1]).z == 0) result.RemoveAt(result.Count - 1);
                result.Add(point);
            }
            return result;
        }

        public static List<Vector2> RemoveLoops(List<Vector2> input)
        {
            // Вырезаем замкнувшийся участок между несмежными отрезками и начинаем проверку заново.
            var points = Simplify(input);
            for (int i = 1; i < points.Count; i++)
            for (int j = i + 2; j < points.Count; j++)
            {
                if (!Intersection(points[i - 1], points[i], points[j - 1], points[j], out var hit)) continue;
                points.RemoveRange(i, j - i);
                points.Insert(i, hit);
                points = Simplify(points);
                i = 0; break;
            }
            return points;
        }

        public static void Round(InfoflowRoute route, float[] radii, int steps)
        {
            // Радиусы уже согласованы между дорожками. Здесь только строятся касательные четверти окружностей.
            route.Points.Clear(); route.Arcs.Clear();
            route.Points.Add(route.Corners[0]);
            for (int i = 1; i + 1 < route.Corners.Count; i++)
            {
                var before = (route.Corners[i] - route.Corners[i - 1]).normalized;
                var after = (route.Corners[i + 1] - route.Corners[i]).normalized;
                float radius = radii[i];
                float turn = Vector3.Cross(before, after).z;
                if (radius <= 0 || Mathf.Abs(turn) < .5f) { route.Points.Add(route.Corners[i]); continue; }
                var start = route.Corners[i] - before * radius;
                var center = start + after * radius;
                float angle = Mathf.Atan2(-after.y, -after.x);
                route.Points.Add(start);
                for (int k = 1; k < steps; k++)
                {
                    float theta = angle + turn * Mathf.PI * .5f * k / steps;
                    route.Points.Add(center + new Vector2(Mathf.Cos(theta), Mathf.Sin(theta)) * radius);
                }
                route.Points.Add(route.Corners[i] + after * radius);
                route.Arcs.Add(new InfoflowArc { Center = center, Radius = radius, StartAngle = angle, Sweep = turn * Mathf.PI * .5f });
            }
            route.Points.Add(route.Corners[route.Corners.Count - 1]);
            route.Points = Simplify(route.Points);
        }

        internal static bool InsideRoutingBounds(InfoflowScene scene, IReadOnlyList<Vector2> points, float width)
        {
            if (!scene.RoutingBounds.HasValue) return true;
            var frame = scene.RoutingBounds.Value;
            float half = width * .5f;
            float left = frame.xMin + half, right = frame.xMax - half;
            float bottom = frame.yMin + half, top = frame.yMax - half;
            // Проверяем ленту целиком, включая дуги; Approximately допускает лишь погрешность float на границе.
            return points.All(p => (p.x >= left || Mathf.Approximately(p.x, left)) &&
                (p.x <= right || Mathf.Approximately(p.x, right)) &&
                (p.y >= bottom || Mathf.Approximately(p.y, bottom)) && (p.y <= top || Mathf.Approximately(p.y, top)));
        }

        public static List<string> Validate(InfoflowScene scene, InfoflowRoutingResult result)
        {
            // Собираем все дефектные линии за один проход: ранний выход после первых
            // сообщений оставлял остальные линии за пределами обязательного исправления.
            var errors = new HashSet<string>();
            var lookup = new InfoflowObstacleLookup(scene.Obstacles, scene.CellSize);
            var endpoints = scene.Endpoints.ToDictionary(e => e.Key);
            var horizontal = new Dictionary<float, List<(float Min, float Max, int Route)>>();
            var vertical = new Dictionary<float, List<(float Min, float Max, int Route)>>();
            var arcs = new HashSet<(Vector2 Center, float Radius, float Start, float Sweep)>();
            for (int n = 0; n < result.Routes.Count; n++)
            {
                var route = result.Routes[n]; var points = route.Points;
                if (points.Count < 2) { errors.Add("Нет геометрии: " + route.Key); continue; }
                if (!InsideRoutingBounds(scene, points, result.Width)) errors.Add("Выход за границы сегментов: " + route.Key);
                // Каждое звено дуги участвует во многих проверках своей линии.
                // Его диапазоны вычисляем один раз, точное пересечение оставляем прежним.
                var ranges = new (Vector2 Min, Vector2 Max)[points.Count - 1];
                for (int i = 1; i < points.Count; i++)
                    ranges[i - 1] = (Vector2.Min(points[i - 1], points[i]), Vector2.Max(points[i - 1], points[i]));
                for (int i = 1; i < points.Count; i++)
                {
                    var a = points[i - 1]; var b = points[i];
                    foreach (var obstacle in lookup.Query(a, b, result.Width * .5f))
                    {
                        // Первый и последний отрезки имеют право касаться своего корпуса в месте подключения.
                        if (i == 1 && endpoints.TryGetValue(route.ProviderKey, out var provider) && provider.Body.Equals(obstacle)) continue;
                        if (i == points.Count - 1 && endpoints.TryGetValue(route.ConsumerKey, out var consumer) && consumer.Body.Equals(obstacle)) continue;
                        if (SegmentHitsRect(a, b, obstacle, result.Width * .5f))
                        { errors.Add("Пересечение АС: " + route.Key); break; }
                    }
                    for (int j = i + 2; j < points.Count; j++)
                    {
                        var first = ranges[i - 1]; var second = ranges[j - 1];
                        if (first.Max.x < second.Min.x || second.Max.x < first.Min.x ||
                            first.Max.y < second.Min.y || second.Max.y < first.Min.y) continue;
                        if (Intersection(a, b, points[j - 1], points[j], out _))
                        { errors.Add("Самопересечение: " + route.Key); break; }
                    }
                    // В обычной разводке наложения допустимы лишь в веере подключения.
                    // Последний резерв отдельно разрешает наложения разных потоков;
                    // корпуса АС и самопересечения по-прежнему проверяются строго.
                    bool portFan = i < route.StartFanPointCount || i > points.Count - route.EndFanPointCount;
                    if (!portFan && !result.UsedCrossingFallback && a.x == b.x) Add(vertical, a.x, a.y, b.y, n);
                    else if (!portFan && !result.UsedCrossingFallback && a.y == b.y) Add(horizontal, a.y, a.x, b.x, n);
                }
                foreach (var arc in route.Arcs)
                    if (!arcs.Add((arc.Center, arc.Radius, arc.StartAngle, arc.Sweep)) && !result.UsedCrossingFallback) errors.Add("Совпадающие дуги: " + route.Key);
            }
            foreach (var group in horizontal.Values.Concat(vertical.Values))
            {
                group.Sort((a, b) => a.Min.CompareTo(b.Min));
                for (int i = 0; i < group.Count; i++)
                for (int j = i + 1; j < group.Count && group[j].Min < group[i].Max; j++)
                    if (group[i].Route != group[j].Route) errors.Add("Совпадающие прямые участки.");
            }
            return errors.ToList();

            void Add(Dictionary<float, List<(float Min, float Max, int Route)>> groups, float coordinate, float a, float b, int route)
            {
                if (!groups.TryGetValue(coordinate, out var list)) groups.Add(coordinate, list = new List<(float, float, int)>());
                list.Add((Mathf.Min(a, b), Mathf.Max(a, b), route));
            }
        }
    }
}
