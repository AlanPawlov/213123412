using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace Sbrt.Av.Gameplay
{
    [Serializable] public class AsDataModel { public long Id; public string Name; public int FpCount; }
    [Serializable] public class AsPlacementDataModel { public long AsId; public string Segment; public string Group; }
    [Serializable] public class KafoDataModel
    {
        public long Id; public string Name;
        public List<string> Segments = new List<string>();
        public List<AsPlacementDataModel> Placements = new List<AsPlacementDataModel>();
    }
    [Serializable] public class KafoDocument
    {
        public KafoDataModel Kafo = new KafoDataModel();
        public List<AsDataModel> Systems = new List<AsDataModel>();
    }
    public sealed class NormalizedSystem
    {
        public string Key, Name; public long Id; public int FpCount; public JToken Original;
        public bool UseMinimumFpSize;
    }
    public sealed class NormalizedSegment { public string Key, Name, RawName; }
    public sealed class NormalizedPlacement
    {
        public string Key, SystemKey, SegmentKey, Group; public JToken Original;
    }
    public sealed class NormalizedKafo
    {
        public string Name;
        public readonly List<NormalizedSystem> Systems = new List<NormalizedSystem>();
        public readonly List<NormalizedSegment> Segments = new List<NormalizedSegment>();
        public readonly List<NormalizedPlacement> Placements = new List<NormalizedPlacement>();
        public readonly List<string> Diagnostics = new List<string>();
        public int SourceSystemCount, SourcePlacementCount, SourceSegmentCount;
    }

    /// <summary>Record-by-record recovery. Source JSON is never rewritten.</summary>
    public static class KafoDataLoader
    {
        static JToken Field(JToken token, string name) => (token as JObject)?.GetValue(name, StringComparison.OrdinalIgnoreCase);
        static string Text(JToken token) => token == null || token.Type == JTokenType.Null ? null :
            token.Type == JTokenType.String ? token.Value<string>() : token.ToString(Newtonsoft.Json.Formatting.None);
        static IEnumerable<JToken> Records(JToken token)
        {
            if (token == null || token.Type == JTokenType.Null) yield break;
            if (token is JArray array) { foreach (var row in array) yield return row; }
            else yield return token;
        }
        static string Display(string value, string fallback) => string.IsNullOrWhiteSpace(value) ? fallback : value;
        static bool Long(JToken token, out long value) => long.TryParse(Text(token), NumberStyles.Integer, CultureInfo.InvariantCulture, out value);

        public static NormalizedKafo Normalize(KafoDocument document) => Load(JToken.FromObject(document ?? new KafoDocument()));
        public static NormalizedKafo Load(string json)
        {
            if (string.IsNullOrWhiteSpace(json)) return Load(new JObject());
            try { return Load(JToken.Parse(json)); }
            catch (Newtonsoft.Json.JsonException e)
            {
                // Even an unreadable source remains represented rather than disappearing.
                var recovered = Load(new JObject { ["Systems"] = new JArray(new JObject {
                    ["Name"] = "Непрочитанные данные", ["FpCount"] = 1 }) });
                recovered.Systems[0].Original = new JValue(json);
                recovered.Systems[0].UseMinimumFpSize = true;
                recovered.Diagnostics.Add("JSON не разобран; исходный текст сохранён в объекте-заглушке: " + e.Message);
                return recovered;
            }
        }
        public static NormalizedKafo Load(JToken root)
        {
            var result = new NormalizedKafo();
            var kfo = Field(root, "Kafo") ?? root;
            result.Name = Display(Text(Field(kfo, "Name")), "KFO");
            var firstById = new Dictionary<long, NormalizedSystem>();
            var firstSegment = new Dictionary<string, NormalizedSegment>(StringComparer.Ordinal);
            foreach (var row in Records(Field(root, "Systems")))
            {
                int index = result.SourceSystemCount++;
                bool hasId = Long(Field(row, "Id"), out long id);
                var fpToken = Field(row, "FpCount");
                bool validFp = Long(fpToken, out long fp) && fp > 0 && fp <= int.MaxValue;
                var system = new NormalizedSystem { Key = "system:" + index, Id = id,
                    Name = Display(Text(Field(row, "Name")), hasId ? "АС " + id : "АС без имени " + (index + 1)),
                    FpCount = validFp ? (int)fp : 1, UseMinimumFpSize = !validFp, Original = row.DeepClone() };
                result.Systems.Add(system);
                if (!validFp) result.Diagnostics.Add(system.Name + ": fpCount заменён минимальным размером; исходное значение сохранено.");
                if (hasId && !firstById.ContainsKey(id)) firstById.Add(id, system);
                else if (hasId) result.Diagnostics.Add("Повтор ID " + id + ": дополнительная запись сохранена как отдельная АС.");
                else result.Diagnostics.Add(system.Name + ": назначен внутренний идентификатор.");
            }
            foreach (var row in Records(Field(kfo, "Segments")))
            {
                int index = result.SourceSegmentCount++;
                string raw = Text(row);
                var segment = new NormalizedSegment { Key = "segment:" + index, RawName = raw,
                    Name = Display(raw, "Сегмент без имени " + (index + 1)) };
                result.Segments.Add(segment);
                if (raw != null && !firstSegment.ContainsKey(raw)) firstSegment.Add(raw, segment);
                else result.Diagnostics.Add(segment.Name + ": повторная или безымянная запись сегмента сохранена.");
            }
            foreach (var row in Records(Field(kfo, "Placements")))
            {
                int index = result.SourcePlacementCount++;
                bool hasId = Long(Field(row, "AsId"), out long id);
                if (!hasId || !firstById.TryGetValue(id, out var system))
                {
                    system = new NormalizedSystem { Key = "placeholder:" + index, Id = id, FpCount = 1, UseMinimumFpSize = true,
                        Name = hasId ? "АС " + id + " (нет описания)" : "АС без ID " + (index + 1), Original = row.DeepClone() };
                    result.Systems.Add(system);
                    if (hasId) firstById[id] = system;
                    result.Diagnostics.Add(system.Name + ": создано недостающее описание.");
                }
                string segmentName = Text(Field(row, "Segment"));
                string segmentKey = null;
                if (segmentName != null)
                {
                    if (!firstSegment.TryGetValue(segmentName, out var segment))
                    {
                        segment = new NormalizedSegment { Key = "inferred-segment:" + result.Segments.Count,
                            RawName = segmentName, Name = Display(segmentName, "Сегмент без имени " + (result.Segments.Count + 1)) };
                        result.Segments.Add(segment); firstSegment.Add(segmentName, segment);
                        result.Diagnostics.Add(segment.Name + ": сегмент создан из ссылки размещения.");
                    }
                    segmentKey = segment.Key;
                }
                result.Placements.Add(new NormalizedPlacement { Key = "placement:" + index, SystemKey = system.Key,
                    SegmentKey = segmentKey, Group = Text(Field(row, "Group")), Original = row.DeepClone() });
            }
            var placed = new HashSet<string>(result.Placements.Select(p => p.SystemKey));
            foreach (var system in result.Systems)
                if (!placed.Contains(system.Key)) result.Placements.Add(new NormalizedPlacement {
                    Key = "implicit:" + system.Key, SystemKey = system.Key, SegmentKey = null });
            return result;
        }
    }
}
