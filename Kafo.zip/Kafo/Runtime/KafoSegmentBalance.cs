using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public static partial class KafoLayoutSolver
    {
        sealed class BalanceBlock
        {
            public Rect Original,Rect,Title;
            public GroupLayout Group;
            public readonly List<AsLayout> Systems=new List<AsLayout>();
        }
        struct BalanceInterval
        {
            public float Min,Max;
            public BalanceInterval(float min,float max){Min=min;Max=max;}
        }

        // Run once after scale search. Feasibility caches retain their compact layouts.
        // Move whole grid tracks; never resize an AS, split a group, or move a bridge.
        static void BalanceMain(Context c,KafoLayoutResult layout)
        {
            var originalSystems=layout.Systems.Select(a=>a.Rect).ToArray();
            var originalGroups=layout.Groups.Select(g=>g.Rect).ToArray();
            var originalTitles=layout.Groups.Select(g=>g.TitleRect).ToArray();
            bool transpose=!layout.BridgesAlongX;
            float scale=layout.CellScale,pad=c.Pad*scale,gap=c.Gap*scale,clearance=c.TitleClearance*scale;
            var bridgeGroups=new HashSet<string>(layout.Systems.Where(a=>a.IsBridge).SelectMany(a=>a.GroupKeys));
            Rect Logical(Rect rect)=>ToLogical(layout.MainRect,rect,transpose);
            Rect World(Rect rect)=>MapFromLogical(layout.MainRect,rect,transpose);
            foreach(var segment in layout.Segments)
            {
                var bounds=Logical(segment.Rect);
                var inner=Rect.MinMaxRect(bounds.xMin+pad,bounds.yMin+pad,bounds.xMax-pad,bounds.yMax-pad);
                if(inner.width<=0||inner.height<=0)continue;
                var blocks=new List<BalanceBlock>();var fixedRects=new List<Rect>();
                var fixedShadows=new List<Rect>{BalanceShadow(Logical(segment.TitleRect),clearance)};
                foreach(var group in layout.Groups.Where(g=>g.SegmentKey==segment.Key))
                {
                    var rect=Logical(group.Rect);var title=Logical(group.TitleRect);
                    if(bridgeGroups.Contains(group.Key)){fixedRects.Add(rect);fixedShadows.Add(BalanceShadow(title,clearance));continue;}
                    var block=new BalanceBlock{Original=rect,Rect=rect,Title=title,Group=group};
                    block.Systems.AddRange(layout.Systems.Where(a=>!a.IsBridge&&a.GroupKeys.Contains(group.Key)));blocks.Add(block);
                }
                foreach(var a in layout.Systems.Where(a=>a.SegmentKeys.Contains(segment.Key)))
                {
                    if(a.IsBridge){fixedRects.Add(KafoLayoutResult.Intersection(bounds,Logical(a.Rect)));continue;}
                    if(a.GroupKeys.Count>0)continue;
                    var rect=Logical(a.Rect);var block=new BalanceBlock{Original=rect,Rect=rect};block.Systems.Add(a);blocks.Add(block);
                }
                if(blocks.Count==0)continue;
                // Full crossing corridors divide the available grid into independent bands.
                var xBands=BalanceFreeBands(inner,fixedRects,gap,false);
                var yBands=BalanceFreeBands(inner,fixedRects,gap,true);
                foreach(var xb in xBands)foreach(var yb in yBands)
                {
                    var area=Rect.MinMaxRect(xb.Min,yb.Min,xb.Max,yb.Max);
                    var members=blocks.Where(b=>KafoLayoutResult.Contains(area,b.Rect,.00001f)).ToList();
                    if(members.Count==0)continue;
                    var obstacles=new List<Rect>(fixedRects);var shadows=new List<Rect>(fixedShadows);
                    foreach(var other in blocks.Except(members))
                    {
                        obstacles.Add(other.Rect);if(other.Group!=null)shadows.Add(BalanceShadow(other.Title,clearance));
                    }
                    BalanceAxis(members,area,obstacles,shadows,gap,clearance,c.GroupPad*scale,(c.Metrics.AsSize.x+c.Gap)*scale,false,true);
                    BalanceAxis(members,area,obstacles,shadows,gap,clearance,0,(c.Metrics.AsSize.z+c.Gap)*scale,true,true);
                    // Moving in the other axis can free a previously obstructed translation.
                    BalanceAxis(members,area,obstacles,shadows,gap,clearance,c.GroupPad*scale,(c.Metrics.AsSize.x+c.Gap)*scale,false,false);
                    BalanceAxis(members,area,obstacles,shadows,gap,clearance,0,(c.Metrics.AsSize.z+c.Gap)*scale,true,false);
                }
                foreach(var block in blocks)
                {
                    var delta=block.Rect.position-block.Original.position;
                    if(block.Group!=null){block.Group.Rect=World(block.Rect);block.Group.TitleRect=World(block.Title);}
                    foreach(var a in block.Systems){var rect=Logical(a.Rect);rect.position+=delta;a.Rect=World(rect);}
                }
            }
            if(layout.Validate(c.Source).Count==0)return;
            // A cosmetic pass must never invalidate a complete, feasible packing.
            for(int i=0;i<layout.Systems.Count;i++)layout.Systems[i].Rect=originalSystems[i];
            for(int i=0;i<layout.Groups.Count;i++){layout.Groups[i].Rect=originalGroups[i];layout.Groups[i].TitleRect=originalTitles[i];}
            layout.Diagnostics.Add("Сохранена исходная безопасная сетка: выравнивание ограничено препятствиями.");
        }
        static Rect BalanceShadow(Rect title,float clearance)=>Rect.MinMaxRect(title.xMin-clearance,title.yMin,title.xMax,title.yMax+clearance);
        static float BalanceMin(Rect rect,bool y)=>y?rect.yMin:rect.xMin;
        static float BalanceMax(Rect rect,bool y)=>y?rect.yMax:rect.xMax;
        static Rect BalanceShift(Rect rect,float delta,bool y){rect.position+=y?new Vector2(0,delta):new Vector2(delta,0);return rect;}

        static List<BalanceInterval> BalanceFreeBands(Rect area,List<Rect> obstacles,float gap,bool y)
        {
            var result=new List<BalanceInterval>{new BalanceInterval(BalanceMin(area,y),BalanceMax(area,y))};
            foreach(var rect in obstacles)
                if(BalanceMin(rect,!y)<=BalanceMin(area,!y)+.00001f&&BalanceMax(rect,!y)>=BalanceMax(area,!y)-.00001f)
                    BalanceSubtract(result,BalanceMin(rect,y)-gap*.5f,BalanceMax(rect,y)+gap*.5f);
            return result;
        }
        static void BalanceSubtract(List<BalanceInterval> ranges,float min,float max)
        {
            for(int i=ranges.Count-1;i>=0;i--)
            {
                var range=ranges[i];if(max<=range.Min||min>=range.Max)continue;
                ranges.RemoveAt(i);
                if(max<range.Max)ranges.Insert(i,new BalanceInterval(max,range.Max));
                if(min>range.Min)ranges.Insert(i,new BalanceInterval(range.Min,min));
            }
        }
        static void BalanceAvoid(List<BalanceInterval> ranges,Rect moving,Rect obstacle,bool y)
        {
            if(BalanceMax(moving,!y)<=BalanceMin(obstacle,!y)+.000001f||BalanceMin(moving,!y)>=BalanceMax(obstacle,!y)-.000001f)return;
            BalanceSubtract(ranges,BalanceMin(obstacle,y)-BalanceMax(moving,y),BalanceMax(obstacle,y)-BalanceMin(moving,y));
        }
        static bool BalancePairsSafe(List<BalanceBlock> blocks,Rect[] rects,Rect[] titles,float gap,float clearance)
        {
            for(int i=0;i<blocks.Count;i++)for(int j=i+1;j<blocks.Count;j++)
            {
                if(KafoLayoutResult.Overlap(rects[i],Expand(rects[j],gap*.5f),.00001f))return false;
                if(blocks[i].Group!=null&&KafoLayoutResult.Overlap(BalanceShadow(titles[i],clearance),rects[j],.00001f))return false;
                if(blocks[j].Group!=null&&KafoLayoutResult.Overlap(BalanceShadow(titles[j],clearance),rects[i],.00001f))return false;
            }
            return true;
        }
        static double BalanceScore(Rect[] rects,Rect area,bool y)
        {
            float min=rects.Min(r=>BalanceMin(r,y)),max=rects.Max(r=>BalanceMax(r,y));
            float length=BalanceMax(area,y)-BalanceMin(area,y);
            double offCenter=Math.Abs((min+max)-(BalanceMin(area,y)+BalanceMax(area,y)))/length;
            return 4*offCenter-.08*(max-min)/length;
        }
        static void BalanceAxis(List<BalanceBlock> blocks,Rect area,List<Rect> obstacles,List<Rect> shadows,
            float gap,float clearance,float groupInset,float pitch,bool y,bool spread)
        {
            var current=blocks.Select(b=>b.Rect).ToArray();double bestScore=BalanceScore(current,area,y);
            Rect[] bestRects=null,bestTitles=null;
            float Anchor(BalanceBlock block)=>BalanceMin(block.Rect,y)+(block.Group!=null?groupInset:0);
            float first=blocks.Min(Anchor);
            // Add at most 65% of the original gap to each grid step, once per axis.
            float extra=spread?gap*.65f/Mathf.Max(.000001f,pitch):0;
            foreach(float factor in new[]{1f,1+extra*.5f,1+extra}.Distinct())
            {
                var rects=new Rect[blocks.Count];var titles=new Rect[blocks.Count];
                float low=float.NegativeInfinity,high=float.PositiveInfinity;
                for(int i=0;i<blocks.Count;i++)
                {
                    float shift=(Anchor(blocks[i])-first)*(factor-1);
                    rects[i]=BalanceShift(blocks[i].Rect,shift,y);titles[i]=BalanceShift(blocks[i].Title,shift,y);
                    low=Mathf.Max(low,BalanceMin(area,y)-BalanceMin(rects[i],y));
                    high=Mathf.Min(high,BalanceMax(area,y)-BalanceMax(rects[i],y));
                }
                if(low>high||!BalancePairsSafe(blocks,rects,titles,gap,clearance))continue;
                var ranges=new List<BalanceInterval>{new BalanceInterval(low,high)};
                for(int i=0;i<blocks.Count&&ranges.Count>0;i++)
                {
                    foreach(var obstacle in obstacles)
                    {
                        BalanceAvoid(ranges,rects[i],Expand(obstacle,gap*.5f),y);
                        if(blocks[i].Group!=null)BalanceAvoid(ranges,BalanceShadow(titles[i],clearance),obstacle,y);
                    }
                    foreach(var shadow in shadows)BalanceAvoid(ranges,rects[i],shadow,y);
                }
                float ideal=(BalanceMin(area,y)+BalanceMax(area,y)-rects.Min(r=>BalanceMin(r,y))-rects.Max(r=>BalanceMax(r,y)))*.5f;
                foreach(var range in ranges)
                {
                    float delta=Mathf.Clamp(ideal,range.Min,range.Max);
                    var candidate=rects.Select(r=>BalanceShift(r,delta,y)).ToArray();
                    double score=BalanceScore(candidate,area,y);if(score>=bestScore-1e-7)continue;
                    var candidateTitles=titles.Select(r=>BalanceShift(r,delta,y)).ToArray();
                    // Keep numerical contact at interval endpoints from creating overlaps.
                    bool safe=true;
                    for(int i=0;i<blocks.Count&&safe;i++)
                    {
                        if(!KafoLayoutResult.Contains(area,candidate[i],.00001f)){safe=false;break;}
                        if(obstacles.Any(o=>KafoLayoutResult.Overlap(candidate[i],Expand(o,gap*.5f),.00001f))||shadows.Any(s=>KafoLayoutResult.Overlap(candidate[i],s,.00001f)))safe=false;
                        if(blocks[i].Group!=null&&obstacles.Any(o=>KafoLayoutResult.Overlap(BalanceShadow(candidateTitles[i],clearance),o,.00001f)))safe=false;
                    }
                    if(!safe)continue;bestScore=score;bestRects=candidate;bestTitles=candidateTitles;
                }
            }
            if(bestRects==null)return;
            for(int i=0;i<blocks.Count;i++){blocks[i].Rect=bestRects[i];blocks[i].Title=bestTitles[i];}
        }
    }
}
