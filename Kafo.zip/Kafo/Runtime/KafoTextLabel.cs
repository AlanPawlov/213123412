using TMPro;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    /// <summary>Fits TMP glyphs in a world-space face, independently of prefab scale, pivot and shear.</summary>
    [ExecuteAlways, DisallowMultipleComponent, RequireComponent(typeof(TextMeshPro))]
    [UnityEngine.Scripting.APIUpdating.MovedFrom(true,"Kafo","Kafo.Runtime",null)]
    public sealed class KafoTextLabel : MonoBehaviour
    {
        [SerializeField, HideInInspector] Vector3 topLeft;
        [SerializeField, HideInInspector] Quaternion orientation=Quaternion.identity;
        [SerializeField, HideInInspector] Vector2 area;
        [SerializeField, HideInInspector] bool configured;
        TextMeshPro label;

        void OnEnable()
        {
            label=GetComponent<TextMeshPro>();
            label.OnPreRenderText+=FitVertices;
            if(configured)label.ForceMeshUpdate(true,true);
        }
        void OnDisable(){if(label!=null)label.OnPreRenderText-=FitVertices;}

        public void Configure(string text,TMP_FontAsset font,Color color,Vector3 origin,Quaternion rotation,Vector2 size,float glyphHeight)
        {
            topLeft=origin;orientation=rotation;area=new Vector2(Mathf.Max(.00001f,size.x),Mathf.Max(.00001f,size.y));configured=true;
            transform.SetPositionAndRotation(origin,rotation);
            label=GetComponent<TextMeshPro>();
            label.font=font;label.text=text??"Без имени";label.color=color;
            label.richText=false;label.isOrthographic=false;
            label.alignment=TextAlignmentOptions.TopLeft;label.textWrappingMode=TextWrappingModes.Normal;
            label.overflowMode=TextOverflowModes.Overflow;
            label.rectTransform.pivot=new Vector2(0,1);label.rectTransform.sizeDelta=area;
            label.margin=Vector4.zero;
            float pointSize=glyphHeight*10*font.faceInfo.pointSize/Mathf.Max(1,font.faceInfo.capLine);
            label.fontSizeMin=pointSize*.01f;label.fontSizeMax=pointSize;label.fontSize=pointSize;
            label.enableAutoSizing=true;label.ForceMeshUpdate(true,true);
            float fitted=label.fontSize;
            label.enableAutoSizing=false;label.fontSize=fitted;label.ForceMeshUpdate(true,true);
        }

        void FitVertices(TMP_TextInfo info)
        {
            if(!configured)return;
            var min=new Vector3(float.PositiveInfinity,float.PositiveInfinity,0);
            var max=new Vector3(float.NegativeInfinity,float.NegativeInfinity,0);
            bool visible=false;
            for(int m=0;m<info.materialCount;m++)
            for(int i=0;i<info.meshInfo[m].vertexCount;i++)
            {
                var v=info.meshInfo[m].vertices[i];min=Vector3.Min(min,v);max=Vector3.Max(max,v);visible=true;
            }
            if(!visible)return;
            float scale=Mathf.Min(1,area.x/Mathf.Max(.000001f,max.x-min.x),area.y/Mathf.Max(.000001f,max.y-min.y));
            var bounds=new Bounds();bool first=true;
            var inverse=transform.worldToLocalMatrix;
            for(int m=0;m<info.materialCount;m++)
            for(int i=0;i<info.meshInfo[m].vertexCount;i++)
            {
                var v=info.meshInfo[m].vertices[i];
                var world=topLeft+orientation*new Vector3((v.x-min.x)*scale,(v.y-max.y)*scale,0);
                info.meshInfo[m].vertices[i]=inverse.MultiplyPoint3x4(world);
                if(first){bounds=new Bounds(world,Vector3.zero);first=false;}else bounds.Encapsulate(world);
            }
            foreach(var renderer in GetComponentsInChildren<MeshRenderer>())
            {
                KafoMeshResizer.ConfigureDynamicRenderer(renderer);
                renderer.bounds=bounds;
            }
        }
    }
}
