using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public enum KafoVisualKind { Application, Segment, Group }
    public static class KafoDefaultVisuals
    {
        static readonly Mesh[] meshes=new Mesh[3];
        static readonly Material[][] materials=new Material[3][];
        public static GameObject Create(KafoVisualKind kind)
        {
            int index=(int)kind;
            if(meshes[index]==null)
            {
                var size=kind==KafoVisualKind.Application?new Vector3(2,1.4f,2):new Vector3(2,kind==KafoVisualKind.Group?.045f:.22f,2);
                meshes[index]=KafoRoundedMesh.Create(size,.28f,kind==KafoVisualKind.Application?.065f:.015f);
                meshes[index].hideFlags=HideFlags.HideAndDontSave;
            }
            if(materials[index]==null || materials[index][0]==null)
            {
                var body=kind==KafoVisualKind.Application?new Color(.12f,.72f,.36f):kind==KafoVisualKind.Segment?new Color(.035f,.085f,.12f):new Color(.13f,.18f,.22f);
                materials[index]=new[]{Material("KFO "+kind+" Body",body),Material("KFO "+kind+" Cap",kind==KafoVisualKind.Application?new Color(.026f,.034f,.036f):body),
                    Material("KFO "+kind+" Rim",kind==KafoVisualKind.Application?new Color(.2f,.25f,.23f):body*1.3f)};
            }
            var root=new GameObject("KFO "+kind);
            if(kind==KafoVisualKind.Application)root.transform.localScale=new Vector3(.7f,.9f,.7f);
            root.AddComponent<MeshFilter>().sharedMesh=meshes[index];
            var renderer=root.AddComponent<MeshRenderer>();renderer.sharedMaterials=materials[index];
            var resizer=root.AddComponent<KafoMeshResizer>();resizer.BoundsRenderers=new Renderer[]{renderer};resizer.CaptureSource();
            return root;
        }
        static Material Material(string name,Color color)
        {
            var shader=Shader.Find("Universal Render Pipeline/Lit")??Shader.Find("Standard")??Shader.Find("Unlit/Color");
            var mat=new Material(shader){name=name,hideFlags=HideFlags.HideAndDontSave};
            mat.color=color;
            if(mat.HasProperty("_Smoothness"))mat.SetFloat("_Smoothness",.45f);
            return mat;
        }
    }
}
