using System.Collections.Generic;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    [UnityEngine.Scripting.APIUpdating.MovedFrom(true,"Kafo","Kafo.Runtime",null)]
    public sealed class KafoGeneratedItem : MonoBehaviour
    {
        public string Kind,Key,SystemKey;
        [TextArea] public string SourceRecord;
        public List<string> PlacementKeys=new List<string>();
        public Rect PlannedRect,TitleRect;
        public KafoMeshResizer Geometry;
    }
}
