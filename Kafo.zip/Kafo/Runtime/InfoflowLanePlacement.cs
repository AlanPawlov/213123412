using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    internal sealed class InfoflowPassageCapacityException : InvalidOperationException
    {
        public InfoflowPassageCapacityException()
            : base("Выбранные проходы не вмещают дорожки при минимальной ширине.") { }
    }
    internal sealed class InfoflowLanePlacement
    {
        const int MaxPackingVisits = 5000;
        readonly InfoflowNetwork network;
        readonly InfoflowScene scene;
        readonly Rect frame;
        readonly float clearance;
        readonly float radius, exitLength;
        readonly Dictionary<int, List<FlowBank>> exitBanks = new Dictionary<int, List<FlowBank>>();
        readonly Dictionary<(int Edge, Vector2 Span, bool Reserve), Vector2> bands =
            new Dictionary<(int, Vector2, bool), Vector2>();
        bool reserveTurns = true;
        bool compressPorts;
        bool onlyConnectedSpans;
        // Система непересекающихся множеств: объединённые рёбра имеют одну базовую координату.
        // displacement задаёт смещение ребра относительно представителя в шагах дорожек.
        readonly int[] parent;
        readonly float[] displacement;

        public InfoflowLanePlacement(InfoflowNetwork network, InfoflowScene scene, Rect frame, float clearance,
            float radius = 0, float exitLength = 0)
        {
            this.network = network;
            this.scene = scene;
            this.frame = frame;
            this.clearance = clearance;
            this.radius = radius;
            this.exitLength = exitLength;
            parent = new int[network.Edges.Count];
            displacement = new float[parent.Length];
            for (int i = 0; i < parent.Length; i++) parent[i] = i;
            foreach (var edge in network.Edges)
            {
                var point = network.Nodes[edge.From].Point;
                edge.Coordinate = edge.Horizontal ? point.y : point.x;
                // Выход ограничивает только первый поперечный участок от каждого конца.
                // Состав и порядок ограничений не зависят от подбираемого масштаба.
                var banks = new List<FlowBank>();
                foreach (var family in edge.Order)
                {
                    int index = family.EdgeIndex[edge.Id];
                    if (index > 0 && family.Edges.Take(index).All(e => e.Horizontal != edge.Horizontal))
                        banks.Add(family.Start);
                    if (index + 1 < family.Edges.Count && family.Edges.Skip(index + 1).All(e => e.Horizontal != edge.Horizontal))
                        banks.Add(family.End);
                }
                if (banks.Count > 0) exitBanks.Add(edge.Id, banks);
            }
            foreach (var node in network.Nodes)
            foreach (bool horizontal in new[] { false, true })
            {
                var straight = node.Edges.Where(e => e.Horizontal == horizontal).ToList();
                if (straight.Count != 2 || network.SplitPassages) continue;
                var a = straight[0]; var b = straight[1];
                var common = a.Lanes.Intersect(b.Lanes).ToList();
                if (common.Count == 0) continue;
                float shift = a.Offsets[common[0].Id] - b.Offsets[common[0].Id];
                if (common.All(w => Mathf.Approximately(a.Offsets[w.Id] - b.Offsets[w.Id], shift)))
                    Join(a.Id, b.Id, shift);
                else network.CrossingNodes.Add(node.Id);
            }
        }

        int Root(int edge)
        {
            if (parent[edge] == edge) return edge;
            int previous = parent[edge];
            parent[edge] = Root(previous);
            displacement[edge] += displacement[previous];
            return parent[edge];
        }

        void Join(int a, int b, float shift)
        {
            int ra = Root(a), rb = Root(b);
            if (ra == rb) return;
            parent[rb] = ra;
            displacement[rb] = displacement[a] + shift - displacement[b];
        }

        public float Place(float width, float gap, float minimumScale = 0)
        {
            // Сначала уменьшаем всю схему в заданных пределах. Только если минимум
            // не помещается в портах, разрешаем сжатие подключений у самой грани.
            if (network.SplitPassages) { compressPorts = true; onlyConnectedSpans = true; }
            for (int reservation = network.SplitPassages ? 7 : 0; reservation < 8; reservation++)
            {
                reserveTurns = reservation % 2 == 0;
                if (reservation == 4)
                {
                    // Последним убираем дополнительный запас на всю пересекающую магистраль.
                    // Фактические поворачивающие линии и корпуса по-прежнему ограничивают звено.
                    onlyConnectedSpans = true; compressPorts = false; bands.Clear();
                }
                if (reservation % 4 == 2) { compressPorts = true; bands.Clear(); }
                float scale = 1;
                foreach (var edge in network.Edges)
                {
                    Band(edge, 0, out float low, out float high);
                    float padding = Mathf.Min(clearance, (high - low) * .1f);
                    scale = Mathf.Min(scale, (high - low - padding * 2) /
                        (width + (edge.MaxOffset - edge.MinOffset) * (width + gap)));
                }
                scale = Mathf.Clamp(scale, minimumScale, 1);
                for (int attempt = 0; attempt < 16; attempt++)
                {
                    bool reorder = reservation % 4 == 3 && scale <= minimumScale;
                    if (PlaceAxis(false, width * scale, (width + gap) * scale, reorder) &&
                        PlaceAxis(true, width * scale, (width + gap) * scale, reorder)) return scale;
                    // Нижнюю границу проверяем точно, а не перескакиваем через неё очередным делением пополам.
                    if (scale <= minimumScale) break;
                    scale = Mathf.Max(minimumScale, scale * .5f);
                }
            }
            if (!network.SplitPassages) throw new InfoflowPassageCapacityException();
            // Последний резерв сохраняет каждую линию и её ширину. После исчерпания
            // других проходов разрешаем пересечения и наложения, явно отмечая уменьшение зазора.
            network.CrossingFallback = true;
            float pitch = width + gap;
            foreach (var edge in network.Edges)
            {
                Band(edge, 0, out float low, out float high);
                float available = Mathf.Max(0, high - low - width);
                float spacing = edge.Lanes.Count > 1 ? Mathf.Min(pitch, available / (edge.Lanes.Count - 1)) : 0;
                float extent = (edge.Lanes.Count - 1) * spacing * .5f;
                float left = low + width * .5f + extent, right = high - width * .5f - extent;
                edge.TrackOrigin = left <= right ? Mathf.Lerp(left, right, (edge.Id + 1f) / (network.Edges.Count + 1f)) : (low + high) * .5f;
                edge.TrackShift = 0;
                for (int i = 0; i < edge.Lanes.Count; i++) edge.Offsets[edge.Lanes[i].Id] = (i - (edge.Lanes.Count - 1) * .5f) * spacing / pitch;
                edge.MinOffset = edge.Offsets.Values.Min(); edge.MaxOffset = edge.Offsets.Values.Max();
                edge.Coordinate = edge.TrackOrigin;
            }
            return 1;
        }

        bool PlaceAxis(bool horizontal, float width, float pitch, bool reorder = false)
        {
            // Для горизонтальных рёбер выбираем координату Z, для вертикальных — X.
            var edges = network.Edges.Where(e => e.Horizontal == horizontal).ToList();
            var roots = edges.Select(e => Root(e.Id)).Distinct().ToList();
            var lower = new Dictionary<int, float>();
            var upper = new Dictionary<int, float>();
            var desired = new Dictionary<int, float>();
            foreach (int root in roots)
            {
                lower[root] = float.NegativeInfinity;
                upper[root] = float.PositiveInfinity;
                desired[root] = 0;
            }
            var counts = roots.ToDictionary(r => r, _ => 0);
            foreach (var edge in edges)
            {
                int root = Root(edge.Id);
                Band(edge, pitch, out float low, out float high);
                lower[root] = Mathf.Max(lower[root], low + width * .5f -
                    (edge.MinOffset + displacement[edge.Id]) * pitch);
                upper[root] = Mathf.Min(upper[root], high - width * .5f -
                    (edge.MaxOffset + displacement[edge.Id]) * pitch);
                var original = network.Nodes[edge.From].Point;
                desired[root] += horizontal ? original.y : original.x; counts[root]++;
            }
            foreach (int root in roots)
            {
                desired[root] /= counts[root];
                float padding = Mathf.Max(0, Mathf.Min(clearance, (upper[root] - lower[root]) * .1f));
                lower[root] += padding; upper[root] -= padding;
                desired[root] = Mathf.Clamp(desired[root], lower[root], upper[root]);
            }
            roots.Sort((a, b) =>
            {
                int order = desired[a].CompareTo(desired[b]);
                return order == 0 ? a.CompareTo(b) : order;
            });
            var rank = roots.Select((r, i) => (r, i)).ToDictionary(p => p.r, p => p.i);
            var constraints = roots.ToDictionary(r => r, _ => new Dictionary<int, float>());
            var spans = edges.ToDictionary(e => e.Id, e => Span(e, pitch));
            var byStart = edges.OrderBy(e => spans[e.Id].x).ToList();
            // Разделение нужно лишь пучкам с пересекающимися продольными диапазонами.
            for (int i = 0; i < byStart.Count; i++)
            {
                var a = byStart[i]; var sa = spans[a.Id];
                for (int j = i + 1; j < byStart.Count; j++)
                {
                    var b = byStart[j]; var sb = spans[b.Id];
                    if (sb.x >= sa.y) break;
                    int ra = Root(a.Id), rb = Root(b.Id);
                    if (ra == rb) continue;
                    var left = a; var right = b;
                    if (rank[ra] > rank[rb]) { (ra, rb) = (rb, ra); left = b; right = a; }
                    float distance = (left.MaxOffset - right.MinOffset + 1 +
                        displacement[left.Id] - displacement[right.Id]) * pitch;
                    if (!constraints[ra].TryGetValue(rb, out float old) || distance > old) constraints[ra][rb] = distance;
                }
            }
            // Прямой проход распространяет нижние границы, обратный — верхние.
            // Если интервалы несовместимы, вызывающий код пробует меньший общий масштаб.
            foreach (int root in roots)
            foreach (var constraint in constraints[root])
                lower[constraint.Key] = Mathf.Max(lower[constraint.Key], lower[root] + constraint.Value);
            for (int i = roots.Count - 1; i >= 0; i--)
                foreach (var constraint in constraints[roots[i]])
                    upper[roots[i]] = Mathf.Min(upper[roots[i]], upper[constraint.Key] - constraint.Value);
            if (roots.Any(r => lower[r] > upper[r]))
                return reorder && PackTracks(edges, roots, spans, width, pitch);
            var positions = roots.ToDictionary(r => r, r => Mathf.Clamp(desired[r], lower[r], upper[r]));
            foreach (int root in roots)
            foreach (var constraint in constraints[root])
                positions[constraint.Key] = Mathf.Max(positions[constraint.Key], positions[root] + constraint.Value);
            foreach (var edge in edges)
            {
                edge.TrackOrigin = positions[Root(edge.Id)]; edge.TrackShift = displacement[edge.Id];
                edge.Coordinate = edge.TrackOrigin + edge.TrackShift * pitch;
            }
            return true;

        }

        bool PackTracks(List<FlowEdge> edges, List<int> roots, Dictionary<int, Vector2> spans, float width, float pitch)
        {
            // Фиксированный порядок разных пучков может создать ложную тесноту.
            // Здесь меняется только их взаимное расположение; дорожки внутри пучка не переставляются.
            var low = roots.ToDictionary(r => r, _ => float.NegativeInfinity);
            var high = roots.ToDictionary(r => r, _ => float.PositiveInfinity);
            var intervals = roots.ToDictionary(r => r, _ => new Vector2(float.PositiveInfinity, float.NegativeInfinity));
            foreach (var edge in edges)
            {
                int r = Root(edge.Id); Band(edge, pitch, out float lo, out float hi);
                low[r] = Mathf.Max(low[r], lo + width * .5f - (edge.MinOffset + displacement[edge.Id]) * pitch);
                high[r] = Mathf.Min(high[r], hi - width * .5f - (edge.MaxOffset + displacement[edge.Id]) * pitch);
                intervals[r] = new Vector2(Mathf.Min(intervals[r].x, spans[edge.Id].x), Mathf.Max(intervals[r].y, spans[edge.Id].y));
            }
            if (roots.Any(r => low[r] > high[r])) return false;
            var neighbours = roots.ToDictionary(r => r, _ => new HashSet<int>());
            var distances = new Dictionary<(int A, int B), float>();
            var orderedEdges = edges.OrderBy(e => spans[e.Id].x).ToList();
            for (int i = 0; i < orderedEdges.Count; i++)
            for (int j = i + 1; j < orderedEdges.Count; j++)
            {
                var a = orderedEdges[i]; var b = orderedEdges[j];
                if (spans[b.Id].x >= spans[a.Id].y) break;
                int ra = Root(a.Id), rb = Root(b.Id); if (ra == rb) continue;
                neighbours[ra].Add(rb); neighbours[rb].Add(ra);
                AddDistance(ra, rb, (a.MaxOffset - b.MinOffset + 1 + displacement[a.Id] - displacement[b.Id]) * pitch);
                AddDistance(rb, ra, (b.MaxOffset - a.MinOffset + 1 + displacement[b.Id] - displacement[a.Id]) * pitch);
            }
            for (int order = 0; order < 4; order++)
            {
                var positions = new Dictionary<int, float>();
                var pending = order == 0 ? roots.OrderBy(r => intervals[r].x).ThenByDescending(r => intervals[r].y).ThenBy(r => r) :
                    order == 1 ? roots.OrderBy(r => high[r] - low[r]).ThenByDescending(r => intervals[r].y - intervals[r].x).ThenBy(r => r) :
                    order == 2 ? roots.OrderBy(r => high[r]).ThenBy(r => low[r]).ThenBy(r => r) : roots.OrderBy(r => low[r]).ThenBy(r => high[r]).ThenBy(r => r);
                bool complete = true;
                foreach (int r in pending)
                {
                    var occupied = neighbours[r].Where(positions.ContainsKey).ToArray();
                    var candidates = new List<float> { low[r] };
                    foreach (int other in occupied) candidates.Add(positions[other] + distances[(other, r)]);
                    bool placed = false;
                    foreach (float candidate in candidates.Where(p => p >= low[r] && p <= high[r]).OrderBy(p => p))
                    {
                        if (occupied.Any(other => candidate < positions[other] + distances[(other, r)] &&
                            !Mathf.Approximately(candidate, positions[other] + distances[(other, r)]) &&
                            candidate > positions[other] - distances[(r, other)] &&
                            !Mathf.Approximately(candidate, positions[other] - distances[(r, other)]))) continue;
                        positions[r] = candidate; placed = true; break;
                    }
                    if (!placed) { complete = false; break; }
                }
                if (!complete) continue;
                foreach (var edge in edges)
                {
                    edge.TrackOrigin = positions[Root(edge.Id)]; edge.TrackShift = displacement[edge.Id];
                    edge.Coordinate = edge.TrackOrigin + edge.TrackShift * pitch;
                }
                return true;
            }
            var solution = new Dictionary<int, float>();
            int visits = 0;
            if (Search())
            {
                foreach (var edge in edges)
                {
                    edge.TrackOrigin = solution[Root(edge.Id)]; edge.TrackShift = displacement[edge.Id];
                    edge.Coordinate = edge.TrackOrigin + edge.TrackShift * pitch;
                }
                return true;
            }
            return false;
            bool Search()
            {
                // После простого уплотнения выбираем самый ограниченный оставшийся диапазон.
                if (++visits > MaxPackingVisits) return false;
                if (solution.Count == roots.Count) return true;
                int selected = -1; List<Vector2> options = null; float best = float.PositiveInfinity;
                foreach (int r in roots)
                {
                    if (solution.ContainsKey(r)) continue;
                    var forbidden = neighbours[r].Where(solution.ContainsKey).Select(other =>
                        new Vector2(solution[other] - distances[(r, other)], solution[other] + distances[(other, r)]))
                        .OrderBy(p => p.x).ToArray();
                    var available = new List<Vector2>(); float cursor = low[r];
                    foreach (var interval in forbidden)
                    {
                        if (interval.y < cursor) continue;
                        if (interval.x > high[r]) break;
                        if (interval.x >= cursor) available.Add(new Vector2(cursor, Mathf.Min(high[r], interval.x)));
                        cursor = Mathf.Max(cursor, interval.y);
                        if (cursor > high[r]) break;
                    }
                    if (cursor <= high[r]) available.Add(new Vector2(cursor, high[r]));
                    if (available.Count == 0) return false;
                    float freedom = available.Sum(p => p.y - p.x);
                    if (freedom < best) { selected = r; options = available; best = freedom; }
                }
                foreach (var option in options)
                foreach (float candidate in option.x == option.y ? new[]{option.x} : new[]{option.x, option.y})
                {
                    solution[selected] = candidate;
                    if (Search()) return true;
                    solution.Remove(selected);
                    if (visits > MaxPackingVisits) return false;
                }
                return false;
            }
            void AddDistance(int a, int b, float value) { if (!distances.TryGetValue((a, b), out float old) || value > old) distances[(a, b)] = value; }
        }

        Vector2 Span(FlowEdge edge, float pitch)
        {
            var a = network.Nodes[edge.From]; var b = network.Nodes[edge.To];
            float low = edge.Horizontal ? Mathf.Min(a.Point.x, b.Point.x) : Mathf.Min(a.Point.y, b.Point.y);
            float high = edge.Horizontal ? Mathf.Max(a.Point.x, b.Point.x) : Mathf.Max(a.Point.y, b.Point.y);
            if (network.SplitPassages) return new Vector2(low, high);
            if (edge.Horizontal && pitch > 0)
            {
                foreach (var node in new[] { a, b })
                foreach (var other in node.Edges.Where(e => !e.Horizontal))
                {
                    if (!onlyConnectedSpans)
                    {
                        low = Mathf.Min(low, other.Coordinate + other.MinOffset * pitch);
                        high = Mathf.Max(high, other.Coordinate + other.MaxOffset * pitch);
                        continue;
                    }
                    // Граница звена зависит только от линий, которые действительно
                    // переходят в соседнее ребро. Чужая пересекающая магистраль его не расширяет.
                    foreach (var wire in edge.Lanes)
                    {
                        if (!other.Offsets.TryGetValue(wire.Id, out float offset)) continue;
                        float coordinate = other.TrackOrigin + (other.TrackShift + offset) * pitch;
                        low = Mathf.Min(low, coordinate); high = Mathf.Max(high, coordinate);
                    }
                }
            }
            return new Vector2(low, high);
        }

        void Band(FlowEdge edge, float pitch, out float low, out float high)
        {
            // Допустимый поперечный диапазон ограничен корпусами АС, портами и запасом для выхода.
            var span = Span(edge, pitch);
            if (bands.TryGetValue((edge.Id, span, reserveTurns), out var band))
            {
                low = band.x; high = band.y;
                return;
            }
            var point = network.Nodes[edge.From].Point;
            float coordinate = edge.Horizontal ? point.y : point.x;
            float lower = edge.Horizontal ? frame.yMin : frame.xMin; float upper = edge.Horizontal ? frame.yMax : frame.xMax;
            foreach (var obstacle in scene.Obstacles)
            {
                float near = edge.Horizontal ? obstacle.xMin : obstacle.yMin;
                float far = edge.Horizontal ? obstacle.xMax : obstacle.yMax;
                if (span.y < near || span.x > far) continue;
                float bottom = edge.Horizontal ? obstacle.yMin : obstacle.xMin;
                float top = edge.Horizontal ? obstacle.yMax : obstacle.xMax;
                if (coordinate <= bottom) upper = Mathf.Min(upper, bottom);
                else if (coordinate >= top) lower = Mathf.Max(lower, top);
                else if (span.y > near && span.x < far) { lower = coordinate; upper = coordinate; }
            }
            if (!compressPorts)
            foreach (var node in new[] { network.Nodes[edge.From], network.Nodes[edge.To] })
                if (node.Bank != null && (edge.Horizontal ? node.Bank.Normal.x != 0 : node.Bank.Normal.y != 0))
                {
                    lower = Mathf.Max(lower, node.Bank.Low); upper = Mathf.Min(upper, node.Bank.High);
                }
            foreach (var node in new[] { network.Nodes[edge.From], network.Nodes[edge.To] })
            {
                var bank = node.Bank;
                if (bank == null || (edge.Horizontal ? bank.Normal.y == 0 : bank.Normal.x == 0)) continue;
                float normal = edge.Horizontal ? bank.Normal.y : bank.Normal.x;
                float face = edge.Horizontal ? bank.Point.y : bank.Point.x;
                float near = frame.yMin, far = frame.yMax;
                if (!edge.Horizontal) { near = frame.xMin; far = frame.xMax; }
                foreach (var body in scene.Obstacles)
                {
                    float a = edge.Horizontal ? body.xMin : body.yMin, b = edge.Horizontal ? body.xMax : body.yMax;
                    if (b <= bank.Low || a >= bank.High) continue;
                    float lo = edge.Horizontal ? body.yMin : body.xMin, hi = edge.Horizontal ? body.yMax : body.xMax;
                    if (normal > 0 && lo >= face) far = Mathf.Min(far, lo);
                    if (normal < 0 && hi <= face) near = Mathf.Max(near, hi);
                }
                // Желаемый прямой выход — мягкий запас; минимальная ширина остаётся жёсткой.
                float wantedExit = reserveTurns ? exitLength : 0;
                if (normal > 0) { lower = Mathf.Max(lower, face + Mathf.Min(wantedExit, (far - face) * .25f)); upper = Mathf.Min(upper, far); }
                else { upper = Mathf.Min(upper, face - Mathf.Min(wantedExit, (face - near) * .25f)); lower = Mathf.Max(lower, near); }
                float anchor = edge.Horizontal ? node.Point.y : node.Point.x;
                float spread = radius + (edge.MaxOffset - edge.MinOffset + 1) * pitch;
                lower = Mathf.Max(lower, anchor - spread); upper = Mathf.Min(upper, anchor + spread);
            }
            if (reserveTurns && exitBanks.TryGetValue(edge.Id, out var banks))
                foreach (var bank in banks) KeepExit(bank);

            low = lower; high = upper;
            bands.Add((edge.Id, span, reserveTurns), new Vector2(low, high));

            void KeepExit(FlowBank bank)
            {
                float normal = edge.Horizontal ? bank.Normal.y : bank.Normal.x;
                float face = edge.Horizontal ? bank.Point.y : bank.Point.x;
                if (normal > 0) lower = Mathf.Max(lower, Mathf.Min(face + radius + exitLength, upper - (upper - lower) * .25f));
                else if (normal < 0) upper = Mathf.Min(upper, Mathf.Max(face - radius - exitLength, lower + (upper - lower) * .25f));
            }
        }
    }
}



