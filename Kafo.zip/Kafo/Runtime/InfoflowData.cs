using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

namespace Sbrt.Av.Gameplay
{
    [Serializable]
    public class InfoflowDataModel
    {
        public long Id;
        public long ConsumerId;
        public long ProviderId;
    }

    public enum InfoflowPortSide { Auto, PositiveZ, NegativeZ, PositiveX, NegativeX }

    [Serializable]
    public sealed class InfoflowSettings : ISerializationCallbackReceiver
    {
        // Ширина — в мировых единицах; зазор всегда вычисляется от выбранной автосайзом ширины.
        [Min(0)] public float MinWidth = .001f;
        [Min(0), FormerlySerializedAs("Width")] public float MaxWidth = .1f;
        [Min(0)] public float GapRatio = 1;
        // Одноразовый перевод старого абсолютного зазора в долю ширины при загрузке сцены.
        [SerializeField, HideInInspector, FormerlySerializedAs("Gap")] float legacyGap = -1;
        [Min(0)] public float RadiusInCells = .25f;
        [Min(0)] public float StraightExit = .15f;
        [Min(0)] public float Clearance = .05f;
        [Min(1)] public int PrimaryPortCount = 15;
        public InfoflowPortSide PreferredSide;
        [Min(0)] public int SearchBudget = 500000;
        [Range(4, 32)] public int ArcSteps = 12;

        public void OnBeforeSerialize() { }

        public void OnAfterDeserialize()
        {
            if (legacyGap < 0) return;
            GapRatio = MaxWidth > 0 ? legacyGap / MaxWidth : 1;
            legacyGap = -1;
        }
    }

    [Serializable]
    public sealed class InfoflowEndpoint
    {
        public long AsId;
        // Ключ физического экземпляра: один серверный AsId может иметь несколько экземпляров.
        public string Key;
        public Rect Body;
        // У моста подключаемся на части корпуса внутри сегмента, сохраняя полное препятствие Body.
        public Rect? PortArea;
        public float Height;
        public float Border = .18f;
        public List<string> Segments = new List<string>();
    }

    public sealed class InfoflowScene
    {
        public readonly List<InfoflowEndpoint> Endpoints = new List<InfoflowEndpoint>();
        public readonly List<Rect> Obstacles = new List<Rect>();
        public readonly List<Rect> SoftAreas = new List<Rect>();
        public Rect Bounds;
        // Внешняя рамка готовых сегментов. Если сегментов нет, доступен обычный внешний обход.
        public Rect? RoutingBounds;
        public float CellSize = 1;
        public bool BridgesAlongX = true;
    }

    [Serializable]
    public sealed class InfoflowArc
    {
        public Vector2 Center;
        public float Radius, StartAngle, Sweep;
    }

    [Serializable]
    public sealed class InfoflowRoute
    {
        public string Key, ProviderKey, ConsumerKey;
        public int SourceIndex;
        public long FlowId;
        public InfoflowPortSide ProviderSide, ConsumerSide;
        // Corners — ортогональная ломаная до скругления; Points — готовые точки для обоих способов отрисовки.
        public List<Vector2> Corners = new List<Vector2>();
        public List<Vector2> Points = new List<Vector2>();
        public List<InfoflowArc> Arcs = new List<InfoflowArc>();
        // Только в этих коротких веерах у перегруженной грани разрешено наложение лент.
        public int StartFanPointCount, EndFanPointCount;
        public Bounds Bounds;
    }

    [Serializable]
    public sealed class InfoflowRoutingResult
    {
        public const int CurrentVersion = 2;
        public int Version = CurrentVersion;
        public int SourceCount, SkippedRecords, SearchVisits, PlannedCrossings;
        public bool UsedFallback, UsedCapacityRouting, UsedCrossingFallback;
        public float Width, Gap, Scale = 1;
        public double RoutingMilliseconds;
        public List<InfoflowRoute> Routes = new List<InfoflowRoute>();
        public List<string> Diagnostics = new List<string>();
    }

    // Vector2.y в расчётах означает направление Z общей плоскости, а не высоту.
    // Оси имеют единичную длину: размеры остаются мировыми даже при масштабированных родителях.
    [Serializable]
    public struct InfoflowPlane
    {
        public Vector3 Origin, X, Z;
        public Vector3 Normal => Vector3.Cross(Z, X).normalized;

        public InfoflowPlane(Transform root, float height)
        {
            Origin = root.TransformPoint(new Vector3(0, height, 0));
            X = root.TransformVector(Vector3.right).normalized;
            var normal = Vector3.Cross(root.TransformVector(Vector3.forward), X).normalized;
            Z = Vector3.Cross(X, normal).normalized;
        }

        public Vector2 Project(Vector3 world) => new Vector2(Vector3.Dot(world - Origin, X), Vector3.Dot(world - Origin, Z));
        public Vector3 World(Vector2 point) => Origin + X * point.x + Z * point.y;
    }
}
