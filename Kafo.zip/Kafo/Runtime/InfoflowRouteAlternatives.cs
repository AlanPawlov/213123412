using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    // Короткие альтернативы в свободных проходах. Сложные обходы остаются за основным поиском.
    // Здесь выбираем кандидата по пересечениям с готовой сетью; маршрутизатор проверит итоговую разводку.
    internal static class InfoflowRouteAlternatives
    {
        public static List<(FlowFamily Family, List<Vector2> Path)> Find(List<FlowFamily> families, InfoflowChannelGraph graph,
            InfoflowScene scene, InfoflowSettings settings, float width, float radius, Crossings crossings, HashSet<FlowFamily> examined,
            bool preferDirectConnections = false)
        {
            var obstacles = new InfoflowObstacleLookup(scene.Obstacles, scene.CellSize);
            // Префиксы, подключения и части обходов повторяются у многих кандидатов.
            // Геометрия и ширина в пределах Find неизменны — проверяем такой отрезок один раз.
            var clearSegments = new Dictionary<(Vector2 A, Vector2 B, int Exempt), bool>();
            var improvements = new List<(FlowFamily Family, List<Vector2> Path, int Reduction, float Length)>();
            foreach (var family in families.Where(f => !examined.Contains(f) && crossings.Counts[f] > 0)
                .OrderByDescending(f => preferDirectConnections && f.Path.Count == 2)
                .ThenByDescending(f => crossings.Counts[f]).ThenBy(f => f.Id).Take(preferDirectConnections ? 4 : 16))
            {
                examined.Add(family);
                if (family.Start.Endpoint == family.End.Endpoint) continue;
                // Сохраняем уже разведённые подключения и неизменяемые участки:
                // оценка кандидата должна видеть те же позиции, что и готовая сеть.
                var reference = family.Wires[0].Route.Corners.ToList();
                if (family.Wires[0].Reversed) reference.Reverse();
                List<Vector2> best = null;
                int bestReduction = 0;
                float bestLength = float.PositiveInfinity;
                float oldLength = InfoflowRouter.Length(family.Path);
                float fullExit = radius + Mathf.Max(0, settings.StraightExit);
                float shortExit = Mathf.Min(fullExit, Mathf.Max(settings.StraightExit, width));
                var shortlist = new List<(List<Vector2> Path, List<Vector2> Preview, int Crossings, float Length)>();
                foreach (float startExit in new[] { fullExit, shortExit }.Distinct())
                foreach (float endExit in new[] { fullExit, shortExit }.Distinct())
                {
                    var start = family.Start.Point; var end = family.End.Point;
                    var a = start + family.Start.Normal * startExit;
                    var b = end + family.End.Normal * endExit;
                    foreach (bool xAxis in new[] { true, false })
                    foreach (float coordinate in graph.Coordinates(xAxis)
                        .OrderBy(v => Mathf.Abs(v - (xAxis ? (a.x + b.x) * .5f : (a.y + b.y) * .5f))).Take(64))
                    {
                        var c = xAxis ? new Vector2(coordinate, a.y) : new Vector2(a.x, coordinate);
                        var d = xAxis ? new Vector2(coordinate, b.y) : new Vector2(b.x, coordinate);
                        Consider(new List<Vector2> { start, a, c, d, b, end });
                    }
                }
                // Продлеваем входящий проход за конфликтный поворот и возвращаемся
                // к прежнему участку по соседнему проходу. Это добавляет два поворота,
                // сохраняя остальной путь и выходы из АС. Проверяем оба направления обхода.
                var reverseSkeleton = family.Path.AsEnumerable().Reverse().ToList();
                foreach (var original in new[] { reference, reference.AsEnumerable().Reverse().ToList() })
                for (int i = 1; i + 1 < original.Count; i++)
                {
                    if (original.Count != family.Path.Count) continue;
                    var before = original[i - 1]; var corner = original[i]; var after = original[i + 1];
                    bool vertical = before.x == corner.x;
                    float from = vertical ? corner.y : corner.x, previous = vertical ? before.y : before.x;
                    float start = vertical ? corner.x : corner.y, end = vertical ? after.x : after.y;
                    var returns = graph.Coordinates(vertical).Where(v => v > Mathf.Min(start, end) && v < Mathf.Max(start, end))
                        .OrderBy(v => Mathf.Abs(v - end)).Take(16).ToArray();
                    var skeleton = original == reference ? family.Path : reverseSkeleton;
                    // Координата графа может лежать на границе АС: отодвигаем ось ленты
                    // на её полуширину и запас, чтобы новый проход был свободен всей толщиной.
                    float padding = width * .5f + Mathf.Max(0, settings.Clearance);
                    foreach (float detour in graph.Coordinates(!vertical).Select(v => v + Mathf.Sign(from - previous) * padding)
                        .Where(v => (v - from) * (from - previous) > 0)
                        .OrderBy(v => Mathf.Abs(v - from)).Take(32))
                    {
                        int availableReturns = 0;
                        foreach (float track in returns)
                        {
                            var path = original.Take(i).ToList();
                            path.Add(vertical ? new Vector2(start, detour) : new Vector2(detour, start));
                            path.Add(vertical ? new Vector2(track, detour) : new Vector2(detour, track));
                            path.Add(vertical ? new Vector2(track, from) : new Vector2(from, track));
                            path.AddRange(original.Skip(i + 1));
                            if (original != reference) path.Reverse();
                            path = InfoflowGeometry.Simplify(path);
                            if (!Clear(path, family)) continue;
                            var basis = skeleton[i];
                            var routing = skeleton.Take(i).ToList();
                            routing.Add(vertical ? new Vector2(basis.x, detour) : new Vector2(detour, basis.y));
                            routing.Add(vertical ? new Vector2(track, detour) : new Vector2(detour, track));
                            routing.Add(vertical ? new Vector2(track, basis.y) : new Vector2(basis.x, track));
                            routing.AddRange(skeleton.Skip(i + 1));
                            if (original != reference) routing.Reverse();
                            // Достаточно двух ближайших свободных возвратов на каждом уровне.
                            if (Consider(path, routing, previewSimplified: true) && ++availableReturns == 2) break;
                        }
                    }
                }
                // Дуги и их безопасность проверяем только у четырёх лучших проходов,
                // а не у каждой комбинации координат. Это ограничивает стоимость улучшения.
                foreach (var candidate in shortlist)
                {
                    var path = candidate.Preview;
                    var route = new InfoflowRoute { Corners = path };
                    var radii = new float[path.Count];
                    for (int i = 1; i + 1 < path.Count; i++)
                        radii[i] = Mathf.Min(radius, Mathf.Min(Vector2.Distance(path[i - 1], path[i]),
                            Vector2.Distance(path[i], path[i + 1])) * .49f);
                    InfoflowGeometry.Round(route, radii, Mathf.Clamp(settings.ArcSteps, 4, 32));
                    if (!Clear(route.Points, family)) continue;
                    int reduction = crossings.Counts[family] - crossings.Count(route.Points, family) * family.Wires.Count;
                    if (reduction <= 0 || reduction < bestReduction || reduction == bestReduction && candidate.Length >= bestLength) continue;
                    best = candidate.Path; bestReduction = reduction; bestLength = candidate.Length;
                }
                if (best != null) improvements.Add((family, best, bestReduction, bestLength));

                bool Consider(List<Vector2> points, List<Vector2> routing = null, bool previewSimplified = false)
                {
                    var path = previewSimplified ? points : InfoflowGeometry.Simplify(points);
                    float length = InfoflowRouter.Length(path);
                    if (path.Count < 3 || path.Count > family.Path.Count + 2 || length > oldLength * 1.5f + scene.CellSize * 2 ||
                        Vector2.Dot((path[1] - path[0]).normalized, family.Start.Normal) < .5f ||
                        Vector2.Dot((path[path.Count - 2] - path[path.Count - 1]).normalized, family.End.Normal) < .5f ||
                        !Clear(path, family)) return false;
                    routing = routing == null ? path : InfoflowGeometry.Simplify(routing);
                    if (shortlist.Any(c => c.Path.SequenceEqual(routing))) return true;
                    int count = crossings.Count(path, family);
                    int rank = shortlist.FindIndex(c => count < c.Crossings || count == c.Crossings && length < c.Length);
                    if (rank < 0) rank = shortlist.Count;
                    if (rank < 4)
                    {
                        shortlist.Insert(rank, (routing, path, count, length));
                        if (shortlist.Count > 4) shortlist.RemoveAt(4);
                    }
                    return true;
                }
            }
            return improvements.OrderByDescending(c => c.Reduction).ThenBy(c => c.Length)
                .ThenBy(c => c.Family.Id).Take(2).Select(c => (c.Family, c.Path)).ToList();

            bool Clear(List<Vector2> points, FlowFamily family)
            {
                if (!InfoflowGeometry.InsideRoutingBounds(scene, points, width)) return false;
                for (int i = 1; i < points.Count; i++)
                {
                    int exempt = i == 1 ? family.Start.Endpoint : i == points.Count - 1 ? family.End.Endpoint : -1;
                    var key = (points[i - 1], points[i], exempt);
                    if (!clearSegments.TryGetValue(key, out bool safe))
                    {
                        safe = true;
                        foreach (var body in obstacles.Query(points[i - 1], points[i], width * .5f))
                        {
                            if (exempt >= 0 && body.Equals(scene.Endpoints[exempt].Body)) continue;
                            if (InfoflowGeometry.SegmentHitsRect(points[i - 1], points[i], body, width * .5f)) { safe = false; break; }
                        }
                        clearSegments.Add(key, safe);
                    }
                    if (!safe) return false;
                    for (int j = i + 2; j < points.Count; j++)
                        if (InfoflowGeometry.Intersection(points[i - 1], points[i], points[j - 1], points[j], out _)) return false;
                }
                return true;
            }
        }

        // Пространственный индекс осевых линий уже со скруглениями. Каждое физическое
        // пересечение учитывается один раз, даже если оно попало на стык двух отрезков дуги.
        internal sealed class Crossings
        {
            readonly float cell;
            readonly List<(FlowFamily Family, FlowWire Wire, Vector2 A, Vector2 B)> edges =
                new List<(FlowFamily, FlowWire, Vector2, Vector2)>();
            readonly Dictionary<Vector2Int, List<int>> buckets = new Dictionary<Vector2Int, List<int>>();
            readonly HashSet<int> visited = new HashSet<int>();
            readonly HashSet<(int Wire, Vector2 Point)> hits = new HashSet<(int, Vector2)>();
            readonly Dictionary<(Vector2 A, Vector2 B, FlowFamily Except), (int Wire, Vector2 Point, bool Endpoint)[]> segmentHits =
                new Dictionary<(Vector2, Vector2, FlowFamily), (int, Vector2, bool)[]>();
            public readonly Dictionary<FlowFamily, int> Counts = new Dictionary<FlowFamily, int>();
            public int Total { get; }

            public Crossings(List<FlowFamily> families, float cellSize)
            {
                cell = cellSize > 0 ? cellSize : 1;
                foreach (var family in families)
                foreach (var wire in family.Wires)
                {
                    var points = wire.Route.Points;
                    for (int i = 1; i < points.Count; i++)
                    {
                        int id = edges.Count;
                        edges.Add((family, wire, points[i - 1], points[i]));
                        foreach (var bin in Cells(points[i - 1], points[i]))
                        {
                            if (!buckets.TryGetValue(bin, out var list)) buckets.Add(bin, list = new List<int>());
                            list.Add(id);
                        }
                    }
                }
                foreach (var family in families)
                    Counts.Add(family, family.Wires.Sum(w => Count(w.Route.Points, family)));
                Total = Counts.Values.Sum() / 2;
            }

            public int Count(List<Vector2> points, FlowFamily except)
            {
                hits.Clear();
                for (int i = 1; i < points.Count; i++)
                {
                    foreach (var hit in SegmentHits(points[i - 1], points[i], except))
                    {
                        if (hit.Endpoint && (hit.Point.Equals(points[0]) || hit.Point.Equals(points[points.Count - 1]))) continue;
                        hits.Add((hit.Wire, hit.Point));
                    }
                }
                return hits.Count;
            }

            (int Wire, Vector2 Point, bool Endpoint)[] SegmentHits(Vector2 a, Vector2 b, FlowFamily except)
            {
                // Сеть фиксирована на всё сравнение кандидатов: одинаковые звенья
                // повторно используют найденные пересечения, включая точки стыков дуг.
                var key = (a, b, except);
                if (segmentHits.TryGetValue(key, out var cached)) return cached;
                List<(int, Vector2, bool)> found = null;
                visited.Clear();
                foreach (var bin in Cells(a, b))
                {
                    if (!buckets.TryGetValue(bin, out var list)) continue;
                    foreach (int id in list)
                    {
                        if (!visited.Add(id)) continue;
                        var edge = edges[id];
                        if (edge.Family == except || !InfoflowGeometry.Intersection(a, b, edge.A, edge.B, out var point)) continue;
                        var other = edge.Wire.Route.Points;
                        if (found == null) found = new List<(int, Vector2, bool)>();
                        found.Add((edge.Wire.Id, point, point.Equals(other[0]) || point.Equals(other[other.Count - 1])));
                    }
                }
                cached = found == null ? Array.Empty<(int, Vector2, bool)>() : found.ToArray();
                segmentHits.Add(key, cached);
                return cached;
            }

            IEnumerable<Vector2Int> Cells(Vector2 a, Vector2 b)
            {
                var min = Vector2.Min(a, b); var max = Vector2.Max(a, b);
                for (int x = Mathf.FloorToInt(min.x / cell); x <= Mathf.FloorToInt(max.x / cell); x++)
                for (int z = Mathf.FloorToInt(min.y / cell); z <= Mathf.FloorToInt(max.y / cell); z++)
                    yield return new Vector2Int(x, z);
            }
        }
    }
}
