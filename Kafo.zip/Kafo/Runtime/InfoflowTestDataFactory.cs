#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;

namespace Sbrt.Av.Gameplay
{
    public enum InfoflowTestPattern { Mixed, Local, Intersegment, Central, Random }

    public static class InfoflowTestDataFactory
    {
        public static List<InfoflowDataModel> Create(InfoflowScene scene, int count, int seed,
            InfoflowTestPattern pattern, List<string> diagnostics)
        {
            // Локальный генератор и отсортированные ID обеспечивают воспроизводимость без изменения Unity Random.
            var random = new Random(seed);
            var ids = scene.Endpoints.Select(e => e.AsId).Distinct().OrderBy(id => id).ToList();
            var result = new List<InfoflowDataModel>();
            if (ids.Count == 0) { diagnostics.Add("В KAFO нет АС для тестовых связей."); return result; }
            if (ids.Count == 1)
            {
                for (int i = 0; i < count; i++) result.Add(new InfoflowDataModel { Id = i + 1, ProviderId = ids[0], ConsumerId = ids[0] });
                return result;
            }
            var segments = ids.ToDictionary(id => id, id => new HashSet<string>(
                scene.Endpoints.Where(e => e.AsId == id).SelectMany(e => e.Segments)));
            var all = new List<(long A, long B)>(); var local = new List<(long A, long B)>();
            var cross = new List<(long A, long B)>(); var central = new List<(long A, long B)>();
            long hub = ids[random.Next(ids.Count)];
            for (int i = 0; i < ids.Count; i++)
            for (int j = i + 1; j < ids.Count; j++)
            {
                var pair = (ids[i], ids[j]); all.Add(pair);
                if (segments[pair.Item1].Overlaps(segments[pair.Item2])) local.Add(pair);
                else if (segments[pair.Item1].Count > 0 && segments[pair.Item2].Count > 0) cross.Add(pair);
                if (pair.Item1 == hub || pair.Item2 == hub) central.Add(pair);
            }
            foreach (var pool in new[] { all, local, cross, central })
                for (int i = pool.Count - 1; i > 0; i--) { int j = random.Next(i + 1); (pool[i], pool[j]) = (pool[j], pool[i]); }
            var used = new HashSet<(long, long)>();
            var positions = new Dictionary<List<(long, long)>, int>();
            for (int i = 0; i < Math.Max(0, count); i++)
            {
                var category = pattern == InfoflowTestPattern.Mixed
                    ? (i % 3 == 0 ? InfoflowTestPattern.Local : i % 3 == 1 ? InfoflowTestPattern.Intersegment : InfoflowTestPattern.Random) : pattern;
                var pool = category == InfoflowTestPattern.Local ? local : category == InfoflowTestPattern.Intersegment ? cross :
                    category == InfoflowTestPattern.Central ? central : all;
                if (pool.Count == 0) pool = all;
                var pair = Take(pool);
                bool reverse = random.Next(2) == 0;
                result.Add(new InfoflowDataModel { Id = i + 1, ProviderId = reverse ? pair.B : pair.A, ConsumerId = reverse ? pair.A : pair.B });
            }
            return result;

            (long A, long B) Take(List<(long A, long B)> pool)
            {
                // Сначала исчерпываем уникальные пары; повторы допустимы, когда других пар уже нет.
                positions.TryGetValue(pool, out int index);
                while (index < pool.Count)
                {
                    var pair = pool[index++]; positions[pool] = index;
                    if (used.Add(pair)) return pair;
                }
                if (pool != all && used.Count < all.Count) return Take(all);
                return pool[random.Next(pool.Count)];
            }
        }
    }
}
#endif
