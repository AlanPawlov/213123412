using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public static partial class KafoLayoutSolver
    {
        static bool IsGateway(string name)=>string.Equals(name?.Trim(),"Шлюзовая сеть",StringComparison.OrdinalIgnoreCase);

        // Logical X follows the ordered chain in both world orientations.
        static Dictionary<string,int> GatewaySides(NormalizedKafo source,IList<NormalizedSegment> order)
        {
            var result=new Dictionary<string,int>();
            var placements=source.Placements.Where(p=>p.SegmentKey!=null).ToLookup(p=>p.SegmentKey);
            for(int i=0;i<order.Count;i++)
            {
                int side=0;
                if(order.Count>1)
                {
                    if(i==0)side=1;
                    else if(i==order.Count-1)side=-1;
                    else
                    {
                        var members=new HashSet<string>(placements[order[i].Key].Where(p=>IsGateway(p.Group)).Select(p=>p.SystemKey));
                        int Score(int neighbor)
                        {
                            var records=placements[order[neighbor].Key].ToList();
                            int shared=records.Select(p=>p.SystemKey).Distinct().Count(members.Contains);
                            return shared*2+(records.Any(p=>IsGateway(p.Group))?1:0);
                        }
                        side=Score(i+1)>Score(i-1)?1:-1;
                    }
                }
                result.Add(order[i].Key,side);
            }
            return result;
        }

        // The guaranteed fallback reserves a complete edge column before sizing strips.
        // Remaining blocks keep their own rectangular grid alongside that column.
        static Pack PackSegmentRest(Context c,List<Item> items,int side)
        {
            var edge=items.Where(i=>IsGateway(((Bucket)i.Value).Group)).ToList();
            if(side==0||edge.Count==0)return PackGrid(items,c.Gap);
            var rest=PackGrid(items.Except(edge).ToList(),new Vector2(Mathf.Max(c.Gap.x,c.TitleClearance),Mathf.Max(c.Gap.y,c.TitleClearance)));
            float edgeWidth=edge.Max(i=>i.W),edgeHeight=edge.Sum(i=>i.H)+c.Gap.y*(edge.Count-1);
            float separation=rest.Items.Count==0?0:Mathf.Max(c.Gap.x,c.TitleClearance);
            var pack=new Pack{W=edgeWidth+separation+rest.W,H=Mathf.Max(edgeHeight,rest.H)};
            float y=0;
            foreach(var item in edge.OrderBy(i=>i.Key,StringComparer.Ordinal))
            {
                item.Rect=new Rect(side<0?0:pack.W-item.W,y,item.W,item.H);y+=item.H+c.Gap.y;pack.Items.Add(item);
            }
            foreach(var item in rest.Items)
            {
                item.Rect.position+=new Vector2(side<0?edgeWidth+separation:0,0);pack.Items.Add(item);
            }
            return pack;
        }

        static bool DistributeGatewayRest(Context c,SegmentWork work,Rect inner,float bandY,float scale)
        {
            var items=work.Rest.Items;
            var edge=items.Where(i=>IsGateway(((Bucket)i.Value).Group)).ToList();
            if(work.GatewaySide==0||edge.Count==0)return false;
            float edgeWidth=edge.Max(i=>i.W)*scale;
            float edgeHeight=(edge.Sum(i=>i.H)+c.Gap.y*(edge.Count-1))*scale;
            // The caller reserves all bridge bands above this portion of the strip.
            inner.yMin=work.Rect.y+bandY*scale;
            float y=inner.yMin+Mathf.Max(0,(inner.height-edgeHeight)*.5f);
            foreach(var item in edge.OrderBy(i=>i.Key,StringComparer.Ordinal))
            {
                float x=work.GatewaySide<0?inner.xMin:inner.xMax-item.W*scale;
                item.Rect=new Rect((x-work.Rect.x)/scale-c.Pad,(y-work.Rect.y)/scale-bandY,item.W,item.H);
                y+=(item.H+c.Gap.y)*scale;
            }
            var rest=items.Except(edge).ToList();
            if(rest.Count==0)return true;
            float separation=Mathf.Max(c.Gap.x,c.TitleClearance)*scale;
            var area=inner;
            if(work.GatewaySide<0)area.xMin+=edgeWidth+separation;else area.xMax-=edgeWidth+separation;
            float minX=rest.Min(i=>i.Rect.xMin),minY=rest.Min(i=>i.Rect.yMin);
            float width=(rest.Max(i=>i.Rect.xMax)-minX)*scale,height=(rest.Max(i=>i.Rect.yMax)-minY)*scale;
            var origin=new Vector2(area.xMin+Mathf.Max(0,(area.width-width)*.5f),area.yMin+Mathf.Max(0,(area.height-height)*.5f));
            foreach(var item in rest)
            {
                var position=origin+(item.Rect.position-new Vector2(minX,minY))*scale;
                item.Rect=new Rect((position.x-work.Rect.x)/scale-c.Pad,(position.y-work.Rect.y)/scale-bandY,item.W,item.H);
            }
            return true;
        }
    }
}
