using System.Collections.Generic;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public static class KafoRoundedMesh
    {
        public static Mesh Create(Vector3 size,float radius,float bevel,int cornerSteps=10)
        {
            radius=Mathf.Clamp(radius,.001f,Mathf.Min(size.x,size.z)*.45f);
            bevel=Mathf.Clamp(bevel,0,Mathf.Min(size.y*.25f,radius*.4f));
            var points=new List<Vector2>();
            for(int corner=0;corner<4;corner++)
            {
                float cx=(corner==0||corner==3?1:-1)*(size.x*.5f-radius);
                float cz=(corner<2?1:-1)*(size.z*.5f-radius);
                for(int step=0;step<=cornerSteps;step++)
                {
                    float a=(corner*90f+step*90f/cornerSteps)*Mathf.Deg2Rad;
                    points.Add(new Vector2(cx+Mathf.Cos(a)*radius,cz+Mathf.Sin(a)*radius));
                }
            }
            // Quadrants start at (+x,+z), (-x,+z), (-x,-z), (+x,-z).
            var vertices=new List<Vector3>();var uv=new List<Vector2>();
            int n=points.Count;
            for(int ring=0;ring<3;ring++)
            foreach(var p in points)
            {
                float inset=ring==2?bevel:0;
                float x=p.x*(size.x-2*inset)/size.x,z=p.y*(size.z-2*inset)/size.z;
                float y=ring==0?0:ring==1?size.y-bevel:size.y;
                vertices.Add(new Vector3(x,y,z));uv.Add(new Vector2(x/size.x+.5f,z/size.z+.5f));
            }
            int topCenter=vertices.Count;vertices.Add(new Vector3(0,size.y,0));uv.Add(new Vector2(.5f,.5f));
            int bottomCenter=vertices.Count;vertices.Add(Vector3.zero);uv.Add(new Vector2(.5f,.5f));
            var sides=new List<int>();var caps=new List<int>();var rim=new List<int>();
            for(int i=0;i<n;i++)
            {
                int next=(i+1)%n;
                Quad(sides,i,n+i,n+next,next);
                Quad(rim,n+i,2*n+i,2*n+next,n+next);
                caps.Add(topCenter);caps.Add(2*n+next);caps.Add(2*n+i);
                caps.Add(bottomCenter);caps.Add(i);caps.Add(next);
            }
            var mesh=new Mesh{name="KFO Rounded Prism"};mesh.SetVertices(vertices);mesh.SetUVs(0,uv);mesh.subMeshCount=3;
            mesh.SetTriangles(sides,0);mesh.SetTriangles(caps,1);mesh.SetTriangles(rim,2);mesh.RecalculateNormals();mesh.RecalculateBounds();
            return mesh;
        }
        static void Quad(List<int> t,int a,int b,int c,int d){t.Add(a);t.Add(b);t.Add(c);t.Add(a);t.Add(c);t.Add(d);}
    }
}
