using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    // Метка владельца позволяет найти старый результат после перезагрузки редактора при потере ссылки на корень.
    [AddComponentMenu("")]
    [DisallowMultipleComponent]
    public sealed class InfoflowOutput : MonoBehaviour
    {
        [HideInInspector] public InfoflowGenerator Owner;
    }
}
