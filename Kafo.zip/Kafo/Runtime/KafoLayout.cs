using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    [Serializable] public class KafoLayoutSettings
    {
        public int Seed;
        [Min(0)] public int SearchAttempts = 32;
        [Range(1,16),Tooltip("Maximum ordinary AS footprint across the bridge direction.")]
        public int MaxAsWidthCells = 4;
        [Range(1,16),Tooltip("Maximum ordinary AS footprint along the bridge direction; bridge spans remain continuous.")]
        public int MaxAsLengthCells = 4;
        [Min(0)] public float ItemGap = .35f;
        [Min(0)] public float SegmentGap = .55f;
        [Min(0)] public float OuterPadding = .25f;
        [Min(0)] public float SegmentPadding = .5f;
        [Min(0)] public float SegmentHeader = .65f;
        [Min(0)] public float GroupPadding = .3f;
        [Min(0)] public float GroupHeader = .55f;
    }
    [Serializable] public struct KafoVisualMetrics
    {
        public Vector3 AsSize, SegmentSize, GroupSize;
        public static KafoVisualMetrics Default => new KafoVisualMetrics {
            AsSize = new Vector3(1.4f, 1.15f, 1.4f), SegmentSize = new Vector3(2, .18f, 2), GroupSize = new Vector3(2, .035f, 2) };
    }
    public sealed class SegmentLayout { public string Key, Name; public Rect Rect, TitleRect; }
    public sealed class GroupLayout { public string Key, Name, SegmentKey; public Rect Rect, TitleRect; }
    public sealed class AsLayout
    {
        public string Key, SystemKey, Name; public Rect Rect; public bool IsBridge;
        public readonly List<string> PlacementKeys = new List<string>();
        public readonly List<string> SegmentKeys = new List<string>();
        public readonly List<string> GroupKeys = new List<string>();
    }
    public sealed class KafoLayoutResult
    {
        public Rect MainRect, IslandRect;
        public float CellScale;
        public Vector2 CellSize;
        public bool UsedFallback;
        public bool BridgesAlongX=true;
        public readonly List<SegmentLayout> Segments = new List<SegmentLayout>();
        public readonly List<GroupLayout> Groups = new List<GroupLayout>();
        public readonly List<AsLayout> Systems = new List<AsLayout>();
        public readonly List<string> Diagnostics = new List<string>();
        public int BridgeCount => Systems.Count(s => s.IsBridge);

        public List<string> Validate(NormalizedKafo source)
        {
            var errors = new List<string>();
            var segments = Segments.ToDictionary(s => s.Key);
            var groups = Groups.ToDictionary(g => g.Key);
            float epsilon = Mathf.Max(.000001f, Mathf.Min(CellSize.x, CellSize.y) * .001f);
            for (int i = 0; i < Segments.Count; i++)
            {
                if (!Contains(MainRect, Segments[i].Rect, epsilon)) errors.Add("Сегмент вне основной зоны: " + Segments[i].Name);
                if (!Contains(Segments[i].Rect, Segments[i].TitleRect, epsilon)) errors.Add("Подпись вне сегмента: " + Segments[i].Name);
                for (int j = i + 1; j < Segments.Count; j++) if (Overlap(Segments[i].Rect, Segments[j].Rect, epsilon)) errors.Add("Пересечение сегментов");
            }
            for (int i = 0; i < Groups.Count; i++)
            {
                var g = Groups[i];
                var parent = g.SegmentKey == null ? IslandRect : segments[g.SegmentKey].Rect;
                if (!Contains(parent, g.Rect, epsilon)) errors.Add("Группа вне родителя: " + g.Name);
                if (!Contains(g.Rect, g.TitleRect, epsilon)) errors.Add("Подпись вне группы: " + g.Name);
                for (int j = i + 1; j < Groups.Count; j++) if (Overlap(g.Rect, Groups[j].Rect, epsilon)) errors.Add("Пересечение групп");
            }
            for (int i = 0; i < Systems.Count; i++)
            {
                var a = Systems[i];
                foreach (var s in Segments) if (Overlap(a.Rect, s.TitleRect, epsilon)) errors.Add("АС перекрывает подпись сегмента: " + a.Name);
                foreach (var g in Groups) if (Overlap(a.Rect, g.TitleRect, epsilon)) errors.Add("АС перекрывает подпись группы: " + a.Name);
                if (!Contains(a.SegmentKeys.Count == 0 ? IslandRect : MainRect, a.Rect, epsilon)) errors.Add("АС вне зоны: " + a.Name);
                if (!a.IsBridge && a.SegmentKeys.Count > 0 && !Contains(segments[a.SegmentKeys[0]].Rect, a.Rect, epsilon)) errors.Add("АС вне сегмента: " + a.Name);
                foreach (string gk in a.GroupKeys)
                {
                    var g = groups[gk];
                    var part = a.IsBridge ? Intersection(a.Rect, segments[g.SegmentKey].Rect) : a.Rect;
                    if (!Contains(g.Rect, part, epsilon)) errors.Add("АС вне группы: " + a.Name);
                }
                foreach (var g in Groups) if (!a.GroupKeys.Contains(g.Key) && Overlap(a.Rect, g.Rect, epsilon)) errors.Add("АС пересекает чужую группу: " + a.Name);
                foreach (var s in Segments) if (!a.SegmentKeys.Contains(s.Key) && Overlap(a.Rect, s.Rect, epsilon)) errors.Add("АС пересекает чужой сегмент: " + a.Name);
                for (int j = i + 1; j < Systems.Count; j++) if (Overlap(a.Rect, Systems[j].Rect, epsilon)) errors.Add("Пересечение АС: " + a.Name + " / " + Systems[j].Name);
            }
            var represented = new HashSet<string>(Systems.SelectMany(s => s.PlacementKeys));
            foreach (var p in source.Placements) if (!represented.Contains(p.Key)) errors.Add("Потеряно размещение " + p.Key);
            var systemKeys = new HashSet<string>(Systems.Select(s => s.SystemKey));
            foreach (var s in source.Systems) if (!systemKeys.Contains(s.Key)) errors.Add("Потеряна АС " + s.Key);
            foreach (var s in source.Segments) if (!segments.ContainsKey(s.Key)) errors.Add("Потерян сегмент " + s.Key);
            return errors;
        }
        public static bool Contains(Rect outer, Rect inner, float e = .00001f) => inner.xMin >= outer.xMin-e && inner.yMin >= outer.yMin-e && inner.xMax <= outer.xMax+e && inner.yMax <= outer.yMax+e;
        public static bool Overlap(Rect a, Rect b, float e = .00001f) => Mathf.Min(a.xMax,b.xMax)-Mathf.Max(a.xMin,b.xMin)>e && Mathf.Min(a.yMax,b.yMax)-Mathf.Max(a.yMin,b.yMin)>e;
        public static Rect Intersection(Rect a, Rect b) => Rect.MinMaxRect(Mathf.Max(a.xMin,b.xMin), Mathf.Max(a.yMin,b.yMin), Mathf.Min(a.xMax,b.xMax), Mathf.Min(a.yMax,b.yMax));
    }

    /// <summary>Pure layout: fit actual occupied rectangles while maximizing a common cell scale.</summary>
    public static partial class KafoLayoutSolver
    {
        sealed class Item { public string Key; public float W,H; public object Value; public Rect Rect; public int Row,Column; }
        sealed class Pack { public float W,H; public int Rows,Columns; public readonly List<Item> Items = new List<Item>(); }
        sealed class Bucket
        {
            public string Key, Group, SegmentKey;
            public readonly List<NormalizedPlacement> Placements = new List<NormalizedPlacement>();
            public Pack Rest; public float W,H;
            public bool IsGroup => Group != null;
        }
        sealed class Bridge
        {
            public NormalizedSystem System; public List<NormalizedPlacement> Placements;
            public int First,Last; public float Thickness, Lane;
        }
        sealed class Band
        {
            public readonly List<Bucket> Buckets = new List<Bucket>();
            public readonly List<Bridge> Bridges = new List<Bridge>();
            public float H, RestY, Y;
        }
        sealed class SegmentWork { public NormalizedSegment Segment; public float W; public Pack Rest; public Rect Rect; }
        sealed class Context
        {
            public NormalizedKafo Source; public KafoVisualMetrics Metrics;
            public Dictionary<string,NormalizedSystem> Systems; public KafoFootprintScale Footprints; public float Unit, Gap, Pad, Header, GroupPad, GroupHeader, TitleClearance, SegmentGap, Outer;
            public Vector2 Size(NormalizedPlacement p) => Size(Systems[p.SystemKey]);
            public Vector2Int Cells(NormalizedSystem s)=>Footprints.Cells(s);
            public Vector2 Size(NormalizedSystem s)
            {
                var cells=Cells(s);
                return new Vector2(cells.x*Metrics.AsSize.x,cells.y*Metrics.AsSize.z);
            }
        }
        static bool Finite(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        static float Positive(float x, float fallback) => Finite(x) && x > .00001f ? x : fallback;
        static Rect SafeRect(Rect r, Rect fallback) => Finite(r.x) && Finite(r.y) && Finite(r.width) && Finite(r.height) && r.width>.001f && r.height>.001f ? r : fallback;
        static float Nonnegative(float v) => Finite(v) ? Mathf.Max(0,v) : 0;
        // The title is at the left/back edge seen by the isometric camera. Content grows
        // towards the foreground, leaving the reserved title strip behind every block.
        static Rect MapFromLogical(Rect basis,Rect r,bool transpose) => transpose
            ? new Rect(basis.xMax-r.y-r.height,basis.yMax-r.x-r.width,r.height,r.width)
            : new Rect(basis.x+r.x,basis.yMax-r.y-r.height,r.width,r.height);
        static Rect ToLogical(Rect basis,Rect r,bool transpose) => transpose
            ? new Rect(basis.yMax-r.yMax,basis.xMax-r.xMax,r.height,r.width)
            : new Rect(r.x-basis.x,basis.yMax-r.yMax,r.width,r.height);
        static Rect Title(Rect r,float pad,float header) => new Rect(r.x+pad,r.y+pad,Mathf.Max(.000001f,r.width-2*pad),header);

        public static KafoLayoutResult Calculate(KafoDocument document, Rect main, Rect island, KafoVisualMetrics metrics, KafoLayoutSettings settings = null) =>
            Calculate(KafoDataLoader.Normalize(document),main,island,metrics,settings);
        public static KafoLayoutResult Calculate(NormalizedKafo source, Rect main, Rect island, KafoVisualMetrics metrics, KafoLayoutSettings settings = null)
        {
            source = source ?? KafoDataLoader.Normalize(null); settings = settings ?? new KafoLayoutSettings();
            metrics.AsSize = new Vector3(Positive(metrics.AsSize.x,1.4f),Positive(metrics.AsSize.y,1),Positive(metrics.AsSize.z,1.4f));
            main = SafeRect(main,new Rect(-10,-7,20,14)); island = SafeRect(island,new Rect(main.xMax+2,main.yMin,4,4));
            var c = new Context { Source=source,Metrics=metrics,Systems=source.Systems.ToDictionary(s=>s.Key),Footprints=new KafoFootprintScale(source,settings),Unit=Mathf.Max(metrics.AsSize.x,metrics.AsSize.z) };
            c.Gap=Mathf.Max(.04f,Nonnegative(settings.ItemGap))*c.Unit;
            c.Pad=Mathf.Max(.2f,Nonnegative(settings.SegmentPadding))*c.Unit;
            // At the reference isometric angle a roof projects one unit towards the title
            // for each unit of height. Leave this clearance beyond the text's own strip.
            c.TitleClearance=c.Metrics.AsSize.y+Mathf.Max(0,c.Metrics.GroupSize.y)+.05f*c.Unit;
            c.Header=Mathf.Max(.25f,Nonnegative(settings.SegmentHeader))*c.Unit+c.TitleClearance;
            c.GroupPad=Mathf.Max(.22f,Nonnegative(settings.GroupPadding))*c.Unit;
            c.GroupHeader=Mathf.Max(.25f,Nonnegative(settings.GroupHeader))*c.Unit+c.TitleClearance;
            c.SegmentGap=Mathf.Max(.08f,Nonnegative(settings.SegmentGap))*c.Unit;
            c.Outer=Nonnegative(settings.OuterPadding)*c.Unit;
            KafoLayoutResult best = null;
            int attempts=Mathf.Clamp(settings.SearchAttempts,0,256);
            var order=OrderedSegments(source);
            // Platforms span the short side; the chain runs along the plane's long side.
            // A wide plane is split into left/right columns, never top/bottom rows.
            bool transpose=main.width<main.height;
            var visited=new HashSet<string>();
            for(int attempt=0;attempt<Mathf.Min(attempts,12);attempt++)
            {
                int variant=(attempt+((settings.Seed%4)+4)%4)%4;
                if(!visited.Add(string.Join("|",order.Select(s=>s.Key))+":"+variant))continue;
                var candidate=SearchDense(c,main,order,transpose,variant);
                if(candidate==null)continue;
                AddIsland(c,candidate,island);
                if(candidate.Validate(source).Count>0) continue;
                if(best==null || candidate.CellScale>best.CellScale*1.002f || candidate.CellScale>=best.CellScale*.998f && candidate.BridgeCount>best.BridgeCount) best=candidate;
            }
            if(best==null)
            {
                best=Build(c,main,order,transpose,false);best.UsedFallback=true;
                AddIsland(c,best,island);
                best.Diagnostics.Add("Резервная компоновка полосами: все размещения сохранены, мосты заменены локальными АС.");
            }
            BalanceMain(c,best);
            best.Diagnostics.InsertRange(0,source.Diagnostics);
            best.Diagnostics.Add(c.Footprints.Description);
            int shared=source.Placements.Where(p=>p.SegmentKey!=null).GroupBy(p=>p.SystemKey).Count(g=>g.Select(p=>p.SegmentKey).Distinct().Count()>1);
            if(shared>best.BridgeCount) best.Diagnostics.Add((shared-best.BridgeCount)+" общих АС показаны локальными экземплярами: безопасный прямой мост не найден.");
            return best;
        }
        static List<NormalizedSegment> OrderedSegments(NormalizedKafo source)
        {
            int Rank(NormalizedSegment segment)
            {
                string name=(segment.Name??"").Trim();
                if(string.Equals(name,"INTERNET",StringComparison.OrdinalIgnoreCase)||string.Equals(name,"ИНТЕРНЕТ",StringComparison.OrdinalIgnoreCase))return 0;
                if(string.Equals(name,"Внешний сектор",StringComparison.OrdinalIgnoreCase))return 1;
                if(string.Equals(name,"Внутренний сектор",StringComparison.OrdinalIgnoreCase))return 2;
                return 3;
            }
            // OrderBy is stable: duplicate named segments and other names retain source order.
            return source.Segments.OrderBy(Rank).ToList();
        }
        static List<Bucket> Buckets(IEnumerable<NormalizedPlacement> placements)
        {
            var result=new List<Bucket>();var lookup=new Dictionary<string,Bucket>();
            foreach(var p in placements)
            {
                string key=p.Group==null?"direct:"+p.Key:"group:"+(p.SegmentKey??"island")+":"+p.Group;
                if(!lookup.TryGetValue(key,out var b)) { b=new Bucket{Key=key,Group=p.Group,SegmentKey=p.SegmentKey};lookup.Add(key,b);result.Add(b); }
                b.Placements.Add(p);
            }
            return result;
        }
        static Pack PackGrid(List<Item> items,float gap,float targetAspect=1)
        {
            var pack=new Pack();if(items.Count==0)return pack;
            var ordered=items.OrderByDescending(i=>i.H).ThenBy(i=>i.Key,StringComparer.Ordinal).ToList();
            double best=double.MaxValue;int columns=1;
            for(int count=1;count<=items.Count;count++)
            {
                var widths=new float[count];var heights=new float[(items.Count+count-1)/count];
                for(int i=0;i<ordered.Count;i++){widths[i%count]=Mathf.Max(widths[i%count],ordered[i].W);heights[i/count]=Mathf.Max(heights[i/count],ordered[i].H);}
                double width=widths.Sum()+gap*(widths.Length-1),height=heights.Sum()+gap*(heights.Length-1);
                double aspect=Math.Log(Math.Max(.000001,width/height/targetAspect));
                double score=width*height*(1+.18*aspect*aspect);
                if(score<best){best=score;columns=count;}
            }
            pack.Columns=columns;pack.Rows=(items.Count+columns-1)/columns;
            var columnWidths=new float[columns];var rowHeights=new float[pack.Rows];
            for(int i=0;i<ordered.Count;i++){columnWidths[i%columns]=Mathf.Max(columnWidths[i%columns],ordered[i].W);rowHeights[i/columns]=Mathf.Max(rowHeights[i/columns],ordered[i].H);}
            var x=new float[columns];var y=new float[pack.Rows];
            for(int i=1;i<x.Length;i++)x[i]=x[i-1]+columnWidths[i-1]+gap;
            for(int i=1;i<y.Length;i++)y[i]=y[i-1]+rowHeights[i-1]+gap;
            for(int i=0;i<ordered.Count;i++)
            {
                var item=ordered[i];item.Column=i%columns;item.Row=i/columns;
                item.Rect=new Rect(x[item.Column],y[item.Row],item.W,item.H);pack.Items.Add(item);
            }
            pack.W=columnWidths.Sum()+gap*(columns-1);pack.H=rowHeights.Sum()+gap*(pack.Rows-1);
            return pack;
        }
        static void PackBucket(Context c,Bucket b,HashSet<string> bridged)
        {
            b.Rest=PackGrid(b.Placements.Where(p=>!bridged.Contains(p.Key)).Select(p=>{
                var size=c.Size(p);return new Item{Key=p.Key,W=size.x,H=size.y,Value=p};}).ToList(),c.Gap);
            b.W=b.Rest.W+(b.IsGroup?2*c.GroupPad:0);b.H=b.Rest.H+(b.IsGroup?2*c.GroupPad+c.GroupHeader:0);
        }
        static KafoLayoutResult Build(Context c,Rect main,IList<NormalizedSegment> order,bool transpose,bool bridgesAllowed)
        {
            var result=new KafoLayoutResult{MainRect=main,BridgesAlongX=!transpose};
            if(order.Count==0) {result.CellScale=1;result.CellSize=transpose?new Vector2(c.Metrics.AsSize.z,c.Metrics.AsSize.x):new Vector2(c.Metrics.AsSize.x,c.Metrics.AsSize.z);return result;}
            var index=order.Select((s,i)=>new{s.Key,Index=i}).ToDictionary(x=>x.Key,x=>x.Index);
            var buckets=Buckets(c.Source.Placements.Where(p=>p.SegmentKey!=null));
            var byPlacement=buckets.SelectMany(b=>b.Placements.Select(p=>new{p.Key,Bucket=b})).ToDictionary(x=>x.Key,x=>x.Bucket);
            var bands=buckets.Select(b=>{var band=new Band();band.Buckets.Add(b);return band;}).ToList();
            if(bridgesAllowed)
            foreach(var records in c.Source.Placements.Where(p=>p.SegmentKey!=null).GroupBy(p=>p.SystemKey).OrderByDescending(g=>g.Count()).ThenBy(g=>g.Key,StringComparer.Ordinal))
            {
                var ps=records.ToList();if(ps.Count<2 || ps.GroupBy(p=>p.SegmentKey).Any(g=>g.Count()>1))continue;
                int first=ps.Min(p=>index[p.SegmentKey]),last=ps.Max(p=>index[p.SegmentKey]);
                if(last-first+1!=ps.Count)continue;
                var joining=ps.Select(p=>bands.First(b=>b.Buckets.Contains(byPlacement[p.Key]))).Distinct().ToList();
                var joinedBuckets=joining.SelectMany(b=>b.Buckets).Distinct().ToList();
                if(joinedBuckets.GroupBy(b=>b.SegmentKey).Any(g=>g.Count()>1))continue;
                var merged=new Band();merged.Buckets.AddRange(joinedBuckets);merged.Bridges.AddRange(joining.SelectMany(b=>b.Bridges));
                merged.Bridges.Add(new Bridge{System=c.Systems[records.Key],Placements=ps,First=first,Last=last});
                foreach(var b in joining)bands.Remove(b);bands.Add(merged);
            }
            var active=bands.Where(b=>b.Bridges.Count>0).OrderBy(b=>b.Bridges.Min(a=>a.System.Key),StringComparer.Ordinal).ToList();
            var bridged=new HashSet<string>(active.SelectMany(b=>b.Bridges).SelectMany(b=>b.Placements).Select(p=>p.Key));
            foreach(var b in buckets)PackBucket(c,b,bridged);
            var works=new List<SegmentWork>();
            foreach(var s in order)
            {
                var sb=buckets.Where(b=>b.SegmentKey==s.Key).ToList();
                var local=sb.Where(b=>!active.Any(band=>band.Buckets.Contains(b))).Select(b=>new Item{Key=b.Key,W=b.W,H=b.H,Value=b}).ToList();
                var pack=PackGrid(local,c.Gap);
                float width=Mathf.Max(2*c.Unit,pack.W,sb.Count==0?0:sb.Max(b=>b.W));
                works.Add(new SegmentWork{Segment=s,Rest=pack,W=width+2*c.Pad});
            }
            float bandY=c.Pad+c.Header;
            foreach(var band in active)
            {
                float y=c.GroupPad+(band.Buckets.Any(b=>b.IsGroup)?c.GroupHeader:0);
                foreach(var bridge in band.Bridges.OrderBy(b=>b.System.Key,StringComparer.Ordinal))
                {
                    float length=works.Skip(bridge.First+1).Take(bridge.Last-bridge.First-1).Sum(w=>w.W)
                        +c.SegmentGap*(bridge.Last-bridge.First)+2*(c.Pad+c.Metrics.AsSize.x);
                    var footprint=c.Cells(bridge.System);double cells=footprint.x*footprint.y;
                    bridge.Thickness=Mathf.Max(c.Metrics.AsSize.z,(float)(cells*c.Metrics.AsSize.x*c.Metrics.AsSize.z/Math.Max(c.Unit,length)));
                    bridge.Lane=y;y+=bridge.Thickness+c.Gap;
                }
                band.RestY=y;band.H=y+band.Buckets.Max(b=>b.Rest.H)+c.GroupPad;
                band.Y=bandY;bandY+=band.H+c.Gap;
            }
            float requiredH=bandY+works.Max(w=>w.Rest.H)+c.Pad;
            float requiredW=works.Sum(w=>w.W)+c.SegmentGap*(works.Count-1)+2*c.Outer;
            float availableW=transpose?main.height:main.width,availableH=transpose?main.width:main.height;
            float scale=Mathf.Min(availableW/requiredW,availableH/(requiredH+2*c.Outer))*.999f;
            result.CellScale=scale;result.CellSize=transpose?new Vector2(c.Metrics.AsSize.z*scale,c.Metrics.AsSize.x*scale):new Vector2(c.Metrics.AsSize.x*scale,c.Metrics.AsSize.z*scale);
            float contentW=availableW-(2*c.Outer+c.SegmentGap*(works.Count-1))*scale;
            float x=c.Outer*scale,totalW=works.Sum(w=>w.W);
            Rect Map(Rect r)=>MapFromLogical(main,r,transpose);
            foreach(var w in works)
            {
                float width=contentW*w.W/totalW;
                w.Rect=new Rect(x,c.Outer*scale,width,availableH-2*c.Outer*scale);x+=width+c.SegmentGap*scale;
                result.Segments.Add(new SegmentLayout{Key=w.Segment.Key,Name=w.Segment.Name,Rect=Map(w.Rect),TitleRect=Map(Title(w.Rect,c.Pad*scale,(c.Header-c.TitleClearance)*scale))});
            }
            foreach(var band in active)
            {
                foreach(var b in band.Buckets)
                {
                    var w=works[index[b.SegmentKey]];
                    var rect=new Rect(w.Rect.x,w.Rect.y+band.Y*scale,w.Rect.width,band.H*scale);
                    if(b.IsGroup)
                    {
                        int segmentIndex=index[b.SegmentKey];
                        var localBridges=band.Bridges.Where(a=>a.Placements.Any(p=>p.SegmentKey==b.SegmentKey)).ToList();
                        bool enters=localBridges.Any(a=>a.First<segmentIndex),exits=localBridges.Any(a=>a.Last>segmentIndex);
                        if(enters!=exits)
                        {
                            float width=Mathf.Min(rect.width,Mathf.Max(b.W,c.Pad+c.Metrics.AsSize.x+c.GroupPad)*scale);
                            if(exits)rect.x=rect.xMax-width;
                            rect.width=width;
                        }
                    }
                    if(b.IsGroup)result.Groups.Add(new GroupLayout{Key=b.Key,Name=GroupName(b.Group),SegmentKey=b.SegmentKey,Rect=Map(rect),TitleRect=Map(Title(rect,c.GroupPad*scale,(c.GroupHeader-c.TitleClearance)*scale))});
                    EmitRest(c,result,b,new Vector2(rect.x,rect.y+band.RestY*scale),scale,Map,false);
                }
                foreach(var bridge in band.Bridges)
                {
                    float endpoint=(c.Pad+c.Metrics.AsSize.x)*scale;
                    float left=works[bridge.First].Rect.xMax-endpoint,right=works[bridge.Last].Rect.x+endpoint;
                    var a=new AsLayout{Key="bridge:"+bridge.System.Key,SystemKey=bridge.System.Key,Name=bridge.System.Name,IsBridge=true,
                        Rect=Map(new Rect(left,works[0].Rect.y+(band.Y+bridge.Lane)*scale,right-left,bridge.Thickness*scale))};
                    foreach(var p in bridge.Placements){a.PlacementKeys.Add(p.Key);a.SegmentKeys.Add(p.SegmentKey);if(p.Group!=null)a.GroupKeys.Add(byPlacement[p.Key].Key);}
                    result.Systems.Add(a);
                }
            }
            foreach(var w in works)DistributeRest(c,result,w,bandY,scale,transpose);
            foreach(var w in works)
            foreach(var item in w.Rest.Items)
            {
                var b=(Bucket)item.Value;
                var origin=new Vector2(w.Rect.x+(c.Pad+item.Rect.x)*scale,w.Rect.y+(bandY+item.Rect.y)*scale);
                var rect=new Rect(origin,new Vector2(b.W,b.H)*scale);
                if(b.IsGroup)result.Groups.Add(new GroupLayout{Key=b.Key,Name=GroupName(b.Group),SegmentKey=b.SegmentKey,Rect=Map(rect),TitleRect=Map(Title(rect,c.GroupPad*scale,(c.GroupHeader-c.TitleClearance)*scale))});
                EmitRest(c,result,b,origin,scale,Map,true);
            }
            return result;
        }
        static Rect Expand(Rect rect,float gap) => Rect.MinMaxRect(rect.xMin-gap,rect.yMin-gap,rect.xMax+gap,rect.yMax+gap);
        static void DistributeRest(Context c,KafoLayoutResult result,SegmentWork work,float bandY,float scale,bool transpose)
        {
            if(work.Rest.Items.Count==0)return;
            var items=work.Rest.Items;
            float pad=c.Pad*scale,gap=c.Gap*scale;
            var inner=new Rect(work.Rect.x+pad,work.Rect.y+(c.Pad+c.Header)*scale,work.Rect.width-2*pad,work.Rect.height-(2*c.Pad+c.Header)*scale);
            var obstacles=new List<Rect>();
            foreach(var group in result.Groups)
            {
                if(group.SegmentKey==work.Segment.Key)obstacles.Add(Expand(ToLogical(result.MainRect,group.Rect,transpose),gap));
                var title=ToLogical(result.MainRect,group.TitleRect,transpose);float clearance=c.TitleClearance*scale;
                obstacles.Add(Rect.MinMaxRect(title.xMin-clearance,title.yMin,title.xMax,title.yMax+clearance));
            }
            foreach(var bridge in result.Systems.Where(a=>a.IsBridge&&a.SegmentKeys.Contains(work.Segment.Key)))
                obstacles.Add(Expand(ToLogical(result.MainRect,bridge.Rect,transpose),gap));
            Rect[] positions;
            if(TrySegmentGrid(items,inner,obstacles,c.Metrics.AsSize.x*scale,c.Metrics.AsSize.z*scale,gap,scale,out positions))
            {
                for(int i=0;i<items.Count;i++)items[i].Rect=new Rect((positions[i].x-work.Rect.x)/scale-c.Pad,(positions[i].y-work.Rect.y)/scale-bandY,items[i].W,items[i].H);
                return;
            }
            // A grid below the reserved bridge bands always fits: its minimum track sizes
            // were included before choosing the common object scale. Expand its gaps only.
            float availableH=work.Rect.height-(bandY+c.Pad)*scale;
            var widths=new float[work.Rest.Columns];var heights=new float[work.Rest.Rows];
            foreach(var item in items){widths[item.Column]=Mathf.Max(widths[item.Column],item.W);heights[item.Row]=Mathf.Max(heights[item.Row],item.H);}
            float columnGap=widths.Length>1?Mathf.Max(c.Gap,(inner.width/scale-widths.Sum())/(widths.Length-1)):0;
            float rowGap=heights.Length>1?Mathf.Max(c.Gap,(availableH/scale-heights.Sum())/(heights.Length-1)):0;
            var x=new float[widths.Length];var y=new float[heights.Length];
            if(x.Length==1)x[0]=Mathf.Max(0,(inner.width/scale-widths[0])*.5f);
            if(y.Length==1)y[0]=Mathf.Max(0,(availableH/scale-heights[0])*.5f);
            for(int i=1;i<x.Length;i++)x[i]=x[i-1]+widths[i-1]+columnGap;
            for(int i=1;i<y.Length;i++)y[i]=y[i-1]+heights[i-1]+rowGap;
            foreach(var item in items)item.Rect=new Rect(x[item.Column],y[item.Row],item.W,item.H);
        }
        static bool TrySegmentGrid(List<Item> items,Rect area,List<Rect> obstacles,float baseWidth,float baseHeight,float gap,float scale,out Rect[] positions)
        {
            positions=null;int count=items.Count;
            int maxColumns=Mathf.Min(32,count*2,Mathf.Max(1,Mathf.FloorToInt((area.width-baseWidth)/Mathf.Max(.000001f,baseWidth+gap))+1));
            int maxRows=Mathf.Min(48,count*2,Mathf.Max(1,Mathf.FloorToInt((area.height-baseHeight)/Mathf.Max(.000001f,baseHeight+gap))+1));
            var options=new List<Vector2Int>();
            for(int columns=1;columns<=maxColumns;columns++)for(int rows=1;rows<=maxRows;rows++)
                if(columns*rows>=count)options.Add(new Vector2Int(columns,rows));
            double Score(Vector2Int grid)
            {
                double aspect=Math.Log(Math.Max(.000001,grid.x*area.height/(grid.y*area.width)));
                return (grid.x*grid.y-count)/(double)count+.18*aspect*aspect;
            }
            var ordered=Enumerable.Range(0,count).OrderByDescending(i=>items[i].W*items[i].H).ThenBy(i=>items[i].Key,StringComparer.Ordinal).ToList();
            foreach(var grid in options.OrderBy(Score).ThenBy(g=>g.y).ThenBy(g=>g.x).Take(48))
            {
                float stepX=grid.x>1?(area.width-baseWidth)/(grid.x-1):0,stepY=grid.y>1?(area.height-baseHeight)/(grid.y-1):0;
                float originX=area.x+(grid.x==1?(area.width-items.Max(i=>i.W)*scale)/2:0);
                float originY=area.y+(grid.y==1?(area.height-items.Max(i=>i.H)*scale)/2:0);
                var candidate=new Rect[count];var placed=new List<Rect>();bool success=true;
                foreach(int index in ordered)
                {
                    var item=items[index];bool found=false;
                    for(int row=0;row<grid.y&&!found;row++)for(int column=0;column<grid.x;column++)
                    {
                        var rect=new Rect(originX+column*stepX,originY+row*stepY,item.W*scale,item.H*scale);
                        if(!KafoLayoutResult.Contains(area,rect,.00001f)||obstacles.Any(o=>KafoLayoutResult.Overlap(rect,o))||placed.Any(p=>KafoLayoutResult.Overlap(rect,Expand(p,gap*.5f))))continue;
                        candidate[index]=rect;placed.Add(rect);found=true;break;
                    }
                    if(!found){success=false;break;}
                }
                if(success){positions=candidate;return true;}
            }
            return false;
        }
        static string GroupName(string raw)=>string.IsNullOrWhiteSpace(raw)?"Группа без имени":raw;
        static void EmitRest(Context c,KafoLayoutResult result,Bucket b,Vector2 origin,float scale,Func<Rect,Rect> map,bool fullPadding)
        {
            if(b.IsGroup)origin+=new Vector2(c.GroupPad,fullPadding?c.GroupPad+c.GroupHeader:0)*scale;
            foreach(var item in b.Rest.Items)
            {
                var p=(NormalizedPlacement)item.Value;var s=c.Systems[p.SystemKey];
                var a=new AsLayout{Key="local:"+p.Key,SystemKey=s.Key,Name=s.Name,Rect=map(new Rect(origin+item.Rect.position*scale,item.Rect.size*scale))};
                a.PlacementKeys.Add(p.Key);if(p.SegmentKey!=null)a.SegmentKeys.Add(p.SegmentKey);if(b.IsGroup)a.GroupKeys.Add(b.Key);result.Systems.Add(a);
            }
        }
        static void AddIsland(Context c,KafoLayoutResult result,Rect requested)
        {
            var buckets=Buckets(c.Source.Placements.Where(p=>p.SegmentKey==null));
            foreach(var b in buckets)PackBucket(c,b,new HashSet<string>());
            var pack=PackGrid(buckets.Select(b=>new Item{Key=b.Key,W=b.W,H=b.H,Value=b}).ToList(),c.Gap);
            float scale=result.CellScale,padding=c.Pad*scale;
            bool transpose=!result.BridgesAlongX;
            float width=Mathf.Max(requested.width,(transpose?pack.H:pack.W)*scale+2*padding),height=Mathf.Max(requested.height,(transpose?pack.W:pack.H)*scale+2*padding);
            var main=result.MainRect;float gap=c.SegmentGap*scale;
            Rect island;
            // Keep the near edge fixed and grow away from the main zone along a separating axis.
            if(requested.xMin>=main.xMax) island=new Rect(Mathf.Max(requested.xMin,main.xMax+gap),requested.yMin,width,height);
            else if(requested.xMax<=main.xMin) island=new Rect(Mathf.Min(requested.xMax,main.xMin-gap)-width,requested.yMin,width,height);
            else if(requested.yMax<=main.yMin) island=new Rect(requested.xMin,Mathf.Min(requested.yMax,main.yMin-gap)-height,width,height);
            else if(requested.yMin>=main.yMax) island=new Rect(requested.xMin,Mathf.Max(requested.yMin,main.yMax+gap),width,height);
            else island=new Rect(main.xMax+gap,requested.yMin,width,height);
            result.IslandRect=island;
            Rect MapIsland(Rect r)=>MapFromLogical(island,r,transpose);
            foreach(var item in pack.Items)
            {
                var b=(Bucket)item.Value;var origin=Vector2.one*padding+item.Rect.position*scale;
                var rect=new Rect(origin,new Vector2(b.W,b.H)*scale);
                if(b.IsGroup)result.Groups.Add(new GroupLayout{Key=b.Key,Name=GroupName(b.Group),SegmentKey=null,Rect=MapIsland(rect),TitleRect=MapIsland(Title(rect,c.GroupPad*scale,(c.GroupHeader-c.TitleClearance)*scale))});
                EmitRest(c,result,b,origin,scale,MapIsland,true);
            }
            if(buckets.Count>0 && (width>requested.width+.001f || height>requested.height+.001f))result.Diagnostics.Add("Островок расширен под все АС без сегментов.");
        }
    }
}
