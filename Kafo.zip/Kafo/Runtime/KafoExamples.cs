using System;
using System.Collections.Generic;

namespace Sbrt.Av.Gameplay
{
    public sealed class KafoExample
    {
        public string Name {get;}
        public string Json {get;}
        internal KafoExample(string name,string json){Name=name;Json=json;}
    }

    /// <summary>Self-contained source documents for demos and EditMode validation.</summary>
    public static class KafoExamples
    {
        public const string Sectors=@"{
  ""Kafo"": {
    ""Id"": 1,
    ""Name"": ""KFO · Внутренний и внешний сектор"",
    ""Segments"": [
      ""Внутренний сектор"",
      ""Внешний сектор"",
      ""INTERNET""
    ],
    ""Placements"": [
      {
        ""AsId"": 1,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Шлюзовая сеть""
      },
      {
        ""AsId"": 2,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 3,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 4,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 5,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 6,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Шлюзовая сеть""
      },
      {
        ""AsId"": 7,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 8,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 9,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 10,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 11,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Шлюзовая сеть""
      },
      {
        ""AsId"": 12,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 13,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 14,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 15,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 16,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Шлюзовая сеть""
      },
      {
        ""AsId"": 17,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 18,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 19,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 20,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 21,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Шлюзовая сеть""
      },
      {
        ""AsId"": 22,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 23,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 24,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 25,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 26,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Шлюзовая сеть""
      },
      {
        ""AsId"": 27,
        ""Segment"": ""INTERNET"",
        ""Group"": null
      },
      {
        ""AsId"": 28,
        ""Segment"": ""INTERNET"",
        ""Group"": null
      },
      {
        ""AsId"": 101,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Шлюзовая сеть""
      },
      {
        ""AsId"": 101,
        ""Segment"": ""INTERNET"",
        ""Group"": ""Шлюзовая сеть""
      }
    ]
  },
  ""Systems"": [
    {
      ""Id"": 1,
      ""Name"": ""ТФС"",
      ""FpCount"": 1
    },
    {
      ""Id"": 2,
      ""Name"": ""META"",
      ""FpCount"": 2
    },
    {
      ""Id"": 3,
      ""Name"": ""META SOWA"",
      ""FpCount"": 3
    },
    {
      ""Id"": 4,
      ""Name"": ""Единая система проектирования"",
      ""FpCount"": 12
    },
    {
      ""Id"": 5,
      ""Name"": ""Корпоративная электронная почта"",
      ""FpCount"": 2
    },
    {
      ""Id"": 6,
      ""Name"": ""SberDocs"",
      ""FpCount"": 3
    },
    {
      ""Id"": 7,
      ""Name"": ""СУИР"",
      ""FpCount"": 1
    },
    {
      ""Id"": 8,
      ""Name"": ""SAP HCM ЕАСУП"",
      ""FpCount"": 2
    },
    {
      ""Id"": 9,
      ""Name"": ""Аврора"",
      ""FpCount"": 3
    },
    {
      ""Id"": 10,
      ""Name"": ""Капитал. Методология"",
      ""FpCount"": 1
    },
    {
      ""Id"": 11,
      ""Name"": ""Atlassian Confluence"",
      ""FpCount"": 2
    },
    {
      ""Id"": 12,
      ""Name"": ""КАП802 Первичные данные"",
      ""FpCount"": 3
    },
    {
      ""Id"": 13,
      ""Name"": ""AI-HUB БТ"",
      ""FpCount"": 1
    },
    {
      ""Id"": 14,
      ""Name"": ""Корпоративный портал"",
      ""FpCount"": 2
    },
    {
      ""Id"": 15,
      ""Name"": ""ПАМ"",
      ""FpCount"": 3
    },
    {
      ""Id"": 16,
      ""Name"": ""ПКЛП15ИАС ДКА"",
      ""FpCount"": 1
    },
    {
      ""Id"": 17,
      ""Name"": ""ТФС"",
      ""FpCount"": 2
    },
    {
      ""Id"": 18,
      ""Name"": ""META"",
      ""FpCount"": 3
    },
    {
      ""Id"": 19,
      ""Name"": ""META SOWA"",
      ""FpCount"": 1
    },
    {
      ""Id"": 20,
      ""Name"": ""Единая система проектирования"",
      ""FpCount"": 2
    },
    {
      ""Id"": 21,
      ""Name"": ""Корпоративная электронная почта"",
      ""FpCount"": 3
    },
    {
      ""Id"": 22,
      ""Name"": ""SberDocs"",
      ""FpCount"": 1
    },
    {
      ""Id"": 23,
      ""Name"": ""СУИР"",
      ""FpCount"": 2
    },
    {
      ""Id"": 24,
      ""Name"": ""SAP HCM ЕАСУП"",
      ""FpCount"": 3
    },
    {
      ""Id"": 25,
      ""Name"": ""Аврора"",
      ""FpCount"": 1
    },
    {
      ""Id"": 26,
      ""Name"": ""Капитал. Методология"",
      ""FpCount"": 2
    },
    {
      ""Id"": 27,
      ""Name"": ""Atlassian Confluence"",
      ""FpCount"": 3
    },
    {
      ""Id"": 28,
      ""Name"": ""КАП802 Первичные данные"",
      ""FpCount"": 1
    },
    {
      ""Id"": 101,
      ""Name"": ""Шлюзовая АС"",
      ""FpCount"": 3
    }
  ]
}
";

        public const string Bridges=@"{
  ""Kafo"": {
    ""Id"": 1,
    ""Name"": ""KFO · Общие АС и мосты"",
    ""Segments"": [
      ""Внешний сектор"",
      ""Внутренний сектор""
    ],
    ""Placements"": [
      {
        ""AsId"": 1,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 2,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 3,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 4,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 5,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 6,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 7,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 8,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 9,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 10,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 11,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 12,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 13,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 14,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 15,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 101,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Шлюзовая сеть""
      },
      {
        ""AsId"": 101,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Шлюзовая сеть""
      },
      {
        ""AsId"": 102,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 102,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 103,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 103,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      }
    ]
  },
  ""Systems"": [
    {
      ""Id"": 1,
      ""Name"": ""ТФС"",
      ""FpCount"": 1
    },
    {
      ""Id"": 2,
      ""Name"": ""META"",
      ""FpCount"": 2
    },
    {
      ""Id"": 3,
      ""Name"": ""META SOWA"",
      ""FpCount"": 1
    },
    {
      ""Id"": 4,
      ""Name"": ""Единая система проектирования"",
      ""FpCount"": 2
    },
    {
      ""Id"": 5,
      ""Name"": ""Корпоративная электронная почта"",
      ""FpCount"": 1
    },
    {
      ""Id"": 6,
      ""Name"": ""SberDocs"",
      ""FpCount"": 2
    },
    {
      ""Id"": 7,
      ""Name"": ""СУИР"",
      ""FpCount"": 1
    },
    {
      ""Id"": 8,
      ""Name"": ""SAP HCM ЕАСУП"",
      ""FpCount"": 2
    },
    {
      ""Id"": 9,
      ""Name"": ""Аврора"",
      ""FpCount"": 1
    },
    {
      ""Id"": 10,
      ""Name"": ""Капитал. Методология"",
      ""FpCount"": 2
    },
    {
      ""Id"": 11,
      ""Name"": ""Atlassian Confluence"",
      ""FpCount"": 1
    },
    {
      ""Id"": 12,
      ""Name"": ""КАП802 Первичные данные"",
      ""FpCount"": 2
    },
    {
      ""Id"": 13,
      ""Name"": ""AI-HUB БТ"",
      ""FpCount"": 1
    },
    {
      ""Id"": 14,
      ""Name"": ""Корпоративный портал"",
      ""FpCount"": 2
    },
    {
      ""Id"": 15,
      ""Name"": ""ПАМ"",
      ""FpCount"": 1
    },
    {
      ""Id"": 101,
      ""Name"": ""ТФС"",
      ""FpCount"": 4
    },
    {
      ""Id"": 102,
      ""Name"": ""META"",
      ""FpCount"": 7
    },
    {
      ""Id"": 103,
      ""Name"": ""AI-HUB БТ"",
      ""FpCount"": 10
    }
  ]
}
";

        public const string Analytics=@"{
  ""Kafo"": {
    ""Id"": 1,
    ""Name"": ""KFO · Аналитическая платформа"",
    ""Segments"": [
      ""Внутренний сектор"",
      ""Внешний сектор"",
      ""INTERNET""
    ],
    ""Placements"": [
      {
        ""AsId"": 1,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 2,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 3,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 4,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 5,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 6,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Сотрудники филиала""
      },
      {
        ""AsId"": 7,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 8,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 9,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 10,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 11,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Сотрудники филиала""
      },
      {
        ""AsId"": 12,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 13,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 14,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 15,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 16,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 17,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 18,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 19,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 20,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 21,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Сотрудники филиала""
      },
      {
        ""AsId"": 22,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 23,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 24,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 25,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 26,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Сотрудники филиала""
      },
      {
        ""AsId"": 27,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 28,
        ""Segment"": ""Внешний сектор"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 29,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 30,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 31,
        ""Segment"": ""INTERNET"",
        ""Group"": ""Корпоративно-аналитическая платформа""
      },
      {
        ""AsId"": 32,
        ""Segment"": ""INTERNET"",
        ""Group"": null
      },
      {
        ""AsId"": 33,
        ""Segment"": ""INTERNET"",
        ""Group"": null
      },
      {
        ""AsId"": 101,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 101,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 102,
        ""Segment"": ""Внутренний сектор"",
        ""Group"": null
      },
      {
        ""AsId"": 102,
        ""Segment"": ""Внешний сектор"",
        ""Group"": null
      }
    ]
  },
  ""Systems"": [
    {
      ""Id"": 1,
      ""Name"": ""ТФС"",
      ""FpCount"": 9
    },
    {
      ""Id"": 2,
      ""Name"": ""META"",
      ""FpCount"": 2
    },
    {
      ""Id"": 3,
      ""Name"": ""META SOWA"",
      ""FpCount"": 3
    },
    {
      ""Id"": 4,
      ""Name"": ""Единая система проектирования"",
      ""FpCount"": 4
    },
    {
      ""Id"": 5,
      ""Name"": ""Корпоративная электронная почта"",
      ""FpCount"": 1
    },
    {
      ""Id"": 6,
      ""Name"": ""SberDocs"",
      ""FpCount"": 2
    },
    {
      ""Id"": 7,
      ""Name"": ""СУИР"",
      ""FpCount"": 3
    },
    {
      ""Id"": 8,
      ""Name"": ""SAP HCM ЕАСУП"",
      ""FpCount"": 4
    },
    {
      ""Id"": 9,
      ""Name"": ""Аврора"",
      ""FpCount"": 9
    },
    {
      ""Id"": 10,
      ""Name"": ""Капитал. Методология"",
      ""FpCount"": 2
    },
    {
      ""Id"": 11,
      ""Name"": ""Atlassian Confluence"",
      ""FpCount"": 3
    },
    {
      ""Id"": 12,
      ""Name"": ""КАП802 Первичные данные"",
      ""FpCount"": 4
    },
    {
      ""Id"": 13,
      ""Name"": ""AI-HUB БТ"",
      ""FpCount"": 1
    },
    {
      ""Id"": 14,
      ""Name"": ""Корпоративный портал"",
      ""FpCount"": 2
    },
    {
      ""Id"": 15,
      ""Name"": ""ПАМ"",
      ""FpCount"": 3
    },
    {
      ""Id"": 16,
      ""Name"": ""ПКАП1158АС ДКА"",
      ""FpCount"": 8
    },
    {
      ""Id"": 17,
      ""Name"": ""ТФС"",
      ""FpCount"": 9
    },
    {
      ""Id"": 18,
      ""Name"": ""META"",
      ""FpCount"": 2
    },
    {
      ""Id"": 19,
      ""Name"": ""META SOWA"",
      ""FpCount"": 3
    },
    {
      ""Id"": 20,
      ""Name"": ""Единая система проектирования"",
      ""FpCount"": 4
    },
    {
      ""Id"": 21,
      ""Name"": ""Корпоративная электронная почта"",
      ""FpCount"": 1
    },
    {
      ""Id"": 22,
      ""Name"": ""SberDocs"",
      ""FpCount"": 2
    },
    {
      ""Id"": 23,
      ""Name"": ""СУИР"",
      ""FpCount"": 3
    },
    {
      ""Id"": 24,
      ""Name"": ""SAP HCM ЕАСУП"",
      ""FpCount"": 4
    },
    {
      ""Id"": 25,
      ""Name"": ""Аврора"",
      ""FpCount"": 9
    },
    {
      ""Id"": 26,
      ""Name"": ""Капитал. Методология"",
      ""FpCount"": 2
    },
    {
      ""Id"": 27,
      ""Name"": ""Atlassian Confluence"",
      ""FpCount"": 3
    },
    {
      ""Id"": 28,
      ""Name"": ""КАП802 Первичные данные"",
      ""FpCount"": 4
    },
    {
      ""Id"": 29,
      ""Name"": ""AI-HUB БТ"",
      ""FpCount"": 1
    },
    {
      ""Id"": 30,
      ""Name"": ""Корпоративный портал"",
      ""FpCount"": 2
    },
    {
      ""Id"": 31,
      ""Name"": ""ПАМ"",
      ""FpCount"": 3
    },
    {
      ""Id"": 32,
      ""Name"": ""ПКЛП15ИАС ДКА"",
      ""FpCount"": 4
    },
    {
      ""Id"": 33,
      ""Name"": ""ТФС"",
      ""FpCount"": 9
    },
    {
      ""Id"": 101,
      ""Name"": ""СУИР"",
      ""FpCount"": 8
    },
    {
      ""Id"": 102,
      ""Name"": ""META"",
      ""FpCount"": 10
    }
  ]
}
";

        public const string Dense=@"{
  ""Kafo"": {
    ""Id"": 1,
    ""Name"": ""KFO · 250 АС / 10 сегментов"",
    ""Segments"": [
      ""Сегмент 1"",
      ""Сегмент 2"",
      ""Сегмент 3"",
      ""Сегмент 4"",
      ""Сегмент 5"",
      ""Сегмент 6"",
      ""Сегмент 7"",
      ""Сегмент 8"",
      ""Сегмент 9"",
      ""Сегмент 10""
    ],
    ""Placements"": [
      {
        ""AsId"": 1,
        ""Segment"": ""Сегмент 1"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 1,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 2,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 3,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 4,
        ""Segment"": ""Сегмент 4"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 5,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 6,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 6,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 6,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 6,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 7,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 8,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 9,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 10,
        ""Segment"": ""Сегмент 10"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 11,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 11,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 11,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 12,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 13,
        ""Segment"": ""Сегмент 3"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 14,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 15,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 16,
        ""Segment"": ""Сегмент 6"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 16,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 17,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 18,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 19,
        ""Segment"": ""Сегмент 9"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 20,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 21,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 21,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 21,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 21,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 22,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 23,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 24,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 25,
        ""Segment"": ""Сегмент 5"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 26,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 26,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 26,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 27,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 28,
        ""Segment"": ""Сегмент 8"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 29,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 30,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 31,
        ""Segment"": ""Сегмент 1"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 31,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 32,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 33,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 34,
        ""Segment"": ""Сегмент 4"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 35,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 36,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 36,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 36,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 36,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 37,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 38,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 39,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 40,
        ""Segment"": ""Сегмент 10"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 41,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 41,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 41,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 42,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 43,
        ""Segment"": ""Сегмент 3"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 44,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 45,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 46,
        ""Segment"": ""Сегмент 6"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 46,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 47,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 48,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 49,
        ""Segment"": ""Сегмент 9"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 50,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 51,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 51,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 51,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 51,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 52,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 53,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 54,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 55,
        ""Segment"": ""Сегмент 5"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 56,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 56,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 56,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 57,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 58,
        ""Segment"": ""Сегмент 8"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 59,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 60,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 61,
        ""Segment"": ""Сегмент 1"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 61,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 62,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 63,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 64,
        ""Segment"": ""Сегмент 4"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 65,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 66,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 66,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 66,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 66,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 67,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 68,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 69,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 70,
        ""Segment"": ""Сегмент 10"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 71,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 71,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 71,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 72,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 73,
        ""Segment"": ""Сегмент 3"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 74,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 75,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 76,
        ""Segment"": ""Сегмент 6"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 76,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 77,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 78,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 79,
        ""Segment"": ""Сегмент 9"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 80,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 81,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 81,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 81,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 81,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 82,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 83,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 84,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 85,
        ""Segment"": ""Сегмент 5"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 86,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 86,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 86,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 87,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 88,
        ""Segment"": ""Сегмент 8"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 89,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 90,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 91,
        ""Segment"": ""Сегмент 1"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 91,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 92,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 93,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 94,
        ""Segment"": ""Сегмент 4"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 95,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 96,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 96,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 96,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 96,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 97,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 98,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 99,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 100,
        ""Segment"": ""Сегмент 10"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 101,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 101,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 101,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 102,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 103,
        ""Segment"": ""Сегмент 3"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 104,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 105,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 106,
        ""Segment"": ""Сегмент 6"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 106,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 107,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 108,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 109,
        ""Segment"": ""Сегмент 9"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 110,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 111,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 111,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 111,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 111,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 112,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 113,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 114,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 115,
        ""Segment"": ""Сегмент 5"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 116,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 116,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 116,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 117,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 118,
        ""Segment"": ""Сегмент 8"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 119,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 120,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 121,
        ""Segment"": ""Сегмент 1"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 121,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 122,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 123,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 124,
        ""Segment"": ""Сегмент 4"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 125,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 126,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 126,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 126,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 126,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 127,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 128,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 129,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 130,
        ""Segment"": ""Сегмент 10"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 131,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 131,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 131,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 132,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 133,
        ""Segment"": ""Сегмент 3"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 134,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 135,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 136,
        ""Segment"": ""Сегмент 6"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 136,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 137,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 138,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 139,
        ""Segment"": ""Сегмент 9"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 140,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 141,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 141,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 141,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 141,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 142,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 143,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 144,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 145,
        ""Segment"": ""Сегмент 5"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 146,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 146,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 146,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 147,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 148,
        ""Segment"": ""Сегмент 8"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 149,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 150,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 151,
        ""Segment"": ""Сегмент 1"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 151,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 152,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 153,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 154,
        ""Segment"": ""Сегмент 4"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 155,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 156,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 156,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 156,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 156,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 157,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 158,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 159,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 160,
        ""Segment"": ""Сегмент 10"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 161,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 161,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 161,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 162,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 163,
        ""Segment"": ""Сегмент 3"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 164,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 165,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 166,
        ""Segment"": ""Сегмент 6"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 166,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 167,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 168,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 169,
        ""Segment"": ""Сегмент 9"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 170,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 171,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 171,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 171,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 171,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 172,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 173,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 174,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 175,
        ""Segment"": ""Сегмент 5"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 176,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 176,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 176,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 177,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 178,
        ""Segment"": ""Сегмент 8"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 179,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 180,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 181,
        ""Segment"": ""Сегмент 1"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 181,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 182,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 183,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 184,
        ""Segment"": ""Сегмент 4"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 185,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 186,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 186,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 186,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 186,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 187,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 188,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 189,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 190,
        ""Segment"": ""Сегмент 10"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 191,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 191,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 191,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 192,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 193,
        ""Segment"": ""Сегмент 3"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 194,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 195,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 196,
        ""Segment"": ""Сегмент 6"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 196,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 197,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 198,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 199,
        ""Segment"": ""Сегмент 9"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 200,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 201,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 201,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 201,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 201,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 202,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 203,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 204,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 205,
        ""Segment"": ""Сегмент 5"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 206,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 206,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 206,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 207,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 208,
        ""Segment"": ""Сегмент 8"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 209,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 210,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 211,
        ""Segment"": ""Сегмент 1"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 211,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 212,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 213,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 214,
        ""Segment"": ""Сегмент 4"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 215,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 216,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 216,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 216,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 216,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 217,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 218,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 219,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 220,
        ""Segment"": ""Сегмент 10"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 221,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 221,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 221,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 222,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 223,
        ""Segment"": ""Сегмент 3"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 224,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 225,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 226,
        ""Segment"": ""Сегмент 6"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 226,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 227,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 228,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 229,
        ""Segment"": ""Сегмент 9"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 230,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 231,
        ""Segment"": ""Сегмент 1"",
        ""Group"": null
      },
      {
        ""AsId"": 231,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 231,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 231,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 232,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 233,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 234,
        ""Segment"": ""Сегмент 4"",
        ""Group"": null
      },
      {
        ""AsId"": 235,
        ""Segment"": ""Сегмент 5"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 236,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 236,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 236,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 237,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 238,
        ""Segment"": ""Сегмент 8"",
        ""Group"": ""Платформа 2""
      },
      {
        ""AsId"": 239,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 240,
        ""Segment"": ""Сегмент 10"",
        ""Group"": null
      },
      {
        ""AsId"": 241,
        ""Segment"": ""Сегмент 1"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 241,
        ""Segment"": ""Сегмент 2"",
        ""Group"": ""Платформа 1""
      },
      {
        ""AsId"": 242,
        ""Segment"": ""Сегмент 2"",
        ""Group"": null
      },
      {
        ""AsId"": 243,
        ""Segment"": ""Сегмент 3"",
        ""Group"": null
      },
      {
        ""AsId"": 244,
        ""Segment"": ""Сегмент 4"",
        ""Group"": ""Платформа 4""
      },
      {
        ""AsId"": 245,
        ""Segment"": ""Сегмент 5"",
        ""Group"": null
      },
      {
        ""AsId"": 246,
        ""Segment"": ""Сегмент 6"",
        ""Group"": null
      },
      {
        ""AsId"": 246,
        ""Segment"": ""Сегмент 7"",
        ""Group"": null
      },
      {
        ""AsId"": 246,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 246,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 247,
        ""Segment"": ""Сегмент 7"",
        ""Group"": ""Платформа 3""
      },
      {
        ""AsId"": 248,
        ""Segment"": ""Сегмент 8"",
        ""Group"": null
      },
      {
        ""AsId"": 249,
        ""Segment"": ""Сегмент 9"",
        ""Group"": null
      },
      {
        ""AsId"": 250,
        ""Segment"": ""Сегмент 10"",
        ""Group"": ""Платформа 2""
      }
    ]
  },
  ""Systems"": [
    {
      ""Id"": 1,
      ""Name"": ""АС 1 · ТФС"",
      ""FpCount"": 1
    },
    {
      ""Id"": 2,
      ""Name"": ""АС 2 · META"",
      ""FpCount"": 2
    },
    {
      ""Id"": 3,
      ""Name"": ""АС 3 · META SOWA"",
      ""FpCount"": 3
    },
    {
      ""Id"": 4,
      ""Name"": ""АС 4 · Единая система проектирования"",
      ""FpCount"": 4
    },
    {
      ""Id"": 5,
      ""Name"": ""АС 5 · Корпоративная электронная почта"",
      ""FpCount"": 5
    },
    {
      ""Id"": 6,
      ""Name"": ""АС 6 · SberDocs"",
      ""FpCount"": 6
    },
    {
      ""Id"": 7,
      ""Name"": ""АС 7 · СУИР"",
      ""FpCount"": 7
    },
    {
      ""Id"": 8,
      ""Name"": ""АС 8 · SAP HCM ЕАСУП"",
      ""FpCount"": 8
    },
    {
      ""Id"": 9,
      ""Name"": ""АС 9 · Аврора"",
      ""FpCount"": 9
    },
    {
      ""Id"": 10,
      ""Name"": ""АС 10 · Капитал. Методология"",
      ""FpCount"": 10
    },
    {
      ""Id"": 11,
      ""Name"": ""АС 11 · Atlassian Confluence"",
      ""FpCount"": 11
    },
    {
      ""Id"": 12,
      ""Name"": ""АС 12 · КАП802 Первичные данные"",
      ""FpCount"": 12
    },
    {
      ""Id"": 13,
      ""Name"": ""АС 13 · AI-HUB БТ"",
      ""FpCount"": 13
    },
    {
      ""Id"": 14,
      ""Name"": ""АС 14 · Корпоративный портал"",
      ""FpCount"": 14
    },
    {
      ""Id"": 15,
      ""Name"": ""АС 15 · ПАМ"",
      ""FpCount"": 15
    },
    {
      ""Id"": 16,
      ""Name"": ""АС 16 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 16
    },
    {
      ""Id"": 17,
      ""Name"": ""АС 17 · ТФС"",
      ""FpCount"": 17
    },
    {
      ""Id"": 18,
      ""Name"": ""АС 18 · META"",
      ""FpCount"": 18
    },
    {
      ""Id"": 19,
      ""Name"": ""АС 19 · META SOWA"",
      ""FpCount"": 1
    },
    {
      ""Id"": 20,
      ""Name"": ""АС 20 · Единая система проектирования"",
      ""FpCount"": 2
    },
    {
      ""Id"": 21,
      ""Name"": ""АС 21 · Корпоративная электронная почта"",
      ""FpCount"": 3
    },
    {
      ""Id"": 22,
      ""Name"": ""АС 22 · SberDocs"",
      ""FpCount"": 4
    },
    {
      ""Id"": 23,
      ""Name"": ""АС 23 · СУИР"",
      ""FpCount"": 5
    },
    {
      ""Id"": 24,
      ""Name"": ""АС 24 · SAP HCM ЕАСУП"",
      ""FpCount"": 6
    },
    {
      ""Id"": 25,
      ""Name"": ""АС 25 · Аврора"",
      ""FpCount"": 7
    },
    {
      ""Id"": 26,
      ""Name"": ""АС 26 · Капитал. Методология"",
      ""FpCount"": 8
    },
    {
      ""Id"": 27,
      ""Name"": ""АС 27 · Atlassian Confluence"",
      ""FpCount"": 9
    },
    {
      ""Id"": 28,
      ""Name"": ""АС 28 · КАП802 Первичные данные"",
      ""FpCount"": 10
    },
    {
      ""Id"": 29,
      ""Name"": ""АС 29 · AI-HUB БТ"",
      ""FpCount"": 11
    },
    {
      ""Id"": 30,
      ""Name"": ""АС 30 · Корпоративный портал"",
      ""FpCount"": 12
    },
    {
      ""Id"": 31,
      ""Name"": ""АС 31 · ПАМ"",
      ""FpCount"": 13
    },
    {
      ""Id"": 32,
      ""Name"": ""АС 32 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 14
    },
    {
      ""Id"": 33,
      ""Name"": ""АС 33 · ТФС"",
      ""FpCount"": 15
    },
    {
      ""Id"": 34,
      ""Name"": ""АС 34 · META"",
      ""FpCount"": 16
    },
    {
      ""Id"": 35,
      ""Name"": ""АС 35 · META SOWA"",
      ""FpCount"": 17
    },
    {
      ""Id"": 36,
      ""Name"": ""АС 36 · Единая система проектирования"",
      ""FpCount"": 18
    },
    {
      ""Id"": 37,
      ""Name"": ""АС 37 · Корпоративная электронная почта"",
      ""FpCount"": 1
    },
    {
      ""Id"": 38,
      ""Name"": ""АС 38 · SberDocs"",
      ""FpCount"": 2
    },
    {
      ""Id"": 39,
      ""Name"": ""АС 39 · СУИР"",
      ""FpCount"": 3
    },
    {
      ""Id"": 40,
      ""Name"": ""АС 40 · SAP HCM ЕАСУП"",
      ""FpCount"": 4
    },
    {
      ""Id"": 41,
      ""Name"": ""АС 41 · Аврора"",
      ""FpCount"": 5
    },
    {
      ""Id"": 42,
      ""Name"": ""АС 42 · Капитал. Методология"",
      ""FpCount"": 6
    },
    {
      ""Id"": 43,
      ""Name"": ""АС 43 · Atlassian Confluence"",
      ""FpCount"": 7
    },
    {
      ""Id"": 44,
      ""Name"": ""АС 44 · КАП802 Первичные данные"",
      ""FpCount"": 8
    },
    {
      ""Id"": 45,
      ""Name"": ""АС 45 · AI-HUB БТ"",
      ""FpCount"": 9
    },
    {
      ""Id"": 46,
      ""Name"": ""АС 46 · Корпоративный портал"",
      ""FpCount"": 10
    },
    {
      ""Id"": 47,
      ""Name"": ""АС 47 · ПАМ"",
      ""FpCount"": 11
    },
    {
      ""Id"": 48,
      ""Name"": ""АС 48 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 12
    },
    {
      ""Id"": 49,
      ""Name"": ""АС 49 · ТФС"",
      ""FpCount"": 13
    },
    {
      ""Id"": 50,
      ""Name"": ""АС 50 · META"",
      ""FpCount"": 14
    },
    {
      ""Id"": 51,
      ""Name"": ""АС 51 · META SOWA"",
      ""FpCount"": 15
    },
    {
      ""Id"": 52,
      ""Name"": ""АС 52 · Единая система проектирования"",
      ""FpCount"": 16
    },
    {
      ""Id"": 53,
      ""Name"": ""АС 53 · Корпоративная электронная почта"",
      ""FpCount"": 17
    },
    {
      ""Id"": 54,
      ""Name"": ""АС 54 · SberDocs"",
      ""FpCount"": 18
    },
    {
      ""Id"": 55,
      ""Name"": ""АС 55 · СУИР"",
      ""FpCount"": 1
    },
    {
      ""Id"": 56,
      ""Name"": ""АС 56 · SAP HCM ЕАСУП"",
      ""FpCount"": 2
    },
    {
      ""Id"": 57,
      ""Name"": ""АС 57 · Аврора"",
      ""FpCount"": 3
    },
    {
      ""Id"": 58,
      ""Name"": ""АС 58 · Капитал. Методология"",
      ""FpCount"": 4
    },
    {
      ""Id"": 59,
      ""Name"": ""АС 59 · Atlassian Confluence"",
      ""FpCount"": 5
    },
    {
      ""Id"": 60,
      ""Name"": ""АС 60 · КАП802 Первичные данные"",
      ""FpCount"": 6
    },
    {
      ""Id"": 61,
      ""Name"": ""АС 61 · AI-HUB БТ"",
      ""FpCount"": 7
    },
    {
      ""Id"": 62,
      ""Name"": ""АС 62 · Корпоративный портал"",
      ""FpCount"": 8
    },
    {
      ""Id"": 63,
      ""Name"": ""АС 63 · ПАМ"",
      ""FpCount"": 9
    },
    {
      ""Id"": 64,
      ""Name"": ""АС 64 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 10
    },
    {
      ""Id"": 65,
      ""Name"": ""АС 65 · ТФС"",
      ""FpCount"": 11
    },
    {
      ""Id"": 66,
      ""Name"": ""АС 66 · META"",
      ""FpCount"": 12
    },
    {
      ""Id"": 67,
      ""Name"": ""АС 67 · META SOWA"",
      ""FpCount"": 13
    },
    {
      ""Id"": 68,
      ""Name"": ""АС 68 · Единая система проектирования"",
      ""FpCount"": 14
    },
    {
      ""Id"": 69,
      ""Name"": ""АС 69 · Корпоративная электронная почта"",
      ""FpCount"": 15
    },
    {
      ""Id"": 70,
      ""Name"": ""АС 70 · SberDocs"",
      ""FpCount"": 16
    },
    {
      ""Id"": 71,
      ""Name"": ""АС 71 · СУИР"",
      ""FpCount"": 17
    },
    {
      ""Id"": 72,
      ""Name"": ""АС 72 · SAP HCM ЕАСУП"",
      ""FpCount"": 18
    },
    {
      ""Id"": 73,
      ""Name"": ""АС 73 · Аврора"",
      ""FpCount"": 1
    },
    {
      ""Id"": 74,
      ""Name"": ""АС 74 · Капитал. Методология"",
      ""FpCount"": 2
    },
    {
      ""Id"": 75,
      ""Name"": ""АС 75 · Atlassian Confluence"",
      ""FpCount"": 3
    },
    {
      ""Id"": 76,
      ""Name"": ""АС 76 · КАП802 Первичные данные"",
      ""FpCount"": 4
    },
    {
      ""Id"": 77,
      ""Name"": ""АС 77 · AI-HUB БТ"",
      ""FpCount"": 5
    },
    {
      ""Id"": 78,
      ""Name"": ""АС 78 · Корпоративный портал"",
      ""FpCount"": 6
    },
    {
      ""Id"": 79,
      ""Name"": ""АС 79 · ПАМ"",
      ""FpCount"": 7
    },
    {
      ""Id"": 80,
      ""Name"": ""АС 80 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 8
    },
    {
      ""Id"": 81,
      ""Name"": ""АС 81 · ТФС"",
      ""FpCount"": 9
    },
    {
      ""Id"": 82,
      ""Name"": ""АС 82 · META"",
      ""FpCount"": 10
    },
    {
      ""Id"": 83,
      ""Name"": ""АС 83 · META SOWA"",
      ""FpCount"": 11
    },
    {
      ""Id"": 84,
      ""Name"": ""АС 84 · Единая система проектирования"",
      ""FpCount"": 12
    },
    {
      ""Id"": 85,
      ""Name"": ""АС 85 · Корпоративная электронная почта"",
      ""FpCount"": 13
    },
    {
      ""Id"": 86,
      ""Name"": ""АС 86 · SberDocs"",
      ""FpCount"": 14
    },
    {
      ""Id"": 87,
      ""Name"": ""АС 87 · СУИР"",
      ""FpCount"": 15
    },
    {
      ""Id"": 88,
      ""Name"": ""АС 88 · SAP HCM ЕАСУП"",
      ""FpCount"": 16
    },
    {
      ""Id"": 89,
      ""Name"": ""АС 89 · Аврора"",
      ""FpCount"": 17
    },
    {
      ""Id"": 90,
      ""Name"": ""АС 90 · Капитал. Методология"",
      ""FpCount"": 18
    },
    {
      ""Id"": 91,
      ""Name"": ""АС 91 · Atlassian Confluence"",
      ""FpCount"": 1
    },
    {
      ""Id"": 92,
      ""Name"": ""АС 92 · КАП802 Первичные данные"",
      ""FpCount"": 2
    },
    {
      ""Id"": 93,
      ""Name"": ""АС 93 · AI-HUB БТ"",
      ""FpCount"": 3
    },
    {
      ""Id"": 94,
      ""Name"": ""АС 94 · Корпоративный портал"",
      ""FpCount"": 4
    },
    {
      ""Id"": 95,
      ""Name"": ""АС 95 · ПАМ"",
      ""FpCount"": 5
    },
    {
      ""Id"": 96,
      ""Name"": ""АС 96 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 6
    },
    {
      ""Id"": 97,
      ""Name"": ""АС 97 · ТФС"",
      ""FpCount"": 7
    },
    {
      ""Id"": 98,
      ""Name"": ""АС 98 · META"",
      ""FpCount"": 8
    },
    {
      ""Id"": 99,
      ""Name"": ""АС 99 · META SOWA"",
      ""FpCount"": 9
    },
    {
      ""Id"": 100,
      ""Name"": ""АС 100 · Единая система проектирования"",
      ""FpCount"": 10
    },
    {
      ""Id"": 101,
      ""Name"": ""АС 101 · Корпоративная электронная почта"",
      ""FpCount"": 11
    },
    {
      ""Id"": 102,
      ""Name"": ""АС 102 · SberDocs"",
      ""FpCount"": 12
    },
    {
      ""Id"": 103,
      ""Name"": ""АС 103 · СУИР"",
      ""FpCount"": 13
    },
    {
      ""Id"": 104,
      ""Name"": ""АС 104 · SAP HCM ЕАСУП"",
      ""FpCount"": 14
    },
    {
      ""Id"": 105,
      ""Name"": ""АС 105 · Аврора"",
      ""FpCount"": 15
    },
    {
      ""Id"": 106,
      ""Name"": ""АС 106 · Капитал. Методология"",
      ""FpCount"": 16
    },
    {
      ""Id"": 107,
      ""Name"": ""АС 107 · Atlassian Confluence"",
      ""FpCount"": 17
    },
    {
      ""Id"": 108,
      ""Name"": ""АС 108 · КАП802 Первичные данные"",
      ""FpCount"": 18
    },
    {
      ""Id"": 109,
      ""Name"": ""АС 109 · AI-HUB БТ"",
      ""FpCount"": 1
    },
    {
      ""Id"": 110,
      ""Name"": ""АС 110 · Корпоративный портал"",
      ""FpCount"": 2
    },
    {
      ""Id"": 111,
      ""Name"": ""АС 111 · ПАМ"",
      ""FpCount"": 3
    },
    {
      ""Id"": 112,
      ""Name"": ""АС 112 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 4
    },
    {
      ""Id"": 113,
      ""Name"": ""АС 113 · ТФС"",
      ""FpCount"": 5
    },
    {
      ""Id"": 114,
      ""Name"": ""АС 114 · META"",
      ""FpCount"": 6
    },
    {
      ""Id"": 115,
      ""Name"": ""АС 115 · META SOWA"",
      ""FpCount"": 7
    },
    {
      ""Id"": 116,
      ""Name"": ""АС 116 · Единая система проектирования"",
      ""FpCount"": 8
    },
    {
      ""Id"": 117,
      ""Name"": ""АС 117 · Корпоративная электронная почта"",
      ""FpCount"": 9
    },
    {
      ""Id"": 118,
      ""Name"": ""АС 118 · SberDocs"",
      ""FpCount"": 10
    },
    {
      ""Id"": 119,
      ""Name"": ""АС 119 · СУИР"",
      ""FpCount"": 11
    },
    {
      ""Id"": 120,
      ""Name"": ""АС 120 · SAP HCM ЕАСУП"",
      ""FpCount"": 12
    },
    {
      ""Id"": 121,
      ""Name"": ""АС 121 · Аврора"",
      ""FpCount"": 13
    },
    {
      ""Id"": 122,
      ""Name"": ""АС 122 · Капитал. Методология"",
      ""FpCount"": 14
    },
    {
      ""Id"": 123,
      ""Name"": ""АС 123 · Atlassian Confluence"",
      ""FpCount"": 15
    },
    {
      ""Id"": 124,
      ""Name"": ""АС 124 · КАП802 Первичные данные"",
      ""FpCount"": 16
    },
    {
      ""Id"": 125,
      ""Name"": ""АС 125 · AI-HUB БТ"",
      ""FpCount"": 17
    },
    {
      ""Id"": 126,
      ""Name"": ""АС 126 · Корпоративный портал"",
      ""FpCount"": 18
    },
    {
      ""Id"": 127,
      ""Name"": ""АС 127 · ПАМ"",
      ""FpCount"": 1
    },
    {
      ""Id"": 128,
      ""Name"": ""АС 128 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 2
    },
    {
      ""Id"": 129,
      ""Name"": ""АС 129 · ТФС"",
      ""FpCount"": 3
    },
    {
      ""Id"": 130,
      ""Name"": ""АС 130 · META"",
      ""FpCount"": 4
    },
    {
      ""Id"": 131,
      ""Name"": ""АС 131 · META SOWA"",
      ""FpCount"": 5
    },
    {
      ""Id"": 132,
      ""Name"": ""АС 132 · Единая система проектирования"",
      ""FpCount"": 6
    },
    {
      ""Id"": 133,
      ""Name"": ""АС 133 · Корпоративная электронная почта"",
      ""FpCount"": 7
    },
    {
      ""Id"": 134,
      ""Name"": ""АС 134 · SberDocs"",
      ""FpCount"": 8
    },
    {
      ""Id"": 135,
      ""Name"": ""АС 135 · СУИР"",
      ""FpCount"": 9
    },
    {
      ""Id"": 136,
      ""Name"": ""АС 136 · SAP HCM ЕАСУП"",
      ""FpCount"": 10
    },
    {
      ""Id"": 137,
      ""Name"": ""АС 137 · Аврора"",
      ""FpCount"": 11
    },
    {
      ""Id"": 138,
      ""Name"": ""АС 138 · Капитал. Методология"",
      ""FpCount"": 12
    },
    {
      ""Id"": 139,
      ""Name"": ""АС 139 · Atlassian Confluence"",
      ""FpCount"": 13
    },
    {
      ""Id"": 140,
      ""Name"": ""АС 140 · КАП802 Первичные данные"",
      ""FpCount"": 14
    },
    {
      ""Id"": 141,
      ""Name"": ""АС 141 · AI-HUB БТ"",
      ""FpCount"": 15
    },
    {
      ""Id"": 142,
      ""Name"": ""АС 142 · Корпоративный портал"",
      ""FpCount"": 16
    },
    {
      ""Id"": 143,
      ""Name"": ""АС 143 · ПАМ"",
      ""FpCount"": 17
    },
    {
      ""Id"": 144,
      ""Name"": ""АС 144 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 18
    },
    {
      ""Id"": 145,
      ""Name"": ""АС 145 · ТФС"",
      ""FpCount"": 1
    },
    {
      ""Id"": 146,
      ""Name"": ""АС 146 · META"",
      ""FpCount"": 2
    },
    {
      ""Id"": 147,
      ""Name"": ""АС 147 · META SOWA"",
      ""FpCount"": 3
    },
    {
      ""Id"": 148,
      ""Name"": ""АС 148 · Единая система проектирования"",
      ""FpCount"": 4
    },
    {
      ""Id"": 149,
      ""Name"": ""АС 149 · Корпоративная электронная почта"",
      ""FpCount"": 5
    },
    {
      ""Id"": 150,
      ""Name"": ""АС 150 · SberDocs"",
      ""FpCount"": 6
    },
    {
      ""Id"": 151,
      ""Name"": ""АС 151 · СУИР"",
      ""FpCount"": 7
    },
    {
      ""Id"": 152,
      ""Name"": ""АС 152 · SAP HCM ЕАСУП"",
      ""FpCount"": 8
    },
    {
      ""Id"": 153,
      ""Name"": ""АС 153 · Аврора"",
      ""FpCount"": 9
    },
    {
      ""Id"": 154,
      ""Name"": ""АС 154 · Капитал. Методология"",
      ""FpCount"": 10
    },
    {
      ""Id"": 155,
      ""Name"": ""АС 155 · Atlassian Confluence"",
      ""FpCount"": 11
    },
    {
      ""Id"": 156,
      ""Name"": ""АС 156 · КАП802 Первичные данные"",
      ""FpCount"": 12
    },
    {
      ""Id"": 157,
      ""Name"": ""АС 157 · AI-HUB БТ"",
      ""FpCount"": 13
    },
    {
      ""Id"": 158,
      ""Name"": ""АС 158 · Корпоративный портал"",
      ""FpCount"": 14
    },
    {
      ""Id"": 159,
      ""Name"": ""АС 159 · ПАМ"",
      ""FpCount"": 15
    },
    {
      ""Id"": 160,
      ""Name"": ""АС 160 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 16
    },
    {
      ""Id"": 161,
      ""Name"": ""АС 161 · ТФС"",
      ""FpCount"": 17
    },
    {
      ""Id"": 162,
      ""Name"": ""АС 162 · META"",
      ""FpCount"": 18
    },
    {
      ""Id"": 163,
      ""Name"": ""АС 163 · META SOWA"",
      ""FpCount"": 1
    },
    {
      ""Id"": 164,
      ""Name"": ""АС 164 · Единая система проектирования"",
      ""FpCount"": 2
    },
    {
      ""Id"": 165,
      ""Name"": ""АС 165 · Корпоративная электронная почта"",
      ""FpCount"": 3
    },
    {
      ""Id"": 166,
      ""Name"": ""АС 166 · SberDocs"",
      ""FpCount"": 4
    },
    {
      ""Id"": 167,
      ""Name"": ""АС 167 · СУИР"",
      ""FpCount"": 5
    },
    {
      ""Id"": 168,
      ""Name"": ""АС 168 · SAP HCM ЕАСУП"",
      ""FpCount"": 6
    },
    {
      ""Id"": 169,
      ""Name"": ""АС 169 · Аврора"",
      ""FpCount"": 7
    },
    {
      ""Id"": 170,
      ""Name"": ""АС 170 · Капитал. Методология"",
      ""FpCount"": 8
    },
    {
      ""Id"": 171,
      ""Name"": ""АС 171 · Atlassian Confluence"",
      ""FpCount"": 9
    },
    {
      ""Id"": 172,
      ""Name"": ""АС 172 · КАП802 Первичные данные"",
      ""FpCount"": 10
    },
    {
      ""Id"": 173,
      ""Name"": ""АС 173 · AI-HUB БТ"",
      ""FpCount"": 11
    },
    {
      ""Id"": 174,
      ""Name"": ""АС 174 · Корпоративный портал"",
      ""FpCount"": 12
    },
    {
      ""Id"": 175,
      ""Name"": ""АС 175 · ПАМ"",
      ""FpCount"": 13
    },
    {
      ""Id"": 176,
      ""Name"": ""АС 176 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 14
    },
    {
      ""Id"": 177,
      ""Name"": ""АС 177 · ТФС"",
      ""FpCount"": 15
    },
    {
      ""Id"": 178,
      ""Name"": ""АС 178 · META"",
      ""FpCount"": 16
    },
    {
      ""Id"": 179,
      ""Name"": ""АС 179 · META SOWA"",
      ""FpCount"": 17
    },
    {
      ""Id"": 180,
      ""Name"": ""АС 180 · Единая система проектирования"",
      ""FpCount"": 18
    },
    {
      ""Id"": 181,
      ""Name"": ""АС 181 · Корпоративная электронная почта"",
      ""FpCount"": 1
    },
    {
      ""Id"": 182,
      ""Name"": ""АС 182 · SberDocs"",
      ""FpCount"": 2
    },
    {
      ""Id"": 183,
      ""Name"": ""АС 183 · СУИР"",
      ""FpCount"": 3
    },
    {
      ""Id"": 184,
      ""Name"": ""АС 184 · SAP HCM ЕАСУП"",
      ""FpCount"": 4
    },
    {
      ""Id"": 185,
      ""Name"": ""АС 185 · Аврора"",
      ""FpCount"": 5
    },
    {
      ""Id"": 186,
      ""Name"": ""АС 186 · Капитал. Методология"",
      ""FpCount"": 6
    },
    {
      ""Id"": 187,
      ""Name"": ""АС 187 · Atlassian Confluence"",
      ""FpCount"": 7
    },
    {
      ""Id"": 188,
      ""Name"": ""АС 188 · КАП802 Первичные данные"",
      ""FpCount"": 8
    },
    {
      ""Id"": 189,
      ""Name"": ""АС 189 · AI-HUB БТ"",
      ""FpCount"": 9
    },
    {
      ""Id"": 190,
      ""Name"": ""АС 190 · Корпоративный портал"",
      ""FpCount"": 10
    },
    {
      ""Id"": 191,
      ""Name"": ""АС 191 · ПАМ"",
      ""FpCount"": 11
    },
    {
      ""Id"": 192,
      ""Name"": ""АС 192 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 12
    },
    {
      ""Id"": 193,
      ""Name"": ""АС 193 · ТФС"",
      ""FpCount"": 13
    },
    {
      ""Id"": 194,
      ""Name"": ""АС 194 · META"",
      ""FpCount"": 14
    },
    {
      ""Id"": 195,
      ""Name"": ""АС 195 · META SOWA"",
      ""FpCount"": 15
    },
    {
      ""Id"": 196,
      ""Name"": ""АС 196 · Единая система проектирования"",
      ""FpCount"": 16
    },
    {
      ""Id"": 197,
      ""Name"": ""АС 197 · Корпоративная электронная почта"",
      ""FpCount"": 17
    },
    {
      ""Id"": 198,
      ""Name"": ""АС 198 · SberDocs"",
      ""FpCount"": 18
    },
    {
      ""Id"": 199,
      ""Name"": ""АС 199 · СУИР"",
      ""FpCount"": 1
    },
    {
      ""Id"": 200,
      ""Name"": ""АС 200 · SAP HCM ЕАСУП"",
      ""FpCount"": 2
    },
    {
      ""Id"": 201,
      ""Name"": ""АС 201 · Аврора"",
      ""FpCount"": 3
    },
    {
      ""Id"": 202,
      ""Name"": ""АС 202 · Капитал. Методология"",
      ""FpCount"": 4
    },
    {
      ""Id"": 203,
      ""Name"": ""АС 203 · Atlassian Confluence"",
      ""FpCount"": 5
    },
    {
      ""Id"": 204,
      ""Name"": ""АС 204 · КАП802 Первичные данные"",
      ""FpCount"": 6
    },
    {
      ""Id"": 205,
      ""Name"": ""АС 205 · AI-HUB БТ"",
      ""FpCount"": 7
    },
    {
      ""Id"": 206,
      ""Name"": ""АС 206 · Корпоративный портал"",
      ""FpCount"": 8
    },
    {
      ""Id"": 207,
      ""Name"": ""АС 207 · ПАМ"",
      ""FpCount"": 9
    },
    {
      ""Id"": 208,
      ""Name"": ""АС 208 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 10
    },
    {
      ""Id"": 209,
      ""Name"": ""АС 209 · ТФС"",
      ""FpCount"": 11
    },
    {
      ""Id"": 210,
      ""Name"": ""АС 210 · META"",
      ""FpCount"": 12
    },
    {
      ""Id"": 211,
      ""Name"": ""АС 211 · META SOWA"",
      ""FpCount"": 13
    },
    {
      ""Id"": 212,
      ""Name"": ""АС 212 · Единая система проектирования"",
      ""FpCount"": 14
    },
    {
      ""Id"": 213,
      ""Name"": ""АС 213 · Корпоративная электронная почта"",
      ""FpCount"": 15
    },
    {
      ""Id"": 214,
      ""Name"": ""АС 214 · SberDocs"",
      ""FpCount"": 16
    },
    {
      ""Id"": 215,
      ""Name"": ""АС 215 · СУИР"",
      ""FpCount"": 17
    },
    {
      ""Id"": 216,
      ""Name"": ""АС 216 · SAP HCM ЕАСУП"",
      ""FpCount"": 18
    },
    {
      ""Id"": 217,
      ""Name"": ""АС 217 · Аврора"",
      ""FpCount"": 1
    },
    {
      ""Id"": 218,
      ""Name"": ""АС 218 · Капитал. Методология"",
      ""FpCount"": 2
    },
    {
      ""Id"": 219,
      ""Name"": ""АС 219 · Atlassian Confluence"",
      ""FpCount"": 3
    },
    {
      ""Id"": 220,
      ""Name"": ""АС 220 · КАП802 Первичные данные"",
      ""FpCount"": 4
    },
    {
      ""Id"": 221,
      ""Name"": ""АС 221 · AI-HUB БТ"",
      ""FpCount"": 5
    },
    {
      ""Id"": 222,
      ""Name"": ""АС 222 · Корпоративный портал"",
      ""FpCount"": 6
    },
    {
      ""Id"": 223,
      ""Name"": ""АС 223 · ПАМ"",
      ""FpCount"": 7
    },
    {
      ""Id"": 224,
      ""Name"": ""АС 224 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 8
    },
    {
      ""Id"": 225,
      ""Name"": ""АС 225 · ТФС"",
      ""FpCount"": 9
    },
    {
      ""Id"": 226,
      ""Name"": ""АС 226 · META"",
      ""FpCount"": 10
    },
    {
      ""Id"": 227,
      ""Name"": ""АС 227 · META SOWA"",
      ""FpCount"": 11
    },
    {
      ""Id"": 228,
      ""Name"": ""АС 228 · Единая система проектирования"",
      ""FpCount"": 12
    },
    {
      ""Id"": 229,
      ""Name"": ""АС 229 · Корпоративная электронная почта"",
      ""FpCount"": 13
    },
    {
      ""Id"": 230,
      ""Name"": ""АС 230 · SberDocs"",
      ""FpCount"": 14
    },
    {
      ""Id"": 231,
      ""Name"": ""АС 231 · СУИР"",
      ""FpCount"": 15
    },
    {
      ""Id"": 232,
      ""Name"": ""АС 232 · SAP HCM ЕАСУП"",
      ""FpCount"": 16
    },
    {
      ""Id"": 233,
      ""Name"": ""АС 233 · Аврора"",
      ""FpCount"": 17
    },
    {
      ""Id"": 234,
      ""Name"": ""АС 234 · Капитал. Методология"",
      ""FpCount"": 18
    },
    {
      ""Id"": 235,
      ""Name"": ""АС 235 · Atlassian Confluence"",
      ""FpCount"": 1
    },
    {
      ""Id"": 236,
      ""Name"": ""АС 236 · КАП802 Первичные данные"",
      ""FpCount"": 2
    },
    {
      ""Id"": 237,
      ""Name"": ""АС 237 · AI-HUB БТ"",
      ""FpCount"": 3
    },
    {
      ""Id"": 238,
      ""Name"": ""АС 238 · Корпоративный портал"",
      ""FpCount"": 4
    },
    {
      ""Id"": 239,
      ""Name"": ""АС 239 · ПАМ"",
      ""FpCount"": 5
    },
    {
      ""Id"": 240,
      ""Name"": ""АС 240 · ПКЛП15ИАС ДКА"",
      ""FpCount"": 6
    },
    {
      ""Id"": 241,
      ""Name"": ""АС 241 · ТФС"",
      ""FpCount"": 7
    },
    {
      ""Id"": 242,
      ""Name"": ""АС 242 · META"",
      ""FpCount"": 8
    },
    {
      ""Id"": 243,
      ""Name"": ""АС 243 · META SOWA"",
      ""FpCount"": 9
    },
    {
      ""Id"": 244,
      ""Name"": ""АС 244 · Единая система проектирования"",
      ""FpCount"": 10
    },
    {
      ""Id"": 245,
      ""Name"": ""АС 245 · Корпоративная электронная почта"",
      ""FpCount"": 11
    },
    {
      ""Id"": 246,
      ""Name"": ""АС 246 · SberDocs"",
      ""FpCount"": 12
    },
    {
      ""Id"": 247,
      ""Name"": ""АС 247 · СУИР"",
      ""FpCount"": 13
    },
    {
      ""Id"": 248,
      ""Name"": ""АС 248 · SAP HCM ЕАСУП"",
      ""FpCount"": 14
    },
    {
      ""Id"": 249,
      ""Name"": ""АС 249 · Аврора"",
      ""FpCount"": 15
    },
    {
      ""Id"": 250,
      ""Name"": ""АС 250 · Капитал. Методология"",
      ""FpCount"": 16
    }
  ]
}
";

        public const string Minimal=@"{
  ""Kafo"": {
    ""Id"": 1,
    ""Name"": ""KFO · Минимальный пример"",
    ""Segments"": [
      ""Основной""
    ],
    ""Placements"": [
      {
        ""AsId"": 1,
        ""Segment"": ""Основной"",
        ""Group"": null
      },
      {
        ""AsId"": 2,
        ""Segment"": ""Основной"",
        ""Group"": ""Аналитика""
      }
    ]
  },
  ""Systems"": [
    {
      ""Id"": 1,
      ""Name"": ""ТФС"",
      ""FpCount"": 1
    },
    {
      ""Id"": 2,
      ""Name"": ""META"",
      ""FpCount"": 4
    }
  ]
}
";

        public const string Orphans=@"{
  ""Kafo"": {
    ""Id"": 1,
    ""Name"": ""KFO · Островок без сегментов"",
    ""Segments"": [
      ""Основной""
    ],
    ""Placements"": [
      {
        ""AsId"": 1,
        ""Segment"": ""Основной"",
        ""Group"": null
      },
      {
        ""AsId"": 100,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 101,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 102,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 103,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 104,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 105,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 106,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 107,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 108,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 109,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 110,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 111,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 112,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 113,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 114,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 115,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 116,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 117,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 118,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 119,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 120,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 121,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 122,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 123,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 124,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 125,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 126,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 127,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 128,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 129,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 130,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 131,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 132,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 133,
        ""Segment"": null,
        ""Group"": ""Группа островка""
      },
      {
        ""AsId"": 134,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 135,
        ""Segment"": null,
        ""Group"": null
      }
    ]
  },
  ""Systems"": [
    {
      ""Id"": 1,
      ""Name"": ""Основная АС"",
      ""FpCount"": 1
    },
    {
      ""Id"": 100,
      ""Name"": ""Отдельная АС 1"",
      ""FpCount"": 1
    },
    {
      ""Id"": 101,
      ""Name"": ""Отдельная АС 2"",
      ""FpCount"": 2
    },
    {
      ""Id"": 102,
      ""Name"": ""Отдельная АС 3"",
      ""FpCount"": 3
    },
    {
      ""Id"": 103,
      ""Name"": ""Отдельная АС 4"",
      ""FpCount"": 4
    },
    {
      ""Id"": 104,
      ""Name"": ""Отдельная АС 5"",
      ""FpCount"": 5
    },
    {
      ""Id"": 105,
      ""Name"": ""Отдельная АС 6"",
      ""FpCount"": 1
    },
    {
      ""Id"": 106,
      ""Name"": ""Отдельная АС 7"",
      ""FpCount"": 2
    },
    {
      ""Id"": 107,
      ""Name"": ""Отдельная АС 8"",
      ""FpCount"": 3
    },
    {
      ""Id"": 108,
      ""Name"": ""Отдельная АС 9"",
      ""FpCount"": 4
    },
    {
      ""Id"": 109,
      ""Name"": ""Отдельная АС 10"",
      ""FpCount"": 5
    },
    {
      ""Id"": 110,
      ""Name"": ""Отдельная АС 11"",
      ""FpCount"": 1
    },
    {
      ""Id"": 111,
      ""Name"": ""Отдельная АС 12"",
      ""FpCount"": 2
    },
    {
      ""Id"": 112,
      ""Name"": ""Отдельная АС 13"",
      ""FpCount"": 3
    },
    {
      ""Id"": 113,
      ""Name"": ""Отдельная АС 14"",
      ""FpCount"": 4
    },
    {
      ""Id"": 114,
      ""Name"": ""Отдельная АС 15"",
      ""FpCount"": 5
    },
    {
      ""Id"": 115,
      ""Name"": ""Отдельная АС 16"",
      ""FpCount"": 1
    },
    {
      ""Id"": 116,
      ""Name"": ""Отдельная АС 17"",
      ""FpCount"": 2
    },
    {
      ""Id"": 117,
      ""Name"": ""Отдельная АС 18"",
      ""FpCount"": 3
    },
    {
      ""Id"": 118,
      ""Name"": ""Отдельная АС 19"",
      ""FpCount"": 4
    },
    {
      ""Id"": 119,
      ""Name"": ""Отдельная АС 20"",
      ""FpCount"": 5
    },
    {
      ""Id"": 120,
      ""Name"": ""Отдельная АС 21"",
      ""FpCount"": 1
    },
    {
      ""Id"": 121,
      ""Name"": ""Отдельная АС 22"",
      ""FpCount"": 2
    },
    {
      ""Id"": 122,
      ""Name"": ""Отдельная АС 23"",
      ""FpCount"": 3
    },
    {
      ""Id"": 123,
      ""Name"": ""Отдельная АС 24"",
      ""FpCount"": 4
    },
    {
      ""Id"": 124,
      ""Name"": ""Отдельная АС 25"",
      ""FpCount"": 5
    },
    {
      ""Id"": 125,
      ""Name"": ""Отдельная АС 26"",
      ""FpCount"": 1
    },
    {
      ""Id"": 126,
      ""Name"": ""Отдельная АС 27"",
      ""FpCount"": 2
    },
    {
      ""Id"": 127,
      ""Name"": ""Отдельная АС 28"",
      ""FpCount"": 3
    },
    {
      ""Id"": 128,
      ""Name"": ""Отдельная АС 29"",
      ""FpCount"": 4
    },
    {
      ""Id"": 129,
      ""Name"": ""Отдельная АС 30"",
      ""FpCount"": 5
    },
    {
      ""Id"": 130,
      ""Name"": ""Отдельная АС 31"",
      ""FpCount"": 1
    },
    {
      ""Id"": 131,
      ""Name"": ""Отдельная АС 32"",
      ""FpCount"": 2
    },
    {
      ""Id"": 132,
      ""Name"": ""Отдельная АС 33"",
      ""FpCount"": 3
    },
    {
      ""Id"": 133,
      ""Name"": ""Отдельная АС 34"",
      ""FpCount"": 4
    },
    {
      ""Id"": 134,
      ""Name"": ""Отдельная АС 35"",
      ""FpCount"": 5
    },
    {
      ""Id"": 135,
      ""Name"": ""Отдельная АС 36"",
      ""FpCount"": 1
    },
    {
      ""Id"": 999,
      ""Name"": ""АС без записей размещения"",
      ""FpCount"": 2
    }
  ]
}
";

        public const string Dirty=@"{
  ""Kafo"": {
    ""Id"": 7,
    ""Name"": ""KFO · Некорректные данные"",
    ""Segments"": [
      ""Повтор"",
      ""Повтор"",
      """",
      null
    ],
    ""Placements"": [
      {
        ""AsId"": 1,
        ""Segment"": ""Повтор"",
        ""Group"": ""Одна группа""
      },
      {
        ""AsId"": 1,
        ""Segment"": ""Повтор"",
        ""Group"": ""Одна группа""
      },
      {
        ""AsId"": 1,
        ""Segment"": ""Необъявленный"",
        ""Group"": null
      },
      {
        ""AsId"": 1,
        ""Segment"": null,
        ""Group"": null
      },
      {
        ""AsId"": 404,
        ""Segment"": ""Необъявленный"",
        ""Group"": """"
      },
      {
        ""AsId"": 404,
        ""Segment"": """",
        ""Group"": """"
      },
      {
        ""AsId"": 9,
        ""Segment"": null,
        ""Group"": ""Группа без сегмента""
      },
      {
        ""AsId"": ""не число"",
        ""Segment"": 42,
        ""Group"": []
      },
      null
    ]
  },
  ""Systems"": [
    {
      ""Id"": 1,
      ""Name"": ""Отрицательный FP"",
      ""FpCount"": -20
    },
    {
      ""Id"": 1,
      ""Name"": null,
      ""FpCount"": ""NaN""
    },
    {
      ""Id"": 9,
      ""Name"": """",
      ""FpCount"": 0
    },
    {
      ""Id"": 10,
      ""Name"": ""Неверное количество"",
      ""FpCount"": {}
    },
    {
      ""Name"": ""Нет ID и количества""
    },
    null,
    42
  ]
}
";

        public static IReadOnlyList<KafoExample> All {get;}=Array.AsReadOnly(new[] {
            new KafoExample("01_Sectors",Sectors),
            new KafoExample("02_Bridges",Bridges),
            new KafoExample("03_Analytics",Analytics),
            new KafoExample("04_Dense",Dense),
            new KafoExample("05_Minimal",Minimal),
            new KafoExample("06_Orphans",Orphans),
            new KafoExample("07_Dirty",Dirty)
        });
    }
}
