using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    // Граф свободных ортогональных проходов. Промежуточный узел графа не обязан становиться изгибом линии.
    internal sealed class InfoflowChannelGraph
    {
        readonly float[] xs, zs;
        readonly List<Rect> sceneObstacles;
        readonly Vector2[] points;
        readonly int[] neighbours;
        readonly float[] distances;
        readonly bool[] horizontalBlocked, verticalBlocked;
        readonly int[] horizontalUse, verticalUse, treeParent, treeDepth;
        readonly int[] horizontalSoft, verticalSoft;
        readonly bool[] terminals;
        readonly float[] costs;
        readonly float[] heuristics;
        readonly int[] heuristicStamps;
        // Состояние A*: node * 4 + направление прихода (0: +X, 1: +Z, 2: -X, 3: -Z).
        // Номер поиска в stamps позволяет переиспользовать массивы без полной очистки.
        readonly int[] parents, stamps;
        readonly bool[] closed;
        (int State, float Priority)[] heap = new (int, float)[256];
        int version, heapCount;
        public int Visits { get; private set; }
        public int Count => xs.Length * zs.Length;
        public Rect Frame { get; }
        public float CellSize { get; }

        public IReadOnlyList<float> Coordinates(bool xAxis) => xAxis ? xs : zs;

        // Параллельные рёбра одного физического прохода расходуют общую вместимость.
        // Корпуса учитываются на концах звена тоже: место для осевой линии ещё не означает место для ленты.
        public sealed class Reservations
        {
            sealed class Band { public float Low, High; public int Used; }
            readonly InfoflowChannelGraph graph;
            readonly int[] horizontal, vertical;
            readonly List<Band> bands = new List<Band>();
            readonly float gap;
            readonly Dictionary<int, HashSet<int>> reachableAfterFailure = new Dictionary<int, HashSet<int>>();
            public readonly float Pitch;
            public readonly float[] Low, High;
            public readonly int[] Used;

            public Reservations(InfoflowChannelGraph graph, float width, float gap, float clearance)
            {
                this.graph = graph; this.gap = gap; Pitch = width + gap;
                horizontal = new int[graph.Count]; vertical = new int[graph.Count];
                Array.Fill(horizontal, -1); Array.Fill(vertical, -1);
                Low = new float[graph.Count * 4]; High = new float[Low.Length]; Used = new int[Low.Length];
                for (int x = 0; x + 1 < graph.xs.Length; x++) Build(true, x, graph.xs[x], graph.xs[x + 1]);
                for (int z = 0; z + 1 < graph.zs.Length; z++) Build(false, z, graph.zs[z], graph.zs[z + 1]);
                void Build(bool alongX, int section, float start, float end)
                {
                    var coordinates = alongX ? graph.zs : graph.xs;
                    var occupied = graph.sceneObstacles.Where(r => (alongX ? r.xMin : r.yMin) <= end &&
                        (alongX ? r.xMax : r.yMax) >= start)
                        .Select(r => new Vector2(alongX ? r.yMin : r.xMin, alongX ? r.yMax : r.xMax))
                        .OrderBy(r => r.x).ToArray();
                    float low = alongX ? graph.Frame.yMin : graph.Frame.xMin;
                    float upper = alongX ? graph.Frame.yMax : graph.Frame.xMax;
                    foreach (var area in occupied)
                    {
                        if (area.x > low) Add(low, Mathf.Min(area.x, upper));
                        low = Mathf.Max(low, area.y);
                    }
                    if (low < upper) Add(low, upper);
                    void Add(float lo, float hi)
                    {
                        if (lo >= hi) return;
                        float padding = Mathf.Min(clearance, (hi - lo) * .1f);
                        int id = bands.Count; bands.Add(new Band { Low = lo + padding, High = hi - padding });
                        int first = Array.BinarySearch(coordinates, lo), last = Array.BinarySearch(coordinates, hi);
                        if (first < 0) first = ~first; if (last < 0) last = ~last - 1;
                        for (int i = first; i <= last; i++)
                        {
                            int node = alongX ? i * graph.xs.Length + section : section * graph.xs.Length + i;
                            (alongX ? horizontal : vertical)[node] = id;
                        }
                    }
                }
            }
            public bool Allows(int node, int next, bool horizontalStep, bool straight, int state, int count,
                out float low, out float high, out int used)
            {
                int id = (horizontalStep ? horizontal : vertical)[Math.Min(node, next)];
                low = 0; high = 0; used = 0;
                if (id < 0) return false;
                var band = bands[id]; low = band.Low; high = band.High; used = band.Used;
                // Один прямой участок должен помещаться в общем диапазоне всех его звеньев.
                if (straight) { low = Mathf.Max(low, Low[state]); high = Mathf.Min(high, High[state]); used = Math.Max(used, Used[state]); }
                return (used + count) * Pitch - gap <= high - low;
            }

            public void Reserve(List<Vector2> path, int count)
            {
                var touched = new HashSet<int>();
                for (int i = 1; i < path.Count; i++)
                {
                    int a = graph.Node(path[i - 1]), b = graph.Node(path[i]);
                    bool alongX = a / graph.xs.Length == b / graph.xs.Length;
                    int step = Math.Sign(b - a) * (alongX ? 1 : graph.xs.Length);
                    while (a != b)
                    {
                        int next = a + step;
                        int id = (alongX ? horizontal : vertical)[Math.Min(a, next)];
                        if (id >= 0) touched.Add(id);
                        a = next;
                    }
                }
                foreach (int id in touched) bands[id].Used += count;
            }

            public bool CanReach(int startState, int target) => !reachableAfterFailure.TryGetValue(startState, out var reached) || reached.Contains(target);

            public void RememberFailure(int startState)
            {
                // Резервы только растут: недоступная из этого выхода область не освободится
                // для следующей пары. Не повторяем полный безуспешный поиск для каждой линии.
                var reached = new HashSet<int>();
                for (int state = 0; state < graph.stamps.Length; state++)
                    if (graph.stamps[state] == graph.version && graph.closed[state]) reached.Add(state / 4);
                reachableAfterFailure[startState] = reached;
            }
        }

        public void ClearUsage() { Array.Clear(horizontalUse, 0, horizontalUse.Length); Array.Clear(verticalUse, 0, verticalUse.Length); }

        public Vector2 AccessPoint(FlowBank bank, float width, float exit)
        {
            // Отделяем короткое подключение к корпусу от магистрали. Почти совпадающие
            // координаты виртуальных портов объединяем, не меняя геометрию АС.
            int direction = bank.Normal.x > 0 ? 0 : bank.Normal.y > 0 ? 1 : bank.Normal.x < 0 ? 2 : 3;
            int node = Node(bank.Point), next;
            float desired = Mathf.Max(width, exit);
            while ((next = Neighbour(node, direction)) >= 0 && Vector2.Dot(Point(node) - bank.Point, bank.Normal) < desired)
                node = next;
            var point = Point(node);
            bool alongX = bank.Normal.y != 0;
            var coordinates = alongX ? xs : zs;
            float tangent = alongX ? point.x : point.y;
            float tolerance = Mathf.Min(width * .25f, CellSize * .001f);
            foreach (float value in coordinates)
                if (value >= tangent - tolerance && value <= tangent + tolerance)
                { if (alongX) point.x = value; else point.y = value; break; }
            return point;
        }

        public InfoflowChannelGraph(InfoflowScene scene, IEnumerable<Vector2> ports, float exterior)
        {
            sceneObstacles = scene.Obstacles;
            CellSize = scene.CellSize;
            Frame = scene.RoutingBounds ?? Rect.MinMaxRect(scene.Bounds.xMin - exterior, scene.Bounds.yMin - exterior,
                scene.Bounds.xMax + exterior, scene.Bounds.yMax + exterior);
            var xValues = new SortedSet<float> { Frame.xMin, Frame.xMax };
            var zValues = new SortedSet<float> { Frame.yMin, Frame.yMax };
            // Границы корпусов и середины промежутков задают проходы без равномерной мелкой сетки.
            foreach (var r in scene.Obstacles)
            {
                xValues.Add(r.xMin); xValues.Add(r.xMax);
                zValues.Add(r.yMin); zValues.Add(r.yMax);
            }
            foreach (var p in ports) { xValues.Add(p.x); zValues.Add(p.y); }
            xs = WithMidpoints(xValues); zs = WithMidpoints(zValues);
            points = new Vector2[Count]; neighbours = new int[Count * 4]; distances = new float[Count * 4];
            terminals = new bool[Count]; heuristics = new float[Count]; heuristicStamps = new int[Count];
            horizontalBlocked = new bool[Count]; verticalBlocked = new bool[Count];
            horizontalUse = new int[Count]; verticalUse = new int[Count];
            horizontalSoft = new int[Count]; verticalSoft = new int[Count];
            foreach (var r in scene.Obstacles)
            {
                int left = Array.BinarySearch(xs, r.xMin), right = Array.BinarySearch(xs, r.xMax);
                int bottom = Array.BinarySearch(zs, r.yMin), top = Array.BinarySearch(zs, r.yMax);
                for (int z = bottom + 1; z < top; z++)
                for (int x = left; x < right; x++) horizontalBlocked[z * xs.Length + x] = true;
                for (int x = left + 1; x < right; x++)
                for (int z = bottom; z < top; z++) verticalBlocked[z * xs.Length + x] = true;
            }
            foreach (var p in ports) terminals[Node(p)] = true;
            // Геометрия графа неизменна: A* многократно читает готовых соседей и длины,
            // не вычисляя координаты и деление индексов при каждом раскрытии состояния.
            for (int z = 0; z < zs.Length; z++)
            for (int x = 0; x < xs.Length; x++) points[z * xs.Length + x] = new Vector2(xs[x], zs[z]);
            for (int node = 0; node < Count; node++)
            for (int direction = 0; direction < 4; direction++)
            {
                int next = FindNeighbour(node, direction);
                neighbours[node * 4 + direction] = next;
                if (next >= 0) distances[node * 4 + direction] = Manhattan(points[node], points[next]);
            }
            foreach (var area in scene.SoftAreas)
            {
                int left = Array.BinarySearch(xs, area.xMin), right = Array.BinarySearch(xs, area.xMax);
                int bottom = Array.BinarySearch(zs, area.yMin), top = Array.BinarySearch(zs, area.yMax);
                if (left < 0) left = ~left; if (right < 0) right = ~right;
                if (bottom < 0) bottom = ~bottom; if (top < 0) top = ~top;
                for (int z = Mathf.Max(0, bottom - 1); z <= Mathf.Min(zs.Length - 1, top); z++)
                for (int x = Mathf.Max(0, left - 1); x <= Mathf.Min(xs.Length - 1, right); x++)
                {
                    int node = z * xs.Length + x;
                    if (x + 1 < xs.Length && zs[z] > area.yMin && zs[z] < area.yMax &&
                        xs[x] < area.xMax && xs[x + 1] > area.xMin) horizontalSoft[node]++;
                    if (z + 1 < zs.Length && xs[x] > area.xMin && xs[x] < area.xMax &&
                        zs[z] < area.yMax && zs[z + 1] > area.yMin) verticalSoft[node]++;
                }
            }
            treeParent = new int[Count]; treeDepth = new int[Count];
            Array.Fill(treeParent, -1);
            BuildTree();
            costs = new float[Count * 4];
            parents = new int[Count * 4]; stamps = new int[Count * 4]; closed = new bool[Count * 4];
        }

        static float[] WithMidpoints(SortedSet<float> values)
        {
            var result = new List<float>();
            bool first = true; float previous = 0;
            foreach (float value in values)
            {
                if (!first)
                {
                    float middle = previous + (value - previous) * .5f;
                    if (middle > previous && middle < value) result.Add(middle);
                }
                result.Add(value); previous = value; first = false;
            }
            return result.ToArray();
        }

        public int Node(Vector2 point) => Array.BinarySearch(zs, point.y) * xs.Length + Array.BinarySearch(xs, point.x);
        public Vector2 Point(int node) => points[node];
        public static Vector2 Direction(int direction) => direction == 0 ? Vector2.right : direction == 1 ? Vector2.up :
            direction == 2 ? Vector2.left : Vector2.down;

        int Neighbour(int node, int direction) => neighbours[node * 4 + direction];

        int FindNeighbour(int node, int direction)
        {
            int x = node % xs.Length, z = node / xs.Length;
            if (direction == 0) return x + 1 < xs.Length && !horizontalBlocked[node] ? node + 1 : -1;
            if (direction == 1) return z + 1 < zs.Length && !verticalBlocked[node] ? node + xs.Length : -1;
            if (direction == 2) return x > 0 && !horizontalBlocked[node - 1] ? node - 1 : -1;
            return z > 0 && !verticalBlocked[node - xs.Length] ? node - xs.Length : -1;
        }

        void BuildTree()
        {
            // Дерево из внешнего угла графа обеспечивает резервные пути без повторного поиска A*.
            var queue = new Queue<int>();
            treeParent[0] = 0; queue.Enqueue(0);
            while (queue.Count > 0)
            {
                int node = queue.Dequeue();
                for (int d = 0; d < 4; d++)
                {
                    int next = Neighbour(node, d);
                    if (next < 0 || terminals[next] || treeParent[next] >= 0) continue;
                    treeParent[next] = node; treeDepth[next] = treeDepth[node] + 1; queue.Enqueue(next);
                }
            }
        }

        public List<Vector2> FindPath(Vector2 start, int startDirection, Vector2 end, int endDirection,
            ref int budget, out bool fallback, bool preferShared = true, Rect? avoidJunction = null,
            Reservations reservations = null, int lineCount = 1, bool accessPoints = false)
        {
            int from = Node(start), to = Node(end);
            // Первый и последний шаги принудительно направлены наружу от соответствующей грани АС.
            int first = accessPoints ? from : Neighbour(from, startDirection), last = accessPoints ? to : Neighbour(to, endDirection);
            if (first < 0 || last < 0) throw new InvalidOperationException("У АС KAFO нет свободного выхода с выбранной стороны.");
            if (reservations != null && !reservations.CanReach(first * 4 + startDirection, last))
                throw new InvalidOperationException("Вместимость доступной области уже исчерпана.");
            fallback = false;
            // Перенос из физически переполненного прохода обязателен, а не является
            // улучшением картинки. Для него поиск завершается и при исчерпанном бюджете улучшений.
            if (budget > 0 || reservations != null)
            {
                version++; heapCount = 0;
                int initial = first * 4 + startDirection;
                if (reservations != null) { reservations.Low[initial] = float.NegativeInfinity; reservations.High[initial] = float.PositiveInfinity; reservations.Used[initial] = 0; }
                stamps[initial] = version;
                closed[initial] = false;
                costs[initial] = 0;
                parents[initial] = -1;
                Push(initial, (Point(first) - end).sqrMagnitude == 0 ? 0 : Manhattan(Point(first), end));
                while (heapCount > 0 && (budget > 0 || reservations != null))
                {
                    int state = Pop();
                    if (closed[state]) continue;
                    closed[state] = true;
                    if (budget > 0) budget--;
                    Visits++;
                    int node = state / 4, incoming = state % 4;
                    if (node == last)
                    {
                        var chain = new List<int>();
                        for (int p = state; p >= 0; p = parents[p]) chain.Add(p / 4);
                        chain.Reverse(); if (!accessPoints) { chain.Insert(0, from); chain.Add(to); }
                        return InfoflowGeometry.Simplify(chain.Select(Point).ToList());
                    }
                    for (int direction = 0; direction < 4; direction++)
                    {
                        if (direction == (incoming + 2) % 4) continue;
                        int next = Neighbour(node, direction);
                        if (next < 0 || next == from || !accessPoints && next == to || terminals[next] && next != last) continue;
                        float low = 0, high = 0; int load = 0;
                        if (reservations != null && !reservations.Allows(node, next, direction % 2 == 0,
                            direction == incoming, state, lineCount, out low, out high, out load)) continue;
                        int nextState = next * 4 + direction;
                        if (stamps[nextState] == version && closed[nextState]) continue;
                        float distance = distances[node * 4 + direction];
                        int edge = direction == 0 || direction == 1 ? node : next;
                        int usage = direction % 2 == 0 ? horizontalUse[edge] : verticalUse[edge];
                        // Общие проходы поощряются; повороты, пересечения и области подписей штрафуются.
                        // Корпуса АС исключены из соседей графа и не являются мягким штрафом.
                        float extra = distance * (!preferShared || usage > 0 ? 1 : 3) + (direction != incoming ? CellSize * 4 : 0);
                        if (reservations != null)
                        {
                            float occupation = (load + lineCount) * reservations.Pitch / (high - low);
                            extra += distance * occupation * occupation * 16;
                        }
                        if (direction == incoming)
                        {
                            int before = Neighbour(node, direction % 2 == 0 ? 3 : 2);
                            int crossing = direction % 2 == 0 ? (before < 0 ? 0 : Mathf.Min(verticalUse[node], verticalUse[before])) :
                                (before < 0 ? 0 : Mathf.Min(horizontalUse[node], horizontalUse[before]));
                            extra += reservations == null ? crossing * CellSize * 32 : Mathf.Min(1, crossing) * CellSize * 2;
                        }
                        extra += distance * 4 * (direction % 2 == 0 ? horizontalSoft[edge] : verticalSoft[edge]);
                        if (avoidJunction.HasValue && InfoflowGeometry.SegmentHitsRect(Point(node), Point(next), avoidJunction.Value))
                            extra += distance * 64;
                        float candidate = costs[state] + extra;
                        if (stamps[nextState] == version && candidate >= costs[nextState]) continue;
                        stamps[nextState] = version; closed[nextState] = false;
                        costs[nextState] = candidate; parents[nextState] = state;
                        if (reservations != null) { reservations.Low[nextState] = low; reservations.High[nextState] = high; reservations.Used[nextState] = load; }
                        // Оценка до цели одинакова для всех направлений прихода в этот узел.
                        if (heuristicStamps[next] != version)
                        {
                            heuristicStamps[next] = version;
                            heuristics[next] = Manhattan(Point(next), end);
                        }
                        Push(nextState, candidate + heuristics[next]);
                    }
                }
            }
            // Бюджет ограничивает улучшение, но не отменяет путь между доступными подключениями.
            fallback = true;
            if (reservations != null)
            {
                if (lineCount == 1) reservations.RememberFailure(first * 4 + startDirection);
                throw new InvalidOperationException("Нет другого прохода для магистрали заданной минимальной ширины.");
            }
            var treePath = TreePath(first, last);
            treePath.Insert(0, from); treePath.Add(to);
            return InfoflowGeometry.Simplify(treePath.Select(Point).ToList());

        }

        List<int> TreePath(int from, int to)
        {
            if (treeParent[from] < 0 || treeParent[to] < 0)
                throw new InvalidOperationException("Свободные проходы KAFO не связаны.");
            var left = new List<int>(); var right = new List<int>();
            // Поднимаем обе ветви до общего предка, затем соединяем их в простой путь.
            while (from != to)
            {
                if (treeDepth[from] >= treeDepth[to]) { left.Add(from); from = treeParent[from]; }
                else { right.Add(to); to = treeParent[to]; }
            }
            left.Add(from); right.Reverse(); left.AddRange(right);
            return left;
        }

        public void MarkPath(List<Vector2> points)
        {
            for (int i = 1; i < points.Count; i++)
            {
                int a = Node(points[i - 1]), b = Node(points[i]);
                if (a < 0 || b < 0 || a / xs.Length != b / xs.Length && a % xs.Length != b % xs.Length)
                    throw new InvalidOperationException("Неортогональное ребро графа проходов KAFO.");
                int step = a / xs.Length == b / xs.Length ? Math.Sign(b - a) : Math.Sign(b - a) * xs.Length;
                while (a != b)
                {
                    int next = a + step;
                    if (Math.Abs(step) == 1) horizontalUse[Math.Min(a, next)]++;
                    else verticalUse[Math.Min(a, next)]++;
                    a = next;
                }
            }
        }

        static float Manhattan(Vector2 a, Vector2 b) => Mathf.Abs(a.x - b.x) + Mathf.Abs(a.y - b.y);

        void Push(int state, float priority)
        {
            if (heapCount == heap.Length) Array.Resize(ref heap, heap.Length * 2);
            int i = heapCount++;
            while (i > 0)
            {
                int parent = (i - 1) / 2;
                if (heap[parent].Priority <= priority) break;
                heap[i] = heap[parent]; i = parent;
            }
            heap[i] = (state, priority);
        }

        int Pop()
        {
            int result = heap[0].State;
            var last = heap[--heapCount];
            if (heapCount == 0) return result;
            int i = 0;
            while (i * 2 + 1 < heapCount)
            {
                int child = i * 2 + 1;
                if (child + 1 < heapCount && heap[child + 1].Priority < heap[child].Priority) child++;
                if (heap[child].Priority >= last.Priority) break;
                heap[i] = heap[child]; i = child;
            }
            heap[i] = last; return result;
        }
    }
}




