using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    static class KafoTestPrefabs
    {
        public const string AsPath="Assets/Kafo/prefab/AS_uni_01.prefab";
        public const string SegmentPath="Assets/Kafo/prefab/Sector_obj.prefab";
        public const string GroupPath="Assets/Kafo/prefab/Group_obj.prefab";

        static GameObject Load(string path)
        {
            var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(path);Assert.That(prefab,Is.Not.Null,path);return prefab;
        }
        public static GameObject CreateAs()
        {
            var go=Object.Instantiate(Load(AsPath));
            var shape=go.GetComponent<KafoMeshResizer>()??go.AddComponent<KafoMeshResizer>();
            Assert.That(shape.CaptureSource(),Is.True);return go;
        }
        static Renderer Zone(Transform parent,string name,Rect rect)
        {
            var go=Object.Instantiate(Load(SegmentPath),parent,false);go.name=name;
            var shape=go.GetComponent<KafoMeshResizer>()??go.AddComponent<KafoMeshResizer>();
            Assert.That(shape.CaptureSource(),Is.True);
            shape.Resize(new Vector3(rect.center.x,0,rect.center.y),new Vector3(rect.width,.1f,rect.height),1);
            return go.GetComponent<Renderer>();
        }
        public static Renderer MainZone(Transform parent,bool tall)=>Zone(parent,"Main test zone",tall?new Rect(-6,-15,12,30):new Rect(-15,-6,30,12));
        public static void Configure(KafoGenerator generator)
        {
            generator.AsPrefab=Load(AsPath);generator.SegmentPrefab=Load(SegmentPath);generator.GroupPrefab=Load(GroupPath);
            if(generator.MainZone==null)generator.MainZone=Zone(generator.transform,"Main test zone",new Rect(-10,-7,20,14));
            if(generator.IslandZone==null)generator.IslandZone=Zone(generator.transform,"Island test zone",new Rect(25,-7,3,3));
        }
    }
}
