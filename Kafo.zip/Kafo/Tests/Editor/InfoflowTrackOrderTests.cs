using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public sealed class InfoflowTrackOrderTests
    {
        [TestCase(0, false)]
        [TestCase(1, false)]
        [TestCase(2, false)]
        [TestCase(3, false)]
        [TestCase(0, true)]
        public void CompactTracksKeepBranchesOutsideTheContinuingLine(int quarter, bool reversed)
        {
            var paths = new[] {
                new List<Vector2> { Vector2.zero, new Vector2(10, 0), new Vector2(10, -7) },
                new List<Vector2> { Vector2.zero, new Vector2(2, 0), new Vector2(2, -3), new Vector2(5, -3) },
                new List<Vector2> { Vector2.zero, new Vector2(2, 0), new Vector2(2, -5), new Vector2(7, -5) }
            };
            foreach (var path in paths)
            {
                for (int i = 0; i < path.Count; i++)
                    for (int turn = 0; turn < quarter; turn++) path[i] = new Vector2(-path[i].y, path[i].x);
                if (reversed) path.Reverse();
            }
            var ordinary = Place(paths, false);
            var compact = Place(paths, true, true);
            Assert.That(compact.Order, Is.EqualTo(ordinary.Order), "Уплотнение не должно переставлять дорожки.");
            for (int a = 0; a < compact.Routes.Count; a++)
            for (int b = a + 1; b < compact.Routes.Count; b++)
            for (int i = 1; i < compact.Routes[a].Points.Count; i++)
            for (int j = 1; j < compact.Routes[b].Points.Count; j++)
                Assert.That(InfoflowGeometry.Intersection(compact.Routes[a].Points[i - 1], compact.Routes[a].Points[i],
                    compact.Routes[b].Points[j - 1], compact.Routes[b].Points[j], out _), Is.False,
                    "Ответвление не должно пересекать продолжающуюся линию, в том числе на дуге.");
        }

        [Test]
        public void EndedBranchTrackCanStillBeReused()
        {
            var paths = new[] {
                new List<Vector2> { Vector2.zero, new Vector2(10, 0), new Vector2(10, -7) },
                new List<Vector2> { Vector2.zero, new Vector2(2, 0), new Vector2(2, -3) },
                new List<Vector2> { new Vector2(4, 0), new Vector2(6, 0), new Vector2(6, -3) }
            };
            var result = Place(paths, true, true);
            Assert.That(result.Routes[1].Corners[0].y, Is.EqualTo(result.Routes[2].Corners[0].y));
            Assert.That(result.Routes.Select(r => r.Corners[0].y).Distinct().Count(), Is.EqualTo(2));
        }

        static (List<InfoflowRoute> Routes, string Order) Place(List<Vector2>[] paths, bool compact, bool tightPacking = false)
        {
            var assembly = typeof(InfoflowRouter).Assembly;
            var familyType = assembly.GetType("Sbrt.Av.Gameplay.FlowFamily");
            var wireType = assembly.GetType("Sbrt.Av.Gameplay.FlowWire");
            var networkType = assembly.GetType("Sbrt.Av.Gameplay.InfoflowNetwork");
            var families = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(familyType));
            var wires = new List<object>();
            for (int i = 0; i < paths.Length; i++)
            {
                var path = paths[i]; var family = Activator.CreateInstance(familyType);
                Set(family, "Id", i); Set(family, "Path", path);
                Set(family, "Start", Bank(path[0], path[1] - path[0]));
                Set(family, "End", Bank(path.Last(), path[path.Count - 2] - path.Last()));
                var wire = Activator.CreateInstance(wireType);
                Set(wire, "Id", i); Set(wire, "Family", family);
                ((IList)familyType.GetField("Wires").GetValue(family)).Add(wire);
                families.Add(family); wires.Add(wire);
            }
            var network = Activator.CreateInstance(networkType, new object[] { families });
            networkType.GetMethod("OrderLanes").Invoke(network, new object[] { families, compact, tightPacking, false });
            var edges = (IList)networkType.GetField("Edges").GetValue(network);
            var nodes = (IList)networkType.GetField("Nodes").GetValue(network);
            var order = new List<string>();
            foreach (var edge in edges)
            {
                int from = (int)edge.GetType().GetField("From").GetValue(edge);
                var point = (Vector2)nodes[from].GetType().GetField("Point").GetValue(nodes[from]);
                bool horizontal = (bool)edge.GetType().GetField("Horizontal").GetValue(edge);
                Set(edge, "TrackOrigin", horizontal ? point.y : point.x);
                var offsets = (Dictionary<int, float>)edge.GetType().GetField("Offsets").GetValue(edge);
                order.Add(string.Join(",", offsets.OrderBy(p => p.Value).Select(p => p.Key)));
            }
            var routes = new List<InfoflowRoute>();
            foreach (var wire in wires)
            {
                var corners = (List<Vector2>)networkType.GetMethod("WirePath").Invoke(network, new object[] { wire, .1f });
                var route = new InfoflowRoute { Corners = InfoflowGeometry.Simplify(corners) };
                var radii = route.Corners.Select((p, i) => i > 0 && i + 1 < route.Corners.Count ? .4f : 0).ToArray();
                InfoflowGeometry.Round(route, radii, 12); routes.Add(route);
            }
            return (routes, string.Join(";", order));

            object Bank(Vector2 point, Vector2 normal)
            {
                var bank = Activator.CreateInstance(assembly.GetType("Sbrt.Av.Gameplay.FlowBank"));
                Set(bank, "Point", point); Set(bank, "Normal", normal.normalized); return bank;
            }
            void Set(object target, string field, object value) => target.GetType().GetField(field).SetValue(target, value);
        }
    }
}
