using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Sbrt.Av.Gameplay
{
    public sealed class InfoflowAcceptanceTests
    {
        public static InfoflowScene Scene(params Vector2[] centers)
        {
            var scene = new InfoflowScene { Bounds = new Rect(-20, -20, 40, 40), CellSize = 2 };
            for (int i = 0; i < centers.Length; i++)
            {
                var endpoint = new InfoflowEndpoint { AsId = i + 1, Key = "as:" + i,
                    Body = new Rect(centers[i] - Vector2.one, Vector2.one * 2), Segments = new List<string> { "segment:" + i % 2 } };
                scene.Endpoints.Add(endpoint); scene.Obstacles.Add(endpoint.Body);
            }
            return scene;
        }

        static InfoflowDataModel Flow(long id, long a, long b) => new InfoflowDataModel { Id = id, ProviderId = a, ConsumerId = b };

        static InfoflowRoutingResult Solve(InfoflowScene scene, List<InfoflowDataModel> flows, InfoflowSettings settings = null)
        {
            var result = InfoflowRouter.Calculate(scene, flows, settings);
            Assert.That(result.Routes.Count, Is.EqualTo(flows.Count - result.SkippedRecords));
            Assert.That(InfoflowGeometry.Validate(scene, result), Is.Empty, string.Join("\n", result.Diagnostics));
            return result;
        }

        public static int Crossings(InfoflowRoutingResult result)
        {
            int count = 0;
            for (int i = 0; i < result.Routes.Count; i++)
            for (int j = i + 1; j < result.Routes.Count; j++)
            {
                var a = result.Routes[i].Points; var b = result.Routes[j].Points;
                for (int x = 1; x < a.Count; x++)
                for (int y = 1; y < b.Count; y++)
                    if (InfoflowGeometry.Intersection(a[x - 1], a[x], b[y - 1], b[y], out _)) count++;
            }
            return count;
        }

        static Vector3[] MeshWorldVertices(Renderer renderer)
        {
            var line = renderer as LineRenderer;
            var mesh = line != null ? new Mesh() : renderer.GetComponent<MeshFilter>().sharedMesh;
            try
            {
                if (line != null) line.BakeMesh(mesh, false);
                return mesh.vertices.Select(renderer.transform.TransformPoint).ToArray();
            }
            finally { if (line != null) Object.DestroyImmediate(mesh); }
        }

        [TestCase(2)]
        [TestCase(15)]
        [TestCase(16)]
        [TestCase(100)]
        public void TwoObjectsHaveNoCrossingsIncludingOppositeServerDirections(int count)
        {
            var scene = Scene(new Vector2(-5, 0), new Vector2(5, 0));
            var flows = Enumerable.Range(0, count).Select(i => Flow(i % 3, i % 2 == 0 ? 1 : 2, i % 2 == 0 ? 2 : 1)).ToList();
            var result = Solve(scene, flows);
            Assert.That(Crossings(result), Is.Zero);
            Assert.That(result.Routes.Select(r => r.Key).Distinct().Count(), Is.EqualTo(count));
            Assert.That(result.Routes.All(r => r.Arcs.Count >= 2), Is.True);
        }

        [Test]
        public void SequentialLeftBranchesPeelFromTheLeftWithoutCrossings()
        {
            var scene = Scene(new Vector2(6, -4), new Vector2(-6, 0), new Vector2(-6, 5), new Vector2(-6, 10));
            var result = Solve(scene, new List<InfoflowDataModel> { Flow(9, 1, 4), Flow(8, 1, 2), Flow(7, 1, 3) });
            Assert.That(Crossings(result), Is.Zero);
            Assert.That(result.Routes.All(r => r.Corners.Count <= 4), Is.True, "Свободный проход не должен получать ступеньки.");
        }

        [TestCase(0, false)]
        [TestCase(1, false)]
        [TestCase(2, false)]
        [TestCase(3, false)]
        [TestCase(0, true)]
        [TestCase(1, true)]
        [TestCase(2, true)]
        [TestCase(3, true)]
        public void SegmentFrameContainsFullRibbonsIncludingFallback(int quarterTurns, bool fallback)
        {
            var scene = Scene(Orient(new Vector2(-5, 0)), Orient(new Vector2(5, 0)));
            var min = Orient(new Vector2(-8, -4)); var max = Orient(new Vector2(8, 4));
            scene.RoutingBounds = Rect.MinMaxRect(Mathf.Min(min.x, max.x), Mathf.Min(min.y, max.y),
                Mathf.Max(min.x, max.x), Mathf.Max(min.y, max.y));
            min = Orient(new Vector2(-2, -2)); max = Orient(new Vector2(2, 3));
            scene.Obstacles.Add(Rect.MinMaxRect(Mathf.Min(min.x, max.x), Mathf.Min(min.y, max.y),
                Mathf.Max(min.x, max.x), Mathf.Max(min.y, max.y)));
            var sides = new[] { InfoflowPortSide.PositiveZ, InfoflowPortSide.NegativeX,
                InfoflowPortSide.NegativeZ, InfoflowPortSide.PositiveX };
            var result = Solve(scene, Enumerable.Range(0, 32).Select(i => Flow(i, 1, 2)).ToList(),
                new InfoflowSettings { MaxWidth = .4f, GapRatio = .75f, PrimaryPortCount = 100,
                    PreferredSide = sides[quarterTurns], SearchBudget = fallback ? 0 : 500000 });
            var frame = scene.RoutingBounds.Value;
            float half = result.Width * .5f;
            foreach (var point in result.Routes.SelectMany(r => r.Points))
            {
                Assert.That(point.x - half, Is.GreaterThanOrEqualTo(frame.xMin - .0001f));
                Assert.That(point.x + half, Is.LessThanOrEqualTo(frame.xMax + .0001f));
                Assert.That(point.y - half, Is.GreaterThanOrEqualTo(frame.yMin - .0001f));
                Assert.That(point.y + half, Is.LessThanOrEqualTo(frame.yMax + .0001f));
            }
            Assert.That(result.Width, Is.GreaterThan(0));
            Assert.That(Crossings(result), Is.Zero);

            Vector2 Orient(Vector2 point)
            {
                for (int i = 0; i < quarterTurns; i++) point = Vector2.Perpendicular(point);
                return point;
            }
        }

        [TestCase(0)]
        [TestCase(1)]
        [TestCase(2)]
        [TestCase(3)]
        public void AlternativePassageAvoidsRealCrossingsWithoutAnOrderingConflict(int quarterTurns)
        {
            // Подпись склоняет первоначальный поиск к верхнему обходу. Позже появляется
            // пересекающая его связь: нижний свободный проход должен выиграть по готовой сети.
            var scene = Scene(new[] { Vector2.zero, new Vector2(18, 5), new Vector2(9, 5), new Vector2(9, 15) }
                .Select(Orient).ToArray());
            var a = Orient(new Vector2(-2, 1.1f)); var b = Orient(new Vector2(22, 8.1f));
            var min = Vector2.Min(a, b); var max = Vector2.Max(a, b);
            scene.SoftAreas.Add(Rect.MinMaxRect(min.x, min.y, max.x, max.y));
            var sides = new[] { InfoflowPortSide.PositiveZ, InfoflowPortSide.NegativeX,
                InfoflowPortSide.NegativeZ, InfoflowPortSide.PositiveX };
            var result = Solve(scene, new List<InfoflowDataModel> { Flow(1, 1, 2), Flow(2, 3, 4) },
                new InfoflowSettings { PreferredSide = sides[quarterTurns] });
            Assert.That(Crossings(result), Is.Zero, "Фактические пересечения надо улучшать независимо от конфликтов порядка.");
            Assert.That(result.Scale, Is.EqualTo(1).Within(.0001f));
            Assert.That(result.UsedFallback, Is.False);

            Vector2 Orient(Vector2 point)
            {
                for (int i = 0; i < quarterTurns; i++) point = Vector2.Perpendicular(point);
                return point;
            }
        }

        [TestCase(0)]
        [TestCase(1)]
        [TestCase(2)]
        [TestCase(3)]
        public void AlternativeCanPassBelowARowAndReturnToThePort(int quarterTurns)
        {
            var scene = Scene(new Vector2(-7, 10), new Vector2(7, 0), new Vector2(-2, 5),
                new Vector2(-2, -2), new Vector2(3, 10));
            scene.Endpoints[2].Body = new Rect(-5, 2, 6, 6);
            scene.Endpoints[3].Body = new Rect(-5, -5, 6, 6);
            foreach (var endpoint in scene.Endpoints) endpoint.Body = Rotate(endpoint.Body);
            scene.Obstacles.Clear(); scene.Obstacles.AddRange(scene.Endpoints.Select(e => e.Body));
            scene.Obstacles.Add(Rotate(new Rect(-12, 12.2f, 24, 5))); // Верхний обход закрыт корпусом.
            var paths = new[]
            {
                new[] { new Vector2(-7, 11), new Vector2(-7, 12), new Vector2(-9, 12), new Vector2(-9, 1.75f), new Vector2(7, 1.75f), new Vector2(7, 1) },
                new[] { new Vector2(-2, 1), new Vector2(-2, 1.5f), new Vector2(1.5f, 1.5f), new Vector2(1.5f, 12), new Vector2(3, 12), new Vector2(3, 11) }
            }.Select(p => p.Select(Orient).ToList()).ToArray();
            var sides = new[] { InfoflowPortSide.PositiveZ, InfoflowPortSide.NegativeX, InfoflowPortSide.NegativeZ, InfoflowPortSide.PositiveX };
            var settings = new InfoflowSettings { PreferredSide = sides[quarterTurns] };
            var assembly = typeof(InfoflowRouter).Assembly;
            var flags = System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic;
            // Фиксируем исходные пути, чтобы тестировать именно новую форму кандидата,
            // независимо от того, какой из потоков основной поиск решит перенести первым.
            var families = (System.Collections.IList)typeof(InfoflowRouter).GetMethod("Expand", flags).Invoke(null,
                new object[] { scene, new[] { Flow(1, 1, 2), Flow(2, 4, 5) }, settings, new InfoflowRoutingResult() });
            var familyType = families[0].GetType();
            for (int i = 0; i < paths.Length; i++)
            {
                familyType.GetField("Path").SetValue(families[i], paths[i]);
                var wires = (System.Collections.IList)familyType.GetField("Wires").GetValue(families[i]);
                var route = (InfoflowRoute)wires[0].GetType().GetField("Route").GetValue(wires[0]);
                route.Corners = paths[i];
                InfoflowGeometry.Round(route, new[] { 0f, .1f, .1f, .1f, .1f, 0f }, 12);
            }
            var graphType = assembly.GetType("Sbrt.Av.Gameplay.InfoflowChannelGraph");
            var graph = System.Activator.CreateInstance(graphType, scene,
                paths.SelectMany(p => new[] { p[0], p[p.Count - 1] }).ToArray(), 4f);
            var alternatives = assembly.GetType("Sbrt.Av.Gameplay.InfoflowRouteAlternatives");
            var crossingType = alternatives.GetNestedType("Crossings", System.Reflection.BindingFlags.NonPublic);
            var crossings = System.Activator.CreateInstance(crossingType, families, 2f);
            var examinedType = typeof(HashSet<>).MakeGenericType(familyType);
            var examined = System.Activator.CreateInstance(examinedType);
            examinedType.GetMethod("Add").Invoke(examined, new[] { families[1] });
            var changes = (System.Collections.IList)alternatives.GetMethod("Find").Invoke(null,
                new object[] { families, graph, scene, settings, .1f, .5f, crossings, examined, false });
            Assert.That(changes.Count, Is.EqualTo(1));
            var path = (List<Vector2>)changes[0].GetType().GetField("Item2").GetValue(changes[0]);
            Assert.That(path.Count, Is.EqualTo(8), "Для нижнего обхода нужны два дополнительных поворота.");
            Assert.That(path.Min(p => Vector2.Dot(p, Orient(Vector2.up))), Is.LessThan(-5));
            for (int i = 1; i < path.Count; i++)
            for (int j = 1; j < paths[1].Count; j++)
                Assert.That(InfoflowGeometry.Intersection(path[i - 1], path[i], paths[1][j - 1], paths[1][j], out _), Is.False);

            Vector2 Orient(Vector2 p)
            {
                for (int i = 0; i < quarterTurns; i++) p = Vector2.Perpendicular(p);
                return p;
            }
            Rect Rotate(Rect r)
            {
                var min = Vector2.Min(Orient(r.min), Orient(r.max)); var max = Vector2.Max(Orient(r.min), Orient(r.max));
                return Rect.MinMaxRect(min.x, min.y, max.x, max.y);
            }
        }

        [TestCase(0, true)]
        [TestCase(1, true)]
        [TestCase(2, true)]
        [TestCase(3, true)]
        [TestCase(0, false)]
        [TestCase(1, false)]
        [TestCase(2, false)]
        [TestCase(3, false)]
        public void PassageAlignmentPreservesTurnDirections(int quarterTurns, bool conflicting)
        {
            // Высокий соседний маршрут раньше вытягивал первый поворот выше следующего.
            // Проверяем четыре ориентации и сохраняем выравнивание там, где оно безопасно.
            var paths = new[]
            {
                new List<Vector2> { new Vector2(0, -2), Vector2.zero, new Vector2(2, 0),
                    new Vector2(2, 10), new Vector2(8, 10), new Vector2(8, 8) },
                new List<Vector2> { new Vector2(.5f, conflicting ? 20 : 1), new Vector2(.5f, conflicting ? 30 : 4),
                    new Vector2(6, conflicting ? 30 : 4), new Vector2(6, conflicting ? 20 : 1) }
            }.Select(path => path.Select(Orient).ToList()).ToArray();
            var originals = paths.Select(path => path.ToArray()).ToArray();
            var cornerA = Orient(new Vector2(0, -5));
            var cornerB = Orient(new Vector2(12, 40));
            var min = Vector2.Min(cornerA, cornerB); var max = Vector2.Max(cornerA, cornerB);
            AlignTestPaths(paths, Rect.MinMaxRect(min.x, min.y, max.x, max.y));
            for (int i = 0; i < paths.Length; i++)
            {
                Assert.That(paths[i].Count, Is.EqualTo(originals[i].Length));
                for (int j = 1; j < paths[i].Count; j++)
                    Assert.That(Vector2.Dot(originals[i][j] - originals[i][j - 1], paths[i][j] - paths[i][j - 1]),
                        Is.GreaterThan(0), "Выравнивание развернуло или схлопнуло звено маршрута.");
            }
            if (conflicting)
                Assert.That(paths[1], Is.EqualTo(originals[1]), "Небезопасный перенос должен отклоняться для всего пучка.");
            else
                Assert.That(Vector2.Dot(paths[0][1], Orient(Vector2.up)),
                    Is.EqualTo(Vector2.Dot(paths[1][1], Orient(Vector2.up))).Within(.0001f));

            Vector2 Orient(Vector2 point)
            {
                for (int i = 0; i < quarterTurns; i++) point = Vector2.Perpendicular(point);
                return point;
            }
        }

        [TestCase(0)]
        [TestCase(1)]
        [TestCase(2)]
        [TestCase(3)]
        public void PassageAlignmentDoesNotLengthenAFreeUturn(int quarterTurns)
        {
            var paths = new[]
            {
                new List<Vector2> { Vector2.zero, new Vector2(0, 10), new Vector2(4, 10), new Vector2(4, 8) },
                new List<Vector2> { new Vector2(1, 20), new Vector2(1, 30), new Vector2(3, 30), new Vector2(3, 20) }
            }.Select(p => p.Select(Orient).ToList()).ToArray();
            var originals = paths.Select(p => p.ToArray()).ToArray();
            AlignTestPaths(paths, new Rect(-50, -50, 100, 100));
            for (int i = 0; i < paths.Length; i++)
                Assert.That(paths[i], Is.EqualTo(originals[i]), "Общий проход не должен вытягивать свободный П-образный обход.");

            Vector2 Orient(Vector2 p)
            {
                for (int i = 0; i < quarterTurns; i++) p = Vector2.Perpendicular(p);
                return p;
            }
        }

        [TestCase(false)]
        [TestCase(true)]
        public void PassageAlignmentRejectsNewCrossingsEvenWithoutExtraLength(bool crossesNeighbour)
        {
            // Перенос горизонтали вниз не меняет длину Z-образного пути, но пересекает чужой отрезок.
            var paths = new[]
            {
                new List<Vector2> { Vector2.zero, new Vector2(0, 2), new Vector2(6, 2), new Vector2(6, 10) },
                crossesNeighbour
                    ? new List<Vector2> { new Vector2(5, 1.5f), new Vector2(7, 1.5f) }
                    : new List<Vector2> { new Vector2(3, .5f), new Vector2(3, 1.5f) }
            };
            var original = paths[0].ToArray();
            AlignTestPaths(paths, new Rect(-10, -10, 30, 30));
            Assert.That(paths[0], Is.EqualTo(original), "Проверять надо и переносимый отрезок, и оба соседних звена.");
        }

        [Test]
        public void PassageAlignmentStillReservesSpaceForTheTerminalTurn()
        {
            var paths = new[] { new List<Vector2> { Vector2.zero, new Vector2(0, .5f), new Vector2(4, .5f), new Vector2(4, 0) } };
            AlignTestPaths(paths, new Rect(-10, -10, 30, 30));
            Assert.That(paths[0][1].y, Is.EqualTo(1.15f).Within(.0001f));
            Assert.That(paths[0][2].y, Is.EqualTo(1.15f).Within(.0001f));
        }

        static void AlignTestPaths(List<Vector2>[] paths, Rect frame)
        {
            var assembly = typeof(InfoflowRouter).Assembly;
            var familyType = assembly.GetType("Sbrt.Av.Gameplay.FlowFamily");
            var bankType = assembly.GetType("Sbrt.Av.Gameplay.FlowBank");
            var families = (System.Collections.IList)System.Activator.CreateInstance(typeof(List<>).MakeGenericType(familyType));
            for (int i = 0; i < paths.Length; i++)
            {
                var path = paths[i];
                var family = System.Activator.CreateInstance(familyType);
                familyType.GetField("Id").SetValue(family, i);
                familyType.GetField("Path").SetValue(family, path);
                familyType.GetField("Start").SetValue(family, Bank(path[0], path[1] - path[0]));
                familyType.GetField("End").SetValue(family, Bank(path[path.Count - 1], path[path.Count - 2] - path[path.Count - 1]));
                families.Add(family);
            }
            var align = typeof(InfoflowRouter).GetMethod("AlignPassages", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
            align.Invoke(null, new object[] { families, new List<Rect>(), frame, 1f, .15f });
            for (int i = 0; i < paths.Length; i++) paths[i] = (List<Vector2>)familyType.GetField("Path").GetValue(families[i]);

            object Bank(Vector2 point, Vector2 normal)
            {
                var bank = System.Activator.CreateInstance(bankType);
                bankType.GetField("Point").SetValue(bank, point);
                bankType.GetField("Normal").SetValue(bank, normal.normalized);
                return bank;
            }
        }

        [TestCase(InfoflowPortSide.PositiveX)]
        [TestCase(InfoflowPortSide.NegativeX)]
        [TestCase(InfoflowPortSide.PositiveZ)]
        [TestCase(InfoflowPortSide.NegativeZ)]
        public void FreeSharedTurnsKeepTheirRadiusAndCommonCenters(InfoflowPortSide side)
        {
            var scene = Scene(Vector2.zero, new Vector2(7, 5));
            var result = Solve(scene, Enumerable.Range(0, 12).Select(i => Flow(i, 1, 2)).ToList(),
                new InfoflowSettings { PreferredSide = side });
            Assert.That(Crossings(result), Is.Zero);
            Assert.That(result.Routes.SelectMany(r => r.Arcs).Min(a => a.Radius), Is.GreaterThan(.45f));
            var centers = result.Routes.SelectMany(r => r.Arcs).Select(a => new Vector2Int(
                Mathf.RoundToInt(a.Center.x * 1000), Mathf.RoundToInt(a.Center.y * 1000))).Distinct();
            Assert.That(centers.Count(), Is.EqualTo(2), "Два общих поворота должны иметь два общих центра.");
        }

        [Test]
        public void MixedLeftAndRightConnectionsDoNotCrossAtThePorts()
        {
            var scene = Scene(Vector2.zero, new Vector2(-6, 6), new Vector2(6, 6));
            var result = Solve(scene, new List<InfoflowDataModel> { Flow(1, 1, 3), Flow(2, 1, 2), Flow(3, 3, 1), Flow(4, 2, 1) });
            Assert.That(Crossings(result), Is.Zero);
        }

        [Test]
        public void CartesianInstancesAndDuplicateSourceIdsArePreserved()
        {
            var scene = Scene(new Vector2(-7, -5), new Vector2(-7, 5), new Vector2(7, -8), new Vector2(7, 0), new Vector2(7, 8));
            scene.Endpoints[1].AsId = 1;
            scene.Endpoints[2].AsId = scene.Endpoints[3].AsId = scene.Endpoints[4].AsId = 2;
            var result = InfoflowRouter.Calculate(scene, new[] { Flow(5, 1, 2), Flow(5, 1, 2), Flow(6, 1, 999) });
            Assert.That(result.Routes.Count, Is.EqualTo(12));
            Assert.That(result.SkippedRecords, Is.EqualTo(1));
            Assert.That(result.Routes.Select(r => r.Key).Distinct().Count(), Is.EqualTo(12));
            Assert.That(InfoflowGeometry.Validate(scene, result), Is.Empty);
        }

        [Test]
        public void SelfLinksRemainSimpleAndDistinct()
        {
            var scene = Scene(Vector2.zero);
            var result = Solve(scene, Enumerable.Range(0, 6).Select(i => Flow(i, 1, 1)).ToList());
            Assert.That(Crossings(result), Is.Zero);
        }

        [Test]
        public void ZeroSearchBudgetPreservesAllConnectionsAndAvoidsObstacles()
        {
            var scene = Scene(new Vector2(-6, 0), new Vector2(6, 0), Vector2.zero);
            var result = Solve(scene, Enumerable.Range(0, 12).Select(i => Flow(i, 1, 2)).ToList(),
                new InfoflowSettings { SearchBudget = 0 });
            Assert.That(result.UsedFallback, Is.True);
        }

        [Test]
        public void TestLinksAreDeterministicWithoutChangingUnityRandom()
        {
            var scene = Scene(Vector2.zero, Vector2.right * 5, Vector2.up * 5);
            string before = JsonUtility.ToJson(Random.state);
            var a = InfoflowTestDataFactory.Create(scene, 30, 17, InfoflowTestPattern.Mixed, new List<string>());
            var b = InfoflowTestDataFactory.Create(scene, 30, 17, InfoflowTestPattern.Mixed, new List<string>());
            Assert.That(string.Join(";", a.Select(f => f.ProviderId + ":" + f.ConsumerId)),
                Is.EqualTo(string.Join(";", b.Select(f => f.ProviderId + ":" + f.ConsumerId))));
            Assert.That(JsonUtility.ToJson(Random.state), Is.EqualTo(before));
        }

        [TestCase(.5f)]
        [TestCase(2f)]
        public void WidthAndEdgeGapApplyEquallyToPortsAndSharedTurns(float gapRatio)
        {
            var settings = new InfoflowSettings { MinWidth = .02f, MaxWidth = .04f, GapRatio = gapRatio };
            var result = Solve(Scene(new Vector2(-5, 0), new Vector2(5, 0)),
                Enumerable.Range(0, 5).Select(i => Flow(i, 1, 2)).ToList(), settings);
            Assert.That(result.Scale, Is.EqualTo(1).Within(.0001f));
            Assert.That(result.Width, Is.EqualTo(settings.MaxWidth).Within(.0001f));
            float gap = result.Width * gapRatio;
            Assert.That(result.Gap, Is.EqualTo(gap).Within(.0001f));
            var ports = result.Routes.Select(r => r.Points[0].x).OrderBy(x => x).ToArray();
            var radii = result.Routes.Select(r => r.Arcs[0].Radius).OrderBy(x => x).ToArray();
            for (int i = 1; i < ports.Length; i++)
            {
                Assert.That(ports[i] - ports[i - 1] - result.Width, Is.EqualTo(gap).Within(.0001f));
                Assert.That(radii[i] - radii[i - 1] - result.Width, Is.EqualTo(gap).Within(.0001f));
            }
            Assert.That(Crossings(result), Is.Zero);
        }

        [TestCase(.5f, false)]
        [TestCase(2f, false)]
        [TestCase(.5f, true)]
        public void AutosizeStaysWithinWidthBoundsAndKeepsRelativeGap(float ratio, bool fixedWidth)
        {
            var settings = new InfoflowSettings { MinWidth = .04f, MaxWidth = fixedWidth ? .04f : .4f, GapRatio = ratio };
            var result = Solve(Scene(new Vector2(-5, 0), new Vector2(5, 0)),
                Enumerable.Range(0, 5).Select(i => Flow(i, 1, 2)).ToList(), settings);
            Assert.That(result.Width, Is.InRange(settings.MinWidth, settings.MaxWidth));
            Assert.That(result.Gap, Is.EqualTo(result.Width * ratio).Within(.00001f));
            if (fixedWidth) Assert.That(result.Width, Is.EqualTo(settings.MinWidth));
            else Assert.That(result.Width, Is.LessThan(settings.MaxWidth));
        }

        [Test]
        public void CrowdedPortsCompressOnlyAtTheFaceWithoutReducingWidth()
        {
            var scene = Scene(new Vector2(-5, 0), new Vector2(5, 0));
            var result = Solve(scene, Enumerable.Range(0, 8).Select(i => Flow(i, 1, 2)).ToList(),
                new InfoflowSettings { MinWidth = .3f, MaxWidth = .3f, GapRatio = .5f });
            Assert.That(result.Width, Is.EqualTo(.3f));
            Assert.That(result.Gap, Is.EqualTo(.15f).Within(.00001f));
            Assert.That(result.Routes.Any(r => r.StartFanPointCount > 0), Is.True);
            foreach (var route in result.Routes)
            {
                Assert.That(route.Points[0].x, Is.InRange(-5.64f, -4.36f));
                Assert.That(route.Points.Last().x, Is.InRange(4.36f, 5.64f));
            }
        }

        [TestCase(false)]
        [TestCase(true)]
        public void OverfullPassageSplitsTheBundleInsteadOfShrinkingBelowMinimum(bool fallback)
        {
            var scene = Scene(new Vector2(-5, 0), new Vector2(5, 0));
            scene.RoutingBounds = new Rect(-8, -5, 16, 10);
            scene.Obstacles.Add(new Rect(-2, -4, 4, 6));
            var result = Solve(scene, Enumerable.Range(0, 8).Select(i => Flow(i, 1, 2)).ToList(),
                new InfoflowSettings { MinWidth = .3f, MaxWidth = .3f, GapRatio = .5f, SearchBudget = fallback ? 0 : 500000 });
            Assert.That(result.Width, Is.EqualTo(.3f));
            var middle = result.Routes.SelectMany(r => r.Points.Skip(1).Select((b, i) => (A: r.Points[i], B: b)))
                .Where(s => Mathf.Min(s.A.x, s.B.x) < 0 && Mathf.Max(s.A.x, s.B.x) > 0).ToArray();
            Assert.That(middle.Any(s => s.A.y > 2 && s.B.y > 2), Is.True);
            Assert.That(middle.Any(s => s.A.y < -4 && s.B.y < -4), Is.True);
        }

        [TestCase(true, false)]
        [TestCase(false, false)]
        [TestCase(true, true)]
        [TestCase(false, true)]
        public void BridgePortsStayInTheEndSegmentForBothSides(bool alongX, bool fallback)
        {
            var root = new GameObject("Bridge connection area check");
            try
            {
                var data = new KafoDataModel(); data.Segments.AddRange(new[] { "left", "right" });
                data.Systems.Add(new AsDataModel { Id = 1 }); data.Systems.Add(new AsDataModel { Id = 2 });
                data.Placements.Add(new AsPlacementDataModel { AsId = 1, Segment = "left" });
                data.Placements.Add(new AsPlacementDataModel { AsId = 1, Segment = "right" });
                data.Placements.Add(new AsPlacementDataModel { AsId = 2, Segment = "left" });
                Body("Segment", "segment:0", new Rect(-12, -8, 11, 16));
                Body("Segment", "segment:1", new Rect(1, -8, 11, 16));
                var bridge = Body("Bridge", "bridge", new Rect(-5, -1, 10, 2)); bridge.SystemKey = "system:0";
                bridge.PlacementKeys.AddRange(new[] { "placement:0", "placement:1" });
                var other = Body("AS", "other", new Rect(-9, 4, 2, 2)); other.SystemKey = "system:1";
                other.PlacementKeys.Add("placement:2");
                var scene = InfoflowSceneSnapshot.Capture(data, root, new InfoflowPlane(root.transform, 0));
                var endpoint = scene.Endpoints.Single(e => e.AsId == 1);
                Assert.That(endpoint.Body, Is.EqualTo(Orient(new Rect(-5, -1, 10, 2))));
                Assert.That(endpoint.PortArea, Is.EqualTo(Orient(new Rect(1, -1, 4, 2))));
                Assert.That(scene.BridgesAlongX, Is.EqualTo(alongX));
                Assert.That(scene.Obstacles, Does.Contain(endpoint.Body));
                var flows = Enumerable.Range(0, 20).Select(i => Flow(i % 3, i % 2 == 0 ? 1 : 2, i % 2 == 0 ? 2 : 1)).ToList();
                var result = Solve(scene, flows, new InfoflowSettings { MaxWidth = .4f, GapRatio = .75f, SearchBudget = fallback ? 0 : 500000 });
                foreach (var route in result.Routes)
                {
                    var port = route.ProviderKey == endpoint.Key ? route.Points[0] : route.Points.Last();
                    var area = endpoint.PortArea.Value;
                    float tangent = alongX ? port.x : port.y;
                    Assert.That(tangent - result.Width * .5f, Is.GreaterThanOrEqualTo((alongX ? area.xMin : area.yMin) - .0001f));
                    Assert.That(tangent + result.Width * .5f, Is.LessThanOrEqualTo((alongX ? area.xMax : area.yMax) + .0001f));
                }
                Assert.That(result.Routes.Select(r => r.ProviderSide).Distinct().Count(), Is.EqualTo(2));
            }
            finally { Object.DestroyImmediate(root); }

            Rect Orient(Rect rect) => alongX ? rect : new Rect(rect.yMin, -rect.xMax, rect.height, rect.width);
            KafoGeneratedItem Body(string kind, string key, Rect rect)
            {
                rect = Orient(rect);
                var go = GameObject.CreatePrimitive(PrimitiveType.Cube); go.transform.SetParent(root.transform, false);
                go.transform.localPosition = new Vector3(rect.center.x, kind == "Segment" ? -.1f : .5f, rect.center.y);
                go.transform.localScale = new Vector3(rect.width, kind == "Segment" ? .1f : 1, rect.height);
                var item = go.AddComponent<KafoGeneratedItem>(); item.Kind = kind; item.Key = key;
                return item;
            }
        }

        [Test]
        public void BothRenderersKeepRoutesPlaneAndIdentityUnderScaledParents()
        {
            var parent = new GameObject("KAFO acceptance parent");
            var root = new GameObject("KAFO acceptance root");
            InfoflowGenerator generator = null;
            try
            {
                parent.transform.position = new Vector3(13, 4, -9);
                parent.transform.rotation = Quaternion.Euler(0, 25, 0); parent.transform.localScale = new Vector3(1.5f, .8f, 2);
                root.transform.SetParent(parent.transform, false);
                root.transform.localPosition = new Vector3(3, 2, 5);
                root.transform.localRotation = Quaternion.Euler(0, 20, 0);
                var model = new KafoDataModel();
                for (int i = 0; i < 2; i++)
                {
                    var body = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    body.transform.SetParent(root.transform, false); body.transform.localPosition = new Vector3(i * 6, 1, 0);
                    var item = body.AddComponent<KafoGeneratedItem>(); item.Kind = "AS"; item.Key = "visual:" + i; item.SystemKey = "system:" + i;
                    model.Systems.Add(new AsDataModel { Id = i + 1 });
                }
                generator = parent.AddComponent<InfoflowGenerator>(); generator.FlowPlaneLocalY = .7f;
                var plane = new InfoflowPlane(root.transform, .7f);
                var scene = InfoflowSceneSnapshot.Capture(model, root, plane);
                generator.Generate(model, root, new[] { Flow(1, 1, 2), Flow(1, 2, 1) });
                var signature = string.Join(";", generator.LastResult.Routes.SelectMany(r => r.Points));
                float width = generator.LastResult.Width;
                foreach (bool batch in new[] { true, false })
                {
                    generator.UseBatchRendering = batch; generator.RebuildVisuals();
                    Assert.That(generator.Registry.Count, Is.EqualTo(2));
                    Assert.That(generator.LastResult.Width, Is.EqualTo(width));
                    Assert.That(string.Join(";", generator.LastResult.Routes.SelectMany(r => r.Points)), Is.EqualTo(signature));
                    var localVertices = new Dictionary<Renderer, Vector3[]>();
                    foreach (var renderer in generator.GeneratedRoot.GetComponentsInChildren<Renderer>())
                    {
                        if (renderer is LineRenderer line) Assert.That(line.useWorldSpace, Is.False);
                        var vertices = MeshWorldVertices(renderer);
                        Assert.That(vertices.Length, Is.GreaterThan(0));
                        localVertices.Add(renderer, vertices.Select(root.transform.InverseTransformPoint).ToArray());
                        foreach (var world in vertices)
                        {
                            Assert.That(root.transform.InverseTransformPoint(world).y, Is.EqualTo(.7f).Within(.0001f));
                            var point = plane.Project(world);
                            foreach (var obstacle in scene.Obstacles)
                            {
                                bool inside = point.x > obstacle.xMin && point.x < obstacle.xMax &&
                                    point.y > obstacle.yMin && point.y < obstacle.yMax;
                                // При ненулевом мировом смещении проекция даёт погрешность на самой границе корпуса.
                                bool boundary = Mathf.Abs(point.x - obstacle.xMin) < .0001f || Mathf.Abs(point.x - obstacle.xMax) < .0001f ||
                                    Mathf.Abs(point.y - obstacle.yMin) < .0001f || Mathf.Abs(point.y - obstacle.yMax) < .0001f;
                                Assert.That(inside && !boundary, Is.False, $"Фактическая вершина ленты внутри АС: batch={batch}, " +
                                    $"point={point.ToString("R")}, obstacle={obstacle.ToString("R")}");
                            }
                        }
                    }
                    // После построения меняем только родителя: пересчёт маршрутов и RebuildVisuals не вызываются.
                    var position = parent.transform.position; var rotation = parent.transform.rotation;
                    parent.transform.SetPositionAndRotation(position + new Vector3(7, -3, 11), Quaternion.Euler(15, 130, -20));
                    foreach (var pair in localVertices)
                    {
                        var moved = MeshWorldVertices(pair.Key);
                        Assert.That(moved.Length, Is.EqualTo(pair.Value.Length));
                        for (int i = 0; i < moved.Length; i++)
                            Assert.That(Vector3.Distance(root.transform.InverseTransformPoint(moved[i]), pair.Value[i]),
                                Is.LessThan(.0002f), "Вершина ленты должна двигаться вместе с KAFO, сохраняя толщину.");
                    }
                    parent.transform.SetPositionAndRotation(position, rotation);
                }
                var duplicate = Object.Instantiate(generator.GeneratedRoot, root.transform);
                var legacy = new GameObject("Generated KAFO Infoflows"); legacy.transform.SetParent(root.transform, false);
                var oldLine = new GameObject("KAFO flow flow:legacy"); oldLine.transform.SetParent(legacy.transform, false);
                oldLine.AddComponent<LineRenderer>();
                var unrelated = new GameObject("User annotation"); unrelated.transform.SetParent(root.transform, false);
                unrelated.AddComponent<LineRenderer>();
                // Имитируем потерю сериализованной ссылки на корень при перезагрузке редактора.
                var serialized = new UnityEditor.SerializedObject(generator);
                serialized.FindProperty("generatedRoot").objectReferenceValue = null;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                generator.RebuildVisuals();
                Assert.That(duplicate == null && legacy == null, Is.True);
                Assert.That(root.GetComponentsInChildren<InfoflowOutput>().Length, Is.EqualTo(1));
                Assert.That(root.GetComponentsInChildren<LineRenderer>().Length, Is.EqualTo(3));
                generator.Clear(); Assert.That(generator.GeneratedRoot, Is.Null);
                Assert.That(unrelated != null, Is.True);
            }
            finally { Object.DestroyImmediate(parent); }
        }
    }
}
