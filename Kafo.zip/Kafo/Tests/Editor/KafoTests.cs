using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using Object=UnityEngine.Object;

namespace Sbrt.Av.Gameplay
{
    public sealed class LayoutTests
    {
        static readonly Rect Main=new Rect(-10,-7,20,14),Island=new Rect(12,-7,2,2);
        static KafoDataModel Document(int segments)
        {
            var d=new KafoDataModel();for(int i=0;i<segments;i++)d.Segments.Add("S"+i);return d;
        }
        static void Add(KafoDataModel d,long id,int fp,string group,params string[] segments)
        {
            d.Systems.Add(new AsDataModel{Id=id,Name="AS "+id,FpCount=fp});
            foreach(var s in segments)d.Placements.Add(new AsPlacementDataModel{AsId=id,Segment=s,Group=group});
        }
        static KafoLayoutResult Solve(KafoDataModel d,int attempts=12,int seed=0)
        {
            var source=KafoDataLoader.Normalize(d);
            var result=KafoLayoutSolver.Calculate(source,Main,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=attempts,Seed=seed});
            Assert.That(result.Validate(source),Is.Empty,string.Join("\n",result.Validate(source)));return result;
        }
        static Vector2Int Footprint(KafoLayoutResult r,AsLayout a)=>r.BridgesAlongX
            ?new Vector2Int(Mathf.RoundToInt(a.Rect.width/r.CellSize.x),Mathf.RoundToInt(a.Rect.height/r.CellSize.y))
            :new Vector2Int(Mathf.RoundToInt(a.Rect.height/r.CellSize.y),Mathf.RoundToInt(a.Rect.width/r.CellSize.x));
        [TestCase(2)][TestCase(3)][TestCase(4)]
        public void SharedAsFormsOneBridgeAcrossEveryMember(int n)
        {
            var d=Document(n);Add(d,1,20,"Shared",d.Segments.ToArray());
            for(int i=0;i<n;i++)Add(d,10+i,2,"Shared","S"+i);
            var r=Solve(d);Assert.That(r.BridgeCount,Is.EqualTo(1));
            Assert.That(r.Systems.Single(s=>s.IsBridge).PlacementKeys.Count,Is.EqualTo(n));Assert.That(r.Groups.Count,Is.EqualTo(n));
        }
        [Test] public void ForcedFallbackKeepsEveryPlacement()
        {
            var d=Document(4);Add(d,1,100,"G",d.Segments.ToArray());Add(d,2,1,null,"S1");
            var r=Solve(d,0);Assert.That(r.UsedFallback,Is.True);Assert.That(r.BridgeCount,Is.Zero);Assert.That(r.Systems.Count,Is.EqualTo(5));
        }
        [Test] public void CompetingParentsCanFallBackWithoutLosingAs()
        {
            var d=Document(2);Add(d,1,3,"G","S0","S1");Add(d,2,3,"Other","S0","S1");
            Add(d,3,4,null,"S0","S1");Add(d,4,1,"G","S0");Solve(d);
        }
        [Test] public void DuplicatePlacementDisablesAmbiguousBridge()
        {
            var d=Document(2);Add(d,1,2,"G","S0","S0","S1");var r=Solve(d);
            Assert.That(r.BridgeCount,Is.Zero);Assert.That(r.Systems.Count,Is.EqualTo(3));
        }
        [TestCase(false)][TestCase(true)]
        public void FpGrowsAlongBothAxesWithWidthPreference(bool tallZone)
        {
            var d=Document(2);Add(d,1,3,null,"S0","S1");Add(d,10,1,null,"S0");Add(d,11,8,null,"S0");
            var n=KafoDataLoader.Normalize(d);
            var main=tallZone?new Rect(0,0,5,35):new Rect(0,0,35,5);
            var r=KafoLayoutSolver.Calculate(n,main,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=2});
            Assert.That(r.Validate(n),Is.Empty);Assert.That(r.BridgeCount,Is.EqualTo(1));
            Assert.That(r.BridgesAlongX,Is.EqualTo(!tallZone));
            var small=r.Systems.Single(s=>s.SystemKey==n.Systems[1].Key).Rect;
            var large=r.Systems.Single(s=>s.SystemKey==n.Systems[2].Key).Rect;
            float smallAlong=r.BridgesAlongX?small.width:small.height,largeAlong=r.BridgesAlongX?large.width:large.height;
            float smallAcross=r.BridgesAlongX?small.height:small.width,largeAcross=r.BridgesAlongX?large.height:large.width;
            Assert.That(largeAlong/smallAlong,Is.EqualTo(4).Within(.001f));Assert.That(largeAcross/smallAcross,Is.EqualTo(4).Within(.001f));
        }
        [TestCase(27,1,1)][TestCase(29,1,2)][TestCase(30,1,3)][TestCase(32,2,2)]
        [TestCase(35,2,3)][TestCase(38,2,4)][TestCase(40,3,3)][TestCase(44,3,4)][TestCase(50,4,4)]
        public void RelativeFpAreaUsesCompactGridRectangles(int fp,int length,int width)
        {
            var d=Document(1);Add(d,1,27,null,"S0");Add(d,2,50,null,"S0");Add(d,3,fp,null,"S0");var r=Solve(d);
            Assert.That(Footprint(r,r.Systems.Single(a=>a.SystemKey=="system:2")),Is.EqualTo(new Vector2Int(length,width)));
        }
        [TestCase(0)][TestCase(8)]
        public void LargeCountsRemainDistinctInMainGroupsAndIsland(int attempts)
        {
            var d=Document(1);Add(d,1,25,null,"S0");Add(d,2,50,"G","S0");Add(d,3,100,"Island",(string)null);var r=Solve(d,attempts);
            Assert.That(Footprint(r,r.Systems.Single(a=>a.SystemKey=="system:0")),Is.EqualTo(Vector2Int.one));
            Assert.That(Footprint(r,r.Systems.Single(a=>a.SystemKey=="system:1")),Is.EqualTo(new Vector2Int(2,3)));
            Assert.That(Footprint(r,r.Systems.Single(a=>a.SystemKey=="system:2")),Is.EqualTo(new Vector2Int(4,4)));
        }
        [TestCase(-100)][TestCase(0)][TestCase(1)][TestCase(50)][TestCase(int.MaxValue)]
        public void EqualFpCountsUseTheSameBaseSize(int fp)
        {
            var d=Document(1);for(int i=0;i<3;i++)Add(d,i,fp,i==1?"G":null,i==2?null:"S0");var r=Solve(d);
            Assert.That(r.Systems.All(a=>Footprint(r,a)==Vector2Int.one),Is.True);
        }
        [TestCase(0)][TestCase(8)]
        public void RecoveredCountsAndPlaceholdersDoNotShiftTheValidRange(int attempts)
        {
            var n=KafoDataLoader.Load("{\"Kafo\":{\"Segments\":[\"S0\"],\"Placements\":[{\"AsId\":1,\"Segment\":\"S0\"},{\"AsId\":2,\"Segment\":\"S0\"},{\"AsId\":999,\"Segment\":\"S0\"}]},\"Systems\":[{\"Id\":1,\"FpCount\":27},{\"Id\":2,\"FpCount\":50},{\"FpCount\":-10},{\"FpCount\":0},{\"FpCount\":\"bad\"},{\"FpCount\":null},{},{\"FpCount\":999999999999}]}");
            var r=KafoLayoutSolver.Calculate(n,Main,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=attempts});
            Assert.That(r.Validate(n),Is.Empty);
            foreach(var system in n.Systems)
            {
                var shape=Footprint(r,r.Systems.Single(a=>a.SystemKey==system.Key));
                Assert.That(shape,Is.EqualTo(system.Key=="system:1"?new Vector2Int(4,4):Vector2Int.one),system.Name);
                Assert.That(system.UseMinimumFpSize,Is.EqualTo(system.Key!="system:0"&&system.Key!="system:1"));
            }
        }
        [Test] public void RelativeSizesAreUnchangedWhenAllCountsAreScaled()
        {
            var a=Document(1);var b=Document(1);int[] counts={27,35,40,50};
            for(int i=0;i<counts.Length;i++){Add(a,i,counts[i],null,"S0");Add(b,i,counts[i]*100,null,"S0");}
            var first=Solve(a);var second=Solve(b);
            Assert.That(second.Systems.Select(s=>s.Key+":"+s.Rect),Is.EqualTo(first.Systems.Select(s=>s.Key+":"+s.Rect)));
        }
        [Test] public void RelativeAreaIsMonotonicAndBoundedAcrossTheEntireRange()
        {
            var d=Document(1);for(int fp=1;fp<=100;fp++)Add(d,fp,fp,null,"S0");var r=Solve(d,1);int previous=0;
            for(int fp=1;fp<=100;fp++)
            {
                var size=Footprint(r,r.Systems.Single(a=>a.SystemKey=="system:"+(fp-1)));
                Assert.That(size.x,Is.InRange(1,4));Assert.That(size.y,Is.InRange(size.x,4));
                Assert.That(size.x*size.y,Is.GreaterThanOrEqualTo(previous));previous=size.x*size.y;
            }
        }
        [Test] public void ExtremePositiveCountsNormalizeWithoutIntegerOverflow()
        {
            var d=Document(1);Add(d,1,int.MaxValue-1,null,"S0");Add(d,2,int.MaxValue,null,"S0");var r=Solve(d);
            Assert.That(Footprint(r,r.Systems.Single(a=>a.SystemKey=="system:0")),Is.EqualTo(Vector2Int.one));
            Assert.That(Footprint(r,r.Systems.Single(a=>a.SystemKey=="system:1")),Is.EqualTo(new Vector2Int(4,4)));
        }
        [Test] public void FootprintLimitIsConfigurableWithoutChangingSourceFp()
        {
            var d=Document(1);Add(d,1,int.MaxValue,null,"S0");Add(d,2,27,null,"S0");var n=KafoDataLoader.Normalize(d);
            var r=KafoLayoutSolver.Calculate(n,Main,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{MaxAsLengthCells=2,MaxAsWidthCells=3});
            Assert.That(r.Validate(n),Is.Empty);Assert.That(n.Systems[0].FpCount,Is.EqualTo(int.MaxValue));
            Assert.That(Footprint(r,r.Systems.Single(a=>a.SystemKey==n.Systems[0].Key)),Is.EqualTo(new Vector2Int(2,3)));
            Assert.That(Footprint(r,r.Systems.Single(a=>a.SystemKey==n.Systems[1].Key)),Is.EqualTo(Vector2Int.one));
            Assert.That(r.Diagnostics.Any(s=>s.Contains("2×3")),Is.True);
        }
        [Test] public void ActualFitEnlargesCellsComparedWithReservedBandFallback()
        {
            var n=KafoDataLoader.Load(KafoExamples.Sectors);
            var safe=KafoLayoutSolver.Calculate(n,Main,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=0});
            var dense=KafoLayoutSolver.Calculate(n,Main,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=8});
            Assert.That(dense.Validate(n),Is.Empty);Assert.That(dense.UsedFallback,Is.False);
            Assert.That(dense.CellScale,Is.GreaterThan(safe.CellScale*1.05f));
        }
        [Test] public void LargeFpIncreasesBridgeThickness()
        {
            float Thickness(int fp)
            {
                var d=Document(2);Add(d,1,fp,null,"S0","S1");Add(d,2,1,null,(string)null);Add(d,3,100,null,(string)null);
                var r=Solve(d,1);var bridge=r.Systems.Single(s=>s.IsBridge);
                return (r.BridgesAlongX?bridge.Rect.height:bridge.Rect.width)/r.CellScale;
            }
            Assert.That(Thickness(100),Is.GreaterThan(Thickness(1)));
        }
        [TestCase(false)][TestCase(true)] public void BridgeEndpointsStayNearTheFacingSegmentEdges(bool tallZone)
        {
            var d=Document(2);Add(d,1,4,"Shared","S0","S1");
            for(int i=0;i<12;i++)Add(d,10+i,1,null,"S"+(i%2));
            var n=KafoDataLoader.Normalize(d);
            var r=KafoLayoutSolver.Calculate(n,tallZone?new Rect(0,0,14,20):Main,Island,KafoVisualMetrics.Default);
            Assert.That(r.Validate(n),Is.Empty);var bridge=r.Systems.Single(a=>a.IsBridge);
            float Start(Rect rect)=>tallZone?-rect.yMax:rect.xMin;
            float End(Rect rect)=>tallZone?-rect.yMin:rect.xMax;
            var members=r.Segments.Where(s=>bridge.SegmentKeys.Contains(s.Key)).OrderBy(s=>Start(s.Rect)).ToList();
            float endpoint=(KafoVisualMetrics.Default.AsSize.x+.5f*Mathf.Max(KafoVisualMetrics.Default.AsSize.x,KafoVisualMetrics.Default.AsSize.z))*r.CellScale;
            Assert.That(End(members[0].Rect)-Start(bridge.Rect),Is.LessThanOrEqualTo(endpoint+.001f));
            Assert.That(End(bridge.Rect)-Start(members[1].Rect),Is.LessThanOrEqualTo(endpoint+.001f));
        }
        [Test] public void UngroupedAsUseTheAvailableSegmentInsteadOfOneCorner()
        {
            var d=Document(1);for(int i=0;i<9;i++)Add(d,i,1,null,"S0");
            var n=KafoDataLoader.Normalize(d);var r=KafoLayoutSolver.Calculate(n,new Rect(0,0,30,15),Island,KafoVisualMetrics.Default);
            Assert.That(r.Validate(n),Is.Empty);
            var segment=r.Segments.Single().Rect;
            float spanX=r.Systems.Max(a=>a.Rect.center.x)-r.Systems.Min(a=>a.Rect.center.x);
            float spanZ=r.Systems.Max(a=>a.Rect.center.y)-r.Systems.Min(a=>a.Rect.center.y);
            Assert.That(spanX/segment.width,Is.GreaterThan(.55f));Assert.That(spanZ/segment.height,Is.GreaterThan(.3f));
        }
        [TestCase(false,9)][TestCase(true,9)][TestCase(false,13)][TestCase(true,13)]
        public void EqualAsFormAlignedRowsAndColumnsWithEvenSpacing(bool tallZone,int count)
        {
            var d=Document(1);for(int i=0;i<count;i++)Add(d,i,1,null,"S0");
            var n=KafoDataLoader.Normalize(d);var bounds=tallZone?new Rect(0,0,15,30):new Rect(0,0,30,15);
            var r=KafoLayoutSolver.Calculate(n,bounds,Island,KafoVisualMetrics.Default);
            Assert.That(r.Validate(n),Is.Empty);
            List<float> Lines(IEnumerable<float> values)
            {
                var lines=new List<float>();foreach(float value in values.OrderBy(x=>x))if(lines.Count==0||value-lines[lines.Count-1]>.001f)lines.Add(value);
                return lines;
            }
            var columns=Lines(r.Systems.Select(a=>a.Rect.xMin));var rows=Lines(r.Systems.Select(a=>a.Rect.yMin));
            Assert.That(columns.Count,Is.GreaterThan(1));Assert.That(rows.Count,Is.GreaterThan(1));
            // The compact segment title also occupies cells near the first rows.
            Assert.That(columns.Count*rows.Count,Is.LessThanOrEqualTo(count*2));
            foreach(var lines in new[]{columns,rows})
            for(int i=2;i<lines.Count;i++)Assert.That(lines[i]-lines[i-1],Is.EqualTo(lines[1]-lines[0]).Within(.001f));
        }
        [TestCase(false,1)][TestCase(true,1)][TestCase(false,2)][TestCase(true,2)][TestCase(false,4)][TestCase(true,4)]
        public void SparseSegmentsBalanceTheirGridWhenAnotherSegmentLimitsCellSize(bool tallZone,int count)
        {
            var d=Document(2);for(int i=0;i<36;i++)Add(d,i,25,null,"S0");
            for(int i=0;i<count;i++)Add(d,100+i,25,null,"S1");
            var n=KafoDataLoader.Normalize(d);var main=tallZone?new Rect(0,0,14,24):new Rect(0,0,24,14);
            var r=KafoLayoutSolver.Calculate(n,main,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=2});
            Assert.That(r.Validate(n),Is.Empty);Assert.That(r.UsedFallback,Is.False);
            var segment=r.Segments.Single(s=>s.Name=="S1");var systems=r.Systems.Where(a=>a.SegmentKeys.Contains(segment.Key)).ToList();
            var occupied=Rect.MinMaxRect(systems.Min(a=>a.Rect.xMin),systems.Min(a=>a.Rect.yMin),systems.Max(a=>a.Rect.xMax),systems.Max(a=>a.Rect.yMax));
            Assert.That(Mathf.Abs(occupied.center.x-segment.Rect.center.x),Is.LessThan(segment.Rect.width*.12f));
            Assert.That(Mathf.Abs(occupied.center.y-segment.Rect.center.y),Is.LessThan(segment.Rect.height*.12f));
            Assert.That(systems.All(a=>Footprint(r,a)==Vector2Int.one),Is.True);
            foreach(bool y in new[]{false,true})
            {
                var lines=systems.Select(a=>y?a.Rect.yMin:a.Rect.xMin).OrderBy(v=>v).ToList();
                var distinct=new List<float>();foreach(float v in lines)if(distinct.Count==0||v-distinct.Last()>.001f)distinct.Add(v);
                for(int i=2;i<distinct.Count;i++)Assert.That(distinct[i]-distinct[i-1],Is.EqualTo(distinct[1]-distinct[0]).Within(.001f));
            }
        }
        [TestCase(false)][TestCase(true)]
        public void SparseGroupsMoveAsWholeBlocksAndKeepTheirLocalGrid(bool tallZone)
        {
            var d=Document(2);for(int i=0;i<40;i++)Add(d,i,25,null,"S0");
            Add(d,100,25,"Sparse group","S1");Add(d,101,25,"Sparse group","S1");
            var n=KafoDataLoader.Normalize(d);var r=KafoLayoutSolver.Calculate(n,tallZone?new Rect(0,0,14,24):new Rect(0,0,24,14),Island,KafoVisualMetrics.Default);
            Assert.That(r.Validate(n),Is.Empty);var group=r.Groups.Single();var segment=r.Segments.Single(s=>s.Key==group.SegmentKey);
            var children=r.Systems.Where(a=>a.GroupKeys.Contains(group.Key)).ToList();
            Assert.That(children.Count,Is.EqualTo(2));
            Assert.That(Mathf.Abs(group.Rect.center.x-segment.Rect.center.x),Is.LessThan(segment.Rect.width*.18f));
            Assert.That(Mathf.Abs(group.Rect.center.y-segment.Rect.center.y),Is.LessThan(segment.Rect.height*.18f));
            Assert.That(children.All(a=>KafoLayoutResult.Contains(group.Rect,a.Rect)),Is.True);
            Assert.That(children.All(a=>Footprint(r,a)==Vector2Int.one),Is.True);
            var offset=children[1].Rect.position-children[0].Rect.position;
            float pitch=(KafoVisualMetrics.Default.AsSize.x+.35f*Mathf.Max(KafoVisualMetrics.Default.AsSize.x,KafoVisualMetrics.Default.AsSize.z))*r.CellScale;
            Assert.That(Mathf.Min(Mathf.Abs(offset.x),Mathf.Abs(offset.y)),Is.LessThan(.001f));
            Assert.That(Mathf.Max(Mathf.Abs(offset.x),Mathf.Abs(offset.y)),Is.EqualTo(pitch).Within(.001f));
        }
        [TestCase(false)][TestCase(true)]
        public void CrossingBridgesKeepTheirEndpointsWhileLocalAsBalanceInsideFreeBands(bool tallZone)
        {
            var d=Document(3);Add(d,1,25,null,"S0","S1","S2");Add(d,2,25,null,"S1");
            for(int i=0;i<24;i++)Add(d,10+i,25,null,"S2");
            var n=KafoDataLoader.Normalize(d);var r=KafoLayoutSolver.Calculate(n,tallZone?new Rect(0,0,16,30):new Rect(0,0,30,16),Island,KafoVisualMetrics.Default);
            Assert.That(r.Validate(n),Is.Empty);Assert.That(r.BridgeCount,Is.EqualTo(1));
            var bridge=r.Systems.Single(a=>a.IsBridge);var local=r.Systems.Single(a=>a.SystemKey=="system:1");
            var segment=r.Segments.Single(s=>s.Name=="S1");
            float Min(Rect rect)=>tallZone?rect.xMin:rect.yMin;
            float Max(Rect rect)=>tallZone?rect.xMax:rect.yMax;
            float middle=(Min(local.Rect)+Max(local.Rect))*.5f;
            float unit=Mathf.Min(r.CellSize.x,r.CellSize.y),padding=.5f*unit,gap=.35f*unit*.5f;
            float from=middle<Min(bridge.Rect)?Min(segment.Rect)+padding:Max(bridge.Rect)+gap;
            float to=middle<Min(bridge.Rect)?Min(bridge.Rect)-gap:Max(segment.Rect)-padding;
            Assert.That(Mathf.Abs(middle-(from+to)*.5f),Is.LessThan((to-from)*.18f));
            Assert.That(KafoLayoutResult.Overlap(local.Rect,bridge.Rect),Is.False);
        }
        [TestCase(false,0)][TestCase(true,0)][TestCase(false,8)][TestCase(true,8)]
        public void SegmentsSpanShortSideAndFormAChainAlongLongSide(bool tallZone,int attempts)
        {
            var d=Document(3);for(int i=0;i<3;i++)Add(d,i,1,null,"S"+i);
            var n=KafoDataLoader.Normalize(d);var main=tallZone?new Rect(0,0,10,30):new Rect(0,0,30,10);
            var r=KafoLayoutSolver.Calculate(n,main,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=attempts});
            Assert.That(r.Validate(n),Is.Empty);Assert.That(r.BridgesAlongX,Is.EqualTo(!tallZone));
            var first=r.Segments[0].Rect;
            foreach(var s in r.Segments)
            {
                Assert.That(tallZone?s.Rect.x:s.Rect.y,Is.EqualTo(tallZone?first.x:first.y).Within(.0001f));
                Assert.That(tallZone?s.Rect.width:s.Rect.height,Is.EqualTo(tallZone?first.width:first.height).Within(.0001f));
            }
        }
        [TestCase(false,0)][TestCase(true,0)][TestCase(false,8)][TestCase(true,8)]
        public void NamedSegmentOrderIsPreservedAndNonAdjacentSharedAsStayVisible(bool tallZone,int attempts)
        {
            var d=Document(0);d.Segments.AddRange(new[]{"Другой Б","Внутренний сектор","internet","Другой А","Внешний сектор"});
            for(int i=0;i<d.Segments.Count;i++)Add(d,i,1,null,d.Segments[i]);
            Add(d,100,8,null,"internet","Внутренний сектор");
            var n=KafoDataLoader.Normalize(d);var bounds=tallZone?new Rect(0,0,15,35):new Rect(0,0,35,15);
            var r=KafoLayoutSolver.Calculate(n,bounds,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=attempts});
            Assert.That(r.Validate(n),Is.Empty);
            Assert.That(r.Segments.Select(s=>s.Name),Is.EqualTo(new[]{"internet","Внешний сектор","Внутренний сектор","Другой Б","Другой А"}));
            Assert.That(r.Systems.Where(s=>s.SystemKey==n.Systems.Last().Key).Sum(a=>a.PlacementKeys.Count),Is.EqualTo(2));
            Assert.That(r.Systems.Where(s=>s.SystemKey==n.Systems.Last().Key).All(a=>!a.IsBridge),Is.True);
        }
        [Test] public void IslandFpGrowthFollowsMainOrientation()
        {
            var d=Document(1);Add(d,1,1,null,"S0");Add(d,2,1,null,(string)null);Add(d,3,4,null,(string)null);
            var n=KafoDataLoader.Normalize(d);var r=KafoLayoutSolver.Calculate(n,Main,Island,KafoVisualMetrics.Default);
            Assert.That(r.Validate(n),Is.Empty);Assert.That(r.BridgesAlongX,Is.True);
            var small=r.Systems.Single(s=>s.SystemKey==n.Systems[1].Key).Rect;var large=r.Systems.Single(s=>s.SystemKey==n.Systems[2].Key).Rect;
            Assert.That(large.height/small.height,Is.EqualTo(4).Within(.001f));Assert.That(large.width/small.width,Is.EqualTo(4).Within(.001f));
        }
        [Test] public void IslandExpansionDoesNotShrinkMainCell()
        {
            var d=Document(1);Add(d,1,1,null,"S0");var before=Solve(d);
            for(int i=0;i<30;i++)Add(d,100+i,4,i%2==0?"Island Group":null,(string)null);
            var after=Solve(d);Assert.That(after.CellScale,Is.EqualTo(before.CellScale));
            Assert.That(after.IslandRect.width*after.IslandRect.height,Is.GreaterThan(Island.width*Island.height));
            Assert.That(KafoLayoutResult.Overlap(after.MainRect,after.IslandRect),Is.False);
        }
        [Test] public void CatalogOnlyAsAndEmptySegmentsAreVisible()
        {
            var d=Document(3);d.Systems.Add(new AsDataModel{Id=1,FpCount=-10});var r=Solve(d);
            Assert.That(r.Segments.Count,Is.EqualTo(3));Assert.That(r.Systems.Count,Is.EqualTo(1));Assert.That(r.Systems[0].SegmentKeys,Is.Empty);
        }
        [Test] public void EmptyMainCanRenderAnIslandAndEntirelyEmptyDocument()
        {
            Solve(Document(0));var d=Document(0);Add(d,1,0,"Island Group",(string)null);Solve(d);
        }
        [Test] public void EveryExamplePassesCoverageAndGeometryChecks()
        {
            Assert.That(KafoExamples.All.Count,Is.EqualTo(7));
            foreach(var example in KafoExamples.All)
            {
                var source=KafoDataLoader.Load(example.Json);
                foreach(var rect in new[]{Main,new Rect(230,110,4,30),new Rect(230,110,35,4)})
                {
                    var r=KafoLayoutSolver.Calculate(source,rect,Island,KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=8});
                    Assert.That(r.Validate(source),Is.Empty,example.Name+" "+string.Join("\n",r.Validate(source)));
                }
            }
        }
        [Test] public void RandomLayoutsRemainCompleteAndDisjoint()
        {
            for(int seed=0;seed<20;seed++)
            {
                var rng=new System.Random(seed);var d=Document(1+rng.Next(6));
                for(int i=0;i<35;i++)
                {
                    var ss=Enumerable.Range(0,d.Segments.Count).Where(_=>rng.Next(3)==0).Select(x=>"S"+x).ToArray();
                    Add(d,i,rng.Next(-5,80),rng.Next(2)==0?"G"+rng.Next(3):null,ss.Length>0?ss:new string[]{null});
                }
                Solve(d,6,seed);
            }
        }
        [Test] public void IdenticalSeedGivesIdenticalRectangles()
        {
            var d=Document(4);for(int i=0;i<12;i++)Add(d,i,i+1,i%2==0?"G":null,"S"+(i%4),"S"+((i+1)%4));
            var a=Solve(d,16,42);var b=Solve(d,16,42);
            Assert.That(a.Systems.Select(s=>s.Key+":"+s.Rect),Is.EqualTo(b.Systems.Select(s=>s.Key+":"+s.Rect)));
        }
        [Test] public void LargeAndInvalidMetricsStillProduceACompleteLayout()
        {
            var d=Document(2);Add(d,1,int.MaxValue,null,"S0");Add(d,2,-1,null,"S1");
            var n=KafoDataLoader.Normalize(d);var r=KafoLayoutSolver.Calculate(n,new Rect(),new Rect(),new KafoVisualMetrics(),new KafoLayoutSettings{SearchAttempts=0,MaxAsLengthCells=0,MaxAsWidthCells=-2});
            Assert.That(r.Validate(n),Is.Empty);
        }
    }
    public sealed class DataTests
    {
        [Test] public void PreparingCachedModelKeepsAllSourceObjectsAndValuesUnchanged()
        {
            var system=new AsDataModel{Id=42,FpCount=-5};
            var placement=new AsPlacementDataModel{AsId=42,Segment="Необъявленный",Group=""};
            var data=new KafoDataModel{
                Systems=new List<AsDataModel>{system,system,null,new AsDataModel{Id=0,FpCount=25}},
                Segments=new List<string>{"","",null},
                Placements=new List<AsPlacementDataModel>{placement,placement,null,new AsPlacementDataModel{AsId=0}}
            };
            string before=Newtonsoft.Json.JsonConvert.SerializeObject(data);
            var prepared=KafoDataLoader.Normalize(data);
            var result=KafoLayoutSolver.Calculate(data,new Rect(0,0,20,15),new Rect(25,0,3,3),KafoVisualMetrics.Default);
            Assert.That(result.Validate(data),Is.Empty);
            Assert.That(prepared.SourceSystemCount,Is.EqualTo(4));Assert.That(prepared.SourcePlacementCount,Is.EqualTo(4));
            Assert.That(prepared.Placements[0].SystemKey,Is.EqualTo("system:0"));
            Assert.That(prepared.Placements[1].SystemKey,Is.EqualTo("system:0"));
            Assert.That(prepared.Placements[3].SystemKey,Is.EqualTo("system:3"),"A typed zero ID is still a valid ID.");
            Assert.That(data.Systems[0],Is.SameAs(system));Assert.That(data.Systems[1],Is.SameAs(system));
            Assert.That(data.Placements[0],Is.SameAs(placement));Assert.That(data.Placements[1],Is.SameAs(placement));
            Assert.That(Newtonsoft.Json.JsonConvert.SerializeObject(data),Is.EqualTo(before));
        }
        [Test] public void NullModelCollectionsAndRecordsRemainSafeAndVisible()
        {
            foreach(var data in new[]{null,new KafoDataModel{Systems=null,Segments=null,Placements=null},
                new KafoDataModel{Systems=new List<AsDataModel>{null},Segments=new List<string>{null},Placements=new List<AsPlacementDataModel>{null}}})
            {
                var result=KafoLayoutSolver.Calculate(data,new Rect(0,0,20,15),new Rect(25,0,3,3),KafoVisualMetrics.Default);
                Assert.That(result.Validate(data),Is.Empty);
                if(data?.Systems!=null){Assert.That(result.Systems.Count,Is.EqualTo(2));Assert.That(result.Segments.Count,Is.EqualTo(1));}
            }
        }
        [Test] public void TestJsonAcceptsTheSameFlatModelAsTheRuntimeApi()
        {
            var data=new KafoDataModel{Id=15,Name="Кэш",Segments=new List<string>{"S"},
                Systems=new List<AsDataModel>{new AsDataModel{Id=10,Name="AS",FpCount=27}},
                Placements=new List<AsPlacementDataModel>{new AsPlacementDataModel{AsId=10,Segment="S"}}};
            var parsed=KafoDataLoader.ReadTestJson(Newtonsoft.Json.JsonConvert.SerializeObject(data));
            Assert.That(parsed.Id,Is.EqualTo(15));Assert.That(parsed.Name,Is.EqualTo(data.Name));
            var expected=KafoLayoutSolver.Calculate(data,new Rect(0,0,20,15),new Rect(25,0,3,3),KafoVisualMetrics.Default);
            var actual=KafoLayoutSolver.Calculate(parsed,new Rect(0,0,20,15),new Rect(25,0,3,3),KafoVisualMetrics.Default);
            Assert.That(actual.Validate(parsed),Is.Empty);
            Assert.That(actual.Systems.Select(s=>s.Key+":"+s.Rect),Is.EqualTo(expected.Systems.Select(s=>s.Key+":"+s.Rect)));
        }
        [Test] public void DirtyFieldsAndReferencesNeverDiscardRecords()
        {
            var n=KafoDataLoader.Load(KafoExamples.Dirty);
            Assert.That(n.SourceSystemCount,Is.EqualTo(7));Assert.That(n.SourcePlacementCount,Is.EqualTo(9));
            Assert.That(n.SourceSegmentCount,Is.EqualTo(4));Assert.That(n.Segments.Count,Is.GreaterThan(4));
            Assert.That(n.Systems.All(s=>s.FpCount>=1),Is.True);Assert.That(n.Diagnostics,Is.Not.Empty);
            var r=KafoLayoutSolver.Calculate(n,new Rect(0,0,20,15),new Rect(25,0,3,3),KafoVisualMetrics.Default);
            Assert.That(r.Validate(n),Is.Empty);
        }
        [Test] public void SourceMetricIsRetainedAfterNegativeFpRecovery()
        {
            var n=KafoDataLoader.Load("{\"Systems\":[{\"Id\":1,\"FpCount\":-500}]} ");
            Assert.That(n.Systems[0].FpCount,Is.EqualTo(1));Assert.That(n.Systems[0].UseMinimumFpSize,Is.True);Assert.That(n.Systems[0].Original["FpCount"].Value<int>(),Is.EqualTo(-500));
            Assert.That(n.Placements.Count,Is.EqualTo(1));
        }
        [Test] public void UnreadableJsonIsRepresentedWithItsSourceText()
        {
            var n=KafoDataLoader.Load("{broken");Assert.That(n.Systems.Count,Is.EqualTo(1));Assert.That(n.Systems[0].Original.Value<string>(),Is.EqualTo("{broken"));
        }
    }
    public sealed class MeshTests
    {
        readonly List<GameObject> objects=new List<GameObject>();
        GameObject Create(){var o=KafoTestPrefabs.CreateAs();objects.Add(o);return o;}
        [TearDown] public void Cleanup(){foreach(var o in objects)if(o!=null)Object.DestroyImmediate(o);objects.Clear();}
        [Test] public void BoundsRespectScaledRotatedParentsAndOffsetPivot()
        {
            var o=Create();var parent=new GameObject("Scaled parent");objects.Add(parent);
            parent.transform.position=new Vector3(230,29,110);parent.transform.rotation=Quaternion.Euler(0,23,0);parent.transform.localScale=new Vector3(3,.4f,2);
            o.transform.SetParent(parent.transform,false);o.transform.localPosition=new Vector3(2,3,-4);
            var shape=o.GetComponent<KafoMeshResizer>();shape.Resize(new Vector3(234,31,113),new Vector3(8,1.1f,5),.8f);
            var b=shape.MeasureBounds();Assert.That(Vector3.Distance(b.center,new Vector3(234,31,113)),Is.LessThan(.001));
            Assert.That(Vector3.Distance(b.size,new Vector3(8,1.1f,5)),Is.LessThan(.001));
        }
        [Test] public void StretchPreservesEveryCornerSample()
        {
            var o=Create();var shape=o.GetComponent<KafoMeshResizer>();var part=shape.SourceParts[0];var reference=shape.ReferenceSize;
            var source=part.Mesh.vertices;float scale=.6f;var target=new Vector3(reference.x*4,reference.y,reference.z*3)*scale;
            shape.Resize(Vector3.zero,target,scale);var changed=part.Filter.sharedMesh.vertices;int checkedCount=0;
            for(int i=0;i<source.Length;i++)
            {
                var p=part.ToReference.MultiplyPoint3x4(source[i]);
                if(p.x<=reference.x*(.5f-shape.BorderX)||p.z<=reference.z*(.5f-shape.BorderZ))continue;
                var expected=p*scale+new Vector3((target.x-reference.x*scale)*.5f,0,(target.z-reference.z*scale)*.5f);
                Assert.That(Vector3.Distance(part.Filter.transform.TransformPoint(changed[i]),expected),Is.LessThan(.0001));checkedCount++;
            }
            Assert.That(checkedCount,Is.GreaterThan(5));
        }
        [Test] public void CopiesAreIndependentAndResizingDoesNotAccumulate()
        {
            var a=Create();var b=Create();var ar=a.GetComponent<KafoMeshResizer>();var br=b.GetComponent<KafoMeshResizer>();
            float originalWidth=br.MeasureBounds().size.x;
            var original=ar.SourceParts[0].Mesh.vertices;ar.Resize(Vector3.zero,new Vector3(10,1,2),1);
            var first=ar.SourceParts[0].Filter.sharedMesh.vertices;
            ar.Resize(Vector3.one,new Vector3(5,2,3),.5f);ar.Resize(Vector3.zero,new Vector3(10,1,2),1);
            Assert.That(ar.SourceParts[0].Filter.sharedMesh.vertices,Is.EqualTo(first));Assert.That(ar.SourceParts[0].Mesh.vertices,Is.EqualTo(original));
            Assert.That(br.MeasureBounds().size.x,Is.EqualTo(originalWidth).Within(.0001));
            ar.enabled=false;ar.enabled=true;Assert.That(ar.SourceParts[0].Filter.sharedMesh.vertices,Is.EqualTo(first));
        }
        [Test] public void DynamicMeshesStayOutOfGpuResidentDrawerAfterReenable()
        {
            var o=Create();var shape=o.GetComponent<KafoMeshResizer>();shape.Resize(Vector3.zero,new Vector3(8,1,2),1);
            var property=typeof(Renderer).GetProperty("allowGPUDrivenRendering",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.NonPublic);
            Assert.That(property,Is.Not.Null);Assert.That((bool)property.GetValue(o.GetComponent<MeshRenderer>()),Is.False);
            shape.enabled=false;shape.enabled=true;Assert.That((bool)property.GetValue(o.GetComponent<MeshRenderer>()),Is.False);
        }
        [Test] public void CompositeRendererBoundsAndMeshesAreResizedTogether()
        {
            var root=new GameObject("Composite");objects.Add(root);var a=Create();var b=Create();
            a.transform.SetParent(root.transform,true);b.transform.SetParent(root.transform,true);b.transform.position=new Vector3(2,0,0);
            var shape=root.AddComponent<KafoMeshResizer>();shape.BoundsRenderers=root.GetComponentsInChildren<MeshRenderer>();Assert.That(shape.CaptureSource(),Is.True);
            shape.Resize(new Vector3(10,4,8),new Vector3(12,2,5),1);
            Assert.That(Vector3.Distance(shape.MeasureBounds().size,new Vector3(12,2,5)),Is.LessThan(.001));
        }
        [Test] public void DecorativeGlowFollowsTheBodyWithoutChangingPhysicalBounds()
        {
            var o=Object.Instantiate(UnityEditor.AssetDatabase.LoadAssetAtPath<GameObject>(KafoTestPrefabs.SegmentPath));objects.Add(o);
            var body=o.GetComponent<MeshRenderer>();var glow=o.GetComponentsInChildren<MeshRenderer>(true).Single(r=>r.name=="Glow");
            glow.transform.position+=Vector3.up*5;glow.gameObject.SetActive(true);
            var originalGlow=glow.bounds;var shape=o.GetComponent<KafoMeshResizer>();shape.BoundsRenderers=null;
            Assert.That(shape.CaptureSource(),Is.True);Assert.That(shape.ReferenceSize,Is.EqualTo(body.bounds.size));
            Assert.That(shape.SourceParts.Any(p=>p.Filter.gameObject==glow.gameObject),Is.True);
            shape.Resize(new Vector3(10,4,8),new Vector3(12,2,5),.6f);
            Assert.That(Vector3.Distance(shape.MeasureBounds().size,new Vector3(12,2,5)),Is.LessThan(.001));
            Assert.That(glow.bounds.max.y,Is.GreaterThan(body.bounds.max.y+1));
            Assert.That(glow.bounds.size.x,Is.EqualTo(body.bounds.size.x).Within(.001));
            shape.RestoreSource();
            Assert.That(Vector3.Distance(glow.bounds.center,originalGlow.center),Is.LessThan(.001));
            Assert.That(Vector3.Distance(glow.bounds.size,originalGlow.size),Is.LessThan(.001));
        }
    }
    public sealed class GeneratorTests
    {
        [TestCase(false)][TestCase(true)]
        public void AsStandOnBodySurfacesEvenWhenGlowExtendsAboveTheSegment(bool tallZone)
        {
            var go=new GameObject("Body surface test");
            try
            {
                var g=go.AddComponent<KafoGenerator>();g.MainZone=KafoTestPrefabs.MainZone(go.transform,tallZone);KafoTestPrefabs.Configure(g);
                var segment=Object.Instantiate(g.SegmentPrefab,go.transform);segment.name="Segment template with high glow";
                var glow=segment.GetComponentsInChildren<MeshRenderer>(true).Single(r=>r.name=="Glow");
                glow.transform.position+=Vector3.up*5;glow.gameObject.SetActive(true);segment.SetActive(false);
                segment.GetComponent<KafoMeshResizer>().BoundsRenderers=null;g.SegmentPrefab=segment;
                var data=new KafoDataModel{Segments=new List<string>{"A","B"},
                    Systems=new List<AsDataModel>{new AsDataModel{Id=1,FpCount=1},new AsDataModel{Id=2,FpCount=1},new AsDataModel{Id=3,FpCount=1},new AsDataModel{Id=4,FpCount=1}},
                    Placements=new List<AsPlacementDataModel>{new AsPlacementDataModel{AsId=1,Segment="A"},new AsPlacementDataModel{AsId=1,Segment="B"},new AsPlacementDataModel{AsId=2,Segment="A"},new AsPlacementDataModel{AsId=3,Segment="B",Group="G"},new AsPlacementDataModel{AsId=4}}};
                g.Generate(data);Assert.That(g.LastResult.Validate(data),Is.Empty);Assert.That(g.ValidatePhysicalBounds(),Is.Empty);
                Assert.That(g.LastResult.BridgeCount,Is.EqualTo(1));
                var items=g.GeneratedRoot.GetComponentsInChildren<KafoGeneratedItem>();
                foreach(var layout in g.LastResult.Systems)
                {
                    var view=items.Single(i=>i.Key==layout.Key);float support=g.IslandZone.bounds.max.y;
                    if(layout.SegmentKeys.Count>0)support=layout.SegmentKeys.Max(key=>items.Single(i=>i.Kind=="Segment"&&i.Key==key).GetComponent<Renderer>().bounds.max.y);
                    foreach(string key in layout.GroupKeys)support=Mathf.Max(support,items.Single(i=>i.Kind=="Group"&&i.Key==key).GetComponent<Renderer>().bounds.max.y);
                    Assert.That(view.Geometry.MeasureBounds().min.y,Is.EqualTo(support).Within(.0002f),view.name);
                }
                foreach(var view in items.Where(i=>i.Kind=="Segment"))
                {
                    var effect=view.GetComponentsInChildren<MeshRenderer>(true).Single(r=>r.name=="Glow");
                    Assert.That(effect.bounds.max.y,Is.GreaterThan(view.Geometry.MeasureBounds().max.y+1));
                }
            }
            finally {Object.DestroyImmediate(go);}
        }
        [Test] public void ServerModelGeneratesWithoutJsonAndReplacesPreviousData()
        {
            var go=new GameObject("Cached model generator");
            try
            {
                var g=go.AddComponent<KafoGenerator>();KafoTestPrefabs.Configure(g);g.Json="{broken";
                var data=new KafoDataModel{Id=15,Name="С сервера",Segments=new List<string>{"A","B"},
                    Systems=new List<AsDataModel>{new AsDataModel{Id=101,Name="Мост",FpCount=27}},
                    Placements=new List<AsPlacementDataModel>{new AsPlacementDataModel{AsId=101,Segment="A"},new AsPlacementDataModel{AsId=101,Segment="B"}}};
                string before=Newtonsoft.Json.JsonConvert.SerializeObject(data);
                g.Generate(data);
                Assert.That(g.LastData,Is.SameAs(data));Assert.That(g.LastResult.BridgeCount,Is.EqualTo(1));
                Assert.That(g.LastResult.Validate(data),Is.Empty);Assert.That(g.ValidatePhysicalBounds(),Is.Empty);
                Assert.That(g.Diagnostics.Any(s=>s.Contains("JSON")),Is.False);
                Assert.That(Newtonsoft.Json.JsonConvert.SerializeObject(data),Is.EqualTo(before));
                var oldRoot=g.GeneratedRoot;
                var next=new KafoDataModel{Systems=new List<AsDataModel>{new AsDataModel{Id=202,FpCount=-1}}};
                g.Generate(next);
                Assert.That(oldRoot==null,Is.True);Assert.That(g.LastData,Is.SameAs(next));
                Assert.That(g.LastResult.Systems.Count,Is.EqualTo(1));Assert.That(g.LastResult.Segments,Is.Empty);
                Assert.That(g.LastResult.Validate(next),Is.Empty);Assert.That(g.ValidatePhysicalBounds(),Is.Empty);
                Assert.That(g.GeneratedRoot.GetComponentsInChildren<KafoGeneratedItem>().Single().name,Does.Contain("202"));
                g.Clear();Assert.That(g.GeneratedRoot,Is.Null);Assert.That(g.LastData,Is.Null);
            }
            finally {Object.DestroyImmediate(go);}
        }
        [TestCase(false)][TestCase(true)]
        public void AsTitlesUseTmpOnTheLeftBroadFaceAndFitEntireNames(bool tallZone)
        {
            var go=new GameObject("AS labels test");var cameraObject=new GameObject("AS labels camera");
            var zone=KafoTestPrefabs.MainZone(go.transform,tallZone);
            var text="{\"Kafo\":{\"Segments\":[\"INTERNET\",\"Внешний сектор\"],\"Placements\":[{\"AsId\":1,\"Segment\":\"INTERNET\"},{\"AsId\":1,\"Segment\":\"Внешний сектор\"},{\"AsId\":2,\"Segment\":\"Внешний сектор\"}]},\"Systems\":[{\"Id\":1,\"Name\":\"Мостовая АС\",\"FpCount\":1},{\"Id\":2,\"Name\":\"Единая система проектирования ПКАП1158АС ДКА\",\"FpCount\":8}]}";
            try
            {
                var g=go.AddComponent<KafoGenerator>();g.MainZone=zone;KafoTestPrefabs.Configure(g);var camera=cameraObject.AddComponent<Camera>();camera.transform.rotation=Quaternion.Euler(35.26439f,tallZone?135:45,0);g.Json=text;g.Generate(KafoDataLoader.ReadTestJson(g.Json));
                Assert.That(g.GeneratedRoot.GetComponentsInChildren<TextMesh>(),Is.Empty);
                foreach(var item in g.GeneratedRoot.GetComponentsInChildren<KafoGeneratedItem>().Where(i=>i.Kind=="AS"||i.Kind=="Bridge"))
                {
                    var label=item.GetComponentInChildren<TextMeshPro>();Assert.That(label,Is.Not.Null);
                    var b=label.GetComponent<Renderer>().bounds;var body=item.Geometry.MeasureBounds();
                    var corners=new Vector3[4];label.rectTransform.GetWorldCorners(corners);
                    foreach(var corner in corners)
                    {
                        Assert.That(corner.y,Is.InRange(body.min.y,body.max.y));
                        if(tallZone)Assert.That(corner.x,Is.InRange(body.min.x,body.max.x));
                        else Assert.That(corner.z,Is.InRange(body.min.z,body.max.z));
                    }
                    Assert.That(label.text,Is.EqualTo(g.LastResult.Systems.Single(a=>a.Key==item.Key).Name));
                    Assert.That(label.enableAutoSizing,Is.False);Assert.That(label.textInfo.characterCount,Is.EqualTo(label.text.Length));
                    Assert.That(b.min.y,Is.GreaterThan(body.min.y));Assert.That(b.max.y,Is.LessThan(body.max.y));
                    if(tallZone)
                    {
                        Assert.That(b.center.z,Is.GreaterThan(body.max.z));Assert.That(b.size.z,Is.LessThan(.0001));
                        Assert.That(b.min.x,Is.GreaterThan(body.min.x));Assert.That(b.max.x,Is.LessThan(body.max.x));
                    }
                    else
                    {
                        Assert.That(b.center.x,Is.LessThan(body.min.x));Assert.That(b.size.x,Is.LessThan(.0001));
                        Assert.That(b.min.z,Is.GreaterThan(body.min.z));Assert.That(b.max.z,Is.LessThan(body.max.z));
                    }
                    var right=camera.transform.InverseTransformDirection(label.transform.right);
                    Assert.That(right.x,Is.GreaterThan(0));Assert.That(right.y,Is.LessThan(0));
                }
            }
            finally {Object.DestroyImmediate(go);Object.DestroyImmediate(cameraObject);}
        }
        [Test] public void TmpLabelsCancelParentScaleAndShearAndRebuildWithoutAccumulatingDeformation()
        {
            var parent=new GameObject("Scaled text parent");var child=new GameObject("Rotated text parent");child.transform.SetParent(parent.transform,false);
            var labelObject=new GameObject("World label");labelObject.transform.SetParent(child.transform,false);
            try
            {
                parent.transform.SetPositionAndRotation(new Vector3(5,3,-2),Quaternion.Euler(10,25,8));parent.transform.localScale=new Vector3(2,.4f,3);
                child.transform.localRotation=Quaternion.Euler(20,15,-12);child.transform.localScale=new Vector3(.7f,1.3f,.6f);
                var label=labelObject.AddComponent<KafoTextLabel>();var text=label.GetComponent<TextMeshPro>();
                var font=Resources.Load<TMP_FontAsset>("KafoFonts/KFO Sans SDF");Assert.That(font,Is.Not.Null);
                var origin=new Vector3(10,7,3);var rotation=Quaternion.Euler(0,90,0);
                label.Configure("Единая система проектирования №1158",font,Color.white,origin,rotation,new Vector2(2,1),.2f);
                var corners=new Vector3[4];text.rectTransform.GetWorldCorners(corners);
                Assert.That(Vector3.Distance(corners[0],corners[1]),Is.EqualTo(1).Within(.0001));
                Assert.That(Vector3.Distance(corners[1],corners[2]),Is.EqualTo(2).Within(.0001));
                var first=text.mesh.vertices.Select(v=>text.transform.TransformPoint(v)).ToArray();
                Assert.That(text.textInfo.characterCount,Is.EqualTo(text.text.Length));
                foreach(var world in first.Take(text.textInfo.meshInfo[0].vertexCount))
                {
                    var local=Quaternion.Inverse(rotation)*(world-origin);
                    Assert.That(local.x,Is.InRange(-.0001f,2.0001f));Assert.That(local.y,Is.InRange(-1.0001f,.0001f));Assert.That(Mathf.Abs(local.z),Is.LessThan(.0001f));
                }
                label.enabled=false;label.enabled=true;text.ForceMeshUpdate(true,true);
                var rebuilt=text.mesh.vertices.Select(v=>text.transform.TransformPoint(v)).ToArray();
                Assert.That(rebuilt.Length,Is.EqualTo(first.Length));
                for(int i=0;i<first.Length;i++)Assert.That(Vector3.Distance(first[i],rebuilt[i]),Is.LessThan(.0001));
            }
            finally {Object.DestroyImmediate(parent);}
        }
        [TestCase(false)][TestCase(true)]
        public void FloorTitlesFitTheirReservedStripsAndReadUpRightFromCamera(bool tallZone)
        {
            var go=new GameObject("Titles test");var cameraObject=new GameObject("Titles camera");
            var zone=KafoTestPrefabs.MainZone(go.transform,tallZone);
            const string group="Корпоративно-аналитическая платформа";
            var document=new KafoDataModel();document.Segments.AddRange(new[]{"Внутренний сектор","Внешний сектор"});
            document.Systems.AddRange(new[]{new AsDataModel{Id=1,Name="Общая АС",FpCount=5},new AsDataModel{Id=2,Name="Локальная АС",FpCount=1},new AsDataModel{Id=3,Name="Островок",FpCount=1}});
            document.Placements.AddRange(new[]{new AsPlacementDataModel{AsId=1,Segment="Внутренний сектор",Group=group},new AsPlacementDataModel{AsId=1,Segment="Внешний сектор",Group=group},new AsPlacementDataModel{AsId=2,Segment="Внутренний сектор",Group=group},new AsPlacementDataModel{AsId=3,Group=group}});
            var text=Newtonsoft.Json.JsonConvert.SerializeObject(document);
            try
            {
                var g=go.AddComponent<KafoGenerator>();g.MainZone=zone;KafoTestPrefabs.Configure(g);var camera=cameraObject.AddComponent<Camera>();camera.transform.rotation=Quaternion.Euler(35.26439f,tallZone?135:45,0);g.Json=text;g.Generate(KafoDataLoader.ReadTestJson(g.Json));
                Assert.That(g.LastResult.Validate(g.LastData),Is.Empty);Assert.That(g.ValidatePhysicalBounds(),Is.Empty);
                foreach(var item in g.GeneratedRoot.GetComponentsInChildren<KafoGeneratedItem>().Where(i=>i.Kind=="Segment"||i.Kind=="Group"))
                {
                    var title=item.GetComponentInChildren<TextMeshPro>();
                    var reserved=item.Kind=="Segment"?g.LastResult.Segments.Single(s=>s.Key==item.Key).TitleRect:g.LastResult.Groups.Single(s=>s.Key==item.Key).TitleRect;
                    var actual=KafoGenerator.Footprint(title.GetComponent<Renderer>().bounds);
                    Assert.That(KafoLayoutResult.Contains(reserved,actual,.0001f),Is.True,item.name+" "+actual+" / "+reserved);
                    foreach(var a in g.LastResult.Systems)Assert.That(KafoLayoutResult.Overlap(actual,a.Rect,.0001f),Is.False,item.name+" / "+a.Name);
                    var textBounds=title.GetComponent<Renderer>().bounds;
                    foreach(var a in g.GeneratedRoot.GetComponentsInChildren<KafoGeneratedItem>().Where(i=>i.Kind=="AS"||i.Kind=="Bridge"))
                    foreach(float x in new[]{textBounds.min.x,textBounds.center.x,textBounds.max.x})
                    foreach(float z in new[]{textBounds.min.z,textBounds.center.z,textBounds.max.z})
                    {
                        var ray=new Ray(new Vector3(x,textBounds.center.y,z),-camera.transform.forward);
                        Assert.That(a.Geometry.MeasureBounds().IntersectRay(ray),Is.False,item.name+" hidden by "+a.name);
                    }
                    string sourceName=item.Kind=="Segment"?g.LastResult.Segments.Single(s=>s.Key==item.Key).Name:g.LastResult.Groups.Single(s=>s.Key==item.Key).Name;
                    string Compact(string value)=>string.Concat(value.Where(c=>!char.IsWhiteSpace(c))).ToUpperInvariant();
                    Assert.That(Compact(title.text),Is.EqualTo(Compact(sourceName)));
                    var direction=camera.transform.InverseTransformDirection(title.transform.right);
                    Assert.That(direction.x,Is.GreaterThan(0));Assert.That(direction.y,Is.GreaterThan(0));
                }
            }
            finally {Object.DestroyImmediate(go);Object.DestroyImmediate(cameraObject);}
        }
        [Test] public void ImportedPrefabsRegenerationAndClearKeepAllRecords()
        {
            var go=new GameObject("Generator test");var text="{\"Systems\":[{\"Id\":1,\"FpCount\":-1},{\"Id\":2,\"FpCount\":4}]}";
            try
            {
                var g=go.AddComponent<KafoGenerator>();KafoTestPrefabs.Configure(g);g.Json=text;g.Generate(KafoDataLoader.ReadTestJson(g.Json));
                Assert.That(g.LastResult.Systems.Count,Is.EqualTo(2));Assert.That(g.ValidatePhysicalBounds(),Is.Empty);
                int first=g.GeneratedRoot.GetComponentsInChildren<KafoGeneratedItem>().Length;g.Generate(KafoDataLoader.ReadTestJson(g.Json));
                Assert.That(g.GeneratedRoot.GetComponentsInChildren<KafoGeneratedItem>().Length,Is.EqualTo(first));
                g.Clear();Assert.That(g.GeneratedRoot,Is.Null);
            }
            finally {Object.DestroyImmediate(go);}
        }
        [TestCase(false)][TestCase(true)] public void MissingConfigurationKeepsPreviousResultWithoutCreatingReplacementModels(bool missingZone)
        {
            var go=new GameObject("Missing configuration test");
            try
            {
                var g=go.AddComponent<KafoGenerator>();KafoTestPrefabs.Configure(g);g.Json=KafoExamples.Minimal;g.Generate(KafoDataLoader.ReadTestJson(g.Json));
                var previous=g.GeneratedRoot;int children=go.transform.childCount;
                if(missingZone)g.MainZone=null;else g.AsPrefab=null;
                Assert.DoesNotThrow(()=>g.Generate(KafoDataLoader.ReadTestJson(g.Json)));Assert.That(g.GeneratedRoot,Is.SameAs(previous));
                Assert.That(go.transform.childCount,Is.EqualTo(children));Assert.That(g.Diagnostics,Is.Not.Empty);
            }
            finally {Object.DestroyImmediate(go);}
        }
    }
}
