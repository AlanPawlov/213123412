using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public sealed class InfoflowMinimumWidthTests
    {
        [Test]
        public void DenseNetworkKeepsAllThousandRecordsWithinWidthLimits()
        {
            // Снимок композиции, на которой генерация прекращалась после 32 переносов.
            var scene = DenseScene();
            var flows = InfoflowTestDataFactory.Create(scene, 1000, 3, InfoflowTestPattern.Mixed, new List<string>());
            var settings = new InfoflowSettings { MinWidth = .01f, MaxWidth = 1, GapRatio = .5f };
            var result = InfoflowRouter.Calculate(scene, flows, settings);
            Assert.That(result.Routes.Count, Is.EqualTo(1000));
            Assert.That(result.Routes.Select(r => r.SourceIndex).OrderBy(i => i), Is.EqualTo(Enumerable.Range(0, 1000)));
            Assert.That(result.Width, Is.InRange(settings.MinWidth, settings.MaxWidth));
            Assert.That(result.Gap, Is.EqualTo(result.Width * settings.GapRatio));
            Assert.That(InfoflowGeometry.Validate(scene, result), Is.Empty);
            var ports = result.Routes.SelectMany(r => new[] {
                (Key: r.ProviderKey, Side: r.ProviderSide, Point: r.Points[0]),
                (Key: r.ConsumerKey, Side: r.ConsumerSide, Point: r.Points.Last()) });
            foreach (var bank in ports.GroupBy(p => (p.Key, p.Side)))
            {
                var coordinates = bank.Select(p => p.Side == InfoflowPortSide.PositiveZ || p.Side == InfoflowPortSide.NegativeZ ? p.Point.x : p.Point.y)
                    .OrderBy(p => p).ToArray();
                for (int i = 1; i < coordinates.Length; i++)
                    Assert.That(coordinates[i] - coordinates[i - 1], Is.EqualTo(result.Width + result.Gap).Within(.0001f));
            }
        }

        [Test]
        public void HigherMinimumWidthNeverDropsRecordsOrEntersBodies()
        {
            var scene = DenseScene();
            var flows = InfoflowTestDataFactory.Create(scene, 1000, 3, InfoflowTestPattern.Mixed, new List<string>());
            var result = InfoflowRouter.Calculate(scene, flows,
                new InfoflowSettings { MinWidth = .05f, MaxWidth = .15f, GapRatio = .5f });
            Assert.That(result.Routes.Count, Is.EqualTo(1000));
            Assert.That(result.Routes.Select(r => r.SourceIndex).OrderBy(i => i), Is.EqualTo(Enumerable.Range(0, 1000)));
            Assert.That(result.Width, Is.InRange(.05f, .15f));
            Assert.That(InfoflowGeometry.Validate(scene, result), Is.Empty);
        }

        static InfoflowScene DenseScene()
        {
            var scene = new InfoflowScene { Bounds = new Rect(-39.73256f, -26.063484f, 117.48512f, 75.34256f),
                RoutingBounds = new Rect(-39.73256f, -26.063484f, 117.48512f, 75.34256f), CellSize = 4.680542f,
                BridgesAlongX = true };
            Add(101, "bridge:system:28", new Rect(49.66815f, -1.3427734f, 16.615906f, 9.302567f), 0.18f, new[] { "segment:1", "segment:2" }, new Rect(59.263245f, -1.3427734f, 7.020813f, 9.302567f));
            Add(1, "local:placement:0", new Rect(1.9254303f, 11.236183f, 4.680542f, 4.651291f), 0.18f, new[] { "segment:0" });
            Add(2, "local:placement:1", new Rect(-23.350082f, -0.7217026f, 4.680542f, 9.302567f), 0.18f, new[] { "segment:0" });
            Add(11, "local:placement:10", new Rect(1.9254303f, -1.3427734f, 4.680542f, 9.302567f), 0.18f, new[] { "segment:0" });
            Add(12, "local:placement:11", new Rect(-2.7556915f, 24.43621f, 9.361084f, 9.302582f), 0.18f, new[] { "segment:0" });
            Add(13, "local:placement:12", new Rect(-23.350067f, 37.01516f, 4.680542f, 4.6512756f), 0.18f, new[] { "segment:0" });
            Add(14, "local:placement:13", new Rect(-10.712601f, 24.43621f, 4.680542f, 9.302582f), 0.18f, new[] { "segment:0" });
            Add(15, "local:placement:14", new Rect(18.307938f, -13.300652f, 9.361084f, 9.302567f), 0.18f, new[] { "segment:1" });
            Add(16, "local:placement:15", new Rect(48.263977f, 23.815132f, 4.680542f, 4.6512756f), 0.18f, new[] { "segment:1" });
            Add(17, "local:placement:16", new Rect(22.98848f, 24.43621f, 4.680542f, 9.302582f), 0.18f, new[] { "segment:1" });
            Add(18, "local:placement:17", new Rect(18.307938f, -0.7217026f, 9.361084f, 9.302567f), 0.18f, new[] { "segment:1" });
            Add(19, "local:placement:18", new Rect(41.94467f, 37.01516f, 4.680542f, 4.6512756f), 0.18f, new[] { "segment:1" });
            Add(20, "local:placement:19", new Rect(16.669739f, 24.43621f, 4.680542f, 9.302582f), 0.18f, new[] { "segment:1" });
            Add(3, "local:placement:2", new Rect(-34.34935f, -0.7217026f, 9.361084f, 9.302567f), 0.18f, new[] { "segment:0" });
            Add(21, "local:placement:20", new Rect(43.583435f, 11.236183f, 9.361084f, 9.302567f), 0.18f, new[] { "segment:1" });
            Add(22, "local:placement:21", new Rect(35.625946f, 37.01516f, 4.680542f, 4.6512756f), 0.18f, new[] { "segment:1" });
            Add(23, "local:placement:22", new Rect(48.263397f, 37.01516f, 4.680542f, 9.302582f), 0.18f, new[] { "segment:1" });
            Add(24, "local:placement:23", new Rect(18.307938f, 11.857262f, 9.361084f, 9.302567f), 0.18f, new[] { "segment:1" });
            Add(25, "local:placement:24", new Rect(29.30719f, 37.01516f, 4.680542f, 4.6512756f), 0.18f, new[] { "segment:1" });
            Add(26, "local:placement:25", new Rect(35.626526f, 11.236183f, 4.680542f, 9.302567f), 0.18f, new[] { "segment:1" });
            Add(27, "local:placement:26", new Rect(63.827362f, 13.4594345f, 9.361084f, 9.302567f), 0.18f, new[] { "segment:2" });
            Add(28, "local:placement:27", new Rect(68.507904f, 26.038383f, 4.680542f, 4.6512756f), 0.18f, new[] { "segment:2" });
            Add(4, "local:placement:3", new Rect(-31.072968f, 11.857254f, 18.722168f, 18.60514f), 0.18f, new[] { "segment:0" });
            Add(5, "local:placement:4", new Rect(-10.712601f, 37.01516f, 4.680542f, 9.302582f), 0.18f, new[] { "segment:0" });
            Add(6, "local:placement:5", new Rect(-9.073837f, -1.3427734f, 9.361084f, 9.302567f), 0.18f, new[] { "segment:0" });
            Add(7, "local:placement:6", new Rect(-29.668808f, 37.01516f, 4.680542f, 4.6512756f), 0.18f, new[] { "segment:0" });
            Add(8, "local:placement:7", new Rect(-17.031342f, 37.01516f, 4.680542f, 9.302582f), 0.18f, new[] { "segment:0" });
            Add(9, "local:placement:8", new Rect(-2.7556915f, 37.01516f, 9.361084f, 9.302582f), 0.18f, new[] { "segment:0" });
            Add(10, "local:placement:9", new Rect(-35.98755f, 37.01516f, 4.680542f, 4.6512756f), 0.18f, new[] { "segment:0" });
            scene.Obstacles.AddRange(scene.Endpoints.Select(e => e.Body));
            scene.SoftAreas.Add(new Rect(67.12009f, -23.723206f, 8.292236f, 1.2081909f));
            scene.SoftAreas.Add(new Rect(38.59903f, -23.723198f, 15.749634f, 1.5881348f));
            scene.SoftAreas.Add(new Rect(-10.640625f, -23.723198f, 18.650757f, 1.5881348f));
            scene.SoftAreas.Add(new Rect(60.974213f, -12.517555f, 6.71521f, 2.1402588f));
            scene.SoftAreas.Add(new Rect(43.335236f, -12.5175705f, 11.949524f, 0.9935913f));
            scene.SoftAreas.Add(new Rect(-5.3435364f, -12.5175705f, 11.949524f, 0.9935913f));
            scene.SoftAreas.Add(new Rect(-34.348938f, -11.896492f, 15.679443f, 1.913971f));
            scene.SoftAreas.Add(new Rect(43.14305f, -7.867872f, 23.141006f, 15.827665f));
            scene.SoftAreas.Add(new Rect(-4.5996685f, 4.7110844f, 11.205641f, 11.17639f));
            scene.SoftAreas.Add(new Rect(-29.875181f, -7.2468014f, 11.205641f, 15.827665f));
            scene.SoftAreas.Add(new Rect(-4.5996685f, -7.867872f, 11.205641f, 15.827665f));
            scene.SoftAreas.Add(new Rect(-9.28079f, 17.911112f, 15.886183f, 15.827681f));
            scene.SoftAreas.Add(new Rect(-29.875166f, 30.49006f, 11.205641f, 11.176374f));
            scene.SoftAreas.Add(new Rect(-17.2377f, 17.911112f, 11.205641f, 15.827681f));
            scene.SoftAreas.Add(new Rect(11.782839f, -19.82575f, 15.886183f, 15.827665f));
            scene.SoftAreas.Add(new Rect(41.738876f, 17.290033f, 11.205643f, 11.176374f));
            scene.SoftAreas.Add(new Rect(16.46338f, 17.911112f, 11.205641f, 15.827681f));
            scene.SoftAreas.Add(new Rect(11.782839f, -7.2468014f, 15.886183f, 15.827665f));
            scene.SoftAreas.Add(new Rect(35.41957f, 30.49006f, 11.205643f, 11.176374f));
            scene.SoftAreas.Add(new Rect(10.14464f, 17.911112f, 11.205641f, 15.827681f));
            scene.SoftAreas.Add(new Rect(-40.87445f, -7.2468014f, 15.886185f, 15.827665f));
            scene.SoftAreas.Add(new Rect(37.058334f, 4.7110844f, 15.886185f, 15.827665f));
            scene.SoftAreas.Add(new Rect(29.100847f, 30.49006f, 11.205641f, 11.176374f));
            scene.SoftAreas.Add(new Rect(41.738297f, 30.49006f, 11.205643f, 15.827681f));
            scene.SoftAreas.Add(new Rect(11.782839f, 5.332163f, 15.886183f, 15.827665f));
            scene.SoftAreas.Add(new Rect(22.782091f, 30.49006f, 11.205641f, 11.176374f));
            scene.SoftAreas.Add(new Rect(29.101427f, 4.7110844f, 11.205641f, 15.827665f));
            scene.SoftAreas.Add(new Rect(57.30226f, 6.9343357f, 15.886185f, 15.827665f));
            scene.SoftAreas.Add(new Rect(61.982803f, 19.513285f, 11.205643f, 11.176374f));
            scene.SoftAreas.Add(new Rect(-37.59807f, 5.332155f, 25.247269f, 25.13024f));
            scene.SoftAreas.Add(new Rect(-17.2377f, 30.49006f, 11.205641f, 15.827681f));
            scene.SoftAreas.Add(new Rect(-15.598936f, -7.867872f, 15.886183f, 15.827665f));
            scene.SoftAreas.Add(new Rect(-36.19391f, 30.49006f, 11.205643f, 11.176374f));
            scene.SoftAreas.Add(new Rect(-23.55644f, 30.49006f, 11.205641f, 15.827681f));
            scene.SoftAreas.Add(new Rect(-9.28079f, 30.49006f, 15.886183f, 15.827681f));
            scene.SoftAreas.Add(new Rect(-42.51265f, 30.49006f, 11.205643f, 11.176374f));
            return scene;

            void Add(long id, string key, Rect body, float border, string[] segments, Rect? area = null)
            {
                scene.Endpoints.Add(new InfoflowEndpoint { AsId = id, Key = key, Body = body, Border = border,
                    Segments = new List<string>(segments), PortArea = area });
            }
        }
    }
}
