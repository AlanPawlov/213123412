using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public sealed class InfoflowPortTurnTests
    {
        [Test]
        public void ShortConnectionAvoidsTheThroughPassageAtBothEnds()
        {
            var scene = InfoflowAcceptanceTests.Scene(new Vector2(-3, -1), new Vector2(3, -1),
                new Vector2(-6, -3), new Vector2(6, -3));
            var assembly = typeof(InfoflowRouter).Assembly;
            var familyType = assembly.GetType("Sbrt.Av.Gameplay.FlowFamily");
            var families = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(familyType));
            var result = new InfoflowRoutingResult { Width = .1f, Gap = .05f };
            var shortRoute = Add(0, 0, 1, new List<Vector2> { new Vector2(-3, 0), new Vector2(-3, .5f), new Vector2(3, .5f), new Vector2(3, 0) },
                new List<Vector2> { new Vector2(-3, .5f), new Vector2(3, .5f) });
            var through = Add(1, 2, 3, new List<Vector2> { new Vector2(-6, -2), new Vector2(-6, .4f), new Vector2(6, .4f), new Vector2(6, -2) });
            Assert.That(InfoflowAcceptanceTests.Crossings(result), Is.EqualTo(2));
            typeof(InfoflowRouter).GetMethod("ImproveDirectConnections", BindingFlags.NonPublic | BindingFlags.Static)
                .Invoke(null, new object[] { families, scene, new InfoflowSettings { StraightExit = .15f }, .5f, result,
                    System.Diagnostics.Stopwatch.StartNew() });
            Assert.That(InfoflowAcceptanceTests.Crossings(result), Is.Zero);
            Assert.That(InfoflowGeometry.Validate(scene, result), Is.Empty);
            Assert.That(result.Routes.Count, Is.EqualTo(2));
            Assert.That(result.Routes[1], Is.SameAs(through));
            Assert.That(result.Width, Is.EqualTo(.1f));
            Assert.That(result.Gap, Is.EqualTo(.05f));

            InfoflowRoute Add(int id, int from, int to, List<Vector2> corners, List<Vector2> path = null)
            {
                var route = new InfoflowRoute { Key = "direct:" + id, SourceIndex = id,
                    ProviderKey = scene.Endpoints[from].Key, ConsumerKey = scene.Endpoints[to].Key, Corners = corners };
                InfoflowGeometry.Round(route, new[] { 0f, .3f, .3f, 0f }, 12);
                result.Routes.Add(route);
                var family = Activator.CreateInstance(familyType);
                Set(family, "Id", id); Set(family, "Path", path ?? corners);
                Set(family, "Start", Bank(from, corners[0])); Set(family, "End", Bank(to, corners.Last()));
                var wire = Activator.CreateInstance(assembly.GetType("Sbrt.Av.Gameplay.FlowWire"));
                Set(wire, "Id", id); Set(wire, "Family", family); Set(wire, "Route", route);
                ((IList)familyType.GetField("Wires").GetValue(family)).Add(wire); families.Add(family);
                return route;
            }
            object Bank(int index, Vector2 point)
            {
                var bank = Activator.CreateInstance(assembly.GetType("Sbrt.Av.Gameplay.FlowBank"));
                Set(bank, "Point", point); Set(bank, "Normal", Vector2.up); Set(bank, "Endpoint", index); return bank;
            }
            void Set(object target, string field, object value) => target.GetType().GetField(field).SetValue(target, value);
        }

        [TestCase(0, -1, false)]
        [TestCase(0, 1, false)]
        [TestCase(1, -1, false)]
        [TestCase(1, 1, false)]
        [TestCase(2, -1, false)]
        [TestCase(2, 1, false)]
        [TestCase(3, -1, false)]
        [TestCase(3, 1, false)]
        [TestCase(0, 1, true)]
        public void VirtualPortsJoinTheStraightWithoutBulgesOrCrossings(int quarter, int side, bool compressed)
        {
            const float width = .05f, gap = .025f;
            var normal = quarter == 0 ? Vector2.up : quarter == 1 ? Vector2.right :
                quarter == 2 ? Vector2.down : Vector2.left;
            var tangent = normal.y != 0 ? Vector2.right : Vector2.up;
            var outgoing = tangent * side;
            var assembly = typeof(InfoflowRouter).Assembly;
            var wireType = assembly.GetType("Sbrt.Av.Gameplay.FlowWire");
            var wires = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(wireType));
            var routes = new List<InfoflowRoute>();
            var starts = new List<bool>();
            var bank = Bank(Vector2.zero, normal, compressed ? .04f : 2);
            for (int i = 0; i < 5; i++)
            {
                // Магистраль уже разложена по дорожкам, но её начало ещё не на грани АС.
                // Встречное направление данных не должно менять геометрию подключения.
                bool straight = i >= 3;
                var original = straight ? normal * 2.3f + tangent * (i == 3 ? -.0375f : .0375f) :
                    normal * (2 + i * (width + gap));
                var end = straight ? original + normal * 3 + outgoing * (i == 3 ? -5 : 5) : original + outgoing * 5;
                bool start = i % 2 == 0;
                var corners = straight ? new List<Vector2> { original, original + normal * 3, end } :
                    new List<Vector2> { original, end };
                if (!start) corners.Reverse();
                var route = new InfoflowRoute { Key = "port:" + i, Corners = corners };
                InfoflowGeometry.Round(route, new float[corners.Count], 12);
                var other = Bank(end, -outgoing, 1);
                var family = Activator.CreateInstance(assembly.GetType("Sbrt.Av.Gameplay.FlowFamily"));
                Set(family, "Start", start ? bank : other); Set(family, "End", start ? other : bank);
                var wire = Activator.CreateInstance(wireType);
                Set(wire, "Id", i); Set(wire, "Family", family); Set(wire, "Route", route);
                Set(wire, "Radii", new float[corners.Count]);
                wires.Add(wire); routes.Add(route); starts.Add(start);
            }
            var result = new InfoflowRoutingResult { Width = width, Gap = gap };
            typeof(InfoflowRouter).GetMethod("FitPortConnections", BindingFlags.NonPublic | BindingFlags.Static)
                .Invoke(null, new object[] { wires, width, 12, result, .6f, true });

            var paths = routes.Select((route, i) => (starts[i] ? route.Points : route.Points.AsEnumerable().Reverse())
                .Take(starts[i] ? route.StartFanPointCount : route.EndFanPointCount).ToList()).ToArray();
            foreach (var path in paths)
            {
                Assert.That(Vector2.Dot(path[0], normal), Is.EqualTo(0).Within(.00001f));
                var across = tangent * Math.Sign(Vector2.Dot(path.Last() - path[0], tangent));
                for (int i = 1; i < path.Count; i++)
                {
                    Assert.That(Vector2.Dot(path[i] - path[i - 1], across), Is.GreaterThanOrEqualTo(-.00001f),
                        "Подключение не должно сначала уходить против направления магистрали.");
                    Assert.That(Vector2.Dot(path[i] - path[i - 1], normal), Is.GreaterThanOrEqualTo(-.00001f));
                }
            }
            for (int a = 0; a < paths.Length; a++)
            for (int b = a + 1; b < paths.Length; b++)
            for (int i = 1; i < paths[a].Count; i++)
            for (int j = 1; j < paths[b].Count; j++)
                Assert.That(InfoflowGeometry.Intersection(paths[a][i - 1], paths[a][i], paths[b][j - 1], paths[b][j], out _),
                    Is.False, "Соседние подключения должны сохранять порядок и на дугах.");
            Assert.That(result.Width, Is.EqualTo(width));
            Assert.That(result.Gap, Is.EqualTo(gap));

            object Bank(Vector2 point, Vector2 direction, float halfSpan)
            {
                var value = Activator.CreateInstance(assembly.GetType("Sbrt.Av.Gameplay.FlowBank"));
                float center = direction.y != 0 ? point.x : point.y;
                Set(value, "Point", point); Set(value, "Normal", direction);
                Set(value, "Low", center - halfSpan); Set(value, "High", center + halfSpan);
                return value;
            }
            void Set(object target, string field, object value) => target.GetType().GetField(field).SetValue(target, value);
        }
    }
}
