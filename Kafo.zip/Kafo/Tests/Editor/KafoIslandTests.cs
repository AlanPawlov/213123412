using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace Sbrt.Av.Gameplay
{
    public sealed class IslandTests
    {
        static KafoDataModel Orphans(int count,bool groups=false)
        {
            var data=new KafoDataModel();
            for(int i=0;i<count;i++)
            {
                data.Systems.Add(new AsDataModel{Id=i,Name="АС "+i,FpCount=i%5==0?30:i%3+1});
                data.Placements.Add(new AsPlacementDataModel{AsId=i,Group=groups&&i%3!=0?"Группа "+i%4:null});
            }
            return data;
        }
        static readonly KafoVisualMetrics Metrics=new KafoVisualMetrics{AsSize=new Vector3(1,.2f,1),SegmentSize=new Vector3(1,.1f,1),GroupSize=new Vector3(1,.01f,1)};
        static KafoLayoutResult Solve(KafoDataModel data,Rect main,Rect island)
        {
            var result=KafoLayoutSolver.Calculate(data,main,island,Metrics,new KafoLayoutSettings{SearchAttempts=0,ItemGapX=.2f,ItemGapZ=.2f,SegmentPadding=.2f});
            Assert.That(result.Validate(data),Is.Empty,string.Join("\n",result.Validate(data)));return result;
        }

        [Test] public void SmallAsFillTheCellsBesideALargeAsWithoutExpandingTheIsland()
        {
            var data=Orphans(9);foreach(var system in data.Systems)system.FpCount=1;data.Systems[0].FpCount=10;
            var island=new Rect(40,0,7.4f,5);
            var result=Solve(data,new Rect(0,0,20,10),island);
            Assert.That(Vector2.Distance(result.IslandRect.position,island.position),Is.LessThan(.0001));
            Assert.That(Vector2.Distance(result.IslandRect.size,island.size),Is.LessThan(.0001));
            Assert.That(result.Systems.Count,Is.EqualTo(9));
            var large=result.Systems.Single(s=>s.Name=="АС 0");
            Assert.That(Vector2.Distance(large.Rect.size,new Vector2(4,4)),Is.LessThan(.0001));
        }

        [TestCase(false,0)][TestCase(false,1)][TestCase(false,2)][TestCase(false,3)]
        [TestCase(true,0)][TestCase(true,1)][TestCase(true,2)][TestCase(true,3)]
        public void IslandKeepsItsCenterAndWidthGrowsOnlyAlongZAndShrinksItsContents(bool tall,int side)
        {
            var data=Orphans(55,true);var main=tall?new Rect(0,0,10,20):new Rect(0,0,20,10);
            var requested=side==0?new Rect(main.xMax+2,0,4,8):side==1?new Rect(-6,0,4,8)
                :side==2?new Rect(0,-6,8,4):new Rect(0,main.yMax+2,8,4);
            var result=Solve(data,main,requested);var actual=result.IslandRect;
            Assert.That(Vector2.Distance(actual.center,requested.center),Is.LessThan(.0001));
            Assert.That(actual.width,Is.EqualTo(requested.width).Within(.0001));
            Assert.That(actual.width,Is.LessThanOrEqualTo(main.width));Assert.That(actual.height,Is.LessThanOrEqualTo(main.height+.0001f));
            Assert.That(KafoLayoutResult.Overlap(main,actual),Is.False);
            Assert.That(result.CellScale,Is.EqualTo(1));Assert.That(result.Systems.Count,Is.EqualTo(data.Placements.Count));
            Assert.That(result.IslandCellScale,Is.GreaterThan(0).And.LessThan(1));
            var origin=result.Systems[0].Rect;
            // Use the logical leading edge: wide layouts reverse X, tall ones transpose X/Z.
            Vector2 Anchor(Rect r)=>result.BridgesAlongX?new Vector2(-r.xMax,r.yMin):new Vector2(r.yMin,r.xMin);
            foreach(var system in result.Systems)
            {
                var delta=(Anchor(system.Rect)-Anchor(origin))/(1.2f*result.IslandCellScale);
                Assert.That(delta.x,Is.EqualTo(Mathf.Round(delta.x)).Within(.0001));
                Assert.That(delta.y,Is.EqualTo(Mathf.Round(delta.y)).Within(.0001));
            }
            var again=Solve(data,main,requested);
            Assert.That(again.IslandRect,Is.EqualTo(actual));
            Assert.That(again.Systems.Select(s=>s.Rect),Is.EqualTo(result.Systems.Select(s=>s.Rect)));
        }

        [Test] public void OverloadShrinksContentsInsteadOfMakingTheIslandLargerThanTheMainZone()
        {
            var data=Orphans(150,true);var result=Solve(data,new Rect(0,0,20,10),new Rect(40,0,4,8));
            Assert.That(result.IslandRect.width,Is.EqualTo(4).Within(.0001));
            Assert.That(result.IslandRect.height,Is.LessThanOrEqualTo(10.0001f));
            Assert.That(result.IslandCellScale,Is.LessThan(1));Assert.That(result.Systems.Count,Is.EqualTo(150));
        }

        [Test] public void AGroupReflowsInsideTheFixedIslandWidth()
        {
            var data=Orphans(30);foreach(var system in data.Systems)system.FpCount=1;
            foreach(var placement in data.Placements)placement.Group="Одна группа";
            var requested=new Rect(40,0,12,5);var result=Solve(data,new Rect(0,0,20,10),requested);
            Assert.That(result.IslandRect.width,Is.EqualTo(requested.width).Within(.0001));
            Assert.That(result.IslandRect.height,Is.LessThanOrEqualTo(10.0001f));
            Assert.That(result.Groups.Count,Is.EqualTo(1));
        }

        [Test] public void RepeatedGenerationKeepsTheAuthoredPositionAndClearRestoresItsBounds()
        {
            var root=new GameObject("Island reset test");
            try
            {
                var generator=root.AddComponent<KafoGenerator>();KafoTestPrefabs.Configure(generator);
                // Test a non-normalized hierarchy and an authored, already resized zone.
                root.transform.SetPositionAndRotation(new Vector3(3,2,-4),Quaternion.Euler(0,23,0));root.transform.localScale=new Vector3(2,.7f,1.4f);
                var zone=generator.IslandZone;var shape=zone.GetComponent<KafoMeshResizer>();
                shape.Resize(new Vector3(30,2,0),new Vector3(4,.2f,6),1);
                var original=zone.bounds;
                generator.Generate(Orphans(80,true));Assert.That(generator.ValidatePhysicalBounds(),Is.Empty);
                var expanded=zone.bounds;Assert.That(expanded.size.x*expanded.size.z,Is.GreaterThan(original.size.x*original.size.z));
                generator.Generate(Orphans(1));
                Assert.That(Vector3.Distance(zone.bounds.center,original.center),Is.LessThan(.001));
                generator.Clear();Assert.That(generator.GeneratedRoot,Is.Null);Assert.That(zone.enabled,Is.False);
                Assert.That(Vector3.Distance(zone.bounds.center,original.center),Is.LessThan(.001));
                Assert.That(Vector3.Distance(zone.bounds.size,original.size),Is.LessThan(.001));
                shape.enabled=false;shape.enabled=true;
                Assert.That(Vector3.Distance(zone.bounds.center,original.center),Is.LessThan(.001));
                Assert.That(Vector3.Distance(zone.bounds.size,original.size),Is.LessThan(.001));
                generator.Generate(Orphans(80,true));generator.Clear();
                Assert.That(Vector3.Distance(zone.bounds.size,original.size),Is.LessThan(.001));
            }
            finally {Object.DestroyImmediate(root);}
        }

        [Test] public void ClearUsesSerializedOriginalBoundsAfterReopeningTheScene()
        {
            string path="Assets/Kafo/Tests/Editor/IslandReload_"+System.Guid.NewGuid().ToString("N")+".unity";
            var scene=UnityEditor.SceneManagement.EditorSceneManager.NewScene(UnityEditor.SceneManagement.NewSceneSetup.EmptyScene);
            try
            {
                var root=new GameObject("Island serialized reset test");UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(root,scene);
                var generator=root.AddComponent<KafoGenerator>();KafoTestPrefabs.Configure(generator);
                var zone=generator.IslandZone;var original=zone.bounds;
                generator.Generate(Orphans(40,true));
                Assert.That(UnityEditor.SceneManagement.EditorSceneManager.SaveScene(scene,path),Is.True);
                scene=UnityEditor.SceneManagement.EditorSceneManager.OpenScene(path);
                generator=scene.GetRootGameObjects().Select(o=>o.GetComponent<KafoGenerator>()).First(g=>g!=null);zone=generator.IslandZone;
                generator.Clear();
                Assert.That(Vector3.Distance(zone.bounds.center,original.center),Is.LessThan(.001));
                Assert.That(Vector3.Distance(zone.bounds.size,original.size),Is.LessThan(.001));
            }
            finally
            {
                UnityEditor.SceneManagement.EditorSceneManager.NewScene(UnityEditor.SceneManagement.NewSceneSetup.EmptyScene);
                AssetDatabase.DeleteAsset(path);
            }
        }

        [Test] public void AMissingSavedBaselineNeverRelocatesTheAuthoredZone()
        {
            var root=new GameObject("Legacy island reset test");
            try
            {
                var generator=root.AddComponent<KafoGenerator>();KafoTestPrefabs.Configure(generator);
                Object.DestroyImmediate(generator.IslandZone.gameObject);
                var zone=Object.Instantiate(generator.SegmentPrefab,root.transform,false);
                zone.transform.position=new Vector3(30,2,0);zone.transform.localScale=new Vector3(.3f,.2f,.4f);
                generator.IslandZone=zone.GetComponent<Renderer>();
                generator.Generate(Orphans(40,true));
                var original=generator.IslandZone.bounds;
                // Older scenes have a generated hierarchy and mesh source, but no saved baseline.
                var state=new SerializedObject(generator);state.FindProperty("originalIslandZone").objectReferenceValue=null;state.ApplyModifiedPropertiesWithoutUndo();
                generator.Clear();
                Assert.That(Vector3.Distance(generator.IslandZone.bounds.center,original.center),Is.LessThan(.001));
                Assert.That(Vector3.Distance(generator.IslandZone.bounds.size,original.size),Is.LessThan(.001));
            }
            finally {Object.DestroyImmediate(root);}
        }

        [Test] public void OversizedAuthoredZoneIsCappedAtTheMainDimensionsWithoutChangingItsCenter()
        {
            var requested=new Rect(40,0,100,80);var main=new Rect(0,0,20,10);
            var result=Solve(Orphans(100),main,requested);
            Assert.That(Vector2.Distance(result.IslandRect.center,requested.center),Is.LessThan(.0001));
            Assert.That(result.IslandRect.width,Is.EqualTo(main.width).Within(.0001));
            Assert.That(result.IslandRect.height,Is.LessThanOrEqualTo(main.height+.0001f));
        }

        [Test] public void EditingTheZoneTransformIsRespectedByGenerationClearAndMeshReload()
        {
            var root=new GameObject("Edited island test");
            try
            {
                var generator=root.AddComponent<KafoGenerator>();KafoTestPrefabs.Configure(generator);
                generator.Generate(Orphans(60,true));
                var zone=generator.IslandZone;var shape=zone.GetComponent<KafoMeshResizer>();
                zone.transform.position+=new Vector3(40,0,30);zone.transform.localScale*=.6f;
                shape.RefreshTransform();var edited=zone.bounds;var position=zone.transform.position;
                generator.Generate(Orphans(60,true));
                Assert.That(Vector3.Distance(zone.transform.position,position),Is.LessThan(.0001));
                Assert.That(Vector3.Distance(zone.bounds.center,edited.center),Is.LessThan(.0001));
                Assert.That(generator.ValidatePhysicalBounds(),Is.Empty);
                generator.Clear();shape.enabled=false;shape.enabled=true;
                Assert.That(Vector3.Distance(zone.transform.position,position),Is.LessThan(.0001));
                Assert.That(Vector3.Distance(zone.bounds.center,edited.center),Is.LessThan(.0001));
                Assert.That(Vector3.Distance(zone.bounds.size,edited.size),Is.LessThan(.001));
            }
            finally {Object.DestroyImmediate(root);}
        }

        [Test] public void IslandGeometryAndTextUseTheIslandScaleWhileTheMainLayoutIsUnchanged()
        {
            var root=new GameObject("Island scale test");
            try
            {
                var generator=root.AddComponent<KafoGenerator>();KafoTestPrefabs.Configure(generator);
                var data=Orphans(70,true);data.Segments.Add("Сегмент");data.Systems.Add(new AsDataModel{Id=100,Name="Основная АС",FpCount=1});
                data.Placements.Add(new AsPlacementDataModel{AsId=100,Segment="Сегмент"});generator.Generate(data);
                var layout=generator.LastResult;
                Assert.That(layout.IslandCellScale,Is.LessThan(layout.CellScale));
                Assert.That(generator.ValidatePhysicalBounds(),Is.Empty);
                var islandKeys=new System.Collections.Generic.HashSet<string>(layout.Systems.Where(s=>s.SegmentKeys.Count==0).Select(s=>s.Key));
                islandKeys.UnionWith(layout.Groups.Where(g=>g.SegmentKey==null).Select(g=>g.Key));
                foreach(var item in generator.GeneratedRoot.GetComponentsInChildren<KafoGeneratedItem>())
                {
                    Assert.That(item.Geometry.UniformScale,Is.EqualTo(islandKeys.Contains(item.Key)?layout.IslandCellScale:layout.CellScale).Within(.000001));
                    var text=item.GetComponentInChildren<TMPro.TextMeshPro>();Assert.That(text,Is.Not.Null);
                    Assert.That(text.textInfo.characterCount,Is.EqualTo(text.text.Length));
                }
            }
            finally {Object.DestroyImmediate(root);}
        }
    }
}
