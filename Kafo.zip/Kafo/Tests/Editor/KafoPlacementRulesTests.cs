using System;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public sealed class PlacementRulesTests
    {
        static KafoDataModel Data(int count)
        {
            var data=new KafoDataModel();for(int i=0;i<count;i++)data.Segments.Add("S"+i);return data;
        }
        static void Add(KafoDataModel data,long id,string group,params string[] segments)
        {
            data.Systems.Add(new AsDataModel{Id=id,Name="АС "+id,FpCount=1});
            foreach(string segment in segments)data.Placements.Add(new AsPlacementDataModel{AsId=id,Segment=segment,Group=group});
        }
        static KafoLayoutResult Solve(KafoDataModel data,bool tall,int attempts)
        {
            var result=KafoLayoutSolver.Calculate(data,tall?new Rect(20,30,16,36):new Rect(20,30,36,16),
                new Rect(60,30,3,3),KafoVisualMetrics.Default,new KafoLayoutSettings{SearchAttempts=attempts});
            Assert.That(result.Validate(data),Is.Empty,string.Join("\n",result.Validate(data)));return result;
        }
        static void Faces(KafoLayoutResult result,GroupLayout group,SegmentLayout neighbor)
        {
            var parent=result.Segments.Single(s=>s.Key==group.SegmentKey);
            float Min(Rect r)=>result.BridgesAlongX?r.xMin:r.yMin;
            float Max(Rect r)=>result.BridgesAlongX?r.xMax:r.yMax;
            bool positive=Min(neighbor.Rect)+Max(neighbor.Rect)>Min(parent.Rect)+Max(parent.Rect);
            float near=positive?Max(parent.Rect)-Max(group.Rect):Min(group.Rect)-Min(parent.Rect);
            float far=positive?Min(group.Rect)-Min(parent.Rect):Max(parent.Rect)-Max(group.Rect);
            float cell=result.BridgesAlongX?result.CellSize.x:result.CellSize.y;
            // At most one unused grid pitch plus the platform's padding.
            Assert.That(near,Is.LessThanOrEqualTo(1.85f*cell+.001f),group.Name);
            Assert.That(near,Is.LessThanOrEqualTo(far+.001f),group.Name+" faces away from its neighbor");
        }

        [TestCase(false,0)][TestCase(true,0)][TestCase(false,8)][TestCase(true,8)]
        public void LayoutStartsAtTheOppositeCornerAndKeepsTheNamedSegmentOrder(bool tall,int attempts)
        {
            var data=Data(0);data.Segments.AddRange(new[]{"Внутренний сектор","INTERNET","Внешний сектор"});
            foreach(string segment in data.Segments)Add(data,data.Systems.Count+1,"Шлюзовая сеть",segment);
            var result=Solve(data,tall,attempts);
            Assert.That(result.Segments.Select(s=>s.Name),Is.EqualTo(new[]{"INTERNET","Внешний сектор","Внутренний сектор"}));
            for(int i=1;i<result.Segments.Count;i++)
            {
                var previous=result.Segments[i-1].Rect;var current=result.Segments[i].Rect;
                if(tall)Assert.That(current.yMin,Is.GreaterThan(previous.yMax));
                else Assert.That(current.xMax,Is.LessThan(previous.xMin));
            }
            foreach(var segment in result.Segments)
            {
                if(tall)Assert.That(segment.HeaderRect.xMin,Is.EqualTo(segment.Rect.xMin).Within(.0001));
                else Assert.That(segment.HeaderRect.yMin,Is.EqualTo(segment.Rect.yMin).Within(.0001));
                foreach(var a in result.Systems.Where(a=>a.SegmentKeys.Contains(segment.Key)))
                {
                    if(tall)Assert.That(a.Rect.xMin,Is.GreaterThanOrEqualTo(segment.HeaderRect.xMax-.0001f));
                    else Assert.That(a.Rect.yMin,Is.GreaterThanOrEqualTo(segment.HeaderRect.yMax-.0001f));
                }
            }
        }

        [TestCase(false,0)][TestCase(true,0)][TestCase(false,8)][TestCase(true,8)]
        public void CompleteHeaderLineStaysClearOfGroupsLocalAsAndBridges(bool tall,int attempts)
        {
            var data=Data(3);Add(data,100,"Общая группа","S0","S1","S2");
            for(int i=0;i<36;i++)Add(data,i,i%3==0?"Группа "+i:null,"S"+(i%3));
            var result=Solve(data,tall,attempts);
            foreach(var segment in result.Segments)
            {
                var header=segment.HeaderRect;
                Assert.That(KafoLayoutResult.Contains(segment.Rect,header),Is.True);
                Assert.That(KafoLayoutResult.Contains(header,segment.TitleRect),Is.True);
                Assert.That(tall?header.height:header.width,Is.EqualTo(tall?segment.Rect.height:segment.Rect.width).Within(.0001));
                foreach(var a in result.Systems)Assert.That(KafoLayoutResult.Overlap(header,a.Rect),Is.False,a.Name);
                foreach(var g in result.Groups)Assert.That(KafoLayoutResult.Overlap(header,g.Rect),Is.False,g.Name);
            }
        }

        [TestCase(false,0)][TestCase(true,0)][TestCase(false,8)][TestCase(true,8)]
        public void LocalGatewayCopiesStayAtTheFacingEdgesAfterBalancing(bool tall,int attempts)
        {
            var data=Data(2);Add(data,100,"Шлюзовая сеть","S0");Add(data,101,"Шлюзовая сеть","S1");
            for(int i=0;i<24;i++)Add(data,i,i%4==0?"Другая группа":null,"S"+(i%2));
            var result=Solve(data,tall,attempts);
            foreach(var group in result.Groups.Where(g=>g.Name=="Шлюзовая сеть"))
                Faces(result,group,result.Segments.Single(s=>s.Key!=group.SegmentKey));
        }

        [TestCase(false,0)][TestCase(true,0)][TestCase(false,8)][TestCase(true,8)]
        public void MiddleGatewayPrefersSharedAsEvenWhenTheirBridgeIsAmbiguous(bool tall,int attempts)
        {
            var data=Data(3);Add(data,100,"Шлюзовая сеть","S1","S1","S2");Add(data,101,"Шлюзовая сеть","S0");
            for(int i=0;i<18;i++)Add(data,i,null,"S"+(i%3));
            var result=Solve(data,tall,attempts);
            var group=result.Groups.Single(g=>g.Name=="Шлюзовая сеть"&&g.SegmentKey==result.Segments[1].Key);
            Faces(result,group,result.Segments[2]);
            Assert.That(result.Systems.Where(s=>s.SystemKey=="system:0").Sum(s=>s.PlacementKeys.Count),Is.EqualTo(3));
            Assert.That(result.Systems.Where(s=>s.SystemKey=="system:0").All(s=>!s.IsBridge),Is.True);
        }

        [TestCase(false,0)][TestCase(true,0)][TestCase(false,8)][TestCase(true,8)]
        public void GatewayMatchingPreservesDistinctCaseAndWhitespaceRecords(bool tall,int attempts)
        {
            var data=Data(2);Add(data,100," ШЛЮЗОВАЯ СЕТЬ ","S0");Add(data,101,"шлюзовая сеть","S0");
            Add(data,102,"Обычная группа","S0");Add(data,103,null,"S1");
            var result=Solve(data,tall,attempts);
            var groups=result.Groups.Where(g=>g.Name.Trim().Equals("Шлюзовая сеть",StringComparison.OrdinalIgnoreCase)).ToList();
            Assert.That(groups.Count,Is.EqualTo(2));Assert.That(groups.Select(g=>g.Name).Distinct().Count(),Is.EqualTo(2));
            foreach(var group in groups)Faces(result,group,result.Segments[1]);
        }

        [TestCase(0)][TestCase(8)] public void SingleSegmentAndIslandGatewaysDoNotRequireANeighbor(int attempts)
        {
            var data=Data(1);Add(data,1,"Шлюзовая сеть","S0");Add(data,2,"Шлюзовая сеть",(string)null);
            var result=Solve(data,false,attempts);
            Assert.That(result.Groups.Count,Is.EqualTo(2));Assert.That(result.Systems.Count,Is.EqualTo(2));
            Assert.That(result.Groups.Count(g=>g.SegmentKey==null),Is.EqualTo(1));
        }

        [Test] public void HeaderValidationRejectsGroupBackdropsEvenWithoutAsInTheHeader()
        {
            var data=Data(1);Add(data,1,"G","S0");var result=Solve(data,false,8);
            result.Groups.Single().Rect=result.Segments.Single().HeaderRect;
            Assert.That(result.Validate(data).Any(e=>e.StartsWith("Группа заходит на полосу")),Is.True);
        }
    }
}
