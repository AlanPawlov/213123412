using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    [UnityEngine.Scripting.APIUpdating.MovedFrom(true, "Kafo", "Kafo.Runtime", null)]
    [DisallowMultipleComponent]
    public sealed class KafoGenerator : MonoBehaviour
    {
#if UNITY_EDITOR
        [TextArea(5, 20), Tooltip("Только для проверки генерации в Inspector.")]
        public string Json = KafoExamples.Bridges;
#endif
        public Renderer MainZone;
        public Renderer IslandZone;
        public GameObject AsPrefab, SegmentPrefab, GroupPrefab;
        public TMP_FontAsset LabelFont;
        public KafoLayoutSettings Settings = new KafoLayoutSettings();
        [SerializeField, HideInInspector] string summary;
        [SerializeField, HideInInspector] List<string> diagnostics = new List<string>();
        [SerializeField, HideInInspector] GameObject generatedRoot;
        [SerializeField, HideInInspector] bool hasIslandContent;
        [SerializeField, HideInInspector] Renderer originalIslandZone;
        [SerializeField, HideInInspector] Bounds originalIslandBounds;
        [SerializeField, HideInInspector] Matrix4x4 originalIslandTransform;
        [SerializeField, HideInInspector] bool hasIslandTransform;
        public string Summary => summary;
        public IReadOnlyList<string> Diagnostics => diagnostics;
        public KafoLayoutResult LastResult { get; private set; }
        public KafoDataModel LastData { get; private set; }
        public GameObject GeneratedRoot => generatedRoot;

        /// <summary>Replaces this generator's visualization with the supplied cached/server model.</summary>
        public void Generate(KafoDataModel data)
        {
            Settings ??= new KafoLayoutSettings();
            diagnostics.Clear();
            if (AsPrefab == null) diagnostics.Add("Не назначен префаб АС.");    
            if (SegmentPrefab == null) diagnostics.Add("Не назначен префаб сегмента.");
            if (GroupPrefab == null) diagnostics.Add("Не назначен префаб группы.");
            if (MainZone == null) diagnostics.Add("Не назначена основная зона генерации.");
            if (IslandZone == null) diagnostics.Add("Не назначена зона островка.");
            if (diagnostics.Count > 0) return;
            var source = KafoDataLoader.Normalize(data);
            var stages = new List<GameObject>();
            try
            {
                var app = Prepare(AsPrefab, "АС", stages);
                var segment = Prepare(SegmentPrefab, "сегмента", stages);
                var group = Prepare(GroupPrefab, "группы", stages);
                if (app == null || segment == null || group == null) return;
                var metrics = new KafoVisualMetrics
                {
                    AsSize = app.GetComponent<KafoMeshResizer>().ReferenceSize,
                    SegmentSize = segment.GetComponent<KafoMeshResizer>().ReferenceSize,
                    GroupSize = group.GetComponent<KafoMeshResizer>().ReferenceSize
                };
                var mainRect = Footprint(MainZone.bounds);
                RememberIsland();
                var islandRect = Footprint(originalIslandBounds);
                var result = KafoLayoutSolver.Calculate(source, mainRect, islandRect, metrics, Settings);
                var validation = result.Validate(source);
                if (validation.Count > 0)
                {
                    var safe = CopySettings(Settings);
                    safe.SearchAttempts = 0;
                    result = KafoLayoutSolver.Calculate(source, mainRect, islandRect, metrics, safe);
                    result.Diagnostics.AddRange(validation.Select(v => "Перекомпоновка: " + v));
                }

                ClearGenerated();
                ResizeIsland(result.IslandRect);
                generatedRoot = new GameObject("Generated KFO");
                generatedRoot.transform.SetParent(transform, false);
                Render(source, result, metrics, app, segment, group);
                var physical = ValidatePhysicalBounds(result);
                if (physical.Count > 0)
                {
                    // Repack the same imported geometry; never substitute another model.
                    ClearGenerated();
                    var safe = CopySettings(Settings);
                    safe.SearchAttempts = 0;
                    result = KafoLayoutSolver.Calculate(source, mainRect, islandRect, metrics, safe);
                    result.Diagnostics.AddRange(physical);
                    result.Diagnostics.Add("Выполнена резервная компоновка с назначенными префабами.");
                    ResizeIsland(result.IslandRect);
                    generatedRoot = new GameObject("Generated KFO");
                    generatedRoot.transform.SetParent(transform, false);
                    Render(source, result, metrics, app, segment, group);
                }

                LastData = data;
                LastResult = result;
                diagnostics = new List<string>(result.Diagnostics);
                hasIslandContent = source.Placements.Any(p => p.SegmentKey == null);
                IslandZone.enabled = hasIslandContent;
                summary =
                    $"{source.Name}\nСегменты: {result.Segments.Count} · Группы: {result.Groups.Count} · АС: {result.Systems.Count} · Мосты: {result.BridgeCount}\nЯчейка: {result.CellSize.x:F3} × {result.CellSize.y:F3} · Островок: {result.IslandCellSize.x:F3} × {result.IslandCellSize.y:F3}\nВсе {source.Placements.Count} размещений отображены · Мосты: {(result.BridgesAlongX ? "X" : "Z")} · Размеры АС: 1×1…{Settings.MaxAsLengthCells}×{Settings.MaxAsWidthCells}";
            }
            finally
            {
                foreach (var stage in stages)
                    if (stage != null)
                        Dispose(stage);
            }
        }

        static KafoLayoutSettings CopySettings(KafoLayoutSettings s) =>
            JsonUtility.FromJson<KafoLayoutSettings>(JsonUtility.ToJson(s));

        GameObject Prepare(GameObject prefab, string kind, List<GameObject> stages)
        {
            var stage = Instantiate(prefab);
            stages.Add(stage);
            stage.name = "KFO Template " + kind;
            stage.hideFlags = HideFlags.HideAndDontSave;
            stage.transform.position = Vector3.zero;
            stage.SetActive(true);
            var shape = stage.GetComponent<KafoMeshResizer>();
            if (shape == null)
                shape = stage.AddComponent<KafoMeshResizer>();
            if (!shape.CaptureSource())
            {
                diagnostics.Add("Префаб " + kind +
                                " не содержит пригодной геометрии. Проверьте BoundsRenderers и Read/Write мешей.");
                return null;
            }

            // Match asymmetric prefab details (name/data panels) to the new layout
            // direction in the captured mesh frame, without rotating the hierarchy.
            var facing = Matrix4x4.Scale(new Vector3(-1, 1, -1));
            foreach (var part in shape.SourceParts) part.ToReference = facing * part.ToReference;

            return stage;
        }

        void ResizeIsland(Rect rect)
        {
            var shape = IslandZone.GetComponent<KafoMeshResizer>();
            if (shape == null)
                shape = IslandZone.gameObject.AddComponent<KafoMeshResizer>();
            shape.FollowTransformChanges = true;
            if (shape.SourceParts.Count == 0)
                shape.CaptureSource();
            var bounds = IslandZone.bounds;
            shape.Resize(new Vector3(rect.center.x, bounds.center.y, rect.center.y),
                new Vector3(rect.width, bounds.size.y, rect.height), 1);
        }

        void RememberIsland()
        {
            var shape = IslandZone.GetComponent<KafoMeshResizer>();
            if (shape != null)
            {
                shape.FollowTransformChanges = true;
                shape.RefreshTransform();
            }
            var matrix = IslandZone.transform.localToWorldMatrix;
            if (originalIslandZone == IslandZone && (!hasIslandTransform || originalIslandTransform == matrix))
            {originalIslandTransform = matrix;hasIslandTransform = true;return;}
            if (originalIslandZone != null && originalIslandZone != IslandZone) RestoreIsland();
            // A user edit establishes a new authored zone. Never restore an old world position over it.
            originalIslandZone = IslandZone;
            originalIslandBounds = IslandZone.bounds;
            originalIslandTransform = matrix;
            hasIslandTransform = true;
        }

        void RestoreIsland()
        {
            if (originalIslandZone != null)
            {
                var shape = originalIslandZone.GetComponent<KafoMeshResizer>();
                if (shape != null)
                {
                    var bounds = hasIslandTransform ? KafoMeshResizer.TransformBounds(originalIslandBounds,
                        originalIslandZone.transform.localToWorldMatrix * originalIslandTransform.inverse) : originalIslandBounds;
                    shape.Resize(bounds.center, bounds.size, 1);
                }
                originalIslandZone.enabled = false;
            }
            originalIslandZone = null;
            hasIslandTransform = false;
        }

        public static Rect Footprint(Bounds b) => new Rect(b.min.x, b.min.z, b.size.x, b.size.z);

        void Render(NormalizedKafo source, KafoLayoutResult result, KafoVisualMetrics metrics, GameObject app,
            GameObject segment, GameObject group)
        {
            float k = result.CellScale, unit = Mathf.Min(result.CellSize.x, result.CellSize.y);
            float mainBottom = MainZone.bounds.max.y + .025f * k, segmentHeight = metrics.SegmentSize.y * k;
            float islandTop = IslandZone.bounds.max.y;
            var segmentTops = new Dictionary<string, float>();
            var groupTops = new Dictionary<string, float>();
            foreach (var s in result.Segments)
            {
                var view = Spawn(segment, s.Rect, mainBottom, segmentHeight, k, "Segment", s.Key);
                view.name = "Segment · " + s.Name;
                view.GetComponent<KafoGeneratedItem>().TitleRect = s.TitleRect;
                float top = view.GetComponent<KafoMeshResizer>().MeasureBounds().max.y;
                segmentTops.Add(s.Key, top);
                FloorLabel(view.transform, s.Name, s.TitleRect, top + .008f * k, unit, .25f,
                    new Color(.45f, .8f, 1), !result.BridgesAlongX);
            }

            foreach (var g in result.Groups)
            {
                float groupScale = g.SegmentKey == null ? result.IslandCellScale : k;
                float groupUnit = g.SegmentKey == null ? Mathf.Min(result.IslandCellSize.x, result.IslandCellSize.y) : unit;
                float y = (g.SegmentKey == null ? islandTop : segmentTops[g.SegmentKey]) + .001f * groupScale;
                var view = Spawn(group, g.Rect, y, metrics.GroupSize.y * groupScale, groupScale, "Group", g.Key);
                view.name = "Group · " + g.Name;
                view.GetComponent<KafoGeneratedItem>().TitleRect = g.TitleRect;
                float top = view.GetComponent<KafoMeshResizer>().MeasureBounds().max.y;
                groupTops.Add(g.Key, top);
                FloorLabel(view.transform, g.Name, g.TitleRect, top + .008f * groupScale, groupUnit, .2f,
                    new Color(.72f, .8f, .85f), !result.BridgesAlongX);
            }

            var systems = source.Systems.ToDictionary(s => s.Key);
            foreach (var a in result.Systems)
            {
                float asScale = a.SegmentKeys.Count == 0 ? result.IslandCellScale : k;
                float asUnit = a.SegmentKeys.Count == 0 ? Mathf.Min(result.IslandCellSize.x, result.IslandCellSize.y) : unit;
                float y = a.SegmentKeys.Count == 0 ? islandTop : a.SegmentKeys.Max(key => segmentTops[key]);
                foreach (string key in a.GroupKeys) y = Mathf.Max(y, groupTops[key]);
                var view = Spawn(app, a.Rect, y, metrics.AsSize.y * asScale, asScale, a.IsBridge ? "Bridge" : "AS", a.Key);
                view.name = (a.IsBridge ? "Bridge · " : "AS · ") + a.Name;
                var item = view.GetComponent<KafoGeneratedItem>();
                item.SystemKey = a.SystemKey;
                item.PlacementKeys = new List<string>(a.PlacementKeys);
                item.SourceRecord = systems[a.SystemKey].Original?.ToString(Newtonsoft.Json.Formatting.Indented);
                float inset = .16f * asUnit, height = metrics.AsSize.y * asScale;
                var origin = result.BridgesAlongX
                    ? new Vector3(a.Rect.xMax + .003f * asScale, y + height - inset, a.Rect.yMin + inset)
                    : new Vector3(a.Rect.xMin + inset, y + height - inset, a.Rect.yMin - .003f * asScale);
                var rotation = Quaternion.Euler(0, result.BridgesAlongX ? 270 : 0, 0);
                float width = (result.BridgesAlongX ? a.Rect.height : a.Rect.width) - 2 * inset;
                Label(view.transform, a.Name, asUnit * .19f, new Color(.88f, 1, .91f), origin, rotation,
                    new Vector2(width, height - 2 * inset));
            }
        }

        GameObject Spawn(GameObject template, Rect rect, float bottom, float height, float scale, string kind,
            string key)
        {
            var go = Instantiate(template, generatedRoot.transform, false);
            go.hideFlags = HideFlags.None;
            go.SetActive(true);
            foreach (var t in go.GetComponentsInChildren<Transform>(true))
                t.gameObject.hideFlags = HideFlags.None;
            var shape = go.GetComponent<KafoMeshResizer>();
            go.transform.position = new Vector3(rect.center.x, bottom, rect.center.y);
            shape.Resize(new Vector3(rect.center.x, bottom + height * .5f, rect.center.y),
                new Vector3(rect.width, height, rect.height), scale);
            var meta = go.GetComponent<KafoGeneratedItem>() ?? go.AddComponent<KafoGeneratedItem>();
            meta.Kind = kind;
            meta.Key = key;
            meta.PlannedRect = rect;
            meta.Geometry = shape;
            return go;
        }

        TextMeshPro Label(Transform parent, string text, float size, Color color, Vector3 origin, Quaternion rotation,
            Vector2 area)
        {
            var go = new GameObject("Label");
            go.transform.SetParent(parent, false);
            var font = LabelFont != null ? LabelFont : Resources.Load<TMP_FontAsset>("KafoFonts/KFO Sans SDF");
            if (font == null)
                font = TMP_Settings.defaultFontAsset;
            var component = go.AddComponent<KafoTextLabel>();
            component.Configure(text, font, color, origin, rotation, area, size);
            return go.GetComponent<TextMeshPro>();
        }

        void FloorLabel(Transform parent, string text, Rect rect, float y, float unit, float size, Color color,
            bool transpose)
        {
            float width = transpose ? rect.height : rect.width, height = transpose ? rect.width : rect.height;
            Label(parent, (text ?? "Без имени").ToUpperInvariant(), unit * size, color,
                new Vector3(transpose ? rect.xMin : rect.xMax, y, rect.yMin),
                Quaternion.Euler(90, transpose ? 270 : 180, 0), new Vector2(width, height));
        }

        public List<string> ValidatePhysicalBounds(KafoLayoutResult result = null)
        {
            result = result ?? LastResult;
            var problems = new List<string>();
            if (generatedRoot == null || result == null)
                return problems;
            float e = Mathf.Max(.000001f, Mathf.Min(Mathf.Min(result.CellSize.x, result.CellSize.y), Mathf.Min(result.IslandCellSize.x, result.IslandCellSize.y)) * .002f);
            var items = generatedRoot.GetComponentsInChildren<KafoGeneratedItem>();
            var surfaces = items.Where(i => i.Kind == "Segment" || i.Kind == "Group")
                .ToDictionary(i => i.Key, i => i.Geometry.MeasureBounds().max.y);
            foreach (var item in items)
            {
                var actual = Footprint(item.Geometry.MeasureBounds());
                if (!KafoLayoutResult.Contains(item.PlannedRect, actual, e) ||
                    !KafoLayoutResult.Contains(actual, item.PlannedRect, e))
                    problems.Add("Bounds отличаются от расчёта: " + item.name);
                if (item.Kind == "Segment" || item.Kind == "Group")
                {
                    var title = item.GetComponentInChildren<TextMeshPro>();
                    if (title == null || !KafoLayoutResult.Contains(item.TitleRect,
                            Footprint(title.GetComponent<Renderer>().bounds), e))
                        problems.Add("Подпись вне зарезервированной полосы: " + item.name);
                }
            }

            foreach (var system in result.Systems)
            {
                float top = system.SegmentKeys.Count == 0 ? IslandZone.bounds.max.y : system.SegmentKeys.Max(key => surfaces[key]);
                foreach (string key in system.GroupKeys) top = Mathf.Max(top, surfaces[key]);
                var item = items.FirstOrDefault(i => i.Key == system.Key);
                if (item != null && Mathf.Abs(item.Geometry.MeasureBounds().min.y - top) > e)
                    problems.Add("АС не стоит на поверхности родителя: " + item.name);
            }

            return problems;
        }

        public void Clear()
        {
            if (IslandZone != null && (generatedRoot != null || originalIslandZone != null))
                RememberIsland();
            ClearGenerated();
            RestoreIsland();
        }

        void ClearGenerated()
        {
            if (generatedRoot != null)
            {
                generatedRoot.SetActive(false);
                Dispose(generatedRoot);
            }

            generatedRoot = null;
            LastResult = null;
            LastData = null;
            summary = "";
            diagnostics.Clear();
            hasIslandContent = false;
            if (IslandZone != null)
                IslandZone.enabled = false;
        }

        static void Dispose(UnityEngine.Object o)
        {
            if (Application.isPlaying)
                Destroy(o);
            else
                DestroyImmediate(o);
        }
    }
}
