using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    public static partial class KafoLayoutSolver
    {
        sealed class IslandBlock
        {
            public Bucket Bucket;
            public Pack Rest;
            public Vector2 ContentOffset;
            public Rect GroupRect;
        }

        static int IslandCells(float length,float pitch,float gap)=>Mathf.Max(1,Mathf.CeilToInt((length+gap)/pitch-.00001f));

        // MaxRects on integer cells: a large AS does not widen every other row/column.
        // A finite strip as tall as all blocks stacked guarantees a position for each block.
        static Pack PackIslandGrid(Context c,List<Item> items,int span,bool growX)
        {
            var result=new Pack();if(items.Count==0)return result;
            float sx=c.Metrics.AsSize.x+c.Gap,sy=c.Metrics.AsSize.z+c.Gap;
            Vector2Int Size(Item item)
            {
                int x=IslandCells(item.W,sx,c.Gap),y=IslandCells(item.H,sy,c.Gap);
                return growX?new Vector2Int(y,x):new Vector2Int(x,y);
            }
            var ordered=items.OrderByDescending(i=>(long)Size(i).x*Size(i).y)
                .ThenByDescending(i=>Mathf.Max(Size(i).x,Size(i).y)).ThenBy(i=>i.Key,StringComparer.Ordinal).ToList();
            span=Mathf.Max(span,ordered.Max(i=>Size(i).x));
            var free=new List<RectInt>{new RectInt(0,0,span,ordered.Sum(i=>Size(i).y))};
            int usedWidth=0,usedHeight=0;
            foreach(var item in ordered)
            {
                var size=Size(item);RectInt chosen=default;
                long bestHeight=long.MaxValue,bestWaste=long.MaxValue;
                foreach(var space in free)
                {
                    if(size.x>space.width||size.y>space.height)continue;
                    long height=Math.Max(usedHeight,space.y+size.y),waste=(long)space.width*space.height-(long)size.x*size.y;
                    if(height<bestHeight||height==bestHeight&&(space.y<chosen.y||space.y==chosen.y&&(space.x<chosen.x||space.x==chosen.x&&waste<bestWaste)))
                    {
                        chosen=new RectInt(space.x,space.y,size.x,size.y);bestHeight=height;bestWaste=waste;
                    }
                }
                // Keep an unconditional stacking fallback even if a free-space search fails.
                if(bestHeight==long.MaxValue)chosen=new RectInt(0,usedHeight,size.x,size.y);
                for(int i=free.Count-1;i>=0;i--)
                {
                    var space=free[i];if(!space.Overlaps(chosen))continue;free.RemoveAt(i);
                    if(chosen.xMin>space.xMin)free.Add(new RectInt(space.x,space.y,chosen.xMin-space.xMin,space.height));
                    if(chosen.xMax<space.xMax)free.Add(new RectInt(chosen.xMax,space.y,space.xMax-chosen.xMax,space.height));
                    if(chosen.yMin>space.yMin)free.Add(new RectInt(space.x,space.y,space.width,chosen.yMin-space.yMin));
                    if(chosen.yMax<space.yMax)free.Add(new RectInt(space.x,chosen.yMax,space.width,space.yMax-chosen.yMax));
                }
                for(int i=free.Count-1;i>=0;i--)
                for(int j=0;j<free.Count;j++)
                {
                    if(i==j)continue;var a=free[i];var b=free[j];
                    if(a.xMin>=b.xMin&&a.yMin>=b.yMin&&a.xMax<=b.xMax&&a.yMax<=b.yMax){free.RemoveAt(i);break;}
                }
                usedWidth=Mathf.Max(usedWidth,chosen.xMax);usedHeight=Mathf.Max(usedHeight,chosen.yMax);
                var position=growX?new Vector2(chosen.y*sx,chosen.x*sy):new Vector2(chosen.x*sx,chosen.y*sy);
                result.Items.Add(new Item{Key=item.Key,W=item.W,H=item.H,Value=item.Value,Rect=new Rect(position,new Vector2(item.W,item.H))});
            }
            result.Columns=growX?usedHeight:usedWidth;result.Rows=growX?usedWidth:usedHeight;
            result.W=result.Columns*sx-c.Gap;result.H=result.Rows*sy-c.Gap;return result;
        }

        static List<Item> IslandBlocks(Context c,List<Bucket> buckets,int span,bool growX,float fraction)
        {
            float sx=c.Metrics.AsSize.x+c.Gap,sy=c.Metrics.AsSize.z+c.Gap;
            int left=Mathf.CeilToInt(Mathf.Max(c.GroupPad,c.TitleClearance)/sx);
            int header=Mathf.CeilToInt((c.GroupPad+c.GroupHeader)/sy);
            int tail=Mathf.CeilToInt(c.GroupPad/(growX?sy:sx));
            var items=new List<Item>();
            foreach(var bucket in buckets)
            {
                var systems=bucket.Placements.Select(p=>{var size=c.Size(p);return new Item{Key=p.Key,W=size.x,H=size.y,Value=p};}).ToList();
                int inset=bucket.IsGroup?(growX?header:left)+tail:0;
                int minimum=systems.Max(i=>IslandCells(growX?i.H:i.W,growX?sy:sx,c.Gap));
                int available=Mathf.Max(minimum,Mathf.FloorToInt((span-inset)*fraction));
                var rest=PackIslandGrid(c,systems,available,growX);
                var block=new IslandBlock{Bucket=bucket,Rest=rest};
                float width=rest.W,height=rest.H;
                if(bucket.IsGroup)
                {
                    block.ContentOffset=new Vector2(left*sx,header*sy);
                    block.GroupRect=new Rect(left*sx-c.GroupPad,0,rest.W+2*c.GroupPad,header*sy+rest.H+c.GroupPad);
                    width=left*sx+rest.W+c.GroupPad;height=block.GroupRect.height;
                }
                items.Add(new Item{Key=bucket.Key,W=width,H=height,Value=block});
            }
            return items;
        }

        static void LayoutIsland(Context c,KafoLayoutResult result,Rect requested)
        {
            var buckets=Buckets(c.Source.Placements.Where(p=>p.SegmentKey==null));
            var main=result.MainRect;
            bool transpose=!result.BridgesAlongX;
            // The authored center is fixed. Only world Z may grow, up to the main zone's dimensions.
            float width=Mathf.Min(requested.width,main.width),maxHeight=main.height;
            if(requested.xMin<main.xMax&&requested.xMax>main.xMin)
            {
                float clearance=Mathf.Abs(requested.center.y-main.center.y)-main.height*.5f;
                if(clearance>0)maxHeight=Mathf.Min(maxHeight,Mathf.Max(.00001f,2*clearance*.99f));
            }
            float initialHeight=Mathf.Min(requested.height,maxHeight);
            result.IslandRect=new Rect(requested.center-new Vector2(width,initialHeight)*.5f,new Vector2(width,initialHeight));
            result.IslandCellScale=result.CellScale;
            result.IslandCellSize=result.CellSize;
            if(buckets.Count==0)return;
            bool growX=transpose;
            float sx=c.Metrics.AsSize.x+c.Gap,sy=c.Metrics.AsSize.z+c.Gap;
            var minimum=IslandBlocks(c,buckets,1,growX,1);
            int minSpan=minimum.Max(i=>IslandCells(growX?i.H:i.W,growX?sy:sx,c.Gap));
            double neededArea=minimum.Sum(i=>(double)i.W*i.H);
            float pitch=growX?sy:sx;
            int compactSpan=Mathf.Max(minSpan,Mathf.CeilToInt((float)Math.Sqrt(neededArea*width/maxHeight)/pitch));
            int nativeSpan=Mathf.Max(minSpan,Mathf.FloorToInt((width/result.CellScale-2*c.Pad+c.Gap)/pitch));
            var spans=Enumerable.Range(minSpan,8).Concat(new[]{nativeSpan,compactSpan,
                Mathf.Max(minSpan,compactSpan/2),Mathf.Max(minSpan,Mathf.CeilToInt(compactSpan*.75f)),
                Mathf.Max(minSpan,Mathf.CeilToInt(compactSpan*1.25f)),compactSpan*2}).Distinct();
            Pack best=null;float scale=0,bestHeight=float.MaxValue;double bestUsed=double.MaxValue;
            foreach(int candidateSpan in spans)
            {
                foreach(float fraction in new[]{1f,.75f,.5f})
                {
                    var pack=PackIslandGrid(c,IslandBlocks(c,buckets,candidateSpan,growX,fraction),candidateSpan,growX);
                    float unscaledW=(transpose?pack.H:pack.W)+2*c.Pad,unscaledH=(transpose?pack.W:pack.H)+2*c.Pad;
                    float fit=Mathf.Min(result.CellScale,width/unscaledW,maxHeight/unscaledH);
                    float height=Mathf.Max(initialHeight,unscaledH*fit);double used=(double)pack.W*pack.H;
                    if(fit>scale*1.00001f||fit>=scale*.99999f&&(height<bestHeight-.00001f||Mathf.Abs(height-bestHeight)<.00001f&&used<bestUsed))
                    {best=pack;scale=fit;bestHeight=height;bestUsed=used;}
                }
            }
            Rect island=new Rect(requested.center-new Vector2(width,bestHeight)*.5f,new Vector2(width,bestHeight));
            result.IslandRect=island;
            result.IslandCellScale=scale;
            result.IslandCellSize=(transpose?new Vector2(c.Metrics.AsSize.z,c.Metrics.AsSize.x):new Vector2(c.Metrics.AsSize.x,c.Metrics.AsSize.z))*scale;
            float availableW=(transpose?bestHeight:width)/scale-2*c.Pad,availableH=(transpose?width:bestHeight)/scale-2*c.Pad;
            var offset=Vector2.one*c.Pad+new Vector2(Mathf.Max(0,(availableW-best.W)*.5f),Mathf.Max(0,(availableH-best.H)*.5f));
            Rect Map(Rect rect)=>MapFromLogical(island,new Rect(rect.position*scale,rect.size*scale),transpose);
            foreach(var item in best.Items)
            {
                var block=(IslandBlock)item.Value;var position=item.Rect.position+offset;
                var bucket=block.Bucket;
                if(bucket.IsGroup)
                {
                    var rect=new Rect(position+block.GroupRect.position,block.GroupRect.size);
                    result.Groups.Add(new GroupLayout{Key=bucket.Key,Name=GroupName(bucket.Group),Rect=Map(rect),TitleRect=Map(GroupTitle(c,rect))});
                }
                foreach(var local in block.Rest.Items)
                {
                    var p=(NormalizedPlacement)local.Value;var s=c.Systems[p.SystemKey];
                    var a=new AsLayout{Key="local:"+p.Key,SystemKey=s.Key,Name=s.Name,Rect=Map(new Rect(position+block.ContentOffset+local.Rect.position,local.Rect.size))};
                    a.PlacementKeys.Add(p.Key);if(bucket.IsGroup)a.GroupKeys.Add(bucket.Key);result.Systems.Add(a);
                }
            }
            if(bestHeight>requested.height+.001f)result.Diagnostics.Add("Островок увеличен только по Z, без смещения центра, в пределах размеров основной зоны.");
            if(scale<result.CellScale*.9999f)result.Diagnostics.Add("Содержимое островка уменьшено до "+(scale/result.CellScale).ToString("P1")+" от масштаба основной зоны; все размещения сохранены.");
        }
    }
}
