using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json.Linq;
#if UNITY_EDITOR
using System.Runtime.CompilerServices;
#endif

namespace Sbrt.Av.Gameplay
{
    [Serializable] public class AsDataModel { public long Id; public string Name; public int FpCount; }
    [Serializable] public class AsPlacementDataModel { public long AsId; public string Segment; public string Group; }
    [Serializable] public class KafoDataModel
    {
        public long Id; public string Name;
        public List<string> Segments = new List<string>();
        public List<AsPlacementDataModel> Placements = new List<AsPlacementDataModel>();
        public List<AsDataModel> Systems = new List<AsDataModel>();
    }
    public sealed class NormalizedSystem
    {
        public string Key, Name; public long Id; public int FpCount; public JToken Original;
        public bool UseMinimumFpSize;
    }
    public sealed class NormalizedSegment { public string Key, Name, RawName; }
    public sealed class NormalizedPlacement
    {
        public string Key, SystemKey, SegmentKey, Group; public JToken Original;
    }
    public sealed class NormalizedKafo
    {
        public string Name;
        public readonly List<NormalizedSystem> Systems = new List<NormalizedSystem>();
        public readonly List<NormalizedSegment> Segments = new List<NormalizedSegment>();
        public readonly List<NormalizedPlacement> Placements = new List<NormalizedPlacement>();
        public readonly List<string> Diagnostics = new List<string>();
        public int SourceSystemCount, SourcePlacementCount, SourceSegmentCount;
    }

    /// <summary>Prepares a layout without modifying the model owned by the caller.</summary>
    public static class KafoDataLoader
    {
        static string Display(string value, string fallback) => string.IsNullOrWhiteSpace(value) ? fallback : value;

        static JToken Original(object record)
        {
#if UNITY_EDITOR
            if (record != null && testRecords.TryGetValue(record, out var raw)) return raw.DeepClone();
#endif
            return record == null ? JValue.CreateNull() : JToken.FromObject(record);
        }

        static bool HasId(object record, string field)
        {
#if UNITY_EDITOR
            if (record != null && testRecords.TryGetValue(record, out var raw)) return Long(Field(raw, field), out _);
#endif
            return record != null;
        }

        public static NormalizedKafo Normalize(KafoDataModel data)
        {
            data = data ?? new KafoDataModel();
            var result = new NormalizedKafo { Name = Display(data.Name, "KFO") };
#if UNITY_EDITOR
            if (testDiagnostics.TryGetValue(data, out var warnings)) result.Diagnostics.AddRange(warnings);
#endif
            var firstById = new Dictionary<long, NormalizedSystem>();
            var firstSegment = new Dictionary<string, NormalizedSegment>(StringComparer.Ordinal);
            foreach (var row in data.Systems ?? Enumerable.Empty<AsDataModel>())
            {
                int index = result.SourceSystemCount++;
                bool hasId = HasId(row, "Id");
                long id = row?.Id ?? 0;
                bool validFp = row != null && row.FpCount > 0;
                var system = new NormalizedSystem { Key = "system:" + index, Id = id,
                    Name = Display(row?.Name, hasId ? "АС " + id : "АС без имени " + (index + 1)),
                    FpCount = validFp ? row.FpCount : 1, UseMinimumFpSize = !validFp, Original = Original(row) };
                result.Systems.Add(system);
                if (!validFp) result.Diagnostics.Add(system.Name + ": fpCount заменён минимальным размером; исходное значение сохранено.");
                if (hasId && !firstById.ContainsKey(id)) firstById.Add(id, system);
                else if (hasId) result.Diagnostics.Add("Повтор ID " + id + ": дополнительная запись сохранена как отдельная АС.");
                else result.Diagnostics.Add(system.Name + ": назначен внутренний идентификатор.");
            }
            foreach (var raw in data.Segments ?? Enumerable.Empty<string>())
            {
                int index = result.SourceSegmentCount++;
                var segment = new NormalizedSegment { Key = "segment:" + index, RawName = raw,
                    Name = Display(raw, "Сегмент без имени " + (index + 1)) };
                result.Segments.Add(segment);
                if (raw != null && !firstSegment.ContainsKey(raw)) firstSegment.Add(raw, segment);
                else result.Diagnostics.Add(segment.Name + ": повторная или безымянная запись сегмента сохранена.");
            }
            foreach (var row in data.Placements ?? Enumerable.Empty<AsPlacementDataModel>())
            {
                int index = result.SourcePlacementCount++;
                bool hasId = HasId(row, "AsId");
                long id = row?.AsId ?? 0;
                if (!hasId || !firstById.TryGetValue(id, out var system))
                {
                    system = new NormalizedSystem { Key = "placeholder:" + index, Id = id, FpCount = 1, UseMinimumFpSize = true,
                        Name = hasId ? "АС " + id + " (нет описания)" : "АС без ID " + (index + 1), Original = Original(row) };
                    result.Systems.Add(system);
                    if (hasId) firstById[id] = system;
                    result.Diagnostics.Add(system.Name + ": создано недостающее описание.");
                }
                string segmentName = row?.Segment;
                string segmentKey = null;
                if (segmentName != null)
                {
                    if (!firstSegment.TryGetValue(segmentName, out var segment))
                    {
                        segment = new NormalizedSegment { Key = "inferred-segment:" + result.Segments.Count,
                            RawName = segmentName, Name = Display(segmentName, "Сегмент без имени " + (result.Segments.Count + 1)) };
                        result.Segments.Add(segment); firstSegment.Add(segmentName, segment);
                        result.Diagnostics.Add(segment.Name + ": сегмент создан из ссылки размещения.");
                    }
                    segmentKey = segment.Key;
                }
                result.Placements.Add(new NormalizedPlacement { Key = "placement:" + index, SystemKey = system.Key,
                    SegmentKey = segmentKey, Group = row?.Group, Original = Original(row) });
            }
            var placed = new HashSet<string>(result.Placements.Select(p => p.SystemKey));
            foreach (var system in result.Systems)
                if (!placed.Contains(system.Key)) result.Placements.Add(new NormalizedPlacement {
                    Key = "implicit:" + system.Key, SystemKey = system.Key, SegmentKey = null });
            return result;
        }

#if UNITY_EDITOR
        // Only the Inspector/test path reads JSON. These weak references retain the raw
        // test records without adding parser state to server models or keeping them alive.
        static readonly ConditionalWeakTable<object, JToken> testRecords = new ConditionalWeakTable<object, JToken>();
        static readonly ConditionalWeakTable<KafoDataModel, List<string>> testDiagnostics = new ConditionalWeakTable<KafoDataModel, List<string>>();
        static JToken Field(JToken token, string name) => (token as JObject)?.GetValue(name, StringComparison.OrdinalIgnoreCase);
        static string Text(JToken token) => token == null || token.Type == JTokenType.Null ? null :
            token.Type == JTokenType.String ? token.Value<string>() : token.ToString(Newtonsoft.Json.Formatting.None);
        static IEnumerable<JToken> Records(JToken token)
        {
            if (token == null || token.Type == JTokenType.Null) yield break;
            if (token is JArray array) { foreach (var row in array) yield return row; }
            else yield return token;
        }
        static bool Long(JToken token, out long value) => long.TryParse(Text(token), NumberStyles.Integer, CultureInfo.InvariantCulture, out value);

        public static NormalizedKafo Load(string json) => Normalize(ReadTestJson(json));

        public static KafoDataModel ReadTestJson(string json)
        {
            if (string.IsNullOrWhiteSpace(json)) return new KafoDataModel();
            try { return ReadTestJson(JToken.Parse(json)); }
            catch (Newtonsoft.Json.JsonException e)
            {
                var recovered = new KafoDataModel();
                var system = new AsDataModel { Name = "Непрочитанные данные" };
                recovered.Systems.Add(system);
                testRecords.Add(system, new JValue(json));
                testDiagnostics.Add(recovered, new List<string> { "JSON не разобран; исходный текст сохранён в объекте-заглушке: " + e.Message });
                return recovered;
            }
        }
        static KafoDataModel ReadTestJson(JToken root)
        {
            var kfo = Field(root, "Kafo") ?? root;
            Long(Field(kfo, "Id"), out long kafoId);
            var result = new KafoDataModel { Id = kafoId, Name = Text(Field(kfo, "Name")) };
            // Accept both the current flat model and the old test-document envelope.
            foreach (var row in Records(Field(kfo, "Systems") ?? Field(root, "Systems")))
            {
                Long(Field(row, "Id"), out long id);
                bool validFp = Long(Field(row, "FpCount"), out long fp) && fp >= int.MinValue && fp <= int.MaxValue;
                var system = new AsDataModel { Id = id, Name = Text(Field(row, "Name")), FpCount = validFp ? (int)fp : 0 };
                result.Systems.Add(system);
                testRecords.Add(system, row.DeepClone());
            }
            foreach (var row in Records(Field(kfo, "Segments")))
                result.Segments.Add(Text(row));
            foreach (var row in Records(Field(kfo, "Placements")))
            {
                Long(Field(row, "AsId"), out long id);
                var placement = new AsPlacementDataModel { AsId = id, Segment = Text(Field(row, "Segment")), Group = Text(Field(row, "Group")) };
                result.Placements.Add(placement);
                testRecords.Add(placement, row.DeepClone());
            }
            return result;
        }
#endif
    }
}
