using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace Sbrt.Av.Gameplay
{
    /// <summary>Corner-preserving deformation in a captured world-metric frame, independent of parent scaling.</summary>
    [ExecuteAlways, DisallowMultipleComponent]
    [UnityEngine.Scripting.APIUpdating.MovedFrom(true,"Kafo","Kafo.Runtime",null)]
    public sealed class KafoMeshResizer : MonoBehaviour
    {
        [Serializable] public class SourcePart
        {
            public MeshFilter Filter;
            public Mesh Mesh;
            public Matrix4x4 ToReference;
        }
        [Tooltip("Physical geometry used for dimensions and support surfaces. Defaults to the root Renderer, or child geometry for a composite root. Decorative child meshes are resized but do not affect these bounds.")]
        public Renderer[] BoundsRenderers;
        [Range(.01f,.49f)] public float BorderX=.18f;
        [Range(.01f,.49f)] public float BorderZ=.18f;
        [SerializeField] List<SourcePart> sourceParts=new List<SourcePart>();
        [SerializeField] Vector3 referenceSize;
        [SerializeField] bool hasTarget;
        [SerializeField] Vector3 targetCenter,targetSize;
        [SerializeField] float uniformScale=1;
        [SerializeField, HideInInspector] bool followTransformChanges;
        [SerializeField, HideInInspector] bool hasResizeFrame;
        [SerializeField, HideInInspector] Matrix4x4 resizeFrame;
        readonly List<Mesh> ownedMeshes=new List<Mesh>();
        // In Unity 6000.6 this engine switch is internal; SRP's own exclusion component
        // uses it as well. Keep the compatibility lookup isolated and preserve it for IL2CPP.
        static readonly PropertyInfo GpuDrivenProperty=typeof(Renderer).GetProperty("allowGPUDrivenRendering",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic);
        public static void ConfigureDynamicRenderer(MeshRenderer renderer)
        {
            if(renderer!=null && GpuDrivenProperty!=null && GpuDrivenProperty.CanWrite)GpuDrivenProperty.SetValue(renderer,false);
        }
        public Vector3 ReferenceSize=>referenceSize;
        public Vector3 TargetSize=>targetSize;
        public float UniformScale=>uniformScale;
        public IReadOnlyList<SourcePart> SourceParts=>sourceParts;
        public bool FollowTransformChanges { get=>followTransformChanges; set=>followTransformChanges=value; }

        public static Bounds TransformBounds(Bounds bounds,Matrix4x4 matrix)
        {
            var result=new Bounds(matrix.MultiplyPoint3x4(bounds.center),Vector3.zero);
            foreach(float x in new[]{bounds.min.x,bounds.max.x})
            foreach(float y in new[]{bounds.min.y,bounds.max.y})
            foreach(float z in new[]{bounds.min.z,bounds.max.z})result.Encapsulate(matrix.MultiplyPoint3x4(new Vector3(x,y,z)));
            return result;
        }
        public void RefreshTransform()
        {
            if(followTransformChanges&&hasTarget&&hasResizeFrame&&resizeFrame!=transform.localToWorldMatrix)Rebuild();
        }

        public Bounds MeasureBounds()
        {
            RefreshTransform();
            var rs=BoundsRenderers;
            if(rs==null||rs.Length==0)rs=DefaultBoundsRenderers();
            bool found=false;var b=new Bounds(transform.position,Vector3.zero);
            foreach(var r in rs)if(r!=null){if(!found){b=r.bounds;found=true;}else b.Encapsulate(r.bounds);}
            return b;
        }
        public bool CaptureSource(bool restoreOriginal=true)
        {
            if(restoreOriginal)RestoreSource();
            if(BoundsRenderers==null||BoundsRenderers.Length==0)BoundsRenderers=DefaultBoundsRenderers();
            var b=MeasureBounds();
            if(b.size.x<=.00001f||b.size.z<=.00001f||float.IsNaN(b.size.x))return false;
            sourceParts.Clear();
            // Capture decoration as well, in the body's reference frame: glow and
            // prefab name/data panels must follow the body without defining its size.
            foreach(var r in GetComponentsInChildren<MeshRenderer>(true))
            {
                if(r==null||r.GetComponent<TMPro.TMP_Text>()!=null)continue;var filter=r.GetComponent<MeshFilter>();
                if(filter==null||filter.sharedMesh==null||!filter.sharedMesh.isReadable)continue;
                sourceParts.Add(new SourcePart{Filter=filter,Mesh=filter.sharedMesh,ToReference=Matrix4x4.Translate(-b.center)*filter.transform.localToWorldMatrix});
            }
            referenceSize=b.size;hasTarget=false;
            foreach(var renderer in BoundsRenderers)
                if(renderer!=null&&!sourceParts.Exists(p=>p.Filter.GetComponent<Renderer>()==renderer))return false;
            return sourceParts.Count>0;
        }
        Renderer[] DefaultBoundsRenderers()
        {
            var body=GetComponent<MeshRenderer>();
            if(body!=null)return new Renderer[]{body};
            var geometry=new List<Renderer>();
            foreach(var renderer in GetComponentsInChildren<MeshRenderer>(true))
                if(renderer.GetComponent<TMPro.TMP_Text>()==null)geometry.Add(renderer);
            return geometry.ToArray();
        }
        public bool Resize(Vector3 worldCenter,Vector3 worldSize,float scale)
        {
            if(sourceParts.Count==0 && !CaptureSource())return false;
            targetCenter=worldCenter;targetSize=worldSize;uniformScale=Mathf.Max(.000001f,scale);hasTarget=true;
            resizeFrame=transform.localToWorldMatrix;hasResizeFrame=true;
            Rebuild();return true;
        }
        public void RestoreSource()
        {
            DisableGpuDrivenRendering();
            foreach(var part in sourceParts)if(part.Filter!=null&&part.Mesh!=null)
            {
                part.Filter.sharedMesh=part.Mesh;
                var renderer=part.Filter.GetComponent<Renderer>();if(renderer!=null)renderer.ResetBounds();
            }
            if(BoundsRenderers!=null)foreach(var renderer in BoundsRenderers)if(renderer!=null)renderer.ResetBounds();
            DisposeMeshes();
        }
        void OnEnable(){DisableGpuDrivenRendering();if(hasTarget && sourceParts.Count>0)Rebuild();}
        void OnDestroy(){DisableGpuDrivenRendering();DisposeMeshes();}
        void DisableGpuDrivenRendering()
        {
            // These meshes are rebuilt and destroyed independently per instance. Keep them off the
            // resident drawer's cached mesh IDs, including when restoring a saved editor scene.
            foreach(var renderer in GetComponentsInChildren<MeshRenderer>(true))ConfigureDynamicRenderer(renderer);
        }
        void DisposeMeshes()
        {
            foreach(var mesh in ownedMeshes)if(mesh!=null){if(Application.isPlaying)Destroy(mesh);else DestroyImmediate(mesh);}
            ownedMeshes.Clear();
        }
        void Rebuild()
        {
            if(followTransformChanges&&hasResizeFrame&&resizeFrame!=transform.localToWorldMatrix)
            {
                var delta=transform.localToWorldMatrix*resizeFrame.inverse;
                var moved=TransformBounds(new Bounds(targetCenter,targetSize),delta);
                targetCenter=moved.center;targetSize=moved.size;
            }
            resizeFrame=transform.localToWorldMatrix;hasResizeFrame=true;
            DisableGpuDrivenRendering();
            DisposeMeshes();
            float sourceX=referenceSize.x*uniformScale,sourceZ=referenceSize.z*uniformScale;
            // If a user requests less than the cap width, shrink caps uniformly rather than folding vertices.
            float bx=Mathf.Min(sourceX*BorderX,targetSize.x*.49f),bz=Mathf.Min(sourceZ*BorderZ,targetSize.z*.49f);
            foreach(var part in sourceParts)
            {
                if(part.Filter==null||part.Mesh==null)continue;
                var mesh=Instantiate(part.Mesh);mesh.name=part.Mesh.name+" (KFO instance)";mesh.hideFlags=HideFlags.HideAndDontSave;
                var vertices=part.Mesh.vertices;
                var worldBounds=new Bounds();bool first=true;
                for(int i=0;i<vertices.Length;i++)
                {
                    Vector3 p=part.ToReference.MultiplyPoint3x4(vertices[i])*uniformScale;
                    p.x=Slice(p.x,sourceX,targetSize.x,bx);
                    p.z=Slice(p.z,sourceZ,targetSize.z,bz);
                    p.y=referenceSize.y>.000001f?p.y*targetSize.y/(referenceSize.y*uniformScale):p.y;
                    var world=targetCenter+p;
                    if(first){worldBounds=new Bounds(world,Vector3.zero);first=false;}else worldBounds.Encapsulate(world);
                    vertices[i]=part.Filter.transform.InverseTransformPoint(world);
                }
                mesh.vertices=vertices;mesh.RecalculateNormals();mesh.RecalculateBounds();
                part.Filter.sharedMesh=mesh;ownedMeshes.Add(mesh);
                // A transformed local AABB overestimates a world-aligned deformed mesh under rotated/scaled parents.
                // Use the actual world-space vertex bounds for both culling and subsequent layout measurements.
                var renderer=part.Filter.GetComponent<Renderer>();if(renderer!=null)renderer.bounds=worldBounds;
            }
        }
        static float Slice(float x,float source,float target,float border)
        {
            float half=source*.5f,inner=half-border;
            if(x < -inner)return -target*.5f+(x+half);
            if(x > inner)return target*.5f-(half-x);
            return inner>.000001f?x*(target*.5f-border)/inner:0;
        }
    }
}
