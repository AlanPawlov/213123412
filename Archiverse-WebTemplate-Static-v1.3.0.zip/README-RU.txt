ARCHIVERSE Web Template Static v1.3.0

Установка в другой Unity-проект:
1. Распакуйте Assets/WebGLTemplates/ArchiverseStatic и файл ArchiverseStatic.meta в Assets/WebGLTemplates проекта.
2. Выберите Web-платформу в Build Profiles / Build Settings.
3. В Player Settings > Resolution and Presentation > Web Template выберите ArchiverseStatic.
4. Соберите проект обычным способом. Открывайте сборку через HTTP-сервер.

Содержимое плеера подставляет Unity через стандартные переменные index.html.
Пропорции окна 8:5. Адаптивная разметка, кнопка fullscreen и оформление сохранены.
Линии неподвижны, цвета линий и глоу плавно меняются.
Fullscreen и скрытие вкладки приостанавливают декоративные обновления.
Предпочтение системы prefers-reduced-motion останавливает декоративную анимацию.
Диагностическая панель в этот переносимый шаблон не включена.

PERFORMANCE-RU.txt содержит метод и результаты сравнения на текущей машине.
Принятый предыдущий шаблон Archiverse v1.2.0 сохранён отдельно.
