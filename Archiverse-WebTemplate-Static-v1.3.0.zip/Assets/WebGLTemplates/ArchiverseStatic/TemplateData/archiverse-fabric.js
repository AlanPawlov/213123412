/* The accepted SVG formulas, shared unchanged by the two variants. */
(function (scope) {
  "use strict";
  scope.createArchiverseFabric = function () {
  const flowPalette = [[49, 228, 161], [11, 152, 187], [54, 123, 255]];
  const flowColourStepSeconds = 2.8, flowColourCycles = 3.5;
  const flowColourStops = { length: 65 };
  const flowColours = new Float64Array(65 * 3);
  const colours = new Array(65);
  const fabricSamples = 81, fabricStrandCount = 36, fabricPeriod = 28;
  const fabricAmplitude = 65 * .7 * .8;
  const fabricPointScratch = new Float64Array(2);
  let fabricLeftMargin = .25, fabricRightMargin = .25;
  let fabricColumns = [], fabricSegments = [], fabricRanges = [];
  let cachedGeometryTime = NaN;
  const strands = Array.from({ length: fabricStrandCount }, (_, i) => {
    const distance = i / (fabricStrandCount - 1);
    const depth = Math.pow(distance, .94) * 2 - 1;
    return { depth, opacity: .76 * Math.pow(1 - distance, 2.8),
      breathing: .08 * (1 - depth * depth),
      sinDepth: Math.sin(depth * 2.2), cosDepth: Math.cos(depth * 2.2) };
  });
  function configure(layout) {
    const { bounds, field, pageWidth } = layout;
    fabricLeftMargin = Math.max(.001, bounds.left / pageWidth);
    fabricRightMargin = Math.max(.001, 1 - bounds.right / pageWidth);
    const positions = Array.from({ length: fabricSamples }, (_, i) => i / (fabricSamples - 1));
    // Extra samples keep the visible fan smooth even beside a nearly full-width player.
    for (let i = 0; i <= 16; i++) {
      positions.push((100 + 1920 * fabricLeftMargin * i / 16) / 2120);
      positions.push((100 + 1920 * (1 - fabricRightMargin * i / 16)) / 2120);
    }
    fabricColumns = [...new Set(positions)].sort((a, b) => a - b).map(createFabricColumn);
    fabricSegments = fabricColumns.slice(1).map((column, i) => {
      const current = fabricColumns[i];
      const handle = (column.x - current.x) / 3;
      return { handle, firstX: ` C ${(current.x + handle).toFixed(3)} `, secondX: ` ${(column.x - handle).toFixed(3)} `, endX: ` ${column.x.toFixed(3)} ` };
    });
    fabricRanges = [{ start: 0, end: fabricColumns.length - 1 }];
    const extent = fabricAmplitude + 47 + 20;
    const waveTop = field.top + (260 - extent) * field.height / 520;
    const waveBottom = field.top + (260 + extent) * field.height / 520;
    // Cull only when the opaque frame covers every possible strand and its blur.
    // Keep complete curve segments past both edges so the visible Beziers are identical.
    if (bounds.top <= waveTop && bounds.bottom >= waveBottom) {
      const leftCut = (bounds.left - field.left) / field.width * 1920 + 24;
      const rightCut = (bounds.right - field.left) / field.width * 1920 - 24;
      const leftEnd = fabricColumns.findIndex(column => column.x >= leftCut);
      let rightStart = fabricColumns.length - 1;
      while (rightStart > 0 && fabricColumns[rightStart].x > rightCut) rightStart--;
      if (leftEnd >= 0 && leftEnd + 1 < rightStart) {
        fabricRanges = [{ start: 0, end: leftEnd }, { start: rightStart, end: fabricColumns.length - 1 }];
      }
    }
    cachedGeometryTime = NaN;
  }

  function createFabricColumn(position) {
    const angle = position * Math.PI * 2;
    const angleSlope = Math.PI * 2 / 2120;
    const x = -100 + position * 2120;
    const screenPosition = Math.max(0, Math.min(1, x / 1920));
    const onLeft = screenPosition < .5;
    const visibleWidth = 1920 * (onLeft ? fabricLeftMargin : fabricRightMargin);
    const edgeDistance = (onLeft ? screenPosition : 1 - screenPosition) * 1920 / visibleWidth;
    const expansion = Math.min(1, edgeDistance);
    // Use the full visible margin for a gentler expansion towards the player.
    const taper = .2 + .8 * expansion ** 3 * (expansion * (expansion * 6 - 15) + 10);
    const expansionSlope = edgeDistance > 0 && edgeDistance < 1 ? (onLeft ? 1 : -1) / visibleWidth : 0;
    const taperSlope = .8 * 30 * expansion ** 2 * (expansion - 1) ** 2 * expansionSlope;
    return {
      x, taper, taperSlope, angleSlope,
      sin1: Math.sin(angle * 2.2), cos1: Math.cos(angle * 2.2),
      sin2: Math.sin(angle * 3.8), cos2: Math.cos(angle * 3.8),
      sin3: Math.sin(angle * 5.4), cos3: Math.cos(angle * 5.4),
      sinFlow: Math.sin(angle * .8), cosFlow: Math.cos(angle * .8),
      flowSlope: angleSlope * .8, y: 0, ySlope: 0, width: 0, widthSlope: 0, flowSin: 0, flowCos: 0
    };
  }

  function updateFabricColumns(phase) {
    const sin1 = Math.sin(-phase * .75), cos1 = Math.cos(-phase * .75);
    const sin2 = Math.sin(phase * .48 + .6), cos2 = Math.cos(phase * .48 + .6);
    const sin3 = Math.sin(-phase * .35), cos3 = Math.cos(-phase * .35);
    const sinFlow = Math.sin(-phase * .36), cosFlow = Math.cos(-phase * .36);
    const spread = 42 + 5 * Math.cos(phase * .45);
    for (const column of fabricColumns) {
      const wave = .72 * (column.sin1 * cos1 + column.cos1 * sin1)
        + .22 * (column.sin2 * cos2 + column.cos2 * sin2)
        + .06 * (column.sin3 * cos3 + column.cos3 * sin3);
      const waveSlope = column.angleSlope * (
        .72 * 2.2 * (column.cos1 * cos1 - column.sin1 * sin1)
        + .22 * 3.8 * (column.cos2 * cos2 - column.sin2 * sin2)
        + .06 * 5.4 * (column.cos3 * cos3 - column.sin3 * sin3)
      );
      column.y = 260 + fabricAmplitude * column.taper * wave;
      column.ySlope = fabricAmplitude * (column.taperSlope * wave + column.taper * waveSlope);
      column.width = spread * column.taper;
      column.widthSlope = spread * column.taperSlope;
      column.flowSin = column.sinFlow * cosFlow + column.cosFlow * sinFlow;
      column.flowCos = column.cosFlow * cosFlow - column.sinFlow * sinFlow;
    }
  }

  function fabricPoint(column, strand) {
    const flowingDepth = strand.depth + strand.breathing * (column.flowSin * strand.cosDepth + column.flowCos * strand.sinDepth);
    const depthSlope = strand.breathing * (column.flowCos * strand.cosDepth - column.flowSin * strand.sinDepth) * column.flowSlope;
    fabricPointScratch[0] = column.y + column.width * flowingDepth;
    fabricPointScratch[1] = column.ySlope + column.widthSlope * flowingDepth + column.width * depthSlope;
  }

  function smoothFabricPath(strand, fullGeometry = false) {
    const ranges = fullGeometry ? [{ start: 0, end: fabricColumns.length - 1 }] : fabricRanges;
    let path = "";
    for (const range of ranges) {
      fabricPoint(fabricColumns[range.start], strand);
      let currentY = fabricPointScratch[0], currentSlope = fabricPointScratch[1];
      path += `M ${fabricColumns[range.start].x.toFixed(3)} ${currentY.toFixed(3)}`;
      for (let i = range.start; i < range.end; i++) {
        const segment = fabricSegments[i];
        fabricPoint(fabricColumns[i + 1], strand);
        const nextY = fabricPointScratch[0], nextSlope = fabricPointScratch[1];
        path += segment.firstX + (currentY + currentSlope * segment.handle).toFixed(3)
          + segment.secondX + (nextY - nextSlope * segment.handle).toFixed(3)
          + segment.endX + nextY.toFixed(3);
        currentY = nextY;
        currentSlope = nextSlope;
      }
    }
    return path;
  }

  function computeColours(time) {
    for (let i = 0; i < flowColourStops.length; i++) {
      const position = (time / flowColourStepSeconds + i / (flowColourStops.length - 1) * flowColourCycles * flowPalette.length) % flowPalette.length;
      const index = Math.floor(position);
      const blend = .5 - .5 * Math.cos((position - index) * Math.PI);
      const from = flowPalette[index], to = flowPalette[(index + 1) % flowPalette.length];
      const base = i * 3;
      for (let channel = 0; channel < 3; channel++) flowColours[base + channel] = from[channel] + (to[channel] - from[channel]) * blend;
      colours[i] = `rgb(${flowColours[base].toFixed(2)},${flowColours[base + 1].toFixed(2)},${flowColours[base + 2].toFixed(2)})`;
    }
    function colourAt(screenPosition) {
      const position = Math.max(0, Math.min(1, screenPosition)) * (flowColourStops.length - 1);
      const left = Math.min(flowColourStops.length - 2, Math.floor(position));
      const right = left + 1;
      const blend = position - left;
      let colour = "";
      for (let channel = 0; channel < 3; channel++) {
        const value = flowColours[left * 3 + channel];
        colour += (channel ? " " : "") + (value + (flowColours[right * 3 + channel] - value) * blend).toFixed(2);
      }
      return colour;
    }
    const left = colourAt(fabricLeftMargin), centre = colourAt(.5), right = colourAt(1 - fabricRightMargin);
    return { colours, glow: [left, centre, right] };
  }

  function render(time, geometryTime) {
    let geometry = null;
    if (geometryTime !== cachedGeometryTime) {
      updateFabricColumns(geometryTime * Math.PI * 2 / fabricPeriod);
      const paths = strands.map(strand => strand.opacity === 0 ? "" : smoothFabricPath(strand));
      geometry = { paths, highlights: [smoothFabricPath(strands[0], true), paths[0], paths[3], paths[7]] };
      cachedGeometryTime = geometryTime;
    }
    return { geometry, ...computeColours(time) };
  }
  return { configure, render };
  };
})(typeof self === "object" ? self : globalThis);
