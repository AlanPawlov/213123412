(() => {
  "use strict";
  const canvas = document.getElementById("unity-canvas");
  const viewport = document.getElementById("unity-fullscreen-container");
  const playerFrame = document.querySelector(".player-frame");
  const fullscreenButton = document.getElementById("fullscreen-button");
  const fullscreenLabel = document.getElementById("fullscreen-label");
  const loadingScreen = document.getElementById("loading-screen");
  const errorScreen = document.getElementById("error-screen");
  const progressBar = document.getElementById("loading-progress");
  const progressFill = document.getElementById("loading-progress-fill");
  const percentage = document.getElementById("loading-percentage");
  const build = window.archiverseBuild;
  let unityInstance;

  const root = document.documentElement;
  const mesh = document.getElementById("flow-mesh");
  const gradient = document.getElementById("flow-colour");
  const glowStyles = [document.querySelector(".ambient").style, playerFrame.style];
  const motionPreference = matchMedia("(prefers-reduced-motion: reduce)");
  const profile = window.archiverseProfile || null;
  // Freeze a crest beside the player's left edge, as in the supplied reference.
  const staticGeometryTime = 27.15;
  let mode = root.dataset.archiverseMotion;
  let engine = null;
  let worker = null;
  let pending = null;
  let prepared = null;
  let layout = null;
  let layoutDirty = true;
  let version = 0;
  let requestId = 0;
  let animationFrame = 0;
  let lastTimestamp = 0;
  let lastUpdate = 0;
  let time = 0;
  let suspended = true;
  let needsFrame = true;

  gradient.setAttribute("gradientUnits", "userSpaceOnUse");
  gradient.setAttribute("x1", "0");
  gradient.setAttribute("x2", "1920");
  gradient.replaceChildren();
  const stops = Array.from({ length: 65 }, (_, i) => {
    const stop = document.createElementNS("http://www.w3.org/2000/svg", "stop");
    stop.setAttribute("offset", String(i / 64));
    gradient.appendChild(stop);
    return stop;
  });
  const paths = Array.from({ length: 36 }, (_, i) => {
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("class", "flow-ribbon");
    path.style.opacity = String(.76 * Math.pow(1 - i / 35, 2.8));
    mesh.appendChild(path);
    return path;
  });
  const highlights = [
    document.querySelector(".flow-glow"),
    document.querySelector(".flow-spine:not(.flow-spine--secondary)"),
    document.querySelector(".flow-pulse"),
    document.querySelector(".flow-spine--secondary")
  ];

  function readLayout() {
    const bounds = playerFrame.getBoundingClientRect();
    const field = mesh.ownerSVGElement.getBoundingClientRect();
    layout = {
      bounds: { left: bounds.left, right: bounds.right, top: bounds.top, bottom: bounds.bottom },
      field: { left: field.left, top: field.top, width: field.width, height: field.height },
      pageWidth: root.clientWidth
    };
    layoutDirty = false;
    version++;
    prepared = null;
    needsFrame = true;
    if (engine) engine.configure(layout);
  }

  function apply(frame) {
    if (frame.geometry) {
      frame.geometry.paths.forEach((data, i) => { if (data) paths[i].setAttribute("d", data); });
      frame.geometry.highlights.forEach((data, i) => highlights[i].setAttribute("d", data));
    }
    frame.colours.forEach((colour, i) => stops[i].setAttribute("stop-color", colour));
    for (const style of glowStyles) {
      style.setProperty("--wave-left", frame.glow[0]);
      style.setProperty("--wave-centre", frame.glow[1]);
      style.setProperty("--wave-right", frame.glow[2]);
    }
  }

  function useStaticFallback(error) {
    if (worker) worker.terminate();
    worker = null;
    pending = null;
    prepared = null;
    mode = "fallback-static";
    root.dataset.archiverseEffectiveMode = mode;
    engine = window.createArchiverseFabric();
    if (layout) engine.configure(layout);
    needsFrame = true;
    console.warn("ARCHIVERSE: wave worker unavailable; using stationary SVG lines.", error);
    wake();
  }

  if (mode === "worker" && typeof Worker === "function") {
    try {
      worker = new Worker(new URL("archiverse-fabric-worker.js", document.currentScript.src));
      worker.onmessage = ({ data }) => {
        if (!pending || pending.id !== data.id) return;
        const sent = pending;
        pending = null;
        if (suspended || layoutDirty || data.version !== version) return;
        prepared = data;
        if (profile) profile.workerResult(data.computeMs, performance.now() - sent.started);
        wake();
      };
      worker.onerror = event => { event.preventDefault(); useStaticFallback(event.message); };
      worker.onmessageerror = () => useStaticFallback("Unreadable worker response");
    } catch (error) { useStaticFallback(error); }
  } else {
    if (mode === "worker") mode = "fallback-static";
    engine = window.createArchiverseFabric();
  }
  root.dataset.archiverseEffectiveMode = mode;

  function wake() {
    if (!suspended && !animationFrame) animationFrame = requestAnimationFrame(tick);
  }

  function tick(timestamp) {
    animationFrame = 0;
    if (suspended) return;
    const started = profile ? performance.now() : 0;
    let applied = false, geometry = false;
    if (layoutDirty) readLayout();
    if (lastTimestamp) time += Math.min(timestamp - lastTimestamp, 100) / 1000;
    lastTimestamp = timestamp;

    if (prepared) {
      if (prepared.version === version) {
        geometry = Boolean(prepared.frame.geometry);
        apply(prepared.frame);
        applied = true;
      }
      prepared = null;
    }
    const reduced = motionPreference.matches;
    if ((needsFrame || (!reduced && timestamp - lastUpdate >= 1000 / 30)) && !pending) {
      const geometryTime = mode === "worker" && !reduced ? time : staticGeometryTime;
      const colourTime = reduced ? 0 : time;
      if (worker) {
        const id = ++requestId;
        // Only one frame is in flight. No queue of old frames can build up.
        const changedLayout = worker.layoutVersion !== version;
        pending = { id, started: profile ? performance.now() : 0 };
        worker.postMessage({ type: "frame", id, version, time: colourTime, geometryTime,
          layout: changedLayout ? layout : null, profile: Boolean(profile) });
        worker.layoutVersion = version;
      } else {
        const frame = engine.render(colourTime, geometryTime);
        geometry = Boolean(frame.geometry);
        apply(frame);
        applied = true;
      }
      needsFrame = false;
      lastUpdate = timestamp;
    }
    if (profile) profile.mainTick(performance.now() - started, applied, geometry);
    if (!reduced || pending || prepared || needsFrame) wake();
  }

  function markLayoutDirty() {
    layoutDirty = true;
    wake();
  }

  function syncMotion() {
    suspended = document.hidden || isFullscreen();
    root.toggleAttribute("data-decoration-suspended", suspended);
    cancelAnimationFrame(animationFrame);
    animationFrame = 0;
    lastTimestamp = 0;
    prepared = null;
    // An already running request may finish once; its result is discarded while paused.
    if (!suspended) {
      layoutDirty = true;
      needsFrame = true;
      wake();
    }
  }

  new ResizeObserver(markLayoutDirty).observe(playerFrame);
  addEventListener("resize", markLayoutDirty);
  addEventListener("scroll", markLayoutDirty, { passive: true });
  motionPreference.addEventListener("change", syncMotion);
  document.addEventListener("visibilitychange", syncMotion);
  document.addEventListener("fullscreenchange", syncMotion);
  document.addEventListener("webkitfullscreenchange", syncMotion);
  addEventListener("pagehide", () => {
    suspended = true;
    cancelAnimationFrame(animationFrame);
    animationFrame = 0;
  });
  addEventListener("pageshow", syncMotion);
  syncMotion();


  function showError(message) {
    console.error("ARCHIVERSE:", message);
    loadingScreen.hidden = true;
    errorScreen.hidden = false;
    fullscreenButton.disabled = true;
  }

  function updateProgress(progress) {
    const value = Math.min(100, Math.max(0, Math.round(progress * 100)));
    progressFill.style.width = `${value}%`;
    percentage.textContent = `${value}%`;
    progressBar.setAttribute("aria-valuenow", String(value));
  }

  function isFullscreen() {
    return Boolean(document.fullscreenElement || document.webkitFullscreenElement);
  }

  function syncFullscreenButton() {
    const expanded = isFullscreen();
    fullscreenButton.setAttribute("aria-pressed", String(expanded));
    fullscreenButton.setAttribute("aria-label", expanded ? "Вернуться к оконному режиму" : "Развернуть приложение на весь экран");
    fullscreenLabel.textContent = expanded ? "Свернуть" : "Развернуть";
  }

  function exitFullscreen() {
    if (unityInstance) unityInstance.SetFullscreen(0);
  }

  fullscreenButton.addEventListener("click", () => {
    if (!unityInstance) return;
    if (isFullscreen()) {
      exitFullscreen();
    } else {
      unityInstance.SetFullscreen(1);
      canvas.focus({ preventScroll: true });
    }
  });

  document.addEventListener("fullscreenchange", syncFullscreenButton);
  document.addEventListener("webkitfullscreenchange", syncFullscreenButton);
  document.addEventListener("fullscreenerror", () => { fullscreenButton.title = "Браузер не разрешил полноэкранный режим"; });
  document.getElementById("reload-button").addEventListener("click", () => window.location.reload());
  document.getElementById("fullscreen-return").addEventListener("click", exitFullscreen);

  if (!build) {
    showError("Build configuration is missing.");
    return;
  }

  build.config.showBanner = (message, type) => {
    if (type === "error") showError(message);
    else console.warn("ARCHIVERSE:", message);
  };

  const loader = document.createElement("script");
  loader.src = build.loaderUrl;
  loader.onerror = () => showError("Could not load the application loader.");
  loader.onload = () => {
    createUnityInstance(canvas, build.config, updateProgress)
      .then((instance) => {
        unityInstance = instance;
        if (profile) profile.setUnity(instance);
        updateProgress(1);
        loadingScreen.classList.add("is-complete");
        loadingScreen.setAttribute("aria-hidden", "true");
        fullscreenButton.disabled = false;
        viewport.setAttribute("data-ready", "true");
      })
      .catch(showError);
  };
  document.body.appendChild(loader);
})();
