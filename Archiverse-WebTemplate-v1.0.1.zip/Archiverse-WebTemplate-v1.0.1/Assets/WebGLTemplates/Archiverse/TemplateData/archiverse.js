(() => {
  "use strict";

  const canvas = document.getElementById("unity-canvas");
  const viewport = document.getElementById("unity-fullscreen-container");
  const playerFrame = document.querySelector(".player-frame");
  const fullscreenButton = document.getElementById("fullscreen-button");
  const fullscreenLabel = document.getElementById("fullscreen-label");
  const loadingScreen = document.getElementById("loading-screen");
  const errorScreen = document.getElementById("error-screen");
  const progressBar = document.getElementById("loading-progress");
  const progressFill = document.getElementById("loading-progress-fill");
  const percentage = document.getElementById("loading-percentage");
  const build = window.archiverseBuild;
  let unityInstance;

  const mesh = document.getElementById("flow-mesh");
  const flowGradient = document.getElementById("flow-colour");
  const flowPalette = [[49, 228, 161], [11, 152, 187], [54, 123, 255]];
  const flowColourStepSeconds = 2.8;
  const flowColourCycles = 3.5;
  flowGradient.setAttribute("gradientUnits", "userSpaceOnUse");
  flowGradient.setAttribute("x1", "0");
  flowGradient.setAttribute("x2", "1920");
  flowGradient.replaceChildren();
  const flowColourStops = Array.from({ length: 65 }, (_, i) => {
    const stop = document.createElementNS("http://www.w3.org/2000/svg", "stop");
    stop.setAttribute("offset", String(i / 64));
    flowGradient.appendChild(stop);
    return stop;
  });
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const fabricStrands = [];
  const fabricSamples = 81;
  const fabricStrandCount = 36;
  const fabricPeriod = 28;
  // Soften the existing deformation by another 20%, keeping the same centre.
  const fabricAmplitude = 65 * .7 * .8;
  let fabricTime = 0;
  let fabricFrame = 0;
  let lastFabricFrame = 0;
  let fabricLeftMargin = .25;
  let fabricRightMargin = .25;
  let fabricPositions = [];

  function createFabricPath(className) {
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("class", className);
    mesh.appendChild(path);
    return path;
  }

  for (let i = 0; i < fabricStrandCount; i++) {
    const distance = i / (fabricStrandCount - 1);
    const spacing = Math.pow(distance, .94);
    const depth = spacing * 2 - 1;
    const path = createFabricPath("flow-ribbon");
    path.style.opacity = String(.76 * Math.pow(1 - distance, 2.8));
    fabricStrands.push({ path, depth });
  }
  const fabricHighlights = [
    { path: document.querySelector(".flow-glow"), depth: fabricStrands[0].depth },
    { path: document.querySelector(".flow-spine:not(.flow-spine--secondary)"), depth: fabricStrands[0].depth },
    { path: document.querySelector(".flow-pulse"), depth: fabricStrands[3].depth },
    { path: document.querySelector(".flow-spine--secondary"), depth: fabricStrands[7].depth }
  ];

  function syncFabricLayout() {
    const bounds = playerFrame.getBoundingClientRect();
    const pageWidth = document.documentElement.clientWidth;
    fabricLeftMargin = Math.max(.001, bounds.left / pageWidth);
    fabricRightMargin = Math.max(.001, 1 - bounds.right / pageWidth);
    const positions = Array.from({ length: fabricSamples }, (_, i) => i / (fabricSamples - 1));
    // Extra samples keep the visible fan smooth even beside a nearly full-width player.
    for (let i = 0; i <= 16; i++) {
      positions.push((100 + 1920 * fabricLeftMargin * i / 16) / 2120);
      positions.push((100 + 1920 * (1 - fabricRightMargin * i / 16)) / 2120);
    }
    fabricPositions = [...new Set(positions)].sort((a, b) => a - b);
    drawFabric(fabricTime);
  }

  function fabricColumn(position, phase) {
    const angle = position * Math.PI * 2;
    const angleSlope = Math.PI * 2 / 2120;
    const x = -100 + position * 2120;
    const screenPosition = Math.max(0, Math.min(1, x / 1920));
    const onLeft = screenPosition < .5;
    const visibleWidth = 1920 * (onLeft ? fabricLeftMargin : fabricRightMargin);
    const edgeDistance = (onLeft ? screenPosition : 1 - screenPosition) * 1920 / visibleWidth;
    const expansion = Math.min(1, edgeDistance);
    // Use the full visible margin for a gentler expansion towards the player.
    const taper = .2 + .8 * expansion ** 3 * (expansion * (expansion * 6 - 15) + 10);
    const expansionSlope = edgeDistance > 0 && edgeDistance < 1 ? (onLeft ? 1 : -1) / visibleWidth : 0;
    const taperSlope = .8 * 30 * expansion ** 2 * (expansion - 1) ** 2 * expansionSlope;
    const wave = .72 * Math.sin(angle * 2.2 - phase * .75)
      + .22 * Math.sin(angle * 3.8 + phase * .48 + .6)
      + .06 * Math.sin(angle * 5.4 - phase * .35);
    const waveSlope = angleSlope * (
      .72 * 2.2 * Math.cos(angle * 2.2 - phase * .75)
      + .22 * 3.8 * Math.cos(angle * 3.8 + phase * .48 + .6)
      + .06 * 5.4 * Math.cos(angle * 5.4 - phase * .35)
    );
    const spread = 42 + 5 * Math.cos(phase * .45);
    return {
      x,
      y: 260 + fabricAmplitude * taper * wave,
      ySlope: fabricAmplitude * (taperSlope * wave + taper * waveSlope),
      width: spread * taper,
      widthSlope: spread * taperSlope,
      flow: angle * .8 - phase * .36,
      flowSlope: angleSlope * .8
    };
  }

  function fabricPoint(column, depth) {
    // Redistribute the gaps smoothly while preserving the order of every strand.
    const breathing = .08 * (1 - depth * depth);
    const flowingDepth = depth + breathing * Math.sin(column.flow + depth * 2.2);
    const depthSlope = breathing * Math.cos(column.flow + depth * 2.2) * column.flowSlope;
    return [
      column.x,
      column.y + column.width * flowingDepth,
      column.ySlope + column.widthSlope * flowingDepth + column.width * depthSlope
    ];
  }

  function smoothFabricPath(points) {
    let path = `M ${points[0][0].toFixed(3)} ${points[0][1].toFixed(3)}`;
    for (let i = 0; i < points.length - 1; i++) {
      const current = points[i];
      const next = points[i + 1];
      const handle = (next[0] - current[0]) / 3;
      // Analytic tangents give adjoining cubic Beziers the same slope at every join.
      path += ` C ${(current[0] + handle).toFixed(3)} ${(current[1] + current[2] * handle).toFixed(3)}`
        + ` ${(next[0] - handle).toFixed(3)} ${(next[1] - next[2] * handle).toFixed(3)}`
        + ` ${next[0].toFixed(3)} ${next[1].toFixed(3)}`;
    }
    return path;
  }

  function drawFlowColours(time) {
    const colours = flowColourStops.map((stop, i) => {
      const colourPosition = (time / flowColourStepSeconds + i / (flowColourStops.length - 1) * flowColourCycles * flowPalette.length) % flowPalette.length;
      const colourIndex = Math.floor(colourPosition);
      const blend = .5 - .5 * Math.cos((colourPosition - colourIndex) * Math.PI);
      const from = flowPalette[colourIndex];
      const to = flowPalette[(colourIndex + 1) % flowPalette.length];
      const channels = from.map((value, channel) => value + (to[channel] - value) * blend);
      stop.setAttribute("stop-color", `rgb(${channels.map(value => value.toFixed(2)).join(",")})`);
      return channels;
    });
    function colourAt(screenPosition) {
      const position = Math.max(0, Math.min(1, screenPosition)) * (colours.length - 1);
      const left = Math.min(colours.length - 2, Math.floor(position));
      const right = left + 1;
      const blend = position - left;
      return colours[left].map((value, channel) => (value + (colours[right][channel] - value) * blend).toFixed(2)).join(" ");
    }
    const style = document.documentElement.style;
    style.setProperty("--wave-left", colourAt(fabricLeftMargin));
    style.setProperty("--wave-centre", colourAt(.5));
    style.setProperty("--wave-right", colourAt(1 - fabricRightMargin));
  }

  function drawFabric(time) {
    drawFlowColours(time);
    const phase = time * Math.PI * 2 / fabricPeriod;
    const columns = fabricPositions.map(position => fabricColumn(position, phase));
    for (const strand of fabricStrands) {
      strand.path.setAttribute("d", smoothFabricPath(columns.map(column => fabricPoint(column, strand.depth))));
    }
    for (const highlight of fabricHighlights) {
      highlight.path.setAttribute("d", smoothFabricPath(columns.map(column => fabricPoint(column, highlight.depth))));
    }
  }

  function animateFabric(timestamp) {
    fabricFrame = requestAnimationFrame(animateFabric);
    if (!lastFabricFrame) lastFabricFrame = timestamp;
    const elapsed = timestamp - lastFabricFrame;
    if (elapsed < 1000 / 30) return;
    fabricTime += Math.min(elapsed, 100) / 1000;
    lastFabricFrame = timestamp;
    drawFabric(fabricTime);
  }

  function syncFabricMotion() {
    cancelAnimationFrame(fabricFrame);
    lastFabricFrame = 0;
    if (reducedMotion.matches) {
      drawFabric(0);
    } else if (!document.hidden && !isFullscreen()) {
      fabricFrame = requestAnimationFrame(animateFabric);
    }
  }

  syncFabricLayout();
  syncFabricMotion();
  new ResizeObserver(syncFabricLayout).observe(playerFrame);
  window.addEventListener("resize", syncFabricLayout);
  reducedMotion.addEventListener("change", syncFabricMotion);
  document.addEventListener("visibilitychange", syncFabricMotion);
  document.addEventListener("fullscreenchange", syncFabricMotion);
  document.addEventListener("webkitfullscreenchange", syncFabricMotion);

  function showError(message) {
    console.error("ARCHIVERSE:", message);
    loadingScreen.hidden = true;
    errorScreen.hidden = false;
    fullscreenButton.disabled = true;
  }

  function updateProgress(progress) {
    const value = Math.min(100, Math.max(0, Math.round(progress * 100)));
    progressFill.style.width = `${value}%`;
    percentage.textContent = `${value}%`;
    progressBar.setAttribute("aria-valuenow", String(value));
  }

  function isFullscreen() {
    return Boolean(document.fullscreenElement || document.webkitFullscreenElement);
  }

  function syncFullscreenButton() {
    const expanded = isFullscreen();
    fullscreenButton.setAttribute("aria-pressed", String(expanded));
    fullscreenButton.setAttribute("aria-label", expanded ? "Вернуться к оконному режиму" : "Развернуть приложение на весь экран");
    fullscreenLabel.textContent = expanded ? "Свернуть" : "Развернуть";
  }

  function exitFullscreen() {
    if (unityInstance) unityInstance.SetFullscreen(0);
  }

  fullscreenButton.addEventListener("click", () => {
    if (!unityInstance) return;
    if (isFullscreen()) {
      exitFullscreen();
    } else {
      unityInstance.SetFullscreen(1);
      canvas.focus({ preventScroll: true });
    }
  });

  document.addEventListener("fullscreenchange", syncFullscreenButton);
  document.addEventListener("webkitfullscreenchange", syncFullscreenButton);
  document.addEventListener("fullscreenerror", () => { fullscreenButton.title = "Браузер не разрешил полноэкранный режим"; });
  document.getElementById("reload-button").addEventListener("click", () => window.location.reload());
  document.getElementById("fullscreen-return").addEventListener("click", exitFullscreen);

  if (!build) {
    showError("Build configuration is missing.");
    return;
  }

  build.config.showBanner = (message, type) => {
    if (type === "error") showError(message);
    else console.warn("ARCHIVERSE:", message);
  };

  const loader = document.createElement("script");
  loader.src = build.loaderUrl;
  loader.onerror = () => showError("Could not load the application loader.");
  loader.onload = () => {
    createUnityInstance(canvas, build.config, updateProgress)
      .then((instance) => {
        unityInstance = instance;
        updateProgress(1);
        loadingScreen.classList.add("is-complete");
        loadingScreen.setAttribute("aria-hidden", "true");
        fullscreenButton.disabled = false;
        viewport.setAttribute("data-ready", "true");
      })
      .catch(showError);
  };
  document.body.appendChild(loader);
})();
